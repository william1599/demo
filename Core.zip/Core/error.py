# -*- coding: utf-8 -*-
"""
Created on Mon Apr 19 10:50:38 2021

@author: imap0
"""
from comm import Communication
def error(mensaje):
    # Funcion que se corre cuando se detecta un error
    print(str(mensaje))