from flask import request
import config
import util


import requests
import json
from datetime import datetime
from datetime import timezone




class Communication:
    class __Communication:
        def __init__(self, token):
            print("INIT COMM")
            self.token = token
            self.headers = {"Authorization":"Bearer "+self.token}

    _instance = None

    
    def __init__(self, token = None):
        print("INIT COMM")
        if not Communication._instance and token!= None:
            Communication._instance = Communication.__Communication(token)

    
    def __getattr__(self, name):
        return getattr(self._instance, name)
        

    def creaModelo(self,configuracion):
        #print("creaModelo INI")
        dt = datetime.now()     
        utc_time = dt.replace(tzinfo = timezone.utc)
        modelo = {
            "nombre":"MD-"+configuracion["training_settings"]["nombre"],
            "estado": "CREADO",#por defecto se crea en estado "CREADO"
            "idconf":configuracion["training_settings"]["idconf"],
            "fecha":utc_time.isoformat(),
            "stop":False,
            "trained_epochs":0
        }
        try:
            response = requests.post(config.URL_MODELSMANAGER+"/modelo/", headers=self.headers,data=modelo)
            response.raise_for_status()
            #print("creaModelo END")
            return response.json()["dato"],None
        except BaseException as e:
            print("Warning (creaModelo): %s" % repr(e))
            return None,e    

    def createModelVariables(self, idmodelo, datos, isOutput):
        print("## Create model variables")
        try: 
            response = requests.put(config.URL_MODELSMANAGER+"/variablesprediccion/modelo/"+str(idmodelo), 
                                    headers=self.headers, 
                                    json=datos, 
                                    params= isOutput)
            response.raise_for_status()
            return None
            #return response.json()["dato"], None
        except BaseException as e:
            print("Warning (creaVariables): %s" % repr(e))
            return None, e

    def creaModelo_new(self,architecture, configuracion):
        #print("creaModelo_new INI")
        dt = datetime.now()     
        utc_time = dt.replace(tzinfo = timezone.utc)
        print("La configuracion en crearModelo es: ", configuracion)
        modelo = {
            "nombre":"MD-"+configuracion["modelo"],
            "id_architecture": architecture["extra"]["id_architecture"],
            "estado": "CREADO",#por defecto se crea en estado "CREADO"
            "idconf":configuracion["idconf"],
            "fecha":utc_time.isoformat(),
            "stop":False,
            "trained_epochs":0,
            "idservicio":architecture["extra"]["idservicio"]
        }
        try:
            response = requests.put(
                config.URL_MODELSMANAGER+"/modelo/", 
                headers=self.headers,
                data=modelo)
            response.raise_for_status()
            #print("creaModelo_new END")
            return response.json()["dato"],None
        except BaseException as e:
            print("Warning (creaModelo_new): %s" % repr(e))
            return None,e    



    def getModelo(self,idmodelo):
        #print("getModelo INI")
        try:
            #print("URL:"+config.URL_TRAINMANAGER+"/modelo/"+str(idmodelo))
            response = requests.get(
                config.URL_MODELSMANAGER+"/modelo/"+str(idmodelo),
                headers=self.headers)
            response.raise_for_status()
            modelo = response.json()["dato"]
            #print("getModelo END")
            return modelo,None
        except BaseException as e:
            print("Warning (getModelo): %s" % repr(e))
            return None,e

    def editaModelo(self,idmodelo, nuevoModelo):
        #print("editaModelo INI")
        try:
            print("URL:"+config.URL_MODELSMANAGER+"/modelo/"+str(idmodelo))
            response = requests.put(
                config.URL_MODELSMANAGER+"/modelo/"+str(idmodelo),
                headers=self.headers,
                data=nuevoModelo)
            response.raise_for_status()
            modelo = response.json()["dato"]
            #print("editaModelo END")
            return modelo,None
        except BaseException as e:
            print("Warning (editaModelo): %s" % repr(e))
            return None,e
        

    def getConf(self,id_config):
        #print("getConf INI")
        try:
            response = requests.get(
                config.URL_MODELSMANAGER+"/trainconf/"+str(id_config),
                headers=self.headers)
            response.raise_for_status()
            temp = response.json()["dato"]        
            #print("getConf END")
            return temp,None
        except BaseException as e:
            print("Warning (getConf): %s" % repr(e))
            return None,e

    def getForecastConfig(self, idconfig):
        #print("getForecastConfig INI")
        try:
            response = requests.get(
                config.URL_FORECASTMANAGER+"/predicion/configuracion/"+idconfig,
                headers=self.headers)
            response.raise_for_status()
            temp = response.json()["dato"]        
            #print("getForecastConfig END")
            return temp,None
        except BaseException as e:
            print("Warning (getForecastConfig): %s" % repr(e))
            return None,e

    def getForecast(self, idforecast):
        try:
            response = requests.get(
                config.URL_FORECASTMANAGER+"/prediccion/" + str(idforecast),
                headers=self.headers
            )
            response.raise_for_status()
            temp = response.json()["dato"]
            return temp, None
        except BaseException as e:
            print("Warning (getForecast): %s" % repr(e))
            return None, e

    def getArquitectura(self,id_architecture):
        #print("getArquitectura INI")
        try:
            response = requests.get(
                config.URL_ARQUITECTURESMANAGER+"/arquitectura/"+str(id_architecture),
                headers=self.headers)
            response.raise_for_status()
            temp = response.json()["dato"]        
            #print("getArquitectura END")
            return temp,None
        except BaseException as e:
            print("Warning (getArquitectura): %s" % repr(e))
            return None,e
        
    def equipos(self, id_linea_produccion):
        
        payload = { 'param': 'idequipo', 'descending': 'true', 'idlineaproduccion': '1' }
        try:
            response = requests.get(config.URL_ADMINMANAGER+"/equipo", params = payload)
            response.raise_for_status()
            print(response.json()["datos"])
            temp = response.json()["datos"]
            listaEquipos = []
            for equipo in temp:
                parametrosEquipo = []
                print("\n")
                valores = list(equipo['parametros'].values())
                parametrosEquipo.append(valores)
                listaEquipos.append(parametrosEquipo)
            
            print(listaEquipos)
            
            return temp, None
        except BaseException as e:
            print("Warning (getEquipos): %s" % repr(e))
            return None, e

    def getCollection(self,id_coll):
        #print("getCollection INI")
        #print("Solicitando coleccion "+str(id_coll))    
        try:
            response = requests.get(
                config.URL_COLLECTIONMANAGER+"/coleccion/"+str(id_coll),
                headers=self.headers)
            response.raise_for_status()
            temp = response.json()["dato"]        
            #print("getCollection END")
            return temp, None
        except BaseException as e:
            print("Warning (getCollection): %s" % repr(e))
            return None, e

    def getFilterCollection(self, id_fc):

        try:
            response = requests.get(
                config.URL_COLLECTIONMANAGER+"/coleccionfiltrada/cf/"+str(id_fc),
                headers=self.headers)
            response.raise_for_status()
            temp = response.json()["dato"]
            return temp, None
        except BaseException as e:
            print("Warning (getFilterCollection): %s" % repr(e)) 
            return None, e
        

    def setEstadoAvance(self,id_modelo, estado):
        #print("setEstadoAvance INI")
        obj = {"trained_epochs":estado}
        #print("El avance del entrenamiento es: ", estado)
        try:
            response = requests.put(
                config.URL_MODELSMANAGER+"/train/status/"+str(id_modelo)+"?trained_epochs="+str(estado),
                headers=self.headers)
            response.raise_for_status()
            #print("setEstadoAvance END")
            return response.json()
        except BaseException as e:
            print("Warning (setEstadoAvance): %s" % repr(e))
            return False
        

    def setResults(self,idmodelo, resultado):
        #print("setResults INI")
        objeto = {
            "idmodelo":idmodelo,
            "resultado":resultado
        }
        #print(objeto)
        try:
            response = requests.post(
                config.URL_MODELSMANAGER+"/train/result",
                headers=self.headers,
                json = objeto)
            response.raise_for_status()
            #print("setResults END")
            return response.json()
        except BaseException as e:
            print("Warning (setResults): %s" % repr(e))
            print(response.json())
            return False
        



    def upsert_layer(self,info):
        #print("upsert_layer INI")  
        #print(info)  
        try:
            response = requests.post(
                config.URL_ARQUITECTURESMANAGER+"/tipocapa",
                headers=self.headers,
                json = info)
            response.raise_for_status()
            #print("upsert_layer END")
            return response.json()
        except BaseException as e:
            print("Warning (upsert_layer): %s" % repr(e))
            return False


    def append_log(self,idmodelo, fila, valores):
        #print("append_log INI")
        #print("ESTOY EN EL APPEND LOG")
        #print(valores)
        data = {"idmodelo": idmodelo, "fila":fila, "valor":valores, "batch": valores[1], "cost_train": valores[2], "cost_test": valores[3]}
        try:
            response = requests.post(
                config.URL_MODELSMANAGER+"/train/result", 
                headers=self.headers,
                data=data)
            response.raise_for_status() 
            #print("append_log END")
            return response.json()
        except BaseException as e:
            print("Warning (append_log): %s" % repr(e))
            return False


    #def get_forecast_config(self,idconfig):
    #    #print("get_forecast_config INI")
    #    #print("Solicitando coleccion "+str(id_coll))    
    #    try:
    #        response = requests.get(
    #            config.URL_TRAINMANAGER+"/coleccion/"+str(id_coll),
    #            headers=self.headers)
    #        response.raise_for_status()
    #        temp = response.json()["dato"]        
    #        #print("get_forecast_config END")
    #        return temp, None
    #    except BaseException as e:
    #        print("Warning (getCollection): %s" % repr(e))
    #        return None, e


    def crear_forecast(self,idforecast_config, idservicio, nombre, idmodelo):
        forecast = {
            "fecha": datetime.now().isoformat(),
            "forecast": None,
            "idforecast_config": idforecast_config,
            "idservicio" : idservicio,
            "nombre" : nombre,
            "estado": config.ESTADOS.CREADO,
            "idmodelo": idmodelo,
            "comentarios": "Sin comentarios"
        }
        print(forecast)
        try:
            response = requests.post(
                config.URL_FORECASTMANAGER+"/prediccion",
                headers=self.headers,
                json=forecast)
            response.raise_for_status()
            #print(response.json())
            temp = response.json()["dato"]        
            #print("save_forecast END")
            return temp, None
        except BaseException as e:
            print("Warning (save_forecast): %s" % repr(e))
            return None, e

    def update_forecast(self, forecast, idforecast):
        print("update_forecast INI")
        # print(forecast)
        try:
            response = requests.put(
                config.URL_FORECASTMANAGER+"/prediccion/"+str(idforecast),
                headers=self.headers,
                json=forecast)
            response.raise_for_status()
            #print(response.json())
            temp = response.json()["dato"]        
            #print("save_forecast END")
            return temp, None
        except BaseException as e:
            print("Warning (update_forecast): %s" % repr(e))
            return None, e

    def create_outputs(self, output_dict):
        try:
            response = requests.post(
                config.URL_FORECASTMANAGER+"/prediccion",
                headers=self.headers,
                json=output_dict
            )
            response.raise_for_status()
            temp = response.json()["dato"]
            return temp, None
        except BaseException as e:
            print("Warning (create_outputus): %s" % repr(e))
            return None, e

    def save_forecast(self, datos, idforecast_config, idservicio, nombre):
        print("save_forecast INI")
        forecast = {
            "fecha": datetime.now().isoformat(),
            "forecast": dict(datos),
            "idforecast_config": idforecast_config,
            "idservicio" : idservicio,
            "nombre" : nombre,
            "estado": config.ESTADOS.CREADO
        }
        print(forecast)
        try:
            response = requests.post(
                config.URL_FORECASTMANAGER+"/prediccion",
                headers=self.headers,
                json=forecast)
            response.raise_for_status()
            #print(response.json())
            temp = response.json()["dato"]        
            #print("save_forecast END")
            return temp, None
        except BaseException as e:
            print("Warning (save_forecast): %s" % repr(e))
            return None, e

    def update_servicio(self, servicio, idservicio):
        print("update_servicio INI")
        print(servicio)
        try:
            response = requests.put(
                config.URL_ADMINMANAGER+"/servicio/"+str(idservicio),
                headers=self.headers,
                json=servicio)
            response.raise_for_status()
            #print(response.json())
            temp = response.json()["dato"]        
            #print("save_forecast END")
            return temp, None
        except BaseException as e:
            print("Warning (update_servicio): %s" % repr(e))
            return None, e


    def bulk_insert_acumulado(self, planificacion):
        print("bulk_insert_acumulado INI")
        print(planificacion)
        try:
            response = requests.post(
                config.URL_ADMINMANAGER+"/acumulado",
                headers=self.headers,
                json=planificacion)
            response.raise_for_status()
            #print(response.json())
            temp = response.json()["dato"]        
            #print("save_forecast END")
            return temp, None
        except BaseException as e:
            print("Warning (bulk_insert_acumulado): %s" % repr(e))
            return None, e

    def get_last_acumulado(self):
        print("get_last_acumulado INI")
        
        try:
            response = requests.get(
                config.URL_ADMINMANAGER+"/acumulado/last",
                headers=self.headers)
            response.raise_for_status()
            #print(response.json())
            temp = response.json()["dato"]        
            #print("get_last_acumulado END")
            return temp, None
        except BaseException as e:
            print("Warning (get_last_acumulado): %s" % repr(e))
            return None, e


