# -*- coding: utf-8 -*-
"""
Created on Tue Apr  6 16:40:44 2021

@author: imap0
"""




import random
import comm
import config
import util
#from Core.model_tools.normalizador import inicializar_normalizador

import json
import getopt
import sys
import time
import os
from datetime import datetime 
from datetime import timezone
import traceback



from importar_datos import carga_de_datos
import os
import pandas as pd
from model_tools.model_class import model
import tensorflow as tf
import model_tools.data_operations as dp
import numpy as np






class Forecast:
    def __init__(self, path, token, modelPath, id_forecast_config):        
        self.path = path
        self.modelPath = modelPath
        self.predictionsPath = "/predictions/"        
        self.modelo = None
        self.idforecast = None
        self.comm = comm.Communication(token)

        #data_folder = path + SEP + "importar_datos"+SEP
        
        


        #TODO: poner todas las rutas de los archivos en un objeto "archivos"

        # Guardaremos la historia acumulada en  importar_datos/database/nombre_data_acumulada
        self.nombre_data_acumulada = self.modelPath + self.predictionsPath + "production_data_acumulado.csv"
        # Guardamos la historia acumulada más la planificacion en importar_datos/database/nombre_data_acumulada_planificacion
        self.nombre_data_acumulada_planificacion= self.modelPath + self.predictionsPath + "production_data_acumulado_planificado.csv" # esta es la historia con la planificacion al final, lo utilizaremos para predecir
        self.fecha_ultima_op = self.modelPath + self.predictionsPath + "production_data_acumulado_fecha_ultima_op.txt"
        #historia de produccion hasta ahora
        self.control_de_piso_archivo_nombre=config.DATA_FOLDER+"producción 2019 a 2020.xlsx"

        #Informacion de los rodillos
        self.info_rodillos_nombre=config.DATA_FOLDER+"/info_rodillos.xlsx"

        #Informacion de mantenimiento
        #self.mantenimiento_nombre=config.DATA_FOLDER+"Mapeo rodillo LP700A.xlsx"
        self.mantenimiento_nombre=""

        #Nueva produccion
        #self.archivo_de_produccion_nueva=config.DATA_FOLDER+"nueva_produccion.xlsx" #así se llamará el archivo en la carpeta excel
        self.archivo_de_produccion_nueva = ""

        #Produccion planificada
        #self.archivo_de_planificacion_nueva=config.DATA_FOLDER+"planificacion.xlsx" #así se llamará el archivo en la carpeta excel
        self.archivo_de_planificacion_nueva = ""


        self.data_produccion_remanente_ciclos_de_vida = "data_produccion_remanente_ciclos_de_vida.csv"

        # Eliminamos la historia anterior para partir de cero, lo hago por debbug
        #try:
        #    os.remove(self.nombre_data_acumulada)
        #except:
        #    print("No existe historia previa")

        self.start(id_forecast_config)

    
    def set_nombre_data_acumulada(self, nombre_data_acumulada):
        self.nombre_data_acumulada = nombre_data_acumulada

    def set_nombre_data_acumulada_planificacion(self, nombre_data_acumulada_planificacion):
        self.nombre_data_acumulada_planificacion = nombre_data_acumulada_planificacion

    def set_control_de_piso_archivo_nombre(self, control_de_piso_archivo_nombre):
        self.control_de_piso_archivo_nombre = control_de_piso_archivo_nombre

    def set_info_rodillos_nombre(self, info_rodillos_nombre):
        self.info_rodillos_nombre = info_rodillos_nombre
    
    def set_mantenimiento_nombre(self, mantenimiento_nombre):
        self.mantenimiento_nombre = mantenimiento_nombre
    
    def set_archivo_de_produccion_nueva(self, archivo):
        self.archivo_de_produccion_nueva = archivo

    def set_archivo_de_planificacion_nueva(self, archivo):
        self.archivo_de_planificacion_nueva = archivo


    def generar_datos_produccion(self, primera):

        #"Eliminamos la historia anterior para partir de cero, lo hago por debbug"
        #try:
        #    os.remove(self.nombre_data_acumulada)
        #except:
        #    print("No existe historia previa")
            

        #Se guardan el historico completo de datos
        #Se tienen datos hasta el 2020-12-15
        if primera: 
            try:           
                carga_de_datos.guardar_data_produccion(self.control_de_piso_archivo_nombre,
                                                self.nombre_data_acumulada,
                                                verificar_superposicion=True)
            except Exception as e:                
                raise Exception("###Error al guardar datos de control de piso") from e
            


        #"pedimos los datos de producción desde del mes de diciembre para agregarlos al actual, estos son los nuevos datos de producción y debe haber sobrelape"
        #archivo_de_produccion_nueva="nueva_produccion.xlsx" #así se llamará el archivo en la carpeta excel
        #carga_de_datos.generar_datos_produccion(self.control_de_piso_archivo_nombre,
        #                                        fecha_de_inicio="2020_12_01",
        #                                        fecha_de_fin="2021_01_01",
        #                                        nombre_salida=self.archivo_de_produccion_nueva,
        #                                        carga="estandar")


        #"pedimos los datos de planificacion la primera semana de enero"
        #carga_de_datos.generar_datos_produccion(self.control_de_piso_archivo_nombre,
        #                                        fecha_de_inicio="2021_1_02",
        #                                        fecha_de_fin="2021_01_07",
        #                                        nombre_salida=self.archivo_de_planificacion_nueva,
        #                                        carga=self.carga_planificacion)
        # el programa dira que no hay superposicion, esto se debe a un error dado que los datos generados son aleatoreos, esto no ocurrira con datos reales

    def guardar_datos(self):
        
        "Guardamos los datos de produccion"
        try:
            fecha1 = carga_de_datos.guardar_data_produccion(self.archivo_de_produccion_nueva,
                                            self.nombre_data_acumulada,
                                            verificar_superposicion=True) # IMPORTANTE, CAMBIAR A TRUE CUANDO TRABAJEMOS CON DATA REAL

        except Exception as e:
            print(e)
            raise Exception("###Error al guardar datos de nueva producción") from e
        #Guardamos los datos de planificacion

        #si se pasó un archivo de planificación
        if self.archivo_de_planificacion_nueva != "":
            try:
                fecha2 = carga_de_datos.guardar_data_produccion(self.archivo_de_planificacion_nueva,
                                                self.nombre_data_acumulada,
                                                self.nombre_data_acumulada_planificacion,
                                                verificar_superposicion=False,# No se verifica superposicion de los datos ya que no existe
                                                tipo_de_data="planificacion")
            except Exception as e:
                raise Exception("###Error al guardar datos de planificación") from e
        
        #En caso contrario
        else:
            production_data_acumulado_antigua = None
            try:
                production_data_acumulado_antigua=pd.read_csv(self.nombre_data_acumulada)
            except Exception as e:
                raise Exception("###No se pudo abrir la base de datos de producción al cargar la planificación") from e
            production_data_acumulado_antigua.to_csv(self.nombre_data_acumulada_planificacion,index=False)
        


        return fecha1 or fecha2



    def crear_dataset(self):
        #Creamos el dataset que puede leer el modelo
        try:
            self.entrada_rodillos,self.existen_fallas=carga_de_datos.crear_dataset_evaluacion(self.info_rodillos_nombre,self.mantenimiento_nombre,self.nombre_data_acumulada_planificacion)
        except Exception as e:
            print(e)
            raise Exception("###Error al preparar dataset de evaluación") from e
        
        # entrada_rodillos es una lista de dataframes con las historias de todos los rodillos excepto los que no tienen fallas previas


    def etl_para_entradas(self, dataframe_entrada):        
        columnas_a_eliminar=["Nombre Rodillo","Material","Recurso","Fecha de creación","Diametro Eje","Largo Rodillo",
                            "KILOS ENTRADA","SALDO (KGS)","DESECHO (KGS)","Kilos Totales Op","Desarrollo","Espesor"] 

        data_produccion_entrada=dataframe_entrada.drop(columnas_a_eliminar,axis=1)
        output_dims=[len(data_produccion_entrada)]+self.modelo.parameters['input_data_dict'][1]["data_dims"]
        dummy_labels=np.zeros(shape=output_dims)

        dummy_labels=pd.DataFrame(dummy_labels,columns=self.modelo.parameters['input_data_dict'][1]["data_columns"])
        data=[data_produccion_entrada,dummy_labels]
        data_name = []

        for input_data in self.modelo.parameters['input_data_dict']:
            data_name.append(input_data['data_name'])

        input_data_dict,dataset_dict=dp.create_dataset_dictionaries(data,data_name)
        return input_data_dict,dataset_dict


    def predecir(self, forecast_obj):
        # Recorremos los rodillos
        salidas=[]
        kilos_producidos_por_entrada=[]
        outPutLayer = None
        for entrada in self.entrada_rodillos:
            kilos_producidos=entrada["Kilos Acumulados Desde Reparación"] # Se extrae lo producido del dataset de entrada
            kilos_producidos_por_entrada.append(kilos_producidos)
            input_data_dict,dataset_dict=self.etl_para_entradas(entrada)
            dataset_dict_norm=self.modelo.normalize(dataset_dict)
            model_output_norm=self.modelo.evaluate_with_names(self.modelo.parameters['salida'], dataset_dict_norm) # Valores brutos en formato de array

            # SE BUSCA EL LAYER DE COST PARA OBTENER LA COLECCION DE SALIDA
            for layers in self.modelo.parameters['layers_architecure']:
                if(layers['cost_string']):
                    outPutLayer = layers['labels']
           
            # ahora creamos un diccionario y desnormalizamos al mismo tiempo con  model.denormalize_model_output
            # dataset name es el formato de dataset que se desea copiar para crear el diccionario
            model_output_dict=self.modelo.denormalize_model_output(model_output_norm,dataset_name=outPutLayer)
            salidas.append(model_output_dict)

        salidas_formato_manuel={"variable":["abreviatura","nombre","kilos_remanentes","porcentaje","valido"],
                                "cabeceras":["Abreviatura","Nombre Rodillo","Kilos remanentes a la falla","Porcentaje de vida útil remanente","Rodillo valido"],
                                "tipo":["text","text","number","number","boolean"],
                                "datos":[]}
        
        for i in range(len(salidas)):
            data=salidas[i]["data"]
            kilos_producidos=kilos_producidos_por_entrada[i][len(kilos_producidos_por_entrada[i])-1]
            abreviatura = util.abreviatura(self.entrada_rodillos[i]["Nombre Rodillo"][0])

            nombre_rodillo=self.entrada_rodillos[i]["Nombre Rodillo"][0]
            
            kilos_remanentes_a_la_falla=data.tolist()[-1][0]
            # se calcula el porcentaje y se agrega a la salida
            porcentaje_de_vida=100*(kilos_remanentes_a_la_falla)/(kilos_remanentes_a_la_falla+kilos_producidos)

            tiene_falla = True
            nombre_encontrado=False
            for tiene_falla_data in self.existen_fallas.values:
                nombre=tiene_falla_data[0]
                if nombre==nombre_rodillo:
                    tiene_falla=tiene_falla_data[2] == "Con Fallas"
                    nombre_encontrado=True
                    break
            if nombre_encontrado==False:
                raise Exception("###No se encontro el nombre del rodillo en la lista de los rodillos con y sin falla")

            salidas_formato_manuel["datos"].append([abreviatura,nombre_rodillo,kilos_remanentes_a_la_falla, porcentaje_de_vida,tiene_falla])
            
        #7.- Armo objeto a guardar
        #resp , error = self.comm.save_forecast(salidas_formato_manuel, self.id_forecast_config, self.idservicio,self.forecast_config["nombre"])
        
        dato = {
            "forecast": dict(salidas_formato_manuel),
            "estado":config.ESTADOS.TERMINADO
        }
        resp , error = self.comm.update_forecast(dato, forecast_obj["idforecast"])
        if error:
            raise Exception("###No se pudo guardar la predicción")
        else:
            # Guardamos las salidas        
            #json_object = json.dumps(salidas_formato_manuel)
            #with open('salidas.txt', 'w') as outfile:
            #    json.dump(json_object, outfile)
            return resp

        
    def read_fecha_ultima_op(self):
        self.fecha_ultima_op



    def get_data_from_DB(self, id_forecast_config):
        self.id_forecast_config = id_forecast_config
        data = {}
        #1.- obtener configuracion del forecast con id_config (✓)
        data["forecast_config"],error = self.comm.getForecastConfig(id_forecast_config)
        self.forecast_config = data["forecast_config"]
        if error:
            raise Exception("###"+str(error))
        

        #2.- obtener colecciones definidas en input de la condfiguracion de forecast
        if("inputs" not in data["forecast_config"].keys()):            
            raise Exception("###No se paso 'inputs' en la configuracion")
        

        #3.- obtener modelo con el idmodelo
        data["modelo"], error = self.comm.getModelo(data["forecast_config"]["idmodelo"])
        if error:            
            raise Exception("###"+str(error))
        

        #4.- obtener la configuracion del modelo
        data["train_conf"], error = self.comm.getConf(data["modelo"]["idconf"])
        if error:
            raise Exception("###"+str(error))
        
        self.idservicio = data["train_conf"]["idservicio"]
        self.idmodelo = data["forecast_config"]["idmodelo"]

        #5.- obtener arquitectura (leer del parameters.json? o lo descrito en la base de datos?)  
        arquitectura, error = self.comm.getArquitectura(data["train_conf"]["id_architecture"])
        if error:
            raise Exception("###"+str(error))

        data["transform_architecture"] = util.transform_conf(arquitectura)
        return data

    def prepare_error_message(self):
        formatted_lines = traceback.format_exc().splitlines()
        i = 1
        message = ""
        for line in formatted_lines:
            if config.DEBUG:
                message+= f"{line}\n"
            elif "###" in line and "raise" not in line:
                formated = line.replace("Exception: ###","")
                if message != "":
                    message += " Lo que originó: \n"
                message+= f"{formated}\n"
                i+=1
                
        return message

    def start(self, id_forecast_config):
        #recuperar configuracion 
        try:
            forecast_data = self.get_data_from_DB(id_forecast_config)
        except Exception as e:
            error_forecast = {
                "estado": config.ESTADOS.ERROR,
                "mensaje_error" : self.prepare_error_message()
            }
            #self.comm.update_forecast(error_forecast, forecast_obj["idforecast"])
            return None, error

        #crear forecast 
        forecast_obj, error = self.comm.crear_forecast(self.id_forecast_config, self.idservicio,self.forecast_config["nombre"], self.idmodelo)
        if error:
            error_forecast = {
                "estado": config.ESTADOS.ERROR,
                "mensaje_error" : str(error)
            }
            self.comm.update_forecast(error_forecast, forecast_obj["idforecast"])
            return None, error
            



        print('fore data')
        print(forecast_data)

       

        #obtener colecciones (✓) 
        collections = forecast_data["forecast_config"]["inputs"]
        archivos = {}
        for key in collections.keys():
            if str(collections[key]).isnumeric():
                collection,err = self.comm.getCollection(collections[key])
                #archivos.append({key:collection})
                archivos[key] = collection

        #setear datos subidos por el usuario
        self.set_archivo_de_produccion_nueva(archivos["historial_produccion"]["ruta"])
        self.set_mantenimiento_nombre(archivos["historial_mantenimiento"]["ruta"])
        if("planificacion" in archivos.keys()):
            self.set_archivo_de_planificacion_nueva(archivos["planificacion"]["ruta"])


        #instanciar modelo
        tf.reset_default_graph()
        nombre_modelo = util.make_model_name(forecast_data["modelo"])
        print("Abriendo modelo: "+nombre_modelo)
        try:
            self.modelo = model.load_model_mix(self.path, nombre_modelo, forecast_data["train_conf"], forecast_data["transform_architecture"], forecast_data["modelo"]["idmodelo"])
        except Exception as error:
            error_forecast = {
                "estado": config.ESTADOS.ERROR,
                "mensaje_error" : self.prepare_error_message()
            }
            self.comm.update_forecast(error_forecast, forecast_obj["idforecast"])
            return None, error


        #se fija si es la primera vez que se esta haciendo una prediccion para este problema
        #TODO: confirmar si id==1 realmente es generico
        try:
            self.generar_datos_produccion(forecast_obj["idforecast"]==1)
        except Exception as error:
            error_forecast = {
                "estado": config.ESTADOS.ERROR,
                "mensaje_error" : self.prepare_error_message()
            }
            self.comm.update_forecast(error_forecast, forecast_obj["idforecast"])
            return None, error
        
        try:
            fecha_ultima_op = self.guardar_datos()
        except Exception as e:
            error_forecast = {
                "estado": config.ESTADOS.ERROR,
                "mensaje_error" : self.prepare_error_message()
            }
            resp = self.comm.update_forecast(error_forecast, forecast_obj["idforecast"])
            return None, error

        if fecha_ultima_op != None:
            if( isinstance(fecha_ultima_op, type(datetime.now()) ) ):
                fecha_ultima_op = fecha_ultima_op.isoformat()
            servicio = {
                "extra":{
                    "fecha_ultima_op": fecha_ultima_op
                }
            }
            resp = self.comm.update_servicio(servicio, self.idservicio)
        
            

        try:
            self.crear_dataset()
        except Exception as e:
            error_forecast = {
                "estado": config.ESTADOS.ERROR,
                "mensaje_error" : self.prepare_error_message()
            }
            self.comm.update_forecast(error_forecast, forecast_obj["idforecast"])
            return None, error
        try:
            forecast = self.predecir(forecast_obj)
        except Exception as e:
            error_forecast = {
                "estado": config.ESTADOS.ERROR,
                "mensaje_error" : self.prepare_error_message()
            }
            self.comm.update_forecast(error_forecast, forecast_obj["idforecast"])
            return None, error

        return "OK", None




def ayuda(fuente):
    print(fuente)
    print("Ejecutar: \n \t 'python forecast_main.py -i id_forecast_config -p path -t token'")
        
# if __name__ == '__main__':
#     id_forecast_config = None
#     path = None
#     token = None
#     modelPath = None
#     try:        
#         opts, args = getopt.getopt(sys.argv[1:],"hi:p:t:a:",["id=","path=","token=", "modelPath="])
#     except getopt.GetoptError:
#         ayuda("Error en getopt")
#         sys.exit(2)
#     for opt, arg in opts:
#         if opt == '-h':
#             ayuda("Ayuda: ")
#             sys.exit()
#         elif opt in ("-i", "--id"):            
#             id_forecast_config = arg
#         elif opt in ("-p","--path"):            
#             path = arg
#         elif opt in ("-t","--token"):            
#             token = arg
#         elif opt in ("-a","--modelPath"):
#             print("AAAAAA LEYENDO ARG")
#             modelPath = arg
#             print(modelPath)
   
#     if id_forecast_config==None or path==None:
#         ayuda("No se paso un id de forecast config")
#         sys.exit()

#     #en caso que hubiera un grafo anterior, este se resetea        
#     tf.compat.v1.reset_default_graph()
#     forecast = Forecast(path, token, modelPath)    
#     salida, error = forecast.start(id_forecast_config)

#     if error:   
#         print("La aplicacion ha terminado con error: "+str(error))
#         sys.exit(-1)
    



