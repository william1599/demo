# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 18:25:23 2020

@authors: 
  Philip
  Manuel

"""
import random
import comm
import config
import util

import json

import getopt
import sys
import time
import os
from datetime import datetime 
from datetime import timezone

import tensorflow as tf
import pandas as pd
import numpy as np
#from matplotlib import pyplot as plt
from model_tools.layer_lib import layers,layer_info
from model_tools.model_class import model
from importar_datos import carga_de_datos
import model_tools.data_operations as dp
sep = os.path.sep


class Forecast:
    def __init__(self, path, token):        
        self.path = path        
        self.modelo = None
        self.comm = comm.Communication(token)

        # Guardaremos la historia acumulada en  importar_datos/database/nombre_data_acumulada
        self.nombre_data_acumulada="production_data_acumulado.csv"
        # Guardamos la historia acumulada más la planificacion en importar_datos/database/nombre_data_acumulada_planificacion
        self.nombre_data_acumulada_planificacion="production_data_acumulado_planificado.csv" # esta es la historia con la planificacion al final, lo utilizaremos para predecir

        #historia de produccion hasta ahora
        self.control_de_piso_archivo_nombre="produccion 2019 a 2020.xlsx"

        #Informacion de los rodillos
        self.info_rodillos_nombre="info_rodillos.xlsx"

        #Informacion de mantenimiento
        self.mantenimiento_nombre="Mapeo rodillo LP700A.xlsx"

        #Nueva produccion
        self.archivo_de_produccion_nueva="nueva_produccion.xlsx" #así se llamará el archivo en la carpeta excel

        #Produccion planificada
        self.archivo_de_planificacion_nueva="planificacion.xlsx" #así se llamará el archivo en la carpeta excel

        # Eliminamos la historia anterior para partir de cero, lo hago por debbug
        try:
            os.remove("importar_datos"+os.sep+"database"+os.sep+nombre_data_acumulada)
        except:
            print("No existe historia previa")

    def set_nombre_data_acumulada(self, nombre_data_acumulada):
        self.nombre_data_acumulada = nombre_data_acumulada

    def set_nombre_data_acumulada_planificacion(self, nombre_data_acumulada_planificacion):
        self.nombre_data_acumulada_planificacion = nombre_data_acumulada_planificacion

    def set_control_de_piso_archivo_nombre(self, control_de_piso_archivo_nombre):
        self.control_de_piso_archivo_nombre = control_de_piso_archivo_nombre

    def set_info_rodillos_nombre(self, info_rodillos_nombre):
        self.info_rodillos_nombre = info_rodillos_nombre
    
    def set_mantenimiento_nombre(self, mantenimiento_nombre):
        self.mantenimiento_nombre = mantenimiento_nombre
    
    def set_archivo_de_produccion_nueva(self, archivo_de_produccion_nueva):
        self.archivo_de_produccion_nueva = archivo_de_produccion_nueva

    def set_archivo_de_planificacion_nueva(self, archivo_de_planificacion_nueva):
        self.archivo_de_planificacion_nueva = archivo_de_planificacion_nueva

    def prep_data(self, carga_planificacion):
        
        
        "Se guardan el historico completo de datos"
        "Se tienen datos hasta el 2020-12-15"
        carga_de_datos.guardar_data_produccion(self.control_de_piso_archivo_nombre,self.nombre_data_acumulada)

        "pedimos los datos de produccion desde del mes de diciembre para agregarlos al actual, estos son los nuevos datos de produccion y debe haber sobrelape"
        #archivo_de_produccion_nueva="nueva_produccion.xlsx" #así se llamará el archivo en la carpeta excel
        carga_de_datos.generar_datos_produccion(self.control_de_piso_archivo_nombre,
                                                fecha_de_inicio="2020_12_01",
                                                fecha_de_fin="2021_01_01",
                                                nombre_salida=self.archivo_de_produccion_nueva,
                                                carga="estandar")


        "pedimos los datos de planificacion la primera semana de enero"
        carga_de_datos.generar_datos_produccion(self.control_de_piso_archivo_nombre,
                                                fecha_de_inicio="2021_1_02",
                                                fecha_de_fin="2021_01_07",
                                                nombre_salida=self.archivo_de_planificacion_nueva,
                                                carga=self.carga_planificacion)
        # el programa dira que no hay superposicion, esto se debe a un error dado que los datos generados son aleatoreos, esto no ocurrira con datos reales

        "Guardamos los datos de produccion"
        carga_de_datos.guardar_data_produccion(self.archivo_de_produccion_nueva,
                                            self.nombre_data_acumulada,
                                            verificar_superposicion=False) # IMPORTANTE, CAMBIAR A TRUE CUANDO TRABAJEMOS CON DATA REAL


        "Guardamos los datos de planificacion"
        carga_de_datos.guardar_data_produccion(self.archivo_de_planificacion_nueva,
                                            self.nombre_data_acumulada,
                                            self.nombre_data_acumulada_planificacion,
                                            verificar_superposicion=False)# No se verifica superposicion de los datos ya que no existe

        "Creamos el dataset que puede leer el modelo"

        self.entrada_rodillos=carga_de_datos.crear_dataset_evaluacion(self.info_rodillos_nombre,self.mantenimiento_nombre,self.nombre_data_acumulada_planificacion)
        # entrada_rodillos es una lista de dataframes con las historias de todos los rodillos excepto los que no tienen fallas previas



        
    def load_data(self, collections):
        input_data_dict = []
        data_dict = []

        for col in collections:            
            raw_data = self.load_file(col) 
            #raw_input_data_dict, raw_dataset_dict = util.etl_para_entradas(raw_data)           
            input_data_dict.append({"data_name": col["ruta"], "data_dims":raw_data[0].shape})
            data_dict.append({"data":raw_data,"data_name": col["ruta"], "data_dims":raw_data[0].shape})
            
        return input_data_dict, data_dict



    def load_file(self, collection_info):
        """
        dataframe=pd.read_csv(
            self.path
            +sep
            +config.RUTA_DATA
            +sep
            +config.RUTA_CLIENTES[collection_info["idempresa"]]
            +sep
            +collection_info["ruta"],
            header=collection_info["header"])
        """
        dataframe=pd.read_csv(collection_info["ruta"])

        #raw_data=dataframe.values
        #print(raw_data)
        return dataframe

    def start(self, id_config):
        #1.- obtener configuracion del forecast con id_config (✓)
        forecast_config,error = self.comm.getForecastConfig(id_config)

        if error :
            return None, error
        

        #2.- obtener colecciones definidas en input de la condfiguracion de forecast
        if("inputs" not in forecast_config.keys()):
            return None, "No se paso inputs en la configuracion"
        

        #3.- obtener modelo con el idmodelo
        modelo, error = self.comm.getModelo(forecast_config["idmodelo"])
        if error :
            return None, error
        

        #4.- obtener la configuracion del modelo
        train_conf, error = self.comm.getConf(modelo["idconf"])
        if error :
            return None, error

        print(json.dumps(train_conf,sort_keys=True, indent=4))
        

        #5.- obtener arquitectura (leer del parameters.json? o lo descrito en la base de datos?)  
        arquitectura, error = self.comm.getArquitectura(train_conf["id_architecture"])
        if error :
            return None, error
        

        transform_architecture = util.transform_conf(arquitectura)
        print(json.dumps(transform_architecture,sort_keys=True, indent=4))

        
        #6.- obtener colecciones (✓) 
        collections = forecast_config["inputs"]
        archivos = []
        for key in collections.keys():
            if str(collections[key]).isnumeric():
                collection,err = self.comm.getCollection(collections[key])
                archivos.append({key:collection})

        print(json.dumps(archivos,sort_keys=True, indent=4))
        

        
        capas = arquitectura["layers_architecure"]
        train_collections = [] 
        capa_counter = 0       
        for capa in capas:
            for i in capa["inputs"]:                
                for key in i:                    
                    if str(i[key]).isnumeric():                        
                        col,err = self.comm.getCollection(i[key])                        
                        transform_architecture["layers_architecure"][capa_counter][key] = col["ruta"].split("/")[-1]
                        print("("+transform_architecture["layers_architecure"][capa_counter][key]+")")
                        train_collections.append(col)

            capa_counter+=1

        print(json.dumps(train_collections,sort_keys=True, indent=4))

        TESTING = True
        if not TESTING:
            input_data_dict, dataset_dict = self.load_data(train_collections)
            train_conf["input_data_dict"] = input_data_dict
        
        

        nombre_modelo = util.make_model_name(modelo)
        print("Abriendo modelo: "+nombre_modelo)
        

        
        if not TESTING:
            #1.- Cargar modelo con nombre
            #2.- Unir colecciones de entrada
            colecciones = {}
            for key in forecast_config["inputs"].keys():
                if str(forecast_config["inputs"][key]).isnumeric():
                    col,err = self.comm.getCollection(forecast_config["inputs"][key])
                    #############################################################
                    #                                                           #
                    #    Reemplazar con lectura de archivos Excel de Philip     #
                    #                                                           #
                    #############################################################

                    #dataframe = pd.read_csv(
                    #            col["ruta"],
                    #            header=None)    
                    colecciones[key] = dataframe

            joined_data = colecciones["historial_produccion"]
            joined_data.append(colecciones["historial_mantenimiento"])
            joined_data.append(colecciones["planificacion"])

                    

            #3.- Ordenar por fecha
            #usar sort_values https://pandas.pydata.org/pandas-docs/version/0.18.1/generated/pandas.DataFrame.sort_values.html#pandas.DataFrame.sort_values


            #4.- Evaluar modelo con datos de entrada

            #5.- Guardo la salida de la evaluacion
            N_rodillos = 20 
            prediction = {
                "variable":["idelemento","nombre","metros_a_falla","kilos_a_falla", "porcentaje_metros","porcentaje_kilos"],
                "cabeceras":["Id Rodillo","Nombre","Metros remanentes","Kilos remanentes", "Porcentaje metros remanentes","Porcentaje kilos remanentes"],
                "tipo":["number", "string", "number", "number", "number", "number"],
                "datos":[]
            }

            i = 0
            while i < N_rodillos:
                tmp = [i, "Rodillo "+str(i), random.randrange(1000, 5000), random.randrange(1000, 5000), random.randrange(0,1000,1)/10, random.randrange(0,1000,1)/10] 
                prediction["datos"].append(tmp)
                i+=1
            
                

            #6.- Guardo el error
            error = random.randrange(1,1000)/10

            #7.- Armo objeto a guardar
            resp , error = self.comm.save_forecast(prediction, forecast_config["idconfig"], train_conf["idservicio"],forecast_config["nombre"])
            if error:
                print(error)
                return None, error
            else:
                print(json.dumps(resp,sort_keys=True, indent=4))
                return resp, None
        else:
            #nombre_modelo = "1_model"
            #trained_model=model.load_model_new(self.path, nombre_modelo, train_conf, transform_architecture, modelo["idmodelo"])
            trained_model = model.load_model_mix(self.path, nombre_modelo, train_conf, transform_architecture, modelo["idmodelo"])
            #trained_model=model.load_model(nombre_modelo)

            #puede ser "baja", "alta" o "estandar"
            self.prep_data("baja")

            # Recorremos los rodillos
            salidas=[]
            for entrada in self.entrada_rodillos:
                
                input_data_dict,dataset_dict=util.etl_para_entradas(entrada)
                
                dataset_dict_norm=trained_model.normalize(dataset_dict)
                
                model_output_norm=trained_model.evaluate_with_names('layer_output-fully_connected-layer_2',dataset_dict_norm) # Valores brutos en formato de array
                
                # ahora creamos un diccionario y desnormalizamos al mismo tiempo con  model.denormalize_model_output
                # dataset name es el formato de dataset que se desea copiar para crear el diccionario
                
                model_output_dict=trained_model.denormalize_model_output(model_output_norm,dataset_name="Vida_remanente_de_ciclo_de_vida") 
                salidas.append(model_output_dict)


            salidas_formato_manuel={"variables":["Nombre Rodillo","Kilos Remanentes"],
                        "cabeceras":["Nombre Rodillo","Kilos remanentes a la falla"],
                        "tipo":["number","array"],
                        "data":[]}
            for i in range(len(salidas)):
                data=salidas[i]["data"]
                nombre_rodillo=entrada_rodillos[i]["Nombre Rodillo"][0]
                salidas_formato_manuel["data"].append([nombre_rodillo,data.tolist()])


            
            json_object = json.dumps(salidas_formato_manuel)
            with open('salidas.txt', 'w') as outfile:
                json.dump(json_object, outfile)

    
            resp , error = self.comm.save_forecast(salidas_formato_manuel, forecast_config["idconfig"], train_conf["idservicio"],forecast_config["nombre"])
            if error:
                print(error)
                return None, error
            else:
                print(json.dumps(resp,sort_keys=True, indent=4))
                return resp, None
    

            """
            trained_model.create_test_train_val_sets(dataset_dict,train_size=0.9,test_size=0.09,val_size=0.01)       

            layer_output_names=trained_model.parameters["layer_output_names"]
            test_set=trained_model.dataset_dict_test
            train_set=trained_model.dataset_dict_train

            outputs_eval =       trained_model.evaluate_with_names(layer_output_names , trained_model.dataset_dict_train)
            outputs_eval_train = trained_model.evaluate_with_names(layer_output_names , trained_model.dataset_dict_train)
            outputs_eval_test =  trained_model.evaluate_with_names(layer_output_names , trained_model.dataset_dict_test)
            outputs_eval =       trained_model.evaluate_with_names(layer_output_names , dataset_dict)

            prediction = outputs_eval[2] #que es 2?
            error = outputs_eval[3] #que es 3?

            
            prediction_denorm = dp.denormalize_data_columns_2d(prediction,denormalize_labels_info)
            rul_labels_denorm = dp.denormalize_data_columns_2d(rul_labels,denormalize_labels_info)




            prediction_train=outputs_eval_train[2]
            labels_train=train_set[2]["data"]
            prediction_test=outputs_eval_test[2]
            labels_test=test_set[2]["data"]

            prediction_denorm_train = dp.denormalize_data_columns_2d(prediction_train,denormalize_labels_info)
            rul_labels_denorm_train = dp.denormalize_data_columns_2d(labels_train,denormalize_labels_info)

            prediction_denorm_test=dp.denormalize_data_columns_2d(prediction_test,denormalize_labels_info)
            rul_labels_denorm_test=dp.denormalize_data_columns_2d(labels_test,denormalize_labels_info)
            """
            dataset_dict_norm=trained_model.normalize(dataset_dict)
            model_output_norm=trained_model.evaluate_with_names('layer_output-fully_connected-layer_2',dataset_dict_norm) # Valores brutos en formato de array
            model_output_dict=trained_model.denormalize_model_output(model_output_norm,dataset_name="Vida_remanente_de_ciclo_de_vida") 

        

def ayuda(fuente):
    print(fuente)
    print("Ejecutar: \n \t 'python forecast_main.py -i id_forecast_config -p path -t token'")
        
if __name__ == '__main__':
    id_forecast_config = None
    path = None
    token = None
    try:        
        opts, args = getopt.getopt(sys.argv[1:],"hi:p:t:",["id=","path=","token="])
    except getopt.GetoptError:
        ayuda("Error en getopt")
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            ayuda("Ayuda: ")
            sys.exit()
        elif opt in ("-i", "--id"):
            print(arg)
            id_forecast_config = arg
        elif opt in ("-p","--path"):
            print(arg)
            path = arg
        elif opt in ("-t","--token"):
            print(arg)
            token = arg
   
    if id_forecast_config==None or path==None:
        ayuda("No se paso un id de forecast config")
        sys.exit()

    #en caso que hubiera un grafo anterior, este se resetea        
    tf.compat.v1.reset_default_graph
    forecast = Forecast(path, token)
    salida, error = forecast.start(id_forecast_config)
    if error:
        print("La aplicacion ha terminado con error: "+str(error))
        sys.exit(-1)


