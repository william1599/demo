# -*- coding: utf-8 -*-
"""
Created on Thu Dec 23 14:12:24 2021

@author: imap0
"""
from errors import EvaluateError, LoadDataError, LoadETLError, LoadEntryDataError, LoadModelError, OutputError
from errors import errors
import comm

import getopt
import sys
import config
import util
import json
import numpy as np


import os
import model_tools.model_class as model
import tensorflow as tf
# import matplotlib.pyplot as plt
from ETL import ETL
model=model.model


class QualityForecast:
    
    def __init__(self, path, token):
        self.path = path
        self.comm = comm.Communication(token)

    def getDataFromDB(self, idmodelo, idforecast):
        print("getDataFromDB")
        data = {}

        #-1.- Obtener forecast
        data["forecast"], error = self.comm.getForecast(str(idforecast))

        #0.- Obtener configuración del forecast con id
        data["forecast_config"], error = self.comm.getForecastConfig(str(data["forecast"]["idforecast_config"]))

        #1.- Obtener modelo con el idmodelo
        data["modelo"], error = self.comm.getModelo(str(idmodelo))
        if error:
            raise Exception("###" + str(error))

        #2.- Obtener config del modelo
        data["train_conf"], error = self.comm.getConf(data["modelo"]["idconf"])
        if error:
            raise Exception("###" + str(error))

        #3.- Obtener arquitectura
        arquitectura, error = self.comm.getArquitectura(data["modelo"]["id_architecture"])
        if error:
            raise Exception("###" + str(error))

        #4.- Se cambia formato de la architectura
        data["transform_architecture"] = util.transform_conf(arquitectura)


        return data


    def is_float(self, value):
        try:
            float(value)
            return True
        except:
            return False
    
    def start(self, idforecast, modelo, forecast, forecast_config):

        # Se guardan los datos en un diccionario
        try:
            forecast_data = {}
            forecast_data["forecast"] = forecast
            forecast_data["forecast_config"] = forecast_config
            forecast_data["modelo"] = modelo
            forecast_data["train_conf"] = modelo["training_config"]
            forecast_data["transform_architecture"] = util.transform_conf(modelo["architecture"])
        except:
            putForecastError(self, errors["LoadDataError"]["message"], idforecast)
            raise LoadDataError


        try:
            # Se obtiene la capa de salida
            for layers in forecast_data["transform_architecture"]["layers_architecure"]:
                if(layers['cost_string']):
                    outPutLayer = layers['labels']
                    inputTensorName = layers['input_tensor']

            # Se carga los ETL
            print(outPutLayer)
            print(inputTensorName)
            e=ETL(outPutLayer)
            e.set_path(self.path)
            e.cargar_metadatos_ETL()
            e.metadata_entrada # Información de la data requerida
        except:
            putForecastError(self, errors["LoadETLError"]["message"], idforecast)
            raise LoadETLError


        # Se transforman los datos a entero o float 
        for key in forecast_data["forecast_config"]["inputs"]:
            try:   
                if(self.is_float(forecast_data["forecast_config"]["inputs"][key])):
                    forecast_data["forecast_config"]["inputs"][key] = float(forecast_data["forecast_config"]["inputs"][key])    
                elif(isinstance(forecast_data["forecast_config"]["inputs"][key], int)):
                    forecast_data["forecast_config"]["inputs"][key] = int(forecast_data["forecast_config"]["inputs"][key])
                
                data_input_usuario = forecast_data["forecast_config"]["inputs"]

                # data_input_usuario={'Diametro Rodillo': 150,
                #                     "Kilos Acumulados Desde Reparacion": 11400}

                # se convierte el input de usuario en el formato del core
                e.convertir_input_usuario_en_dataset_dict(data_input_usuario)
                input_data_dict=e.input_data_dict
                dataset_dict=e.dataset_dict
                print("input_data_dict", input_data_dict)
                print("dataset_dict", dataset_dict)
                tf.reset_default_graph()
            except:
                putForecastError(self, errors["LoadEntryDataError"]["message"], idforecast)
                raise LoadEntryDataError
            


        try: 
            # Se construye el nombre del modelo para cargarlo.
            nombre_modelo = util.make_model_name(forecast_data["modelo"])

            # Se instancia el modelo
            model_1 = model.load_model_mix(self.path, nombre_modelo, forecast_data["train_conf"], forecast_data["transform_architecture"], forecast_data["modelo"]["idmodelo"])
        except:
            putForecastError(self, errors["LoadModelError"]["message"], idforecast)
            raise LoadModelError


        try:
            # Se normalizan los datos
            dataset_dict_norm=model_1.normalize(dataset_dict)

            # Se evaluan los valores normalizados
            salida_normalizada=model_1.evaluate_with_names(inputTensorName, dataset_dict_norm)

            # Se desnormalizan los valores
            print("VOY A DESNORMALIZAR VALORES")
            salida=model_1.denormalize_model_output(salida_normalizada, outPutLayer)["data"]
        except:
            putForecastError(self, errors["EvaluateError"]["message"], idforecast)
            raise EvaluateError

        try:
            # Se crea el diccionario de salida
            print("VOY A CREAR DICCIONARIO DE SALIDA")
            print(inputTensorName)
            print(outPutLayer)
            output_dictionary=model_1.create_output_dictionary(salida, outPutLayer)

            # Esto convierte la salida en un resultado amigable
            output_dictionary['data'] = json.dumps(output_dictionary['data'].tolist())

            # Aqui se actualiza el forecast en la DB con el estado y los resultados 
            dato = {
                "estado": config.ESTADOS.TERMINADO,
                "forecast": output_dictionary
            }

            # Se actualiza la prediccion en la base de datos
            #resp, error = self.comm.create_outputs(output_dictionary)
            resp, error = self.comm.update_forecast(dato, idforecast)
            print("output_dictionary")
            print(output_dictionary)    
        except:
            putForecastError(self, errors["OutputError"]["message"], idforecast)
            raise OutputError


def putForecastError(self, message, idforecast):
    error_forecast = {
        "estado": config.ESTADOS.ERROR,
        "mensaje_error": str(message)
    }
    resp, error = self.comm.update_forecast(error_forecast, idforecast)


def ayuda(fuente):
    print(fuente)
    print("Ejecutar: \n \t 'python forecast_main.py -i id_forecast_config -p path -t token'")

if __name__ == '__main__':

    path = None
    token = None
    idmodelo = None

    try:
        opts, args = getopt.getopt(sys.argv[1:], "hi:p:t:a:", ["id=", "path=", "token=", "idmodelo="])
    except getopt.GetoptError:
        ayuda("Error en getopt")
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            ayuda("Ayuuda: ")
            sys.exit()
        elif opt in ("-i", "--id"):
            print("id_forecast_config")
            print(arg)
            idforecast = arg
        elif opt in ("-p", "--path"):
            print(arg)
            path = arg
        elif opt in ("-t", "--token"):
            token = arg
        elif opt in ("-a", "--idmodelo"):
            idmodelo = arg
        
    qualityForecast = QualityForecast(path, token)
    qualityForecast.start(token, idmodelo, idforecast)

    print("ESTOY EN EL MAIN")



# # Datos de entrada
# path= os.getcwd()
# carpeta_datos="datos"
# nombre_datos="DatasetCreado.csv"
# if carpeta_datos=="":
#     ruta_datos=nombre_datos
# else:
#     ruta_datos=carpeta_datos+os.sep+nombre_datos


# nombre_etl="ETL2"

# e=ETL(nombre_etl)
# e.cargar_metadatos_ETL()


# Nombre_datos_de_entrada=["Entrada"] #Esto sale del modelo, todo lo que no se utiliza como salida

# e.metadata_entrada # Información de la data requerida

# data_input_usuario=[{"data_name":"Entrada",
#           'data_input_names': ['Sensor 1', 'Sensor 2', 'Temperatura Preferida'],
#           'data_input':[0.5,3,"Frio"]}]

# e.obtener_data_solicitada(Nombre_datos_de_entrada)

# print("Se requiere "+str(e.obtener_data_solicitada(Nombre_datos_de_entrada)["data_column_names"]))
# print("Que deben ser "+str(e.obtener_data_solicitada(Nombre_datos_de_entrada)["data_types"]))


# # Esta es el formato en el que entra la data que introduce el usuario
# data_input_usuario={'Sensor 1':0.5,
#                     "Sensor 2":0.1,
#                     "Temperatura Preferida":"Caliente"}

# # se convierte el input de usuario en el formato del core
# e.convertir_input_usuario_en_dataset_dict(data_input_usuario)



# input_data_dict=e.input_data_dict
# dataset_dict=e.dataset_dict


# tf.reset_default_graph()


# model_1=model.load_model("6_model")

# # Este es el uso tradicional de evaluación

# dataset_dict_norm=model_1.normalize(dataset_dict)

# # 'layer_output_fully_connected_layer_2' proviene del nombre de la capa de salida
# salida_normalizada=model_1.evaluate_with_names('layer_output_fully_connected_layer_2',dataset_dict_norm)

# salida=model_1.denormalize_model_output(salida_normalizada,"Salida")["data"]

# # Esto convierte la salida en un resultado amigable
# output_dictionary=model_1.create_output_dictionary(salida,"Salida")
# # ={'data': array([[8.05988011, 2.21264666]]),
# #      'data_name': 'Salida',
# #      'data_dims': [2],
# #      'data_columns': ['F 1', 'F 2']}




