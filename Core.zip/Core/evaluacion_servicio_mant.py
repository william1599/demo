# -*- coding: utf-8 -*-
"""
Created on Tue Apr  6 16:40:44 2021

@author: imap0
"""




import random
import comm
import config
import util
#from Core.model_tools.normalizador import inicializar_normalizador

import json
import getopt
import sys
import time
import os
from datetime import datetime 
from datetime import timezone
import traceback



from importar_datos import carga_de_datos
import os
import pandas as pd
from model_tools.model_class import model
import tensorflow as tf
import model_tools.data_operations as dp
import numpy as np






class Forecast:
    def __init__(self, path, token, modelPath):        
        self.path = path
        self.modelPath = modelPath
        self.predictionsPath = "/predictions/"        
        self.modelo = None
        self.idforecast = None
        self.comm = comm.Communication(token)

    def set_file_path(self, path):
        self.file_path = path


    def etl_para_entradas(self, dataframe_entrada):        
        columnas_a_eliminar=["Nombre Rodillo","Material","Recurso","Fecha de creación","Diametro Eje","Largo Rodillo",
                            "KILOS ENTRADA","SALDO (KGS)","DESECHO (KGS)","Kilos Totales Op","Desarrollo","Espesor"] 

        data_produccion_entrada=dataframe_entrada.drop(columnas_a_eliminar,axis=1)
        print('##########AAA')
        print(data_produccion_entrada)
        print('##########AAA')
        output_dims=[len(data_produccion_entrada)]+self.modelo.parameters['input_data_dict'][1]["data_dims"]
        dummy_labels=np.zeros(shape=output_dims)

        # AQUI TIRABA EL ERROR DEL DATACOLUMNS, SE VE EN EL TEST MAIN 
        dummy_labels=pd.DataFrame(dummy_labels,columns=self.modelo.parameters['input_data_dict'][1]["data_columns"])
        data=[data_produccion_entrada,dummy_labels]
        # ESTO SE SACA DEL PARAMETERS
        ######################################
        data_name = []

        for input_data in self.modelo.parameters['input_data_dict']:
            data_name.append(input_data['data_name'])


        #data_name=["845","846"]
        #print(data_name)
        ######################################
        input_data_dict,dataset_dict=dp.create_dataset_dictionaries(data,data_name)
        #dataset_dict = initialize_normalizer()
        return input_data_dict,dataset_dict


    def predecir(self, forecast_obj):
        print('Entre a predecir')
        # Recorremos los rodillos
        salidas=[]
        kilos_producidos_por_entrada=[]
        outPutLayer = None
        
        # Se lee el archivo
        entrada = pd.read_excel(self.file_path, engine='openpyxl')

        # Se quitan las columnas sin header
        remove_cols = [col for col in entrada.columns if 'Unnamed' in col]
        entrada.drop(remove_cols, axis='columns', inplace=True)

        # Se debe cambiar esto a la salida dinamica
        kilos_producidos=entrada["Kilos Acumulados Desde Reparación"] # Se extrae lo producido del dataset de entrada
        kilos_producidos_por_entrada.append(kilos_producidos)

        # Se debe cambiar la funcion etl para entradas a dinamico
        input_data_dict,dataset_dict=self.etl_para_entradas(entrada)
        dataset_dict_norm=self.modelo.normalize(dataset_dict)
        model_output_norm=self.modelo.evaluate_with_names(self.modelo.parameters['salida'], dataset_dict_norm) # Valores brutos en formato de array

        # SE BUSCA EL LAYER DE COST PARA OBTENER LA COLECCION DE SALIDA
        for layers in self.modelo.parameters['layers_architecure']:
            if(layers['cost_string']):
                outPutLayer = layers['labels']
        
        # ahora creamos un diccionario y desnormalizamos al mismo tiempo con  model.denormalize_model_output
        # dataset name es el formato de dataset que se desea copiar para crear el diccionario
        model_output_dict=self.modelo.denormalize_model_output(model_output_norm,dataset_name=outPutLayer)
        salidas.append(model_output_dict)

        salidas_formato_manuel={"variable":["abreviatura","nombre","kilos_remanentes","porcentaje","valido"],
                                "cabeceras":["Abreviatura","Nombre Rodillo","Kilos remanentes a la falla","Porcentaje de vida útil remanente","Rodillo valido"],
                                "tipo":["text","text","number","number","boolean"],
                                "datos":[]}
        
        data=salidas[0]["data"]
        # kilos_remanentes_a_la_falla  = json.dumps(data.tolist())
        data_aux = data.tolist()
        nombre_rodillo = entrada["Nombre Rodillo"].tolist()

        for i in range(len(data_aux)):
            abreviatura = util.abreviatura(nombre_rodillo[i])
            porcentaje_de_vida = 100 * (data_aux[i][0]) / (data_aux[i][0] + kilos_producidos[i])
            kilo_remanente = data_aux[i][0]
            salidas_formato_manuel["datos"].append([abreviatura, nombre_rodillo[i], kilo_remanente, porcentaje_de_vida])
        
        dato = {
            "forecast": dict(salidas_formato_manuel),
            "estado":config.ESTADOS.TERMINADO
        }
        resp , error = self.comm.update_forecast(dato, forecast_obj["idforecast"])
        if error:
            raise Exception("###No se pudo guardar la predicción")
        else:
            return resp

        
    def read_fecha_ultima_op(self):
        self.fecha_ultima_op



    def get_data_from_DB(self, id_forecast_config):
        self.id_forecast_config = id_forecast_config
        data = {}
        #1.- obtener configuracion del forecast con id_config (✓)
        data["forecast_config"],error = self.comm.getForecastConfig(id_forecast_config)
        self.forecast_config = data["forecast_config"]
        if error:
            raise Exception("###"+str(error))
        

        #2.- obtener colecciones definidas en input de la condfiguracion de forecast
        if("inputs" not in data["forecast_config"].keys()):            
            raise Exception("###No se paso 'inputs' en la configuracion")
        

        #3.- obtener modelo con el idmodelo
        data["modelo"], error = self.comm.getModelo(data["forecast_config"]["idmodelo"])
        if error:            
            raise Exception("###"+str(error))
        

        #4.- obtener la configuracion del modelo
        data["train_conf"], error = self.comm.getConf(data["modelo"]["idconf"])
        if error:
            raise Exception("###"+str(error))
        
        self.idservicio = data["train_conf"]["idservicio"]
        self.idmodelo = data["forecast_config"]["idmodelo"]

        #5.- obtener arquitectura (leer del parameters.json? o lo descrito en la base de datos?)  
        arquitectura, error = self.comm.getArquitectura(data["train_conf"]["id_architecture"])
        if error:
            raise Exception("###"+str(error))

        data["transform_architecture"] = util.transform_conf(arquitectura)
        #print(json.dumps(data["transform_architecture"],sort_keys=True, indent=4))
        
        return data

    def prepare_error_message(self):
        formatted_lines = traceback.format_exc().splitlines()
        i = 1
        message = ""
        for line in formatted_lines:
            if config.DEBUG:
                message+= f"{line}\n"
            elif "###" in line and "raise" not in line:
                formated = line.replace("Exception: ###","")
                if message != "":
                    message += " Lo que originó: \n"
                message+= f"{formated}\n"
                i+=1
                
        return message

    def start(self, id_forecast_config):

        #recuperar configuracion 
        try:
            forecast_data = self.get_data_from_DB(id_forecast_config)
        except Exception as error:
            error_forecast = {
                "estado": config.ESTADOS.ERROR,
                "mensaje_error" : self.prepare_error_message()
            }
            return None, error

        #crear forecast 
        forecast_obj, error = self.comm.crear_forecast(self.id_forecast_config, self.idservicio,self.forecast_config["nombre"], self.idmodelo)
        if error:
            error_forecast = {
                "estado": config.ESTADOS.ERROR,
                "mensaje_error" : str(error)
            }
            self.comm.update_forecast(error_forecast, forecast_obj["idforecast"])
            return None, error
            
        #obtener colecciones (✓) 
        collections = forecast_data["forecast_config"]["inputs"]
        archivos = {}
        for key in collections.keys():
            if str(collections[key]).isnumeric():
                collection,err = self.comm.getCollection(collections[key])
                #archivos.append({key:collection})
                archivos[key] = collection


        print("##ARCHIVOS###")
        print(archivos)
        print("##ARCHIVOS###")

        self.set_file_path(archivos["historial_produccion"]["ruta"])

        #instanciar modelo
        nombre_modelo = util.make_model_name(forecast_data["modelo"])
        print("Abriendo modelo: "+nombre_modelo)
        try:
            self.modelo = model.load_model_mix(self.path, nombre_modelo, forecast_data["train_conf"], forecast_data["transform_architecture"], forecast_data["modelo"]["idmodelo"])
        except Exception as error:
            error_forecast = {
                "estado": config.ESTADOS.ERROR,
                "mensaje_error" : self.prepare_error_message()
            }
            self.comm.update_forecast(error_forecast, forecast_obj["idforecast"])
            return None, error

        try:
            forecast = self.predecir(forecast_obj)
        except Exception as e:
            print('El error esta en predecir')
            print(e)
            error_forecast = {
                "estado": config.ESTADOS.ERROR,
                "mensaje_error" : self.prepare_error_message()
            }
            self.comm.update_forecast(error_forecast, forecast_obj["idforecast"])
            return None, error

        return "OK", None


def ayuda(fuente):
    print(fuente)
    print("Ejecutar: \n \t 'python forecast_main.py -i id_forecast_config -p path -t token'")
        
    



