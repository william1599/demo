# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 18:25:23 2020

@authors: 
  Philip
  Manuel

"""

print("################ COMENZANDO EJECUCION #################")
from importlib import resources
#from Core.errors import LoadETLError
import comm
import config
import util
# from flask import Flask, request
# from flask_restful import Resource, Api
# from flask_cors import CORS

import json

import getopt
import sys
import time
import os
from datetime import datetime 
from datetime import timezone
from ETL import ETL
from errors import LoadDataError, LoadETLError, NormalizeError, TrainError, generateModelError
from errors import errors
import ast

import tensorflow as tf
import pandas as pd
import numpy as np

#from matplotlib import pyplot as plt
from model_tools.layer_lib import layers,layer_info
from model_tools.model_class import model
import model_tools.data_operations as dp
sep = os.path.sep

errorList = {
    "entrenar": "<h4>Ha ocurrido un error al crear el modelo, considere lo siguiente: <br></h4><p>- Se debe ingresar una capa de costos y de salida a la arquitectura <br>- La capa de costos debe tener asociado un archivo en su etiqueta <br>- La primera capa debe recibir una colección como entrada <br><br>Si el problema persiste, contactar a un administrador</p>",
    "lectura": "<h4>Ha ocurrido un error al leer los archivos, considere lo siguiente: <br></h4><p>- El formato de los archivos debe ser .csv <br>- El formato de los datos no es el correcto <br>Si el problema persiste, contactar a un administrador</p>"
}

# app = Flask(__name__)
# api = Api(app)
# cors = CORS(app, resources={r"/train/*": {"origins": "*"}})


class Train():
    def __init__(self, path, token):
        print("INIT")
        self.path = path        
        self.modelo = None
        self.comm = comm.Communication(token) 
        
    def load_data(self, collections):
        #collections = [822]
        input_data_dict = []
        data_dict = []
        
        for col in collections:            
            raw_data, data_columns = self.load_file(col)
            input_data_dict.append({"data_name": str(col["idcoleccion"]), "data_dims":raw_data[0].shape, "data_columns": data_columns})
            data_dict.append({"data":raw_data,"data_name": str(col["idcoleccion"]), "data_dims":raw_data[0].shape, "data_columns": data_columns})

        return input_data_dict, data_dict

    def load_data_etl(self, filterCollections):
        print("ENTRE AL LOAD ETL")
        seleccion_columnas = {}

        for col in filterCollections:
            operacion_rangos = []
            informacion_tipos = {}
            informacion_tipos = col['etl']['Tipos']
            seleccion_columnas[str(col['idColeccionFiltrada'])] = col['etl']['Entrada']
            operacion_rangos = col['etl']['Rangos']
            nombre_etl = str(col['idColeccionFiltrada'])
            e = ETL(nombre_etl)
            e.set_path(self.path)

        print("seleccionColumnas: ", seleccion_columnas)
        e.inicializar_ETL(col['coleccions']['ruta'], operacion_rangos, seleccion_columnas, informacion_tipos)
        print("inputa_data_dict: ", e.input_data_dict)
        print("dataset_dict: ", e.dataset_dict)
        return e.input_data_dict, e.dataset_dict

    def load_file(self, collection_info):
        """
        dataframe=pd.read_csv(
            self.path
            +sep
            +config.RUTA_DATA
            +sep
            +config.RUTA_CLIENTES[collection_info["idempresa"]]
            +sep
            +collection_info["ruta"],
            header=collection_info["header"])
        """
        dataframe=pd.read_csv(collection_info["ruta"])
        raw_data=dataframe.values
        data_col = list(dataframe.columns)
        return raw_data, data_col

    def post(self):
        return { 'message': "DEVOLVI ALGO" }

    def get(self):
        self.comm = comm.Communication() 
        self.start(1, 2, 3)
        return { 'message': "DEVOLVI ALGO GET" }

    def start(self, id_config, first, idmodelo):
        print("ENTRE AL START DE TEST_MAIN.PY")
        print(idmodelo)

        modelo, error = self.comm.getModelo(int(idmodelo))

        if(error):
            print("Error en get modelo")
            self.comm.editaModelo(idmodelo,{"estado":"ERROR", "entrenando": False, "error": True, "tipo_error": str(error)})
            return None, error

        #1.- obtener configuracion con id_config (✓)
        conf,error = self.comm.getConf(id_config)        
        if error:
            print("Error en get config")
            self.comm.editaModelo(idmodelo,{"estado":"ERROR", "entrenando": False, "error": True, "tipo_error": str(error)})
            return None, error

        
        #1 y medio - obtener la arquitectura definida en la configuracion (✓)
        print("pidiendo arquitectura "+ str(conf["id_architecture"]))
        architecture,error = self.comm.getArquitectura(conf["id_architecture"])
        if error:
            self.comm.editaModelo(idmodelo,{"estado":"ERROR", "entrenando": False, "error": True, "tipo_error": str(error)})
            return None, error

        transform_architecture = util.transform_conf(architecture)

        #2.- obtener colecciones (✓)
        # 

        try:             
            capas = architecture["layers_architecure"]
            collections = []
            filterCollections = [] 
            capa_counter = 0       
            for capa in capas:
                for i in capa["inputs"]:                
                    for key in i:                    
                        if str(i[key]).isnumeric():                        
                            col, err = self.comm.getFilterCollection(i[key])
                            transform_architecture["layers_architecure"][capa_counter][key] = str(col["idColeccionFiltrada"])
                            collections.append(col["coleccions"])
                            filterCollections.append(col)
                capa_counter+=1
        except Exception as e:
            print("Cai en el error de los archivos")
            print("Error es: ", e)
            self.comm.editaModelo(idmodelo,{"estado":"ERROR", "entrenando": False, "error": True, "tipo_error": errors["LoadDataError"]["message"]})
            raise LoadDataError

        try:
            input_data_dict, dataset_dict = self.load_data_etl(filterCollections)
        except Exception as e:
            print("Error en load data")
            print("Error es: ", e)
            print("Exception: ", Exception)
            self.comm.editaModelo(idmodelo,{"estado":"ERROR", "entrenando": False, "error": True, "tipo_error": errors["LoadETLError"]["message"]})
            raise LoadETLError

        conf["input_data_dict"] = input_data_dict
                
        #3.- crear modelo con estado "CREADO" (✓)

        #en caso que hubiera un grafo anterior, este se resetea
        
            
        #tf.compat.v1.reset_default_graph
        model_1 = None
        #model_1=model(conf, transform_architecture, idmodelo)

        if(first == 'true'):
            print("\n\n\n\n ENTRE A CREAR MODELO NUEVO \n\n\n\n\n\n")
            try: 
                # Se crea el modelo (Se instancia)
                print('VOY A CREAR MODELO')
                #tf.compat.v1.reset_default_graph()
                tf.reset_default_graph()
                model_1=model(conf, transform_architecture, modelo["idmodelo"])
            except Exception as e:
                print("error en crear modelo")
                print(e)
                self.comm.editaModelo(idmodelo,{"estado":"ERROR", "entrenando": False, "error": True, "tipo_error": str(e)})
                raise generateModelError
            

            print("\n\n\n\n arriba la ID")
            if error != None:
                #sys.exit("Error:"+str(error))
                self.comm.editaModelo(idmodelo,{"estado":"ERROR", "entrenando": False, "error": True})
                return None, error
        else:
            print("\n\n\n\n ENTRE AL RE ENTRENAR MODELO \n\n\n\n\n\n")
            tf.reset_default_graph()
            model_1=model(conf, transform_architecture, int(first))
            try:
                
                modelo, error = self.comm.getModelo(int(first))
            except Exception as e:
                print('Error al re entrenar modelo')
                self.comm.editaModelo(idmodelo,{"estado":"ERROR", "entrenando": False, "error": True, "tipo_error": str(e)})
            print("SALI DEL RE ENTRENAR MODELO")



        model_1.set_comm(self.comm)
        model_1.set_path(self.path)

        try:
            # Manda a normalizar
            model_1.initialize_normalizer(dataset_dict, float(conf['lower_bound']), float(conf['upper_bound']))
        except Exception as e:
            print("Error en inicializar el normalizador")
            print(e)
            self.comm.editaModelo(idmodelo,{"estado":"ERROR", "entrenando": False, "error": True, "tipo_error": str(e)})
            raise NormalizeError
        
        try:
            dataset_dict_norm=model_1.normalize(dataset_dict)
        except Exception as e:
            print("Error al normalizar")
            self.comm.editaModelo(idmodelo,{"estado":"ERROR", "entrenando": False, "error": True, "tipo_error": str(e)})
            raise NormalizeError

        try: 
            # Comienza el entrenamiento
            model_1.train(dataset_dict_norm, conf['trainset'], conf['testset'])
        except Exception as e:
            print("error en entrenar modelo")
            print(e)
            self.comm.editaModelo(idmodelo,{"estado":"ERROR", "entrenando": False, "error": True, "tipo_error": "Error al iniciar entrenamiento. Verifique los parámetros ingresados. \nLa tasa de muestreo no puede ser cero."})
            raise TrainError
        

        nombre_modelo = util.make_model_name(modelo)
        model_1.save_model(nombre_modelo)
        newVersion = modelo["version"] + 1

        if(first == 'true'):
            self.comm.createModelVariables(idmodelo, filterCollections[0], {'isOutput': 'false'})
            self.comm.createModelVariables(idmodelo, filterCollections[-1], {'isOutput': 'true'})

        #self.comm.createModelVariables(idmodelo, filterCollections[0]['etl']['Entrada'])
        self.comm.editaModelo(first, { "version": newVersion })
        return None, None


def ayuda():
    print("Ejecutar: \n \t  'python test_main.py -i id_forecast_config -p path -t token'")