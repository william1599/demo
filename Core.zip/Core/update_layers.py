import inspect
import comm
import getopt
import sys

from model_tools.layer_lib import layers,layer_info


def ayuda():
    print("Ejecutar: \n \t  'python update_layers.py -t token'")

if __name__ == '__main__':    
    token = None   
    try:        
        opts, args = getopt.getopt(sys.argv[1:],"ht:",["token="])
    except getopt.GetoptError:
        ayuda()
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            ayuda()
            sys.exit()        
        elif opt in ("-t","--token"):            
            token = arg
    
    if token == None:
        ayuda()
        sys.exit()

    comm = comm.Communication(token) 


    for m in inspect.getmembers(layers, inspect.isclass):
        comm.upsert_layer(m[1].info)