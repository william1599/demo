import os
import sys
## la funcion que carga una funcion segun la ruta
def cargar_funcion(nombre_funcion,ruta_carpeta_funciones=os.path.abspath('')+os.sep+"funciones"):
    """
    nombre_funcion: string con el nombre del archivo .py y la función que se encuentra adentro de ese archivo
    ruta_carpeta_funciones: Ruta a la carpeta donde se encuentran las funciones, en este caso lo deje como la carpeta funciones que esta en este root
    se devuelve la 
    """
    print("Entre a cargar funcion")
    sys.path.insert(1, ruta_carpeta_funciones)
    ldict={}
    exec("""from {name} import {name}; funcion={name}""".format(name=nombre_funcion),globals(),ldict)
    funcion=ldict["funcion"]
    return funcion ##

# Cargamos la funcion especifica en la variable funcion
#funcion=cargar_funcion("hunter")

# establecemos el 
#diccionario_entrada={"archivo 1":"archivo_1.txt",
#                        "archivo 2":"archivo_2.csv"}
#funcion(diccionario_entrada)