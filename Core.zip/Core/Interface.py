# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 22:35:48 2020

@author: Philip
"""


from tkinter import *
from tkinter.ttk import *
from tkinter import ttk
import copy
import numpy as np
from Import_Data import MNIST
from model_tools.layer_lib import layers,layer_info

def gui(entry_data,entry_data_name,entry_data_dims):
    
    
    window1 = Tk()
    window1.title("Data")
    window1.geometry('500x400')
    data_input_combos=[]
    for i in range( 10):
            data_input_combos.append(Combobox(window1,state="readonly",values=entry_data_name))
            data_input_combos[i].grid(column=1, row=i+1)
            if i==0:data_input_combos[i].current(0)
            elif i==1: data_input_combos[i].current(1)
            elif i==2: data_input_combos[i].current(2)
            
            
            
    data_name=[]
    def got_to_layers():
        for i in range(10):
            current=data_input_combos[i].get()
            if current=="":
                continue
            data_name.append(data_input_combos[i].get())
        window1.destroy()
            
        
    next1_button=Button(window1,text="next>",command=got_to_layers)
    next1_button.grid(column=1, row=i+2)
    window1.mainloop()
    
    data_dims=[]
    data=[]
    for data_entry in data_name:
        index=entry_data_name.index(data_entry)
        current_dims=entry_data_dims[index]
        current_data=entry_data[index]
        data_dims.append(current_dims)
        data.append(current_data)
    
    
    """ 
    Layers Window
    """
    
    layer_settings_dict=layer_info.layer_settings_dictionary()
    layer_trainable_parameters_dict=layer_info.layer_trainable_parameters_dictionary()
    layer_input_tensors_dict=layer_info.layer_input_tensors_dictionary()
    
    layer_types = [func for func in dir(layers) if "_layer" in func]
    for i in range(len(layer_types)):
        layer_types[i]=layer_types[i].replace("_layer","")
    
    
    layer_windows=[]
    go_to_costs=False
    layer_n=0
    variables=copy.deepcopy(data_name)
    
    
    layer_architectures=[]
    trainable_parameters_names=[]
    layer_output_names=[]
    def set_layer():
        nonlocal layer_n
        layer_type_=layer_type_combo.get()
        setting_dict=dict(layer_type=layer_type_)
        for i in range(len(setting_widgets)):
            setting=layer_settings_dict[layer_type_][i][0]
            value=setting_widgets[i].get()
            if layer_settings_dict[layer_type_][i][1]=="float":
                #the seting is an int_value
                value=float(value)
            setting_dict.update([(setting,value)])
        for i in range(len(input_widgets)):
            input_name=layer_input_tensors_dict[layer_type_][i]
            value=input_widgets[i].get()
            
            setting_dict.update([(input_name,value)])
        
        layer_architectures.append(setting_dict)
        
        trainable_parameters_i=layer_trainable_parameters_dict[layer_type_]
        for parameter in trainable_parameters_i:
            trainable_parameters_names.append("trainable_parameter-"+layer_type_+"-layer_"+str(layer_n)+"-"+parameter)
        output_name="layer_output-"+layer_type_+"-layer_"+str(layer_n)
        layer_output_names.append(output_name)
        variables.append(output_name)
        
        
        
    
    
    def new_layer_f():
        nonlocal set_layer
        set_layer()
        nonlocal go_to_costs
        go_to_costs=False
        win.destroy()
    
    def go_to_cost_f():
        nonlocal set_layer
        set_layer()
        nonlocal go_to_costs
        win.destroy()
        
    def select_layer():
        nonlocal setting_widgets
        nonlocal setting_labels
        nonlocal input_labels
        nonlocal input_widgets
        
        
        for i in range(len(setting_widgets)):
            setting_labels[i].destroy()
            setting_widgets[i].destroy()
        current_type=layer_type_combo.get()
    #    current_type_index=layer_types.index(current_type)
        
        settings=layer_settings_dict[current_type]
        layer_input_tensors=layer_input_tensors_dict[current_type]
        current_row=3
        i=0
        
        input_widgets=[]
        input_labels=[]
        for input_tensor in layer_input_tensors:
            input_labels.append(Label(win,text=input_tensor))        
            input_widgets.append(Combobox(win,state="readonly",values=variables,width=40))
            
            input_widgets[i].grid(column=1,row=current_row+i)
            input_widgets[i].current(0)
            input_labels[i].grid(column=0,row=current_row+i)
            i=i+1
        current_row=current_row+i
        i=0
        setting_widgets=[]
        setting_labels=[]
        for setting in settings:
            setting_labels.append(Label(win,text=setting[0]))
            if setting[1]=="float":
                #the setting is an intiger
                setting_widgets.append(Spinbox(win, from_=1,to=1000000000000000, width=5))
                
            else:
                setting_widgets.append(Combobox(win,state="readonly",values=setting[1],width=40))
                setting_widgets[i].current(0)
            setting_widgets[i].grid(column=1,row=current_row+i)
            setting_labels[i].grid(column=0,row=current_row+i)
                
            i=i+1 
        
        new_layer_button=Button(win,text="Next Layer",command=new_layer_f)
        new_layer_button.grid(column=0,row=current_row+i)
        
        go_to_costs_button=Button(win,text="Finish and go to Costs",command=go_to_cost_f)
        go_to_costs_button.grid(column=1,row=current_row+i)
        
        
        
    while not go_to_costs:
        
        layer_windows.append(Tk())
        win=layer_windows[layer_n]
        win.title("Layer "+str(layer_n+1))
        win.geometry('500x400')
        
        
        layer_type_label=Label(win,text="Layer Type")
        layer_type_label.grid(column=0,row=1)
        layer_type_combo=Combobox(win,state="readonly",values=layer_types,width=40)
        layer_type_combo.grid(column=1,row=1)
        layer_type_button=Button(win,text="Ok",command=select_layer)
        layer_type_button.grid(column=2,row=1)
        
        setting_widgets=[]
        setting_labels=[]
        input_labels=[]
        input_widgets=[]
        go_to_costs=True
        win.mainloop()
        layer_n+=1
        
    
    input_data_dict=[]
    for i in range(len(data_name)):
        input_data_dict.append(dict(data=data[i],data_name=data_name[i],data_dims=data_dims[i]))
      
        
    cost_string=""
    def create_cost():
        nonlocal cost_string
        cost_string=insert_function_text.get("1.0","end-1c")
        cost_window.destroy()
        
        
    """Cost function"""
    if go_to_costs:
        cost_window=Tk()
        cost_window.title("Cost "+str(layer_n+1))
        cost_window.geometry('1200x400')
        
        frame=Frame(cost_window)
        
        cost_data_label=Label(frame,text="Data")
        cost_data_label.grid(column=0,row=0)
        data_list=[]
        for i in range(len(data_name)):
            data_list.append(Text(frame,height=1,borderwidth=0,width=40))
            data_list[i].insert(1.0,data_name[i])
            data_list[i].grid(column=0,row=1+i)
            data_list[i]["state"]="disabled"
        max_index=i
        
        cost_parameters_label=Label(frame,text="Parameters")
        cost_parameters_label.grid(column=2,row=0)
        outputs_list=[]
        for i in range(len(trainable_parameters_names)):
            outputs_list.append(Text(frame,height=1,borderwidth=0,width=60))
            outputs_list[i].insert(1.0,trainable_parameters_names[i])
            outputs_list[i].grid(column=2,row=1+i)
            outputs_list[i]["state"]="disabled"
        
            
        if i>max_index:max_index=i
        cost_outputs_label=Label(frame,text="Outputs")
        cost_outputs_label.grid(column=1,row=0)
        outputs_list=[]
        for i in range(len(layer_output_names)):
            outputs_list.append(Text(frame,height=1,borderwidth=0,width=50))
            outputs_list[i].insert(1.0,layer_output_names[i])
            outputs_list[i].grid(column=1,row=1+i)
            outputs_list[i]["state"]="disabled"
        
        if i>max_index:max_index=i
        frame.grid(column=0,row=0)
        insert_function_label=Label(cost_window,text="Insert Function:")
        insert_function_label.grid(column=0,row=max_index+1)
        insert_function_text=Text(cost_window,height=1,borderwidth=0,width=150)
        insert_function_text.grid(column=0,row=max_index+2)
        insert_function_button=Button(cost_window,text="Finish",command=create_cost)
        insert_function_button.grid(column=0,row=max_index+3)
        
        
        
        
        
        cost_window.mainloop() 
        
        
    
    return input_data_dict,layer_architectures,trainable_parameters_names,layer_output_names,cost_string
    
    
    