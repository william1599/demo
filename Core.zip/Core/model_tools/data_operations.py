# -*- coding: utf-8 -*-
"""
Created on Tue Jan 28 19:18:31 2020

@author: Philip
"""

import numpy as np
import sys
import copy
# import ujson

def sample(X,Y=None,N=1):
    """
    Randomly samples a batch of size N
    """
    N_data=np.size(X,0)
    if N>N_data:
        sys.exit("Not enough data to sample.\n Data Size="+str(N_data)+"\n Requested Data="+str(N))            
    indexes=np.random.choice(N_data,N,replace=False)
    if Y is None:
        return X[indexes,:]
    else: return X[indexes,:],Y[indexes,:]
    
    
def slice_train_test_validation(data_,train_size=0.6,test_size=0.2,val_size=0.2):
    """
    Slices the input data into train, test and validation sets
    """
    
    if train_size+test_size+val_size!=1.0:
        sys.exit("Train, test and validation sizes must add 1")
    
    N_data=np.size(data_,0)
    N_train=int(np.floor(N_data*train_size))
    N_test=int(np.floor(N_data*test_size))
    N_validation=int(np.floor(N_data*val_size))
    
    data_train=data_[0:N_train]
    data_test=data_[N_train:N_train+N_test]
    data_val=data_[N_train+N_test:N_train+N_test+N_validation]
    return data_train,data_test,data_val
def slice_data_series_as_window_with_labels(data,window_size,label_axis=0,label_stride=1):
    # Data Requirements:
    # axis 0 = time dimension
    # Inputs:   data
    #           window size
    #           label_axis, axis where the predicted label is
    #           label_stride, time steps between the edge of the window and the label (for time prediction models)
    
    T=len(data)
    n=T-label_stride-window_size
    data_windows=[]
    data_widnows_labels=[]
    for i in range(n):
        data_windows.append(data[i:i+window_size,:])
        data_widnows_labels.append([data[i+window_size+label_stride-1,label_axis]])
    
    return np.array(data_windows),np.array(data_widnows_labels)
    
def normalize_data_columns_2d(data,lower_bound=0,upper_bound=1):
    #normalizes the columns of a 2d data set between the lower bound and upper bound
    max_data=np.max(data,axis=0)
    min_data=np.min(data,axis=0)
    data_normalized=np.zeros(np.shape(data))
    for i in range(np.shape(data)[0]): # For every datapoint in the data
        for j in range(np.shape(data)[1]): # For every variable
            x=data[i,j]
            min_x=min_data[j]
            max_x=max_data[j]
            data_normalized[i,j]=(upper_bound-lower_bound)*((x-min_x)/(max_x-min_x))+lower_bound
    denormalize_2d_info=dict(max_data=max_data,
                         min_data=min_data,
                         upper_bound=upper_bound,
                         lower_bound=lower_bound)
    return data_normalized,denormalize_2d_info

def denormalize_data_columns_2d(data_normalized,denormalize_2d_info):
    #normalizes the columns of a 2d data set between the lower bound and upper bound
    max_data=denormalize_2d_info["max_data"]
    min_data=denormalize_2d_info["min_data"]
    upper_bound=denormalize_2d_info["upper_bound"]
    lower_bound=denormalize_2d_info["lower_bound"]
    data_denormalized=np.zeros(np.shape(data_normalized))
    for i in range(np.shape(data_normalized)[0]): # For every datapoint in the data
        for j in range(np.shape(data_normalized)[1]): # For every variable
            x_norm=data_normalized[i,j]
            min_x=min_data[j]
            max_x=max_data[j]
            data_denormalized[i,j]=(x_norm-lower_bound)*(max_x-min_x)/(upper_bound-lower_bound)+min_x
    return data_denormalized

            
def normalize_data_columns_3d(data,lower_bound=0,upper_bound=1):
    #normalizes the columns of a 3d data set between the lower bound and upper bound
    # for images and time series
    max_data=np.max(np.max(data,axis=0),axis=0)
    min_data=np.min(np.min(data,axis=0),axis=0)
    data_normalized=np.zeros(np.shape(data))
    for i in range(np.shape(data)[0]):
        for j in range(np.shape(data)[1]):
            for k in range(np.shape(data)[2]):
                x=data[i,j,k]
                min_x=min_data[k]
                max_x=max_data[k]
                data_normalized[i,j,k]=(upper_bound-lower_bound)*((x-min_x)/(max_x-min_x))+lower_bound
    return data_normalized
             
        
        
    
    
    

def batch_from_input_data_dict_v1(input_data_dict,batch_size=100):
    
    n_data=np.shape(input_data_dict[0]["data"])[0]
    
    indices=np.random.choice(n_data,batch_size)
    input_data_dict_batch=copy.deepcopy(input_data_dict)
    for i in range(len(input_data_dict)):
        input_data_dict_batch[i]["data"]=input_data_dict_batch[i]["data"][indices]
    return input_data_dict_batch
        
    
def batch_from_input_data_dict(input_data_dict,batch_size=100):
    n_data=np.shape(input_data_dict[0]["data"])[0]
    indices=np.arange(n_data)
    np.random.shuffle(indices)
    batch_indices = [indices[batch_size*i:batch_size*(i+1)] for i in range(int(np.floor(len(indices)/batch_size + 1)))]
    if batch_indices[-1].size==0:
        batch_indices=batch_indices[:-1]
        #remove the last batch if it is empty
    
    
    input_data_dict_batches=[]
    for batch_index in range(len(batch_indices)):
        batch_dict=[]
        for i in range(len(input_data_dict)):
            data_dictionary=dict(input_data_dict[i])
            indices=batch_indices[batch_index]
            data=input_data_dict[i]["data"]
            data_batch=data[indices]
            data_dictionary["data"]=data_batch
            batch_dict.append(data_dictionary)
        input_data_dict_batches.append(batch_dict)
        
    return input_data_dict_batches
def create_dataset_dictionaries(data_list,data_names_list):
    """

    Parameters
    ----------
    data_list : list
        List with dataframes.
    data_names_list : list
        list of strings with the names of the datasets.

    Returns
    -------
    input_data_dict: List of dictionaries
        Each dictionary contains name, dimensions, column names of the dataset
        Used for the creation of the model
    dataset_dict: List of dictionaries
        Each dictionary contains name, dataset, dimensions, column names of the dataset
        Used for training and evaluation
    """



    # Creo los diccionarios necesarios
    data_dims=[]
    for i in range(len(data_list)):
        data_dims.append(data_list[i].values[0].shape)
    
    input_data_dict=[]
    for i in range(len(data_names_list)): # diccionario que incluye la forma de los datos
        input_data_dict.append(dict(data_name=data_names_list[i],data_dims=data_dims[i],data_columns=data_list[i].columns.tolist())) #agregue a la informacion de las entradas los nombres de las columnas en formato de lista
    
    dataset_dict=[]# dicionario que incluye los datos
    for i in range(len(data_names_list)): 
        dataset_dict.append(dict(data=data_list[i].values,data_name=data_names_list[i],data_dims=data_dims[i],data_columns=data_list[i].columns.tolist()))

    return input_data_dict,dataset_dict

