# -*- coding: utf-8 -*-
"""
Funciones para normalizar
"""
import pandas as pd
import numpy as np
def inicializar_normalizador(dataset_dict,lower_bound=0,upper_bound=1):
    """
    lista_dataframes: lista que contiene los dataframes de los datos pd.DataFrame
    nombres_bases_de_datos: Lista que contiene los nombres de los datos
    lower_bound y upper_bound: limites entre los cuales se normaliza
    """
    normalize_info=dict()
    # normalized_data=[]
    for i in range(len(dataset_dict)):
        data=dataset_dict[i]["data"]
        nombre_data=dataset_dict[i]["data_name"]
        
        # dim=[batch,dim_x] Se normaliza en torno a x
        if len(np.shape(data))==2:
             #normalizes the columns of a 2d data set between the lower bound and upper bound
            max_data=np.max(data,axis=0).tolist()
            min_data=np.min(data,axis=0).tolist()
            for j in range(len(min_data)): #Failsafe, en el caso que un sensor solo tenga un valor, se normaliza respecto a 0
                if max_data[j]==min_data[j]:
                    if min_data[j]>0:
                        min_data[j]=0
                    else:
                        max_data[j]=0
            normalize_info[nombre_data]=dict(max_data=max_data,
                                                 min_data=min_data,
                                                 upper_bound=upper_bound,
                                                 lower_bound=lower_bound)
        
        # dim=[batch,dim_t,dim_x] Se normaliza en torno a x, se utiliza para series de tiempo
        elif len(np.shape(data))==3:
            dim_x=data.shape[2]
            dim_t=data.shape[1]
            dim_batch=data.shape[1]
            data_reshape=np.reshape(data,[-1,dim_x])
            
            # lo mismo que para el caso 2d
            max_data=np.max(data_reshape,axis=0).tolist()
            min_data=np.min(data_reshape,axis=0).tolist()
            for j in range(len(min_data)): #Failsafe, en el caso que un sensor solo tenga un valor, se normaliza respecto a 0
                if max_data[j]==min_data[j]:
                    if min_data[j]>0:
                        min_data[j]=0
                    else:
                        max_data[j]=0
            normalize_info[nombre_data]=dict(max_data=max_data,
                                                 min_data=min_data,
                                                 upper_bound=upper_bound,
                                                 lower_bound=lower_bound)
            
            
            
            
        else:
            print("Dimension de entrada no soportada")
    return normalize_info
def normalizar(dataset_dict,normalize_info):
    datos_normalizados=[]
    for i in range(len(dataset_dict)):
        data=dataset_dict[i]["data"]
        nombre_data=dataset_dict[i]["data_name"]
        data_dims=dataset_dict[i]["data_dims"]
        data_columns=dataset_dict[i]["data_columns"]
        # dim=[batch,dim_x] Se normaliza en torno a x
        if len(np.shape(data))==2:
            normalize_info_i=normalize_info[nombre_data]
            min_data=normalize_info_i["min_data"]
            max_data=normalize_info_i["max_data"]
            upper_bound=normalize_info_i["upper_bound"]
            lower_bound=normalize_info_i["lower_bound"]
            data_normalized=np.zeros(np.shape(data))
            for i in range(np.shape(data)[0]): # For every datapoint in the data
                for j in range(np.shape(data)[1]): # For every variable
                    x=data[i,j]
                    min_x=min_data[j]
                    max_x=max_data[j]
                    if max_x-min_x==0:
                        data_normalized[i,j]=x
                    else:
                        data_normalized[i,j]=(upper_bound-lower_bound)*((x-min_x)/(max_x-min_x))+lower_bound
            dataset_norm_dict=dict(data=data_normalized,
                                   data_name=nombre_data,
                                   data_dims=data_dims,
                                   data_columns=data_columns)
            datos_normalizados.append(dataset_norm_dict)
            
        # dim=[batch,dim_t,dim_x] Se normaliza en torno a x, se utiliza para series de tiempo
        elif len(np.shape(data))==3:
            dim_x=data.shape[2]
            dim_t=data.shape[1]
            dim_batch=data.shape[1]
            # Se alinean las el batch con el tiempo
            data_reshape=np.reshape(data,[-1,dim_x])
            
            # lo mismo que para el caso 2d
            normalize_info_i=normalize_info[nombre_data]
            min_data=normalize_info_i["min_data"]
            max_data=normalize_info_i["max_data"]
            upper_bound=normalize_info_i["upper_bound"]
            lower_bound=normalize_info_i["lower_bound"]
            data_normalized=np.zeros(np.shape(data_reshape))
            from tqdm import trange
            for i in trange(np.shape(data_reshape)[0]): # For every datapoint in the data
                for j in range(np.shape(data_reshape)[1]): # For every variable
                    x=data_reshape[i,j]
                    min_x=min_data[j]
                    max_x=max_data[j]
                    data_normalized[i,j]=(upper_bound-lower_bound)*((x-min_x)/(max_x-min_x))+lower_bound
            
            # se vuelve a la configuración inicial
            data_normalized=np.reshape(data_normalized,[dim_batch,dim_t,dim_x])
            dataset_norm_dict=dict(data=data_normalized,
                                   data_name=nombre_data,
                                   data_dims=data_dims,
                                   data_columns=data_columns)
            datos_normalizados.append(dataset_norm_dict)
            
        else:
            print("Dimension de entrada no soportada")
    dataset_norm_dict=datos_normalizados
    return dataset_norm_dict
def desnormalizar(dataset_dict,normalize_info):
    datos_desnormalizados=[]
    for i in range(len(dataset_dict)):
        data=dataset_dict[i]["data"]
        nombre_data=dataset_dict[i]["data_name"]
        data_dims=dataset_dict[i]["data_dims"]
        data_columns=dataset_dict[i]["data_columns"]
        
        # dim=[batch,dim_x] Se normaliza en torno a x
        if len(np.shape(data))==2:
            normalize_info_i=normalize_info[nombre_data]
            min_data=normalize_info_i["min_data"]
            max_data=normalize_info_i["max_data"]
            upper_bound=normalize_info_i["upper_bound"]
            lower_bound=normalize_info_i["lower_bound"]
            data_denormalized=np.zeros(np.shape(data))
            for i in range(np.shape(data)[0]): # For every datapoint in the data
                for j in range(np.shape(data)[1]): # For every variable
                    x_norm=data[i,j]
                    min_x=min_data[j]
                    max_x=max_data[j]
                    data_denormalized[i,j]=(x_norm-lower_bound)*(max_x-min_x)/(upper_bound-lower_bound)+min_x
            dataset_denorm_dict=dict(data=data_denormalized,
                                   data_name=nombre_data,
                                   data_dims=data_dims,
                                   data_columns=data_columns)
            datos_desnormalizados.append(dataset_denorm_dict)
        else:
            print("Dimension de entrada no soportada")
    dataset_denorm_dict=datos_desnormalizados
    return datos_desnormalizados
    
    
    
    














