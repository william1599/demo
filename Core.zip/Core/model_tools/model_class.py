# -*- coding: utf-8 -*-
"""
Created on Thu Jan 30 23:04:27 2020

@author: Philip

This is the model class
It contains the trained model and all its capabilities.
It requires the parameters dictionary to be initialized,
the entries in the parameters dictionary are:
    input_data_dict
    layers_architecure
    trainable_parameters_names
    layer_output_names
    cost_string
"""
import comm
import util
import json
import csv
import config
import shutil

import os
import threading
import tensorflow as tf
print("############")
print(tf.__version__)
print("############")
import numpy as np
import copy
from .layer_lib import layers,layer_info
from . import data_operations
from . import normalizador as norm
import time
import error
from errors import InternalServerError, LoadEntryDataError, UnauthorizedError
class model():
    def __init__(self,conf_parameters, architecture, idmodelo, training = True):
        #condicion de parada
        self.stop = False
        self.entrenando = False
        self.idmodelo = idmodelo
        #self.id_config = id_config
        self.id_config = conf_parameters["idconf"]
        self.path = None

        """INITIALIZE THE MODELS"""        

        early_stopping = conf_parameters["early_stopping"]
        if (early_stopping!=None):
            early_stopping = int(early_stopping)

        #crear training_settings
        training_settings={"n_epochs":int(conf_parameters["n_epochs"]), #int
                        "batch_size":int(conf_parameters["batch_size"]), # int
                        "learning_rate":float(conf_parameters["learning_rate"]), # float
                        "print_cost_every_n_batch":int(conf_parameters["print_cost_every_n_batch"]),                         
                        "early_stopping":early_stopping, 
                        "L1_lambda": float(conf_parameters["L1_lambda"]), 
                        "L2_lambda": float(conf_parameters["L2_lambda"]), 
                        "dropout":float(conf_parameters["dropout"]), 
                        # Aditional Stuff
                        "training_log_outputs":architecture["extra"]["training_log_outputs"]}

        # Extract architectures and settings

        if("trainable_parameters_names" in conf_parameters.keys()):
            print(".............................. ESTROY EN EIF .................................")
            trainable_parameters_names = conf_parameters["trainable_parameters_names"]
        else:
            trainable_parameters_names = util.create_trainable_parameters_names(architecture["layers_architecure"])

        self.parameters={
            "input_data_dict":conf_parameters["input_data_dict"],
            "layers_architecure":architecture["layers_architecure"],
            "training_settings":training_settings,
            "trainable_parameters_names":trainable_parameters_names,
            "layer_output_names":architecture["extra"]["layers_output_names"],
            "cost_string":architecture["cost_string"],
            #"normalize_info":conf_parameters["normalize_info"],
            #"salida": conf_parameters["extra"]["salida"]
        }

        if("normalize_info" in conf_parameters):
            self.parameters["normalize_info"] = conf_parameters["normalize_info"]

        if("salida" in architecture["extra"]):
            self.parameters["salida"] = architecture["extra"]["salida"]

        if("prediccion" in conf_parameters):
            self.parameters["prediccion"] = True
        else:
            self.parameters["prediccion"] = False

        #print("COST_STRING: "+architecture["cost_string"])
        

        self.input_data_dict=conf_parameters["input_data_dict"]
        self.layer_architectures=architecture["layers_architecure"]

        


        self.training_settings=training_settings
        
        # Creates the data placeholders
        self.input_data_placeholders=self.create_input_data_placeholders()
        
        # a list that contains all the sequential layers and their classes
        try:
            self.layer_list=self.create_layers()
        except Exception as e:
            print("EROR: ", e)
            raise ValueError("Error al crear las capas. Verifique que la arquitectura está correctamente definida")
        
        
        # Creates the cost tensor
        try:
            self.cost=self.create_cost()
        except Exception as e:
            print("Error cost: ", e)
            raise ValueError("Error al crear los costos. Verifique que existe una capa de costos y que sea correcta")
        
        
        self.cost_name="cost"
        # Creates the optimizer
        self.optimizer = tf.compat.v1.train.AdamOptimizer(learning_rate=self.training_settings["learning_rate"]).minimize(self.cost)
        
        # initializes the training log
        if training:
            self.training_log_header,self.training_log_data=self.init_training_log()
        
        
        # Variable initializer
        
        self.init = tf.compat.v1.global_variables_initializer()
        
        self.sess=tf.compat.v1.Session()
        # run the session
        
        self.sess.run(self.init)
        

    def set_comm(self, comm):
        self.comm = comm


    def set_path(self, path):
        self.path = path
    

    ##se llama una vez por cada elemento a predecir = rodillos
    def evaluate_with_names(self,evaluated_tensors_names,input_data_dict=1):
        """
        takes a name or list of names and evaluates their value using as placeholder the input_data_dict
        """
        if input_data_dict==1:
            input_data_dict=self.input_data_dict_test
        feed_dict=dict()
        for i in range(len(self.input_data_placeholders)):
            current_input_data=input_data_dict[i]["data"]
            update={self.input_data_placeholders[i]:current_input_data}
            feed_dict.update(update)
        evaluated_tensors=[]
        if type(evaluated_tensors_names)==str:
            evaluated_tensors_names=[evaluated_tensors_names]
        for name in evaluated_tensors_names:
            evaluated_tensors.append(self.get_with_name(name))
        if len(evaluated_tensors)==1:
            evaluated_tensors=evaluated_tensors[0]
        else:
            evaluated_tensors=tuple(evaluated_tensors)
        evaluation=self.sess.run(evaluated_tensors,feed_dict=feed_dict)
        return evaluation

    def evaluate_with_names_quality(self,evaluated_tensors_names,input_data_dict=1):
        """
        takes a name or list of names and evaluates their value using as placeholder the input_data_dict
        """
        if input_data_dict==1:
            input_data_dict=self.input_data_dict_test
        feed_dict=dict()
        current_input_data=input_data_dict[0]["data"]
        update={self.input_data_placeholders[0]:current_input_data}
        feed_dict.update(update)
        evaluated_tensors=[]
        if type(evaluated_tensors_names)==str:
            evaluated_tensors_names=[evaluated_tensors_names]
        for name in evaluated_tensors_names:
            evaluated_tensors.append(self.get_with_name(name))
            
        if len(evaluated_tensors)==1:
            evaluated_tensors=evaluated_tensors[0]
        else:
            evaluated_tensors=tuple(evaluated_tensors)
        
        evaluation=self.sess.run(evaluated_tensors,feed_dict=feed_dict)
        return evaluation

    def feed_dict_with_names(self,input_data_dict):
        # creates a feed_dict used for the sess.run method
        feed_dict=dict()
        for i in range(len(self.input_data_placeholders)):
            current_input_data=input_data_dict[i]["data"]
            update={self.input_data_placeholders[i]:current_input_data}
            feed_dict.update(update)
        return feed_dict
        
        
    def create_input_data_placeholders(self):
        # Creates the placeholders for the input data
        input_data_placeholders=[]
        for data_dictionary in self.input_data_dict:
            name=data_dictionary["data_name"]
            #name = name.split("/")[-1]
            dims=np.concatenate([[None],data_dictionary["data_dims"]])
            # PREGUNTAR ESTO
            #tf.compat.v1.disable_eager_execution()
            input_data_placeholders.append(
                    tf.compat.v1.placeholder(shape=dims,dtype=tf.float32,
                                   name=name))
        return input_data_placeholders
    def create_layers(self):
        print('Entre al create layer')
        # Creates the layers list using the architecture and layers.py clasess
        layer_dict=layer_info.layer_dictionary()
        
        layers_list=[]
        layer_number=0
        for layer_architecture in self.layer_architectures:
            # layer_type=layer_architecture["layer_type"]
            if(self.parameters["prediccion"]):
                layer_type = layer_architecture["layer_type"][:-6]
            else:
                layer_type=layer_architecture["layer_type"]
            #extract the function that initializes the layer
            class_init=layer_dict[layer_type]
            #print(class_init)
            layers_list.append(class_init(layer_number,layer_architecture))

            layer_number+=1   
        return layers_list
    
    def create_cost(self):
        # creates the cost from a string which is read as code
        cost_string=self.parameters["cost_string"]
        #cost_string="layer_output_"+cost_string
        
        trainable_parameters_names=self.parameters["trainable_parameters_names"]
        #"""L1 and L2 regularization"""
        L1_lambda=self.parameters["training_settings"]["L1_lambda"]
        if not(L1_lambda==0.) and not(L1_lambda=="None"):
            L1_term=str(L1_lambda)+"*("
            i=0
            for beta in trainable_parameters_names:
                if i!=0:
                    L1_term+="+"
                L1_term+="tf.reduce_sum(tf.abs("+beta+"))"
                i+=1
            L1_term+=")"
            cost_string+="+"+L1_term
            
        L2_lambda=self.parameters["training_settings"]["L2_lambda"]
        if not(L2_lambda==0.) and not(L2_lambda=="None"):
            L2_term=str(L2_lambda)+"*("
            i=0
            for beta in trainable_parameters_names:
                if i!=0:
                    L2_term+="+"
                L2_term+="tf.reduce_sum(tf.square("+beta+"))"
                i+=1
            L2_term+=")"
            
            cost_string+="+"+L2_term
        
        self.cost_string=cost_string
        
        layer_output_names=self.parameters["layer_output_names"]
        tensor_names=trainable_parameters_names+layer_output_names
        for dictionary in self.parameters["input_data_dict"]:
            tensor_names.append(dictionary["data_name"])
        cost_str="cost="+cost_string
        i=0
        print("Cost string antes del for: " + cost_str)
        #print("Tensor names es: " + tensor_names)
        for tensor_name in tensor_names[:len(tensor_names) - 1]:
            #tensor_name = tensor_name.split("/")[-1]
            get_tensor_string="self.get_with_name(tensor_names["+str(i)+"])"
            i=i+1
            cost_str=cost_str.replace(tensor_name,get_tensor_string)
            
        locals_=locals()
        # String ejecuta como codigox
        exec(cost_str,globals(),locals_)
        cost=locals_["cost"]
        
        cost=tf.identity(cost,name="cost")
        return cost

    def consultarStop(self):
        while self.entrenando:
            #consultar modelo
            status, err = self.comm.getModelo(self.idmodelo)
            #print(json.dumps(status,sort_keys=True, indent=4))            
            if(status["stop"]==True):
                #print("PARANDOOOOOOOOOOOOO")
                self.stop = True
            #self.stop = random.random() < self.probability
            time.sleep(1)


    def create_test_train_val_sets(self,dataset_dict,train_size=0.8,test_size=0.19,val_size=0.01):
        self.dataset_dict_train,self.dataset_dict_test,self.dataset_dict_val=self.slice_input_data(dataset_dict,train_size,test_size,val_size)   
        
    def train(self,dataset_dict,train_size=0.8,test_size=0.19,val_size=0.01):
        print("Entre a la funcion train")
        print(train_size)
        print(test_size)
        self.entrenando = True

        #4.- crear hilo que llama a consultarStop (✓)
        analysisStoper = threading.Thread(target=self.consultarStop)
        analysisStoper.start()

        #setea el estado del modelo en la base de datos a entrenando
        #TODO: consultar antes los estados de un modelo y enviar el estado que corresponda a 
        #ENTRENANDO

        self.comm.editaModelo(self.idmodelo,{"estado":"ENTRENANDO", "entrenando": True, "log_header": json.dumps(self.training_log_header)})

        # Separate the dataset in training and testing
        self.dataset_dict_train,self.dataset_dict_test,self.dataset_dict_val=self.slice_input_data(dataset_dict, train_size, test_size, 0)
        batch_size=self.training_settings["batch_size"]
        n_epochs=self.training_settings["n_epochs"]
        feed_dict_test=self.feed_dict_with_names(self.dataset_dict_test)
        feed_dict_train=self.feed_dict_with_names(self.dataset_dict_train)
        batches_dict=data_operations.batch_from_input_data_dict(self.dataset_dict_train,batch_size)
        batch_n=0
        min_cost=self.sess.run(self.cost,feed_dict=feed_dict_test)
        early_stop_counter=0
        """Initialize Training Log"""
        training_log_header,training_log_data=self.init_training_log()
        fila = 0 
        print("Comenzando entrenamiento...")
        for epoch in range(n_epochs):
            #5.- setear estado de avance (✓)
            self.comm.setEstadoAvance(self.idmodelo,epoch)
            for batch_dict in batches_dict:

                feed_dict_batch=self.feed_dict_with_names(batch_dict)
                _,cost_eval_train=self.sess.run((self.optimizer,self.cost),feed_dict=feed_dict_batch)
                batch_n+=1
                
                if (batch_n+1) % self.training_settings["print_cost_every_n_batch"]==0:                   
                    
                    cost_eval=self.sess.run(self.cost,feed_dict=feed_dict_test)
                    cost_train_eval=self.sess.run(self.cost,feed_dict=feed_dict_train)
                    
                    """save_log"""
                    training_log_data_n=[epoch+1,batch_n+1,cost_train_eval,cost_eval]
                    if self.training_settings["training_log_outputs"]!=[]: # if there are other outputs for the log
                        output_values_train=self.evaluate_with_names(
                            self.training_settings["training_log_outputs"],self.dataset_dict_train)
                        output_values_test=self.evaluate_with_names(
                            self.training_settings["training_log_outputs"],self.dataset_dict_test)
                        if len(self.training_settings["training_log_outputs"])==1:
                            training_log_data_n.append(output_values_train)
                            training_log_data_n.append(output_values_test)
                        else:
                            for i in range(len(self.training_settings["training_log_outputs"])):
                                training_log_data_n.append(output_values_train[i])
                                training_log_data_n.append(output_values_test[i])
                    
                    training_log_data.append(training_log_data_n)
                    #guardar log en la base de datos!
                    self.comm.append_log(self.idmodelo, fila, training_log_data_n)
                    fila+=1


                #6.- si self.stop == true salir del ciclo
                if self.stop:
                    break
            #6.- si self.stop == true salir del ciclo
            if self.stop:
                print("CANCELE EL TRAIN")
                break
        
            current_cost=self.sess.run(self.cost,feed_dict=feed_dict_test)
            if current_cost>=min_cost and self.training_settings["early_stopping"]!=None and int(self.training_settings["early_stopping"])!=0:
                early_stop_counter+=1
                if early_stop_counter>=self.training_settings["early_stopping"]:
                    print("Early stopping applied")
                    break
            else:
                min_cost=current_cost
                early_stop_counter=0

        if self.stop:
            print("Se ha detenido el entrenamiento de forma externa")
            self.comm.editaModelo(self.idmodelo,{"estado":"CANCELADO", "entrenando": False})
        else:
            print("El entrenamiento ha terminado exitosamente")
            self.comm.editaModelo(self.idmodelo,{"estado":"ENTRENADO", "entrenando": False})
        
        self.entrenando = False

        #7.- parar hilo (✓)
        analysisStoper.join()

        self.training_log_data=training_log_data
        self.training_log_header=training_log_header
        print("Training finished")
    def init_training_log(self):
        training_log_header=["epoch","batch","costo entrenamiento","costo test"]
        # add the other required values to the log
        if self.training_settings["training_log_outputs"]!=[]:
            for output_name in self.training_settings["training_log_outputs"]:
                if self.get_with_name(output_name).shape.as_list()!=[]:
                    #print ("Error, log value needs to be a scalar")
                    error.error("Error, log value needs to be a scalar")

                output_name = output_name.replace("layer_output-", '')
                training_log_header+=[output_name+"_train",output_name+"_test"]
        training_log_data=[]
        return training_log_header,training_log_data
            
    def slice_input_data(self,dataset_dict,train_size=0.6,test_size=0.2,val_size=0.2):
        input_data_dict_train=copy.deepcopy(dataset_dict)
        input_data_dict_test=copy.deepcopy(dataset_dict)
        input_data_dict_val=copy.deepcopy(dataset_dict)
        for i in range(len(dataset_dict)):
            
            data_i=dataset_dict[i]["data"]
            data_train,data_test,data_val=data_operations.slice_train_test_validation(data_i,train_size,test_size,val_size)
            
            
            input_data_dict_train[i]["data"]=data_train
            input_data_dict_test[i]["data"]=data_test
            input_data_dict_val[i]["data"]=data_val
            
        return input_data_dict_train,input_data_dict_test,input_data_dict_val
   
    
    def get_with_name(self,name):
        return tf.compat.v1.get_default_graph().get_tensor_by_name(name+":0")
        
    def save_model(self,name):
        #sep = os.path.sep
        # SOLO WINDOWS
        sep = "/"
        print("Saving model...")
        if(self.path==None):
            print("ERROR: Model not saved. Path not defined")
            return

        """
        save_files_list=os.listdir(self.path+sep+config.RUTA_MODELOS)
        if save_files_list==[]:
            model_id=1
        else:
            id_found=False
            model_id=0
            while not id_found:
                model_id+=1
                id_in_list=False
                for file_str in save_files_list:
                    file_id=file_str.split("_")[0]
                    if str(model_id)==file_id:
                        id_in_list=True
                        break
                if not id_in_list:
                    break
                if model_id==1000:
                    break
        """
        
        #folder_path=self.path + sep + config.RUTA_MODELOS + sep + str(model_id) + "_" + name
        folder_path=self.path + sep + config.RUTA_MODELOS + sep + name
        self.comm.editaModelo(self.idmodelo, {"ruta": folder_path})
        if(os.path.exists(folder_path)):
            shutil.rmtree(folder_path)
        os.mkdir(folder_path)
        saver = tf.compat.v1.train.Saver()
        
        prediction_directory = "predictions"
        prediction_path = folder_path + sep + prediction_directory
        if(os.path.exists(prediction_path)):
            shutil.rmtree(prediction_path)
        os.mkdir(prediction_path)
        saver.save(self.sess,folder_path+sep+"session")        
        parameters=self.parameters

        ##QUE ES ESTO?
        f_parameters = open(folder_path+sep+"parameters.json","w")
        # f_parameters.write(str(parameters))
        json.dump(parameters,f_parameters)
        f_parameters.close()
        
        file=open(folder_path+sep+'training_log.csv', mode='w')
        csv_writer=csv.writer(file, delimiter=';', quotechar='"', quoting=csv.QUOTE_MINIMAL, lineterminator = '\n')
        csv_writer.writerow(self.training_log_header)
        for row in self.training_log_data:
            csv_writer.writerow(row)
        file.close()
        
        #print("Model saved as "+str(model_id)+"_"+name)
        print("Model saved as "+name)
        return

    def load_model(name, path):        
        sep = os.path.sep
        print("Loading model")
        path = path + sep + 'save' + sep + name
        parameters=json.load(open(path+sep+"parameters.json"))
        # parameters=eval(open(path+"\\parameters.txt","r").read())
        loaded_model=model(parameters)
        saver = tf.compat.v1.train.Saver()
        saver.restore(loaded_model.sess,path+sep+"session")
        print("Model "+name+" loaded")
        return loaded_model

    def load_model_mix(path, name, train_conf, architecture, idmodelo, test = True):
        sep = os.path.sep
        print("Loading model")
        print('MODELO: ')
        print(name)
        # print(architecture)
        folder_path = path + sep + config.RUTA_MODELOS + sep + name
        parameters = None
        try:
            #parameters=json.load(open(path+os.sep+"parameters.json"))
            print("PATH: ", folder_path+sep+"parameters.json")
            parameters=json.load(open(folder_path+sep+"parameters.json"))
        except Exception as e:
            #error.error("No se encontro el modelo "+name)
            raise Exception("###No se encontró el modelo "+name) from e

        
        
        parameters["idconf"] = train_conf["idconf"]
        parameters["n_epochs"] = parameters["training_settings"]["n_epochs"]
        parameters["early_stopping"] = train_conf["early_stopping"]
        parameters["batch_size"] = parameters["training_settings"]["batch_size"]
        parameters["learning_rate"] = parameters["training_settings"]["learning_rate"]
        parameters["print_cost_every_n_batch"] = parameters["training_settings"]["print_cost_every_n_batch"]
        parameters["L1_lambda"] = parameters["training_settings"]["L1_lambda"]
        parameters["L2_lambda"] = parameters["training_settings"]["L2_lambda"]
        parameters["dropout"] = parameters["training_settings"]["dropout"]
        parameters["extra"] = {}
        parameters["extra"]["training_log_outputs"] = architecture["extra"]["training_log_outputs"]
        
        parameters["extra"]["layers_output_names"] = parameters["layer_output_names"]
        parameters["extra"]["salida"] = architecture["extra"]["salida"]
        
        #parameters["layers_architecure"] = parameters["layer_architectures"]
        parameters["layers_architecure"] = parameters["layers_architecure"]

        for layer in parameters["layers_architecure"]:
            layer["layer_type"] = layer["layer_type"]+"_layer"
        
        parameters["prediccion"] = True
        
        print(json.dumps(parameters,sort_keys=True, indent=4))

        loaded_model = None
        try:
            loaded_model=model(parameters, parameters, idmodelo, False)
        except Exception as e:
            #error.error("Error al crear el modelo "+name+" a partir de los parametros en parameters.json \nCausas posibles: \n Modelo mal definido \n Versión del nucleo no compatible con modelo")
            print('####')
            print(e)
            print('####')
            raise Exception("###No se pudo instanciar el modelo "+name) from e

        

        saver = tf.compat.v1.train.Saver()

        

        try:
            #saver.restore(loaded_model.sess,path+os.sep+"session")
            saver.restore(loaded_model.sess,folder_path+sep+"session")
        except Exception as e:            
            raise Exception("###No se pudo cargar el modelo ubicado en "+folder_path+"\nPosibles causas: \n Falta algún archivo de la sesion \n Los datos de la sesión no coinciden con el modelo en parameters.json") from e


        print("Model "+name+" loaded")
        return loaded_model

    def load_model_new(path, name, train_conf, architecture, idmodelo, test = True):
        sep = os.path.sep
        print("Loading model")
        folder_path = path + sep + config.RUTA_MODELOS + sep + name
        #parameters=json.load(open(folder_path+sep+"parameters.json"))
        
        loaded_model=model(train_conf, architecture, idmodelo)

        #reemplazar _layer con -layer en trainable parameters


        saver = tf.compat.v1.train.Saver()
        saver.restore(loaded_model.sess,folder_path+sep+"session")
        print("Model "+name+" loaded")
        return loaded_model

    # Inicializa en params la configuracion del normalizador
    def initialize_normalizer(self,dataset_dict,lower_bound=0,upper_bound=1):
        if lower_bound>=upper_bound:
            raise Exception("Cota superior del normalizador debe ser mayor que la cota inferior")
        normalize_info=norm.inicializar_normalizador(dataset_dict,lower_bound,upper_bound)
        # Guarda la normalización en los parámetros
        print('VOY A PRINTEAR NORMALIZAR INFO')
        print(normalize_info)
        self.parameters["normalize_info"]=normalize_info

    def normalize(self,dataset_dict): # Normaliza las entradas, utilizar antes de entrenar o evaluar
        normalize_info = None
        try:
            normalize_info=self.parameters["normalize_info"]
            print('##NORMALIZAINFO')
            print(normalize_info)
            print('##NORMALIZAINFO')
        except Exception as e:
            raise Exception("###No se encuentran datos de normalización, posible causa, no se inicializó el normalizador al entrenar. En este caso el modelo no debe ser normalizado antes de evaluar ni desnormalizado despues de evaluar") from e

        return norm.normalizar(dataset_dict,normalize_info)
    def denormalize(self,dataset_dict_normalized): # Desnormaliza las salidas, utilizar despues de evaluar
        normalize_info = None
        try:
            normalize_info=self.parameters["normalize_info"]
        except Exception as e:            
            raise Exception("###No se encuentran datos de normalización, posible causa, no se inicializó el normalizador al entrenar. En este caso el modelo no debe ser normalizado antes de evaluar ni desnormalizado despues de evaluar") from e
        
        return norm.desnormalizar(dataset_dict_normalized,normalize_info)
    def create_output_dictionary(self,model_output,dataset_name):
        # Creates a dictionary for the output using the format used in dataset_name in self.parameters["input_data_dict"] input (labels) 
        found=False
        for dataset_dict in self.parameters["input_data_dict"]:
            print(dataset_dict)
            print(dataset_name)
            if dataset_dict["data_name"]==dataset_name:
                found=True
                break
        if found==False:
            raise Exception("###No se encontro nombre de dataset en los posibles datasets de entrada al desnormalizar la salida")
        # Se crea el diccionario de salida
        
        output_dataset_dict=dict(data=model_output,data_name=dataset_name,data_dims=dataset_dict["data_dims"],data_columns=dataset_dict["data_columns"])
        return output_dataset_dict
        
    def denormalize_model_output(self,model_output_norm,dataset_name):
        normalize_info = None
        try:
            normalize_info=self.parameters["normalize_info"]
        except Exception as e:            
            raise Exception("###No se encuentran datos de normalización, posible causa, no se inicializó el normalizador al entrenar. En este caso el modelo no debe ser normalizado antes de evaluar ni desnormalizado despues de evaluar") from e
        output_dataset_dict_norm=[self.create_output_dictionary(model_output_norm,dataset_name)]
        normalize_info[dataset_name]
        return norm.desnormalizar(output_dataset_dict_norm,normalize_info)[0]        


    
