# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 12:14:12 2020

@author: Philip

This file seeks the info in layers to generate info about the available layers
"""
from . import layers


def layer_dictionary():
    
    layer_types = [func for func in dir(layers) if "_layer" in func]
    
    dictionary=dict()
    for type_ in layer_types:
        #type_name=type_.replace("_layer","")
        locals_=locals()
        exec("layer_class=layers."+type_,globals(),locals_)
        dictionary.update([(type_,locals_["layer_class"])])
#        print(locals_["a"])
        
    return dictionary

def layer_settings_dictionary():
    layer_types = [func for func in dir(layers) if "_layer" in func]
    dictionary=dict()
    for type_ in layer_types:
        
        type_name=type_.replace("_layer","")
        locals_=locals()
        exec("local_settings=layers."+type_+".settings()",globals(),locals_)
        dictionary.update([(type_name,locals_["local_settings"])])
    return dictionary


def layer_trainable_parameters_dictionary():
    layer_types = [func for func in dir(layers) if "_layer" in func]
    dictionary=dict()
    for type_ in layer_types:
        
        type_name=type_.replace("_layer","")
        locals_=locals()
        exec("local_trainable_parameters=layers."+type_+".trainable_parameters()",globals(),locals_)
        dictionary.update([(type_name,locals_["local_trainable_parameters"])])
    return dictionary

def layer_input_tensors_dictionary():
    layer_types = [func for func in dir(layers) if "_layer" in func]
    dictionary=dict()
    for type_ in layer_types:
        
        type_name=type_.replace("_layer","")
        locals_=locals()
        exec("local_input_tensors=layers."+type_+".input_tensors()",globals(),locals_)
        dictionary.update([(type_name,locals_["local_input_tensors"])])
    return dictionary



    
    


