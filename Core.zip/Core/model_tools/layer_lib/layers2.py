# -*- coding: utf-8 -*-
"""
Created on Fri Jan 31 15:17:44 2020

@author: Philip
"""
"""
Layer types:
    Neural Networks
    Pooling
    ActivationFunctions

All layers are initialized with the following atributes

layer_input_dim: Int Array
layer_input_tensor : TensorFlow Tensor
layer_number: int, identifiying the layer number
layer_architecture: dictionary with the required settings to construct the layer

Also these methods:

trainable_parameters(): Returns a list of the names of the trainable paramaters, e.g.: for NN ["W","b"]
settings(): returns a list of the names of the settings with their possible values (numerical or categorical)
            a=setings(); a[i]=[setting_name,setting_value_list]
                e.g.:   for activation function layers [["activation_function",["relu","relu6","sigmoid","tanh"]]]
            if the values are numerical setting_value_list="float"
                e.g.: [["layer_output_dim","float"]]
            
Layers also require to create the following atributes:
    self.layer_input_dim= Int Array
    self.layer_number= Int
    self.layer_output_dim= Int Array
    self.name="*layer_type*-layer_*layer_number*
    
    self.layer_output_tensor= Layer output tensorflow tensor 
    the output tensor name has to be: name="layer_output-"+self.name

if the layer has trainable parameters:
    self.*parameter*: Tensor with the trainable parameter from trainable_parameters()
    the name of the parameter tensors needs to be: name="trainable_parameter-"+self.name+"-*parameter*"
    
"""

import tensorflow as tf
import tensorflow_probability as tfp
import numpy as np
#import os
def get_with_name(name):
    "returns a tensor by calling it whit its name"
    return tf.get_default_graph().get_tensor_by_name(name+":0")




class fully_connected_layer():
    def trainable_parameters():
        return ["W","b"]
    def settings():
        return [["n_hidden_values","float"],
                ["activation_function",["relu","relu6","sigmoid","tanh","softmax","none"]]]
    def input_tensors():
        return ["input_tensor"]
    def output_tensors():
        return [""]
        
    def __init__(self,layer_number,layer_architecture):
        """
        Traditional fully connected layer
        layer_architecture dictionary requires the following 
        layer_output_dim
        ----------
        Implemented activation functions:
            relu
            leaky_relu
            relu6
            sigmoid
            tanh
            softmax
            none
        """
        
        def leaky_relu(x):
            return tf.nn.leaky_relu(x, alpha=0.01)
        activation_function_dict=dict(relu=tf.nn.relu,
                                      leaky_relu=leaky_relu,
                                      relu6=tf.nn.relu6,
                                      sigmoid=tf.nn.sigmoid,
                                      tanh=tf.nn.tanh,
                                      softmax=tf.nn.softmax,
                                      none=lambda *args: args[0])
        
        
        self.layer_input_tensor=get_with_name(layer_architecture["input_tensor"])
        
        self.layer_input_dim=self.layer_input_tensor.shape.as_list()
        
        self.layer_number=layer_number
        
        self.hidden_values=layer_architecture["n_hidden_values"]
        
        
        self.name="fully_connected-layer_"+str(self.layer_number)
        
        activation_function_name=layer_architecture["activation_function"]
        activation_function=activation_function_dict[activation_function_name]
        
        
        n_inputs=np.prod(self.layer_input_dim[1:]) # don't sum over data
        input_reshape=tf.reshape(self.layer_input_tensor,[-1,n_inputs])
        
        init_weights = tf.contrib.layers.xavier_initializer()
        self.W=tf.get_variable( "trainable_parameter-"+self.name+"-W", [n_inputs, self.hidden_values], dtype=tf.float32, initializer=init_weights)
        self.b=tf.get_variable( "trainable_parameter-"+self.name+"-b", [self.hidden_values], dtype=tf.float32, initializer=init_weights)
        self.layer_output_tensor=activation_function(tf.matmul(input_reshape,self.W)+self.b)
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name="layer_output-"+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()

class variational_normal_layer():
    def trainable_parameters():
        return ["W_mu","W_rho","b_mu","b_rho","prior_mu","prior_rho"]
    def settings():
        return [["latent_space_size","float"],
                ["activation_function",["relu","relu6","sigmoid","tanh","softmax","none"]]]
    def input_tensors():
        return ["input_tensor"]
    def output_tensors():
        return ["mu","sigma","sample","KLdivergence"]
        
        
        
    def __init__(self,layer_number,layer_architecture):
        """
        
        ----------
        Implemented activation functions:
            relu
            leaky_relu
            relu6
            sigmoid
            tanh
            softmax
            none
        """
        
        def leaky_relu(x):
            return tf.nn.leaky_relu(x, alpha=0.01)
        activation_function_dict=dict(relu=tf.nn.relu,
                                      leaky_relu=leaky_relu,
                                      relu6=tf.nn.relu6,
                                      sigmoid=tf.nn.sigmoid,
                                      tanh=tf.nn.tanh,
                                      softmax=tf.nn.softmax,
                                      none=lambda *args: args[0])
        
        
        self.layer_input_tensor=get_with_name(layer_architecture["input_tensor"])
        
        self.layer_input_dim=self.layer_input_tensor.shape.as_list()
        
        self.layer_number=layer_number
        
        self.latent_space_size=layer_architecture["latent_space_size"]
        
        
        self.name="variational_normal-layer_"+str(self.layer_number)
        
        activation_function_name=layer_architecture["activation_function"]
        activation_function=activation_function_dict[activation_function_name]
        
        
        n_inputs=np.prod(self.layer_input_dim[1:]) # don't sum over data
        input_reshape=tf.reshape(self.layer_input_tensor,[-1,n_inputs])
        
        init_weights = tf.contrib.layers.xavier_initializer()
        self.W_mu=tf.get_variable( "trainable_parameter-"+self.name+"-W_mu", [n_inputs, self.latent_space_size], dtype=tf.float32, initializer=init_weights)
        self.b_mu=tf.get_variable( "trainable_parameter-"+self.name+"-b_mu", [self.latent_space_size], dtype=tf.float32, initializer=init_weights)
        
        self.W_rho=tf.get_variable( "trainable_parameter-"+self.name+"-W_rho", [n_inputs, self.latent_space_size], dtype=tf.float32, initializer=init_weights)
        self.b_rho=tf.get_variable( "trainable_parameter-"+self.name+"-b_rho", [self.latent_space_size], dtype=tf.float32, initializer=init_weights)
        
        self.mu=activation_function(tf.matmul(input_reshape,self.W_mu)+self.b_mu)
        self.rho=activation_function(tf.matmul(input_reshape,self.W_rho)+self.b_rho)
        self.sigma=tf.nn.softplus(self.rho)
        
        
        self.layer_output_tensor_sigma=tf.identity(self.sigma,name="layer_output-"+self.name+"_sigma")
        self.layer_output_dim_sigma=self.layer_output_tensor_sigma.shape.as_list()
        
        self.layer_output_tensor_mu=tf.identity(self.sigma,name="layer_output-"+self.name+"_mu")
        self.layer_output_dim_mu=self.layer_output_tensor_mu.shape.as_list()
        
        
        self.layer_output_tensor_distribution=tfp.distributions.Normal(loc=self.mu,scale=self.sigma,name="layer_output-"+self.name+"_distribution")
        self.layer_output_dim_distribution=self.layer_output_tensor_distribution.batch_shape.as_list()
        
        
        
        self.layer_output_tensor_sample=self.layer_output_tensor_distribution.sample()
        self.layer_output_tensor_sample=tf.identity(self.layer_output_tensor_sample,name="layer_output-"+self.name+"_sample")
        self.layer_output_dim_sample=self.layer_output_tensor_sample.shape.as_list()
        
        
        self.prior_rho=tf.compat.v1.get_variable("trainable_parameter-"+self.name+"-prior_rho",shape=(),dtype=tf.float32)
        self.prior_mu=tf.compat.v1.get_variable("trainable_parameter-"+self.name+"-prior_mu",shape=(),dtype=tf.float32)
        self.prior_sigma=tf.nn.softplus(self.prior_rho)
        self.prior_dist=tfp.distributions.Normal(loc=self.prior_mu,scale=self.prior_sigma)
        
        self.layer_output_tensor_KLdivergence=tf.reduce_mean(self.layer_output_tensor_distribution.log_prob(self.layer_output_tensor_sample)-self.prior_dist.log_prob(self.layer_output_tensor_sample))
        self.layer_output_tensor_KLdivergence=tf.identity(self.layer_output_tensor_KLdivergence,name="layer_output-"+self.name+"_KLdivergence")
        self.layer_output_dim_KLdivergence=self.layer_output_tensor_KLdivergence.shape.as_list()
        
        
        self.layer_output_tensor=[self.layer_output_tensor_mu,self.layer_output_tensor_sigma,self.layer_output_tensor_sample,self.layer_output_tensor_KLdivergence]
        self.layer_output_dim=[self.layer_output_dim_mu,self.layer_output_dim_sigma,self.layer_output_dim_sample,self.layer_output_dim_KLdivergence]
        
class negative_log_likelyhood_normal_layer():
    def trainable_parameters():
        return []
    def settings():
        return []
    def input_tensors():
        return ["mu","sigma","labels"]
    def output_tensors():
        return [""]
        
        
        
    def __init__(self,layer_number,layer_architecture):
        
        
        
        self.mu=get_with_name(layer_architecture["mu"])
        self.sigma=get_with_name(layer_architecture["sigma"])
        self.labels=get_with_name(layer_architecture["labels"])
        self.dist=tfp.distributions.Normal(loc=self.mu,scale=self.sigma)
        
        
        # self.layer_input_dim=self.layer_input_tensor.shape.as_list()
        
        self.layer_number=layer_number
        
        
        
        self.name="negative_log_likelyhood_normal-layer_"+str(self.layer_number)
        self.layer_output_tensor=tf.reduce_mean(-self.dist.log_prob(self.labels))
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name="layer_output-"+self.name)
        self.layer_output_dims=self.layer_output_tensor.shape.as_list()
        
class recurrent_neural_network_layer():
    def trainable_parameters():
        return ["W_h","U_h","b_h","W_y","b_y"]
    def settings():
        return [["n_hidden_values","float"],
                ["n_ouptuts","float"],
                ["activation_function_hidden_layer",["relu","relu6","sigmoid","tanh","softmax","none"]],
                ["activation_function_output",["relu","relu6","sigmoid","tanh","softmax","none"]]]
    def input_tensors():
        return ["input_tensor"]
    def output_tensors():
        return [""]
        
        
    def __init__(self,layer_number,layer_architecture):
        """
        Traditional fully connected layer
        layer_architecture dictionary requires the following 
        layer_output_dim
        ----------
        Implemented activation functions:
            relu
            leaky_relu
            relu6
            sigmoid
            tanh
            softmax
            none
        """
        def leaky_relu(x):
            return tf.nn.leaky_relu(x, alpha=0.01)
        activation_function_dict=dict(relu=tf.nn.relu,
                                      leaky_relu=leaky_relu,
                                      relu6=tf.nn.relu6,
                                      sigmoid=tf.nn.sigmoid,
                                      tanh=tf.nn.tanh,
                                      softmax=tf.nn.softmax,
                                      none=lambda *args: args[0])
        
        
        self.layer_input_tensor=get_with_name(layer_architecture["input_tensor"])
        
        self.layer_input_dim=self.layer_input_tensor.shape.as_list()
        
        self.layer_number=layer_number
        
        self.hidden_values=layer_architecture["n_hidden_values"]
        self.n_ouptuts=layer_architecture["n_ouptuts"]
        
        
        self.name="recurrent_neural_network-layer_"+str(self.layer_number)
        
        activation_function_name=layer_architecture["activation_function_hidden_layer"]
        activation_function_hidden_layer=activation_function_dict[activation_function_name]
        
        
        activation_function_name=layer_architecture["activation_function_output"]
        activation_function_output=activation_function_dict[activation_function_name]
        
        
        
        n_inputs=np.prod(self.layer_input_dim[2:]) # don't sum over data
        print(self.layer_input_dim)
        n_t=self.layer_input_dim[1]
        input_reshape=tf.reshape(self.layer_input_tensor,[-1,n_t,n_inputs])
        # input of tf scan requires the time axis to be the first axis
        input_swap=tf.transpose(input_reshape,[1,0,2])
        
        init_weights = tf.contrib.layers.xavier_initializer()
        self.W_h=tf.get_variable( "trainable_parameter-"+self.name+"-W_h", [n_inputs, self.hidden_values], dtype=tf.float32, initializer=init_weights)
        self.b_h=tf.get_variable( "trainable_parameter-"+self.name+"-b_h", [self.hidden_values], dtype=tf.float32, initializer=init_weights)
        
        self.U_h=tf.get_variable( "trainable_parameter-"+self.name+"-U_h", [self.hidden_values, self.hidden_values], dtype=tf.float32, initializer=init_weights)
        
        self.W_y=tf.get_variable( "trainable_parameter-"+self.name+"-W_y", [self.hidden_values, self.n_ouptuts], dtype=tf.float32, initializer=init_weights)
        self.b_y=tf.get_variable( "trainable_parameter-"+self.name+"-b_y", [self.n_ouptuts], dtype=tf.float32, initializer=init_weights)
        
        h_0=activation_function_hidden_layer(tf.matmul(input_swap[0,:,:],self.W_h)+self.b_h)
        y_0=activation_function_output(tf.matmul(h_0,self.W_y)+self.b_y)
        initializer=(y_0,h_0)
        def recurrent(prev_output,current_input):
            y_prev,h_prev=prev_output
            x_current=current_input
            h_current=activation_function_hidden_layer(tf.matmul(h_prev,self.U_h)+tf.matmul(x_current,self.W_h)+self.b_h)
            y_current=activation_function_output(tf.matmul(h_current,self.W_y)+self.b_y)
            return y_current,h_current
        
        y_swap,h_swap=tf.scan(recurrent,input_swap,initializer,parallel_iterations=1000,swap_memory=True)
        
        
        self.layer_output_tensor=tf.transpose(y_swap,[1,0,2])
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name="layer_output-"+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()
        
    
class activation_function_layer():
    def trainable_parameters():
        return []
    def settings():
        return [["activation_function",["relu","relu6","sigmoid","tanh","softmax"]]]
    def input_tensors():
        return ["input_tensor"]
    def output_tensors():
        return [""]
        
    def __init__(self,layer_number,layer_architecture):
        """
        Neural network activation funcion layer
        layer_architecture dictionary requires the following :
            activation_function
        ----------
        Implemented activation functions:
            relu
            relu6
            sigmoid
            tanh
            softmax
        """
        activation_function_dict=dict(relu=tf.nn.relu,
                                      relu6=tf.nn.relu6,
                                      sigmoid=tf.nn.sigmoid,
                                      tanh=tf.nn.tanh,
                                      softmax=tf.nn.softmax)
        
        
        
        self.layer_input_tensor=get_with_name(layer_architecture["input_tensor"])
        self.layer_input_dim=self.layer_input_tensor.shape.as_list()
        self.layer_number=layer_number
        
        self.activation_function_name=layer_architecture["activation_function"]
        
        
        self.name="activation_function-layer_"+str(self.layer_number)
        
        self.layer_output_tensor=activation_function_dict[self.activation_function_name](self.layer_input_tensor)
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name="layer_output-"+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()
        
class cross_entropy_with_logits_layer():
    def trainable_parameters():
        return []
    def settings():
        return []
    def input_tensors():
        return ["input_tensor_logits","labels"]
    def output_tensors():
        return [""]
        
    def __init__(self,layer_number,layer_architecture):
        """
        Cross entropy with logits
        used as cost function in clasification problems
        """
        self.input_tensor_logits=get_with_name(layer_architecture["input_tensor_logits"])
        self.labels=get_with_name(layer_architecture["labels"])
        self.layer_number=layer_number
        
        
        
        self.name="cross_entropy_with_logits-layer_"+str(self.layer_number)
        
        self.layer_output_tensor=tf.nn.softmax_cross_entropy_with_logits(logits=self.input_tensor_logits,labels=self.labels)
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name="layer_output-"+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()

class root_mean_square_error_layer():
    
    def trainable_parameters():
        return []
    def settings():
        return []
    def input_tensors():
        return ["input_tensor","labels"]
    def output_tensors():
        return [""]
        
    def __init__(self,layer_number,layer_architecture):
        """
        Cross entropy with logits
        used as cost function in clasification problems
        """
        self.input_tensor=get_with_name(layer_architecture["input_tensor"])
        self.labels=get_with_name(layer_architecture["labels"])
        self.layer_number=layer_number
        
        
        
        self.name="root_mean_square_error-layer_"+str(self.layer_number)
        
        self.layer_output_tensor=tf.sqrt(tf.reduce_mean(tf.square(self.input_tensor-self.labels)))
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name="layer_output-"+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()
class mean_square_error_layer():
    def trainable_parameters():
        return []
    def settings():
        return []
    def input_tensors():
        return ["input_tensor","labels"]
    def output_tensors():
        return [""]
        
    def __init__(self,layer_number,layer_architecture):
        """
        Cross entropy with logits
        used as cost function in clasification problems
        """
        self.input_tensor=get_with_name(layer_architecture["input_tensor"])
        self.labels=get_with_name(layer_architecture["labels"])
        self.layer_number=layer_number
        
        
        
        self.name="mean_square_error-layer_"+str(self.layer_number)
        
        self.layer_output_tensor=tf.reduce_mean(tf.square(self.input_tensor-self.labels))
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name="layer_output-"+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()

class addition_layer():
    def trainable_parameters():
        return []
    def settings():
        return []
    def input_tensors():
        return ["input_tensor_A","input_tensor_B"]
    def output_tensors():
        return [""]
        
    def __init__(self,layer_number,layer_architecture):
        """
        Cross entropy with logits
        used as cost function in clasification problems
        """
        self.input_tensor_A=get_with_name(layer_architecture["input_tensor_A"])
        self.input_tensor_B=get_with_name(layer_architecture["input_tensor_B"])
        self.layer_number=layer_number
        
        
        
        self.name="addition-layer_"+str(self.layer_number)
        
        self.layer_output_tensor=tf.add(self.input_tensor_A,self.input_tensor_B)
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name="layer_output-"+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()

class mean_layer():
    def trainable_parameters():
        return []
    def settings():
        return []
    def input_tensors():
        return ["input_tensor"]
    def output_tensors():
        return [""]
        
    def __init__(self,layer_number,layer_architecture):
        """
        Cross entropy with logits
        used as cost function in clasification problems
        """
        self.input_tensor=get_with_name(layer_architecture["input_tensor"])
        self.layer_number=layer_number
        
        
        
        self.name="mean-layer_"+str(self.layer_number)
        
        self.layer_output_tensor=tf.reduce_mean(self.input_tensor)
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name="layer_output-"+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()
        

class flatten_layer():
    def trainable_parameters():
        return []
    def settings():
        return []
    def input_tensors():
        return ["input_tensor"]
    def output_tensors():
        return [""]
        
    def __init__(self,layer_number,layer_architecture):
        """
        flatten an input
        
        """
        self.input_tensor=get_with_name(layer_architecture["input_tensor"])
        self.layer_number=layer_number
        
        self.layer_input_dim=self.input_tensor.shape.as_list()
        
        self.name="flatten-layer_"+str(self.layer_number)
        
        n_inputs=np.prod(self.layer_input_dim[1:]) # don't sum over data
        self.layer_output_tensor=tf.reshape(self.input_tensor,[-1,n_inputs])
        
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name="layer_output-"+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()

        
        