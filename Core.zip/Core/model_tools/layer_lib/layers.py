# -*- coding: utf-8 -*-
"""
Created on Fri Jan 31 15:17:44 2020

@author: Philip
"""
"""
Layer types:
    Neural Networks
    Pooling
    ActivationFunctions

All layers are initialized with the following atributes

layer_input_dim: Int Array
layer_input_tensor : TensorFlow Tensor
layer_number: int, identifiying the layer number
layer_architecture: dictionary with the required settings to construct the layer

Also these methods:

trainable_parameters(): Returns a list of the names of the trainable paramaters, e.g.: for NN ["W","b"]
settings(): returns a list of the names of the settings with their possible values (numerical or categorical)
            a=setings(); a[i]=[setting_name,setting_value_list]
                e.g.:   for activation function layers [["activation_function",["relu","relu6","sigmoid","tanh"]]]
            if the values are numerical setting_value_list="float"
                e.g.: [["layer_output_dim","float"]]
            
Layers also require to create the following atributes:
    self.layer_input_dim= Int Array
    self.layer_number= Int
    self.layer_output_dim= Int Array
    self.name="*layer_type*-layer_*layer_number*
    
    self.layer_output_tensor= Layer output tensorflow tensor 
    the output tensor name has to be: name="layer_output-"+self.name

if the layer has trainable parameters:
    self.*parameter*: Tensor with the trainable parameter from trainable_parameters()
    the name of the parameter tensors needs to be: name="trainable_parameter_"+self.name+"-*parameter*"
    
"""

import tensorflow as tf
#import tensorflow_probability as tfp
import numpy as np

LAYER_OUTPUT = "layer_output-"

def layer_name(clase, layer_number):
    return  clase.info["variable_name"]+'_'+str(layer_number)

def print_names():
    graph = tf.compat.v1.get_default_graph()
    for op in graph.get_operations():
        print(op.name)
#returns a tensor by calling it whit its name
def get_with_name(name):    
    return tf.compat.v1.get_default_graph().get_tensor_by_name(name+":0")

class fully_connected_layer():
    info = {
            "variable_name" : "fully_connected_layer",
            "visible_name":"Fully connected",
            "descripcion":"Capa completamente conectada",
            "inputs":[{
                "visible_name": "Tensor de entrada",
                "variable_name": "input_tensor",
                "descripcion" : "Descripción del tensor de entrada"
            }],
            "settings":[{
                    "visible_name":"Numero de valores ocultos",
                    "variable_name":"n_hidden_values",
                    "descripcion":"Descripcion de hidden values",
                    "type":"float"
                },
                {
                    "visible_name":"Función de activación",
                    "variable_name":"activation_function",
                    "descripcion":"Descripcion de función de activación",
                    "type":["relu","relu6","sigmoid","tanh","softmax","none"]
                }
            ],
            "outputs" :[]
        }
        
        

    def trainable_parameters():
        return ["W","b"]

    @classmethod
    def settings(cls):
        arr = []
        for s in cls.info["settings"]:
            arr.append([s["variable_name"],s["type"]])
        return arr
    @classmethod
    def input_tensors(cls):
        return [i["variable_name"] for i in cls.info["inputs"]]

    @classmethod
    def output_tensors():
        arr = [i["variable_name"] for i in cls.info["outputs"]]
        if(len(arr)==0):
            arr.append("")
        return arr
        
    def __init__(self,layer_number,layer_architecture):
        """
        Traditional fully connected layer
        layer_architecture dictionary requires the following 
        layer_output_dim
        ----------
        Implemented activation functions:
            relu
            relu6
            sigmoid
            tanh
            softmax
            none
        """

        def leaky_relu(x):
            return tf.nn.leaky_relu(x, alpha=0.01)
        
        activation_function_dict=dict(relu=tf.nn.relu,
                                      leaky_relu=leaky_relu,
                                      relu6=tf.nn.relu6,
                                      sigmoid=tf.nn.sigmoid,
                                      tanh=tf.nn.tanh,
                                      softmax=tf.nn.softmax,
                                      none=lambda *args: args[0])
        
        print_names()
        #layer_architecture["input_tensor"] = layer_architecture["input_tensor"].split("/")[-1]
        print("################################")
        self.layer_input_tensor=get_with_name(layer_architecture["input_tensor"])
        print("#######################")
        
        self.layer_input_dim=self.layer_input_tensor.shape.as_list()
        
        self.layer_number=layer_number
        
        self.hidden_values=layer_architecture["n_hidden_values"]

                
        #self.name="fully_connected-layer_"+str(self.layer_number)
        #self.name = fully_connected_layer.info["variable_name"]+'_'+str(self.layer_number)
        self.name = layer_name(fully_connected_layer, self.layer_number)
        
        activation_function_name=layer_architecture["activation_function"]
        activation_function=activation_function_dict[activation_function_name]
        
        
        n_inputs=np.prod(self.layer_input_dim[1:]) # don't sum over data
        input_reshape=tf.reshape(self.layer_input_tensor,[-1,n_inputs])
        
        init_weights = tf.contrib.layers.xavier_initializer()
        self.W=tf.compat.v1.get_variable( "trainable_parameter_"+self.name+"_W", [n_inputs, int(self.hidden_values)], dtype=tf.float32, initializer=init_weights)
        self.b=tf.compat.v1.get_variable( "trainable_parameter_"+self.name+"_b", [int(self.hidden_values)], dtype=tf.float32, initializer=init_weights)
        self.layer_output_tensor=activation_function(tf.matmul(input_reshape,self.W)+self.b)
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name=LAYER_OUTPUT+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()

class variational_normal_layer():
    info = {
            "variable_name" : "variational_normal_layer",
            "visible_name":"Variational Normal",
            "descripcion":"Variational Normal",
            "inputs":[{
                "visible_name": "Tensor de entrada",
                "variable_name": "input_tensor",
                "descripcion" : "Descripción del tensor de entrada"
            }],
            "settings":[{
                    "visible_name":"Tamaño de espacio latente",
                    "variable_name":"latent_space_size",
                    "descripcion":"Tamaño de espacio latente",
                    "type":"float"
                },
                {
                    "visible_name":"Función de activación",
                    "variable_name":"activation_function",
                    "descripcion":"Descripcion de función de activación",
                    "type":["relu","relu6","sigmoid","tanh","softmax","none"]
                }
            ],
            "outputs" :[
                {
                    "visible_name": "Mu",
                    "variable_name": "mu",
                    "descripcion" : "Mu"
                },
                {
                    "visible_name": "Sigma",
                    "variable_name": "sigma",
                    "descripcion" : "Sigma"
                },
                {
                    "visible_name": "Sample",
                    "variable_name": "sample",
                    "descripcion" : "Sample"
                },
                {
                    "visible_name": "KLdivergence",
                    "variable_name": "KLdivergence",
                    "descripcion" : "KLdivergence"
                }
            ]
        }
    def trainable_parameters():
        return ["W_mu","W_rho","b_mu","b_rho","prior_mu","prior_rho"]
    @classmethod
    def settings(cls):
        arr = []
        for s in cls.info["settings"]:
            arr.append([s["variable_name"],s["type"]])
        return arr
    @classmethod
    def input_tensors(cls):
        return [i["variable_name"] for i in cls.info["inputs"]]

    @classmethod
    def output_tensors():
        arr = [i["variable_name"] for i in cls.info["outputs"]]
        if(len(arr)==0):
            arr.append("")
        return arr
    
    """
    def settings():
        return [["latent_space_size","float"],
                ["activation_function",["relu","relu6","sigmoid","tanh","softmax","none"]]]
    def input_tensors():
        return ["input_tensor"]
    def output_tensors():
        return ["mu","sigma","sample","KLdivergence"]
    """    
        
        
    def __init__(self,layer_number,layer_architecture):
        """
        
        ----------
        Implemented activation functions:
            relu
            leaky_relu
            relu6
            sigmoid
            tanh
            softmax
            none
        """
        
        def leaky_relu(x):
            return tf.nn.leaky_relu(x, alpha=0.01)
        activation_function_dict=dict(relu=tf.nn.relu,
                                      leaky_relu=leaky_relu,
                                      relu6=tf.nn.relu6,
                                      sigmoid=tf.nn.sigmoid,
                                      tanh=tf.nn.tanh,
                                      softmax=tf.nn.softmax,
                                      none=lambda *args: args[0])
        
        print("#####################")
        self.layer_input_tensor=get_with_name(layer_architecture["input_tensor"])
        print("#####################2222")
        
        self.layer_input_dim=self.layer_input_tensor.shape.as_list()
        
        self.layer_number=layer_number
        
        self.latent_space_size=layer_architecture["latent_space_size"]
        
        
        #self.name="variational_normal-layer_"+str(self.layer_number)
        self.name = layer_name(variational_normal_layer, self.layer_number)
        
        activation_function_name=layer_architecture["activation_function"]
        activation_function=activation_function_dict[activation_function_name]
        
        
        n_inputs=np.prod(self.layer_input_dim[1:]) # don't sum over data
        input_reshape=tf.reshape(self.layer_input_tensor,[-1,n_inputs])
        
        init_weights = tf.contrib.layers.xavier_initializer()
        self.W_mu=tf.get_variable( "trainable_parameter_"+self.name+"_W_mu", [n_inputs, self.latent_space_size], dtype=tf.float32, initializer=init_weights)
        self.b_mu=tf.get_variable( "trainable_parameter_"+self.name+"_b_mu", [self.latent_space_size], dtype=tf.float32, initializer=init_weights)
        
        self.W_rho=tf.get_variable( "trainable_parameter_"+self.name+"_W_rho", [n_inputs, self.latent_space_size], dtype=tf.float32, initializer=init_weights)
        self.b_rho=tf.get_variable( "trainable_parameter_"+self.name+"_b_rho", [self.latent_space_size], dtype=tf.float32, initializer=init_weights)
        
        self.mu=activation_function(tf.matmul(input_reshape,self.W_mu)+self.b_mu)
        self.rho=activation_function(tf.matmul(input_reshape,self.W_rho)+self.b_rho)
        self.sigma=tf.nn.softplus(self.rho)
        
        
        self.layer_output_tensor_sigma=tf.identity(self.sigma,name=LAYER_OUTPUT+self.name+"_sigma")
        self.layer_output_dim_sigma=self.layer_output_tensor_sigma.shape.as_list()
        
        self.layer_output_tensor_mu=tf.identity(self.sigma,name=LAYER_OUTPUT+self.name+"_mu")
        self.layer_output_dim_mu=self.layer_output_tensor_mu.shape.as_list()
        
        
        self.layer_output_tensor_distribution=tfp.distributions.Normal(loc=self.mu,scale=self.sigma,name=LAYER_OUTPUT+self.name+"_distribution")
        self.layer_output_dim_distribution=self.layer_output_tensor_distribution.batch_shape.as_list()
        
        
        
        self.layer_output_tensor_sample=self.layer_output_tensor_distribution.sample()
        self.layer_output_tensor_sample=tf.identity(self.layer_output_tensor_sample,name=LAYER_OUTPUT+self.name+"_sample")
        self.layer_output_dim_sample=self.layer_output_tensor_sample.shape.as_list()
        
        
        self.prior_rho=tf.compat.v1.get_variable("trainable_parameter_"+self.name+"-prior_rho",shape=(),dtype=tf.float32)
        self.prior_mu=tf.compat.v1.get_variable("trainable_parameter_"+self.name+"-prior_mu",shape=(),dtype=tf.float32)
        self.prior_sigma=tf.nn.softplus(self.prior_rho)
        self.prior_dist=tfp.distributions.Normal(loc=self.prior_mu,scale=self.prior_sigma)
        
        self.layer_output_tensor_KLdivergence=tf.reduce_mean(self.layer_output_tensor_distribution.log_prob(self.layer_output_tensor_sample)-self.prior_dist.log_prob(self.layer_output_tensor_sample))
        self.layer_output_tensor_KLdivergence=tf.identity(self.layer_output_tensor_KLdivergence,name=LAYER_OUTPUT+self.name+"_KLdivergence")
        self.layer_output_dim_KLdivergence=self.layer_output_tensor_KLdivergence.shape.as_list()
        
        
        self.layer_output_tensor=[self.layer_output_tensor_mu,self.layer_output_tensor_sigma,self.layer_output_tensor_sample,self.layer_output_tensor_KLdivergence]
        self.layer_output_dim=[self.layer_output_dim_mu,self.layer_output_dim_sigma,self.layer_output_dim_sample,self.layer_output_dim_KLdivergence]
        
class negative_log_likelyhood_normal_layer():
    info = {
            "variable_name" : "negative_log_likelyhood_normal_layer",
            "visible_name":"Negative log likelyhood normal",
            "descripcion":"Capa probablemente normal con log negativo",
            "inputs":[{
                "visible_name": "Mu",
                "variable_name": "mu",
                "descripcion" : "Mu"
            },
            {
                "visible_name": "Sigma",
                "variable_name": "sigma",
                "descripcion" : "Sigma"
            },
            {
                "visible_name": "Labels",
                "variable_name": "labes",
                "descripcion" : "Labels"
            }],
            "settings":[],
            "outputs" :[]
        }
    def trainable_parameters():
        return []
    """
    def settings():
        return []
    def input_tensors():
        return ["mu","sigma","labels"]
    def output_tensors():
        return [""]
    """
    @classmethod
    def settings(cls):
        arr = []
        for s in cls.info["settings"]:
            arr.append([s["variable_name"],s["type"]])
        return arr
    @classmethod
    def input_tensors(cls):
        return [i["variable_name"] for i in cls.info["inputs"]]

    @classmethod
    def output_tensors():
        arr = [i["variable_name"] for i in cls.info["outputs"]]
        if(len(arr)==0):
            arr.append("")
        return arr
        
        
        
    def __init__(self,layer_number,layer_architecture):
        
        
        
        self.mu=get_with_name(layer_architecture["mu"])
        self.sigma=get_with_name(layer_architecture["sigma"])
        self.labels=get_with_name(layer_architecture["labels"])
        self.dist=tfp.distributions.Normal(loc=self.mu,scale=self.sigma)
        
        
        # self.layer_input_dim=self.layer_input_tensor.shape.as_list()
        
        self.layer_number=layer_number
        
        
        
        #self.name="negative_log_likelyhood_normal-layer_"+str(self.layer_number)
        self.name = layer_name(negative_log_likelyhood_normal_layer, self.layer_number)
        self.layer_output_tensor=tf.reduce_mean(-self.dist.log_prob(self.labels))
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name=LAYER_OUTPUT+self.name)
        self.layer_output_dims=self.layer_output_tensor.shape.as_list()
        

class recurrent_neural_network_layer():
    info = {
            "variable_name" : "recurrent_neural_network_layer",
            "visible_name":"Recurrent neural network",
            "descripcion":"descripcion de la red neuronal",
            "inputs":[{
                "visible_name": "Tensor de entrada",
                "variable_name": "input_tensor",
                "descripcion" : "Descripción del tensor de entrada"
            }],
            "settings":[{
                    "visible_name":"Numero de valores ocultos",
                    "variable_name":"n_hidden_values",
                    "descripcion":"Descripcion de hidden values",
                    "type":"float"
                },
                {
                    "visible_name":"Número de salidas",
                    "variable_name":"n_ouptuts",
                    "descripcion":"Descripcion del numero de salidas",
                    "type":"float"
                },
                {
                    "visible_name":"Función de activación para capas ocultas",
                    "variable_name":"activation_function_hidden_layer",
                    "descripcion":"Descripcion de función de activación para capas ocultas",
                    "type":["relu","relu6","sigmoid","tanh","softmax","none"]
                },
                {
                    "visible_name":"Salida de función de activación",
                    "variable_name":"activation_function_output",
                    "descripcion":"Descripcion de salida de función de activación",
                    "type":["relu","relu6","sigmoid","tanh","softmax","none"]
                }],            
            "outputs" :[] 
            }
    
    
    def trainable_parameters():
        return ["W_h","U_h","b_h","W_y","b_y"]
    """
    def settings():
        return [["n_hidden_values","float"],
                ["n_ouptuts","float"],
                ["activation_function_hidden_layer",["relu","relu6","sigmoid","tanh","softmax","none"]],
                ["activation_function_output",["relu","relu6","sigmoid","tanh","softmax","none"]]]
    """
    @classmethod
    def settings(cls):
        arr = []
        for s in cls.info["settings"]:
            arr.append([s["variable_name"],s["type"]])
        return arr

    @classmethod
    def input_tensors(cls):
        return [i["variable_name"] for i in cls.info["inputs"]]

    @classmethod
    def output_tensors():
        arr = [i["variable_name"] for i in cls.info["outputs"]]
        if(len(arr)==0):
            arr.append("")
        return arr
        
    def __init__(self,layer_number,layer_architecture):
        """
        Traditional fully connected layer
        layer_architecture dictionary requires the following 
        layer_output_dim
        ----------
        Implemented activation functions:
            relu
            relu6
            sigmoid
            tanh
            softmax
            none
        """
        
        activation_function_dict=dict(relu=tf.nn.relu,
                                      relu6=tf.nn.relu6,
                                      sigmoid=tf.nn.sigmoid,
                                      tanh=tf.nn.tanh,
                                      softmax=tf.nn.softmax,
                                      none=lambda *args: args[0])
        
        
        self.layer_input_tensor=get_with_name(layer_architecture["input_tensor"])
        
        self.layer_input_dim=self.layer_input_tensor.shape.as_list()
        
        self.layer_number=layer_number
        
        self.hidden_values=layer_architecture["n_hidden_values"]
        self.n_ouptuts=layer_architecture["n_ouptuts"]
        
        
        #self.name="recurrent_neural_network-layer_"+str(self.layer_number)
        self.name = layer_name(recurrent_neural_network_layer, self.layer_number)
        
        activation_function_name=layer_architecture["activation_function_hidden_layer"]
        activation_function_hidden_layer=activation_function_dict[activation_function_name]
        
        
        activation_function_name=layer_architecture["activation_function_output"]
        activation_function_output=activation_function_dict[activation_function_name]
        
        
        
        n_inputs=np.prod(self.layer_input_dim[2:]) # don't sum over data
        print(self.layer_input_dim)
        n_t=self.layer_input_dim[1]
        input_reshape=tf.reshape(self.layer_input_tensor,[-1,n_t,n_inputs])
        # input of tf scan requires the time axis to be the first axis
        input_swap=tf.transpose(input_reshape,[1,0,2])
        
        init_weights = tf.contrib.layers.xavier_initializer()
        self.W_h=tf.get_variable( "trainable_parameter_"+self.name+"_W_h", [n_inputs, self.hidden_values], dtype=tf.float32, initializer=init_weights)
        self.b_h=tf.get_variable( "trainable_parameter_"+self.name+"_b_h", [self.hidden_values], dtype=tf.float32, initializer=init_weights)
        
        self.U_h=tf.get_variable( "trainable_parameter_"+self.name+"_U_h", [self.hidden_values, self.hidden_values], dtype=tf.float32, initializer=init_weights)
        
        self.W_y=tf.get_variable( "trainable_parameter_"+self.name+"_W_y", [self.hidden_values, self.n_ouptuts], dtype=tf.float32, initializer=init_weights)
        self.b_y=tf.get_variable( "trainable_parameter_"+self.name+"_b_y", [self.n_ouptuts], dtype=tf.float32, initializer=init_weights)
        
        h_0=activation_function_hidden_layer(tf.matmul(input_swap[0,:,:],self.W_h)+self.b_h)
        y_0=activation_function_output(tf.matmul(h_0,self.W_y)+self.b_y)
        initializer=(y_0,h_0)
        def recurrent(prev_output,current_input):
            y_prev,h_prev=prev_output
            x_current=current_input
            h_current=activation_function_hidden_layer(tf.matmul(h_prev,self.U_h)+tf.matmul(x_current,self.W_h)+self.b_h)
            y_current=activation_function_output(tf.matmul(h_current,self.W_y)+self.b_y)
            return y_current,h_current
        
        y_swap,h_swap=tf.scan(recurrent,input_swap,initializer)
        
        
        self.layer_output_tensor=tf.transpose(y_swap,[1,0,2])
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name=LAYER_OUTPUT+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()
        
    
class activation_function_layer():
    info = {
            "variable_name" : "activation_function_layer",
            "visible_name":"Capa de función de activación",
            "descripcion":"descripcion de la capa",
            "inputs":[{
                "visible_name": "Tensor de entrada",
                "variable_name": "input_tensor",
                "descripcion" : "Descripción del tensor de entrada"
            }],
            "settings":[{
                    "visible_name":"Función de activación",
                    "variable_name":"activation_function",
                    "descripcion":"Descripcion de función de activación",
                    "type":["relu","relu6","sigmoid","tanh","softmax"]
                }],
            "outputs" :[] 
            }
    def trainable_parameters():
        return []
    @classmethod
    def settings(cls):
        arr = []
        for s in cls.info["settings"]:
            arr.append([s["variable_name"],s["type"]])
        return arr

    @classmethod
    def input_tensors(cls):
        return [i["variable_name"] for i in cls.info["inputs"]]

    @classmethod
    def output_tensors():
        arr = [i["variable_name"] for i in cls.info["outputs"]]
        if(len(arr)==0):
            arr.append("")
        return arr

    def __init__(self,layer_number,layer_architecture):
        """
        Neural network activation funcion layer
        layer_architecture dictionary requires the following :
            activation_function
        ----------
        Implemented activation functions:
            relu
            relu6
            sigmoid
            tanh
            softmax
        """
        activation_function_dict=dict(relu=tf.nn.relu,
                                      relu6=tf.nn.relu6,
                                      sigmoid=tf.nn.sigmoid,
                                      tanh=tf.nn.tanh,
                                      softmax=tf.nn.softmax)
        
        
        
        self.layer_input_tensor=get_with_name(layer_architecture["input_tensor"])
        self.layer_input_dim=self.layer_input_tensor.shape.as_list()
        self.layer_number=layer_number
        
        self.activation_function_name=layer_architecture["activation_function"]
        
        
        #self.name="activation_function-layer_"+str(self.layer_number)
        self.name = layer_name(activation_function_layer, self.layer_number)
        
        self.layer_output_tensor=activation_function_dict[self.activation_function_name](self.layer_input_tensor)
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name=LAYER_OUTPUT+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()
        
class cross_entropy_with_logits_layer():
    info = {
            "variable_name" : "cross_entropy_with_logits_layer",
            "visible_name":"Capa de entropía cruzada",
            "descripcion":"descripcion de la capa",
            "inputs":[{
                "visible_name": "Logits de tensor de entrada",
                "variable_name": "input_tensor_logits",
                "descripcion" : "Descripción del tensor de entrada"
            },
            {
                "visible_name": "Etiquetas",
                "variable_name": "labels",
                "descripcion" : "Descripción de etiquetas"
            }],
            "settings":[],
            "outputs" :[]
            }
    def trainable_parameters():
        return []
    @classmethod
    def settings(cls):
        arr = []
        for s in cls.info["settings"]:
            arr.append([s["variable_name"],s["type"]])
        return arr

    @classmethod
    def input_tensors(cls):
        return [i["variable_name"] for i in cls.info["inputs"]]
    
    @classmethod
    def output_tensors():
        arr = [i["variable_name"] for i in cls.info["outputs"]]
        if(len(arr)==0):
            arr.append("")
        return arr

    def __init__(self,layer_number,layer_architecture):
        """
        Cross entropy with logits
        used as cost function in clasification problems
        """
        self.input_tensor_logits=get_with_name(layer_architecture["input_tensor_logits"])
        self.labels=get_with_name(layer_architecture["labels"])
        self.layer_number=layer_number
        
        
        
        #self.name="cross_entropy_with_logits-layer_"+str(self.layer_number)
        self.name = layer_name(cross_entropy_with_logits_layer, self.layer_number)
        
        self.layer_output_tensor=tf.nn.softmax_cross_entropy_with_logits(logits=self.input_tensor_logits,labels=self.labels)
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name=LAYER_OUTPUT+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()

class root_mean_square_error_layer():
    info = {
            "variable_name" : "root_mean_square_error_layer",
            "visible_name":"Capa de promedio de raíz cuadrada del error",
            "descripcion":"descripcion de la capa",
            "inputs":[{
                "visible_name": "Tensor de entrada",
                "variable_name": "input_tensor",
                "descripcion" : "Descripción del tensor de entrada"
            },
            {
                "visible_name": "Etiquetas",
                "variable_name": "labels",
                "descripcion" : "Descripción de etiquetas"
            }],
            "settings":[],
            "outputs":[]
            }

    def trainable_parameters():
        return []
    @classmethod
    def settings(cls):
        arr = []
        for s in cls.info["settings"]:
            arr.append([s["variable_name"],s["type"]])
        return arr

    @classmethod
    def input_tensors(cls):
        return [i["variable_name"] for i in cls.info["inputs"]]
    
    @classmethod
    def output_tensors():
        arr = [i["variable_name"] for i in cls.info["outputs"]]
        if(len(arr)==0):
            arr.append("")
        return arr

    def __init__(self,layer_number,layer_architecture):
        """
        Cross entropy with logits
        used as cost function in clasification problems
        """
        #print("Nombre del layer es: "+layer_architecture["input_tensor"])
        self.input_tensor=get_with_name(layer_architecture["input_tensor"])
        self.labels=get_with_name(layer_architecture["labels"])
        self.layer_number=layer_number
        
        
        
        #self.name="root_mean_square_error-layer_"+str(self.layer_number)
        self.name = layer_name(root_mean_square_error_layer, self.layer_number)
        
        self.layer_output_tensor=tf.sqrt(tf.reduce_mean(tf.square(self.input_tensor-self.labels)))
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name=LAYER_OUTPUT+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()

class mean_square_error_layer():
    info = {
            "variable_name" : "mean_square_error_layer",
            "visible_name": "Mean square error",
            "descripcion":"descripcion de la capa",
            "inputs":[{
                "visible_name": "Tensor de entrada",
                "variable_name": "input_tensor",
                "descripcion" : "Descripción del tensor de entrada"
            },
            {
                "visible_name": "Etiquetas",
                "variable_name": "labels",
                "descripcion" : "Descripción de etiquetas"
            }],
            "settings":[],
            "outputs":[]
            }
    
    def trainable_parameters():
        return []
    @classmethod
    def settings(cls):
        arr = []
        for s in cls.info["settings"]:
            arr.append([s["variable_name"],s["type"]])
        return arr

    @classmethod
    def input_tensors(cls):
        return [i["variable_name"] for i in cls.info["inputs"]]

    @classmethod
    def output_tensors():
        arr = [i["variable_name"] for i in cls.info["outputs"]]
        if(len(arr)==0):
            arr.append("")
        return arr

    def __init__(self,layer_number,layer_architecture):
        """
        Cross entropy with logits
        used as cost function in clasification problems
        """
        self.input_tensor=get_with_name(layer_architecture["input_tensor"])
        layer_architecture["labels"] = layer_architecture["labels"].split("/")[-1]
        self.labels=get_with_name(layer_architecture["labels"])
        self.layer_number=layer_number
        
        
        
        #self.name="mean_square_error-layer_"+str(self.layer_number)
        self.name = layer_name(mean_square_error_layer, self.layer_number)
        
        self.layer_output_tensor=tf.reduce_mean(tf.square(self.input_tensor-self.labels)) # CAMBIADO
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name=LAYER_OUTPUT+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()

class addition_layer():
    info = {
            "variable_name" : "addition_layer",
            "visible_name": "Addition",
            "descripcion":"descripcion de la capa",
            "inputs":[{
                "visible_name": "Tensor de entrada A",
                "variable_name": "input_tensor_A",
                "descripcion" : "Descripción del tensor de entrada"
            },
            {
                "visible_name": "Tensor de entrada A",
                "variable_name": "input_tensor_B",
                "descripcion" : "Descripción del tensor de entrada"
            }],
            "settings":[],
            "outputs":[]
            }    
    def trainable_parameters():
        return []
    @classmethod
    def settings(cls):
        arr = []
        for s in cls.info["settings"]:
            arr.append([s["variable_name"],s["type"]])
        return arr

    @classmethod
    def input_tensors(cls):
        return [i["variable_name"] for i in cls.info["inputs"]]

    @classmethod
    def output_tensors():
        arr = [i["variable_name"] for i in cls.info["outputs"]]
        if(len(arr)==0):
            arr.append("")
        return arr

    def __init__(self,layer_number,layer_architecture):
        """
        Cross entropy with logits
        used as cost function in clasification problems
        """
        self.input_tensor_A=get_with_name(layer_architecture["input_tensor_A"])
        self.input_tensor_B=get_with_name(layer_architecture["input_tensor_B"])
        self.layer_number=layer_number
        
        
        
        #self.name="addition-layer_"+str(self.layer_number)
        self.name = layer_name(addition_layer, self.layer_number)
        
        self.layer_output_tensor=tf.sum(self.input_tensor_A,self.input_tensor_B)
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name=LAYER_OUTPUT+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()

class mean_layer():
    info = {
            "variable_name" : "mean_layer",
            "visible_name": "Mean",
            "descripcion":"descripcion de la capa",
            "inputs":[{
                "visible_name": "Tensor de entrada",
                "variable_name": "input_tensor",
                "descripcion" : "Descripción del tensor de entrada"
            }],
            "settings":[],
            "outputs":[]
            }    
    
    def trainable_parameters():
        return []
    @classmethod
    def settings(cls):
        arr = []
        for s in cls.info["settings"]:
            arr.append([s["variable_name"],s["type"]])
        return arr

    @classmethod
    def input_tensors(cls):
        return [i["variable_name"] for i in cls.info["inputs"]]
    
    @classmethod
    def output_tensors():
        arr = [i["variable_name"] for i in cls.info["outputs"]]
        if(len(arr)==0):
            arr.append("")
        return arr

    def __init__(self,layer_number,layer_architecture):
        """
        Cross entropy with logits
        used as cost function in clasification problems
        """
        self.input_tensor=get_with_name(layer_architecture["input_tensor"])
        self.layer_number=layer_number
        
        
        
        #self.name="mean-layer_"+str(self.layer_number)
        self.name = layer_name(mean_layer, self.layer_number)
        
        self.layer_output_tensor=tf.reduce_mean(self.input_tensor)
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name=LAYER_OUTPUT+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()
        

class flatten_layer():
    info = {
            "variable_name" : "flatten_layer",
            "visible_name": "Flatten",
            "descripcion":"descripcion de la capa",
            "inputs":[{
                "visible_name": "Tensor de entradaaa",
                "variable_name": "input_tensor",
                "descripcion" : "Descripción del tensor de entrada"
            }],
            "settings":[],
            "outputs":[]
            }   
    
    def trainable_parameters():
        return []
    @classmethod
    def settings(cls):
        arr = []
        for s in cls.info["settings"]:
            arr.append([s["variable_name"],s["type"]])
        return arr

    @classmethod
    def input_tensors(cls):
        return [i["variable_name"] for i in cls.info["inputs"]]

    @classmethod
    def output_tensors():
        arr = [i["variable_name"] for i in cls.info["outputs"]]
        if(len(arr)==0):
            arr.append("")
        return arr

    def __init__(self,layer_number,layer_architecture):
        """
        flatten an input
        
        """
        self.input_tensor=get_with_name(layer_architecture["input_tensor"])
        self.layer_number=layer_number
        
        self.layer_input_dim=self.input_tensor.shape.as_list()
        
        #self.name="flatten-layer_"+str(self.layer_number)
        self.name = layer_name(flatten_layer, self.layer_number)
        
        n_inputs=np.prod(self.layer_input_dim[1:]) # don't sum over data
        self.layer_output_tensor=tf.reshape(self.input_tensor,[-1,int(n_inputs)])
        
        self.layer_output_tensor=tf.identity(self.layer_output_tensor,name=LAYER_OUTPUT+self.name)
        
        self.layer_output_dim=self.layer_output_tensor.shape.as_list()

        



