# -*- coding: utf-8 -*-
"""
Created on Wed May  6 15:21:52 2020
outlier removal algorithms
@author: Philip
"""
import numpy as np
def is_number(x):
    #Checks if the input object is numerical
    return isinstance(x, (int, float, complex)) and not isinstance(x, bool)


def z_score(data,max_score=3):
    #Returns the z score of the data in the columns
    n_values=len(data[0])
    # mean=np.mean(data,axis=0)
    # std=np.std(data,axis=0)
    z_score_=np.zeros(np.shape(data))
    for j in range(n_values):
        mean_j=np.mean(data[:,j])
        std_j=np.std(data[:,j])
        z_score_j=(data[:,j]-mean_j)/std_j
        for i in range(len(data[:,0])):
            z_score_[i,j]=z_score_j[i]
    
    return z_score_

def hampel_filter(data,window_size=30,max_score=2.5):
    data_j=data[:,0]
    def hampel_filter_forloop(input_series, window_size=10, n_sigmas=3):
        
        n = len(input_series)
        new_series = input_series.copy()
        k = 1.4826 # scale factor for Gaussian distribution
        
        indices = []
        
        # possibly use np.nanmedian 
        for i in range((window_size),(n - window_size)):
            x0 = np.median(input_series[(i - window_size):(i + window_size)])
            S0 = k * np.median(np.abs(input_series[(i - window_size):(i + window_size)] - x0))
            if (np.abs(input_series[i] - x0) > n_sigmas * S0):
                new_series[i] = x0
                indices.append(i)
        
        return new_series, indices
    filtered_data=np.zeros(np.shape(data))
    for j in range(len(data[0])):
        data_j=data[:,j]
        filtered_data_j,indices_j=hampel_filter_forloop(data_j)
        filtered_data[:,j]=filtered_data_j
        
    return filtered_data
        
        
        
        
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    








