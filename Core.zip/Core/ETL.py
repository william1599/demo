# -*- coding: utf-8 -*-
"""
Created on Wed Oct 13 15:39:42 2021

@author: imap0
"""
import pandas as pd
import numpy as np
import json
import os
class ETL():
    def __init__(self,nombre_etl):
        self.ruta_guardado="save"
        self.nombre_etl=nombre_etl
        
        self.path = None
        
        
    def set_path(self, path):
        self.path = path
        print(path)
    def inicializar_ETL(self,ruta_datos,operacion_rangos,operacion_seleccion_columnas,informacion_tipos):
        print("INICIALIZET ETL ///////////////////////")
        self.cargar_data(ruta_datos)
        self.columnas=list(self.raw_data.columns)
        # self.datos=self.raw_data.values
        
        self.informacion_tipos=informacion_tipos
        self.operacion_seleccion_columnas=operacion_seleccion_columnas
        self.operacion_rangos=operacion_rangos
        
        self.one_hot_encoder_metadata=self.one_hot_encoding_initialize(self.informacion_tipos)
        
        self.aplicar_operaciones()
        self.crear_metadata_entrada_etl()
        self.save_etl_metadata()
        
    def crear_metadata_entrada_etl(self):
        metadata_entrada=[]
        for dictionary in self.input_data_dict:
            metadata_dict={}
            name=dictionary["data_name"]
            data_columns=dictionary["data_columns"]
            list_tipos=[]
            list_columnas=[]
            i=0
            while i < len(data_columns):
                
                col=data_columns[i]
                print(col)
                if "_CLASE_" in col:
                    nombre_columna,clase=col.split("_CLASE_")
                    clases=[clase]
                    nombre_columna_i=nombre_columna
                    while nombre_columna_i==nombre_columna and i <len(data_columns)-1:
                        i+=1
                        print(i)
                        nombre_columna_i,clase=data_columns[i].split("_CLASE_")
                        clases.append(clase)
                    tipo_entrada=clases
                else:
                    nombre_columna=col
                    tipo_entrada=self.informacion_tipos[col]
                list_tipos.append(tipo_entrada)
                list_columnas.append(nombre_columna)
                i+=1
            metadata_dict["data_name"]=name
            metadata_dict["data_input_names"]=list_columnas
            metadata_dict["data_types"]=list_tipos
            metadata_entrada.append(metadata_dict)
        
                        
            
        self.metadata_entrada=metadata_entrada
    def obtener_data_solicitada(self,entradas):
        print("obtener_data_solicitada")
        metadata_entrada=self.metadata_entrada
        print(metadata_entrada)
        entradas_solicitadas=[]
        entradas_tipos=[]
        for i in range(len(metadata_entrada)):
            if metadata_entrada[i]["data_name"] in entradas:
                for j in range(len(metadata_entrada[i]["data_input_names"])):
                    if metadata_entrada[i]["data_input_names"][j] not in entradas_solicitadas:
                        entradas_solicitadas.append(metadata_entrada[i]["data_input_names"][j])
                        entradas_tipos.append(metadata_entrada[i]["data_types"][j])
        data_input_usuario={"data_column_names":entradas_solicitadas,
               "data_types":entradas_tipos}
        return data_input_usuario


    def convertir_input_usuario_en_dataset_dict(self,data_input_usuario):
        print("convertir_input_usuario_en_dataset_dict")
        metadata_entrada=self.metadata_entrada
        input_data_dict=self.input_data_dict
        entradas_usuario=list(data_input_usuario.keys())
        data=[[]]
        for name in self.columnas:
            if name in entradas_usuario:
                print("if")
                print(data_input_usuario[name])
                data[0].append(data_input_usuario[name])
            else:
                #print("else")
                data[0].append(0)
        self.raw_data=pd.DataFrame(data,columns=self.columnas)
        self.datos=pd.DataFrame(data,columns=self.columnas).values
        self.aplicar_operaciones()
            
        
        
        
        
        
        

    def cargar_metadatos_ETL(self):
        print("cargar_metadatos_ETL")
        ruta=self.path + os.sep + self.ruta_guardado + os.sep + self.nombre_etl + "_metadata.json"
        print(ruta)
        f = open(ruta,)
        self.metadata=json.load(f)
        print(self.metadata)
        self.columnas=self.metadata["columnas"]
        self.ruta_datos_originales=self.metadata["ruta_datos_originales"]
        self.informacion_tipos=self.metadata["informacion_tipos"]
        self.one_hot_encoder_metadata=self.metadata["one_hot_encoder_metadata"]
        self.operacion_rangos=self.metadata["operacion_rangos"]
        self.operacion_seleccion_columnas=self.metadata["operacion_seleccion_columnas"]
        
        self.input_data_dict=self.metadata["input_data_dict"]
        self.metadata_entrada=self.metadata["metadata_entrada"]
        
    def cargar_data(self,ruta_datos):
        self.ruta_datos=ruta_datos
        self.raw_data=pd.read_csv(ruta_datos,skipinitialspace=True)
        self.datos=self.raw_data.values
        
        
    def aplicar_operaciones(self):
        self.datos=self.seleccionar_rangos(self.operacion_rangos)
        self.dataset_dict,self.input_data_dict=self.seleccionar_columnas(self.operacion_seleccion_columnas)
        self.aplicar_one_hot()

        
        
        
        
        
    def seleccionar_rangos(self,operacion_rangos):
        datos=self.datos
        for rangos in operacion_rangos:
            indices_a_conservar=[]
            columna=np.argmax(np.array(self.columnas)== list(rangos.values())[2])
            rango_min=list(rangos.values())[1]
            rango_max=list(rangos.values())[0]
            for i in range(len(datos)):
                conservar=True
                if rango_min!=None and rango_min!="":
                    if datos[i,columna]<rango_min:
                        conservar=False
                if rango_max!=None and rango_max!="":
                    if datos[i,columna]>rango_max:
                        conservar=False
                if conservar==True:
                    indices_a_conservar.append(i)
            datos=datos[indices_a_conservar]
        return datos
                    
                        
                
    
    def seleccionar_columnas(self,operacion_seleccion_columnas):
        """Esta funcion crea los distintos diccionarios a partir de la data actual"""
        dataset_dict=[]
        input_data_dict=[]
        for nombre_dataset in operacion_seleccion_columnas:
            columnas=operacion_seleccion_columnas[nombre_dataset]
            new_columnas=[]
            new_units=[]
            columnas_agregadas=[]
            for columna in columnas:
                
                splitted=columna.split("[")
                if len(splitted)==1:
                    unidades=""
                elif len(splitted)>2:
                    unidades=""
                else:
                    unidades=splitted[1]
                    splitted2=unidades.split("]")
                    if len(splitted2)==2 and splitted2[1]=="":
                        unidades=splitted2[0]
                        columna=splitted[0]
                    else:
                        unidades=""
                if columna in columnas_agregadas:
                    i=1
                    while True:
                        nombre_tentativo=columna+" "+str(i)
                        if nombre_tentativo in columnas_agregadas:
                            i=i+1
                        else: 
                            # columna=nombre_tentativo
                            break
                    columna=columna
                
                columnas_agregadas.append(columna)
                new_columnas.append(columna.strip())
                new_units.append(unidades)
            columnas=new_columnas
            unidades=new_units
                
            data=self.raw_data[columnas].values
            
            
            
            dictionary={"data_name":nombre_dataset,
                        "data_dims":[len(columnas)],
                        "data_columns":columnas,
                        "data_columns_units":unidades,
                        "data":data}
            dataset_dict.append(dictionary)
            
            dictionary2={"data_name":nombre_dataset,
                        "data_dims":[len(columnas)],
                        "data_columns":columnas,
                        "data_columns_units":unidades}
            input_data_dict.append(dictionary2)
        return dataset_dict,input_data_dict
    
    def one_hot_encoding_initialize(self,informacion_tipos):
        data_one_hot_input_dict={}
        
        datos=self.seleccionar_rangos(self.operacion_rangos)
        self.dataset_dict,self.input_data_dict=self.seleccionar_columnas(self.operacion_seleccion_columnas)
        for dataset_dict in self.dataset_dict:
            metadadata_one_hot=[]
            columnas=dataset_dict["data_columns"]
            data_name=dataset_dict["data_name"]
            
            for col_i in range(len(columnas)):
                col=columnas[col_i]
                tipo=informacion_tipos[col]
                if tipo=="string": # Se aplica one hot a los strings para evaluar como clases
                
                    metadata={}
                    metadata["nombre_columna"]=col
                    metadata["ubicacion"]=col_i
                    
                    data_col=self.raw_data[col]
                    clases=pd.unique(data_col)
                    for i in range(len(clases)):
                        if clases[i]!=clases[i]:
                            clases=np.delete(clases,i)# sacamos la clase nan
                            break
                    clases=list(clases)
                    clases.append("Sin Infromacion")
                    metadata["clases"]=clases
                    metadadata_one_hot.append(metadata)
            n_one_hot_columns=len(metadadata_one_hot)
            
            if n_one_hot_columns!=0:
                i_=len(columnas)-n_one_hot_columns-1
                for i in range(n_one_hot_columns):
                    ubicacion_clases=[]
                    for j in range(len(metadadata_one_hot[i]["clases"])):
                        i_+=1
                        ubicacion_clases.append(i_)
                    metadadata_one_hot[i]["ubicacion_clases"]=ubicacion_clases
            data_one_hot_input_dict[data_name]=metadadata_one_hot
                
                
        
        return data_one_hot_input_dict
    def aplicar_one_hot(self):
        # Aplica el one hot encoding, se debe utilizar despues de inicializar las columnas
        # Se cicla por dataset dict
        for data_name in self.one_hot_encoder_metadata:# se cicla por los datastes
            metadadata_one_hot=self.one_hot_encoder_metadata[data_name]
            if len(metadadata_one_hot)==0:continue #Si no tiene one hot la saltamos
            data_dict=[x for x in self.dataset_dict if x["data_name"]==data_name][0]
            i_dict=[i for i in range(len(self.dataset_dict)) if self.dataset_dict[i]["data_name"]==data_name][0]
            
            data=np.array(data_dict["data"])
            data_columns=data_dict["data_columns"]
            data_dims=data_dict["data_dims"]
            
            one_hot_list=[]
            one_hot_columns=[]
            ubicaciones_a_eliminar=[]
            # Se cicla por columnas one hot
            for col_i in range(len(metadadata_one_hot)):
                col_metadata=metadadata_one_hot[col_i]
                
                col=col_metadata["nombre_columna"]
                ubicacion=col_metadata["ubicacion"]
                clases=col_metadata["clases"]
                
                clases_column_name=[col+"_CLASE_"+clase for clase in clases]
                
                
                if col in data_columns:
                        
                    nuevas_columnas=clases_column_name
                    one_hot_data=np.zeros([len(data),len(nuevas_columnas)])
                    for i in range(len(data)): # se crea el One hot ciclando por la data
                        clase_actual=data[i,ubicacion]
                        if clase_actual in clases:
                            index=[x for x in range(len(clases)) if clases[x]==clase_actual][0]
                        else:
                            index=len(clases)-1
                        one_hot_data[i,index]=1
                        
                        
                    one_hot_list.append(one_hot_data)
                    one_hot_columns.append(nuevas_columnas)
                    ubicaciones_a_eliminar.append(ubicacion)
            
            
            nuevas_columnas_dict=[data_columns[x] for x in range(len(data_columns)) if not x in ubicaciones_a_eliminar]
            
            self.dummy=nuevas_columnas_dict
            for l in one_hot_columns:
                nuevas_columnas_dict+=l
            
            nueva_data_dict=np.delete(data,ubicaciones_a_eliminar,1)
            for oh in one_hot_list:
                nueva_data_dict=np.concatenate((nueva_data_dict,oh),axis=1)
            nuevas_dims=[len(nuevas_columnas_dict)]
            
            self.dataset_dict[i_dict]["data"]=nueva_data_dict
            self.dataset_dict[i_dict]["data_columns"]=nuevas_columnas_dict
            self.dataset_dict[i_dict]["data_dims"]=nuevas_dims
            self.dataset_dict[i_dict]["data_columns_original"]=data_columns
            
            self.input_data_dict[i_dict]["data_columns"]=nuevas_columnas_dict
            self.input_data_dict[i_dict]["data_columns_original"]=data_columns
            self.input_data_dict[i_dict]["data_dims"]=nuevas_dims
    def devolver_onehot_a_string(self):
        new_dataset_dict=[]
        # Se cicla por dataset dict
        for data_dict in self.dataset_dict:# se cicla por los datastes
            data_name=data_dict["data_name"]
            if self.one_hot_encoder_metadata[data_name]!=[]:
                metadata_one_hot=self.one_hot_encoder_metadata[data_name]
                if len(metadata_one_hot)==0:continue #Si no tiene one hot la saltamos
                data_dict=[x for x in self.dataset_dict if x["data_name"]==data_name][0]
                i_dict=[i for i in range(len(self.dataset_dict)) if self.dataset_dict[i]["data_name"]==data_name][0]
                
                data=np.array(data_dict["data"])
                data_columns=data_dict["data_columns"]
                ubicacion_original_columnas=data_dict["data_columns_original"]
                data_dims=data_dict["data_dims"]
                lista_columnas=[]
                ubicacion_col_list=[]
                indices_columnas_one_hot=[]
                for metadata in metadata_one_hot:
                    indices_columnas=metadata["ubicacion_clases"]
                    indices_columnas_one_hot+=indices_columnas
                    current_one_hot_data=data[:,indices_columnas]
                    clases=metadata["clases"]
                    columna_con_string=[]
                    for row in current_one_hot_data:
                        clase=clases[np.argmax(row)]
                        columna_con_string.append(clase)
                    columna_con_string=np.reshape(np.array(columna_con_string),[-1,1])
                    lista_columnas.append(columna_con_string)
                    ubicacion_col_list.append(metadata["ubicacion"])
                    
                
                data_sin_onehot=data[:,:min(indices_columnas_one_hot)]
                i=0
                j=0
                n=0
                j_max=len(data_sin_onehot[0])
                i_max=len(indices_columnas_one_hot)
                inicio=True
                
                while True:
                    if i==i_max and j==j_max:break
                    # if j>j_max:break
                    Terminamos=True
                    if inicio:                    
                        if i in ubicacion_col_list:
                            i_index=[k for k in range(len(ubicacion_col_list)) if ubicacion_col_list[k]==i][0]
                            Values=lista_columnas[i_index]
                            
                            i+=1
                            Terminamos=False
                        else:
                            Values=data_sin_onehot[:,j:j+1]
                            j+=1
                            i+=1
                            Terminamos=False
                        inicio=False
                    else:
                        if i in ubicacion_col_list:
                            i_index=[k for k in range(len(ubicacion_col_list)) if ubicacion_col_list[k]==i][0]
                            Values=np.concatenate([Values,lista_columnas[i_index]],axis=1)
                            i+=1
                            Terminamos=False
                        elif j<j_max:
                            # print(i)
                            # print(np.shape(Values))
                            Values=np.concatenate([Values,data_sin_onehot[:,j:j+1]],axis=1)
                            j+=1
                            i+=1
                            Terminamos=False
                    # print(j)
                    if Terminamos:break
                self.dummy=self.dataset_dict
                data_dict={"data_name":data_dict["data_name"],
                           "data_dims":[len(Values[0])],
                           "data_columns":ubicacion_original_columnas,
                           "data":Values,
                           "data_columns_units":data_dict["data_columns_units"]}
                new_dataset_dict.append(data_dict)
            else:
                new_dataset_dict.append(data_dict)
        self.dummy=new_dataset_dict
            # new_dataset_dict
        return new_dataset_dict
            
            
        1
        
        
        
        
        
    def save_etl_metadata(self):
        print('save_etl_metadata')
        metadata={}
        metadata["one_hot_encoder_metadata"]=self.one_hot_encoder_metadata
        metadata["nombre_etl"]=self.nombre_etl
        metadata["columnas"]=self.columnas
        metadata["informacion_tipos"]=self.informacion_tipos
        metadata["ruta_datos_originales"]=self.ruta_datos
        metadata["operacion_rangos"]=self.operacion_rangos
        metadata["operacion_seleccion_columnas"]=self.operacion_seleccion_columnas
        metadata["input_data_dict"]=self.input_data_dict
        metadata["metadata_entrada"]=self.metadata_entrada
        print("termine de salvar los datos a guardar")
        self.metadata=metadata
        with open(self.path+os.sep+self.ruta_guardado+os.sep+self.nombre_etl+"_"+'metadata.json', 'w') as fp:
            json.dump(metadata, fp)
        
        
        