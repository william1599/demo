# -*- coding: utf-8 -*-
"""
Created on Tue Nov 23 15:33:27 2021

@author: imap0
"""


import pandas as pd
import os
import model_tools.data_operations as dp
import model_tools.model_class as model
import tensorflow as tf
model=model.model

# Datos de entrada
carpeta_datos="datos"
nombre_datos="DatasetCreado.csv"
if carpeta_datos=="":
    ruta_datos=nombre_datos
else:
    ruta_datos=carpeta_datos+os.sep+nombre_datos

Cols=["Sensor 1","Sensor 2","Temperatura Preferida","F 1","F 2","Voto"]

informacion_tipos={"Sensor 1": "numero",
                   "Sensor 2": "numero",
                   "Temperatura Preferida":"string",
                   "F 1":"numero",
                   "F 2":"numero",
                   "Voto":"string"}
operacion_seleccion_columnas={"Entrada":["Sensor 1","Sensor 2","Temperatura Preferida"],
                              "Salida":["F 1","F 2","Voto"]}           
operacion_rangos=[["Sensor 1",0,50]]
        
nombre_etl="ETL2"

from ETL import ETL

# Seccion de ETLs del front
# Se constuye el ETL
e=ETL(nombre_etl)


# Inicializa el etl
e.inicializar_ETL(ruta_datos,operacion_rangos,operacion_seleccion_columnas,informacion_tipos)



input_data_dict=e.input_data_dict # Va al parameters
dataset_dict=e.dataset_dict # Va a normalizar->entrada modelo para entrenar




