
class InternalServerError(Exception):
    pass

class SchemaValidationError(Exception):
    pass

class UnauthorizedError(Exception):
    pass

class LoadDataError(Exception):
    pass

class LoadETLError(Exception):
    pass

class LoadEntryDataError(Exception):
    pass

class LoadModelError(Exception):
    pass

class EvaluateError(Exception):
    pass

class OutputError(Exception):
    pass

class generateModelError(Exception):
    pass

class NormalizeError(Exception):
    pass

class TrainError(Exception):
    pass

errors = {
    "InternalServerError": {
        "message": "Something went wrong",
        "status": 500
    },
     "SchemaValidationError": {
         "message": "Request is missing required fields",
         "status": 400
     },
     "UnauthorizedError": {
         "message": "Sin autorización",
         "status": 401
     },
     "LoadDataError": {
         "message": "Error al cargar los datos",
         "status": 500
     },
     "LoadETLError": {
         "message": "Error al cargar los datos de ETL. Verifique el tensor de entrada de la arquitectura.",
         "status": 500
     },
     "LoadEntryDataError": {
         "message": "Error al cargar datos de entrada",
         "status": 400
     },
     "LoadModelError": {
         "message": "Error al cargar los datos del modelo",
         "status": 400
     },
     "EvaluateError": {
         "message": "Error al evaluar los datos con el modelo",
         "status": 400
     },
     "OutputError": {
         "message": "Error al generar los datos de salida",
         "status": 400
     },
     "generateModelError": {
         "message": "Error al crear el modelo. Verifique que la arquitectura sea correcta",
         "status": 400
     },
     "NormalizeError": {
         "message": "Error al normalizar los datos",
         "status": 400
     },
     "TrainError": {
         "message": "Error al entrenar",
         "status": 400
     }
}