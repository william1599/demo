# -*- coding: utf-8 -*-
"""
Created on Mon Apr 20 13:08:13 2020

@author: Philip
"""

""

from tkinter import *
from tkinter.ttk import *
from tkinter import ttk
import copy
import data_operations
import numpy as np
from Import_Data import MNIST
from model_tools.layer_lib import layers,layer_info
"""
Data pre processing
"""
X,Y=MNIST.import_data_set()
X=np.reshape(X,[-1,28,28])
X,Y=data_operations.sample(X,Y,N=1000)
X_train,X_test,X_val,Y_train,Y_test,Y_val=data_operations.slice_train_test_validation(X,Y,train_size=0.6,test_size=0.2,val_size=0.2)


input_dim_=np.array(X_train.shape)[1:]
output_dim_=np.array(Y_train.shape)[1:]

entry_data_name=("MNIST","MNIST2","MNIST_Label")
entry_data_dims=(input_dim_,input_dim_,output_dim_)


""" 
Inputs Window
"""


window1 = Tk()
window1.title("Data")
window1.geometry('500x400')
data_input_combos=[]
for i in range( 10):
        data_input_combos.append(Combobox(window1,state="readonly",values=entry_data_name))
        data_input_combos[i].grid(column=1, row=i+1)
        if i==0:data_input_combos[i].current(0)
        elif i==1: data_input_combos[i].current(1)
        elif i==2: data_input_combos[i].current(2)
        
        
        
data_name=[]
def got_to_layers():
    for i in range(10):
        current=data_input_combos[i].get()
        if current=="":
            continue
        data_name.append(data_input_combos[i].get())
    window1.destroy()
        
    
next1_button=Button(window1,text="next>",command=got_to_layers)
next1_button.grid(column=1, row=i+2)
window1.mainloop()

data_dims=[]
for data_entry in data_name:
    index=entry_data_name.index(data_entry)
    current=entry_data_dims[index]
    data_dims.append(current)


""" 
Layers Window
"""

layer_settings_dict=layer_info.layer_settings_dictionary()
layer_trainable_parameters_dict=layer_info.layer_trainable_parameters_dictionary()
layer_input_tensors_dict=layer_info.layer_input_tensors_dictionary()

layer_types = [func for func in dir(layers) if "_layer" in func]
for i in range(len(layer_types)):
    layer_types[i]=layer_types[i].replace("_layer","")


layer_windows=[]
go_to_costs=False
layer_n=0
variables=copy.deepcopy(data_name)


layer_architectures=[]
trainable_parameters_names=[]
layer_output_names=[]
def set_layer():
    global layer_n
    layer_type_=layer_type_combo.get()
    setting_dict=dict(layer_type=layer_type_)
    for i in range(len(setting_widgets)):
        setting=layer_settings_dict[layer_type_][i][0]
        value=setting_widgets[i].get()
        if layer_settings_dict[layer_type_][i][1]=="float":
            #the seting is an int_value
            value=float(value)
        setting_dict.update([(setting,value)])
    for i in range(len(input_widgets)):
        input_name=layer_input_tensors_dict[layer_type_][i]
        value=input_widgets[i].get()
        
        setting_dict.update([(input_name,value)])
    
    layer_architectures.append(setting_dict)
    
    trainable_parameters_i=layer_trainable_parameters_dict[layer_type_]
    for parameter in trainable_parameters_i:
        trainable_parameters_names.append("trainable_parameter-"+layer_type_+"-layer_"+str(layer_n)+"-"+parameter)
    output_name="layer_output-"+layer_type_+"-layer_"+str(layer_n)
    layer_output_names.append(output_name)
    variables.append(output_name)
    
    
    


def new_layer_f():
    global set_layer
    set_layer()
    global go_to_costs
    go_to_costs=False
    win.destroy()

def go_to_cost_f():
    global set_layer
    set_layer()
    global go_to_costs
    win.destroy()
    
def select_layer():
#    layer_type_button["state"]="disabled"
#    layer_type_combo["state"]="disabled"
    global setting_widgets
    global setting_labels
    global input_labels
    global input_widgets
    
    
    for i in range(len(setting_widgets)):
        setting_labels[i].destroy()
        setting_widgets[i].destroy()
    current_type=layer_type_combo.get()
#    current_type_index=layer_types.index(current_type)
    
    settings=layer_settings_dict[current_type]
    layer_input_tensors=layer_input_tensors_dict[current_type]
    current_row=3
    i=0
    
    input_widgets=[]
    input_labels=[]
    for input_tensor in layer_input_tensors:
        input_labels.append(Label(win,text=input_tensor))        
        input_widgets.append(Combobox(win,state="readonly",values=variables,width=40))
        
        input_widgets[i].grid(column=1,row=current_row+i)
        input_widgets[i].current(0)
        input_labels[i].grid(column=0,row=current_row+i)
        i=i+1
    current_row=current_row+i
    i=0
    setting_widgets=[]
    setting_labels=[]
    for setting in settings:
        setting_labels.append(Label(win,text=setting[0]))
        if setting[1]=="float":
            #the setting is an intiger
            setting_widgets.append(Spinbox(win, from_=1,to=1000000000000000, width=5))
            
#            setting_widgets[i].grid(column=1,row=current_row+i)
#            setting_labels[i].grid(column=0,row=current_row+i)
        else:
            setting_widgets.append(Combobox(win,state="readonly",values=setting[1],width=40))
            setting_widgets[i].current(0)
        setting_widgets[i].grid(column=1,row=current_row+i)
        setting_labels[i].grid(column=0,row=current_row+i)
            
        i=i+1 
    
    new_layer_button=Button(win,text="Next Layer",command=new_layer_f)
    new_layer_button.grid(column=0,row=current_row+i)
    
    go_to_costs_button=Button(win,text="Finish and go to Costs",command=go_to_cost_f)
    go_to_costs_button.grid(column=1,row=current_row+i)
    
    
    
while not go_to_costs:
    
    layer_windows.append(Tk())
    win=layer_windows[layer_n]
    win.title("Layer "+str(layer_n+1))
    win.geometry('500x400')
    
    
    layer_type_label=Label(win,text="Layer Type")
    layer_type_label.grid(column=0,row=1)
    layer_type_combo=Combobox(win,state="readonly",values=layer_types,width=40)
    layer_type_combo.grid(column=1,row=1)
    layer_type_button=Button(win,text="Ok",command=select_layer)
    layer_type_button.grid(column=2,row=1)
    
    setting_widgets=[]
    setting_labels=[]
    go_to_costs=True
    win.mainloop()
    layer_n+=1



"""
Output of the GUI
"""


data=[X,X,Y]
data_name
data_dims

input_data_dict=[]
for i in range(len(data_name)):
    input_data.append(dict(data_name=data_name[i],data_dims=data_dims[i]))
    

layer_architectures=[{'layer_type': 'fully_connected',
  'layer_output_dim': 100.0,
  'input_tensor': 'MNIST'},
 {'layer_type': 'activation_function',
  'activation_function': 'sigmoid',
  'input_tensor': 'layer_output-fully_connected-layer_0'}]
trainable_parameters_names=['trainable_parameter-fully_connected-layer_0-W',
 'trainable_parameter-fully_connected-layer_0-b']
layer_output_names=['layer_output-fully_connected-layer_0',
 'layer_output-activation_function-layer_1']


"""
Create Model
"""
parameters=dict(input_data_dict=input_data_dict,
                layer_architectures=layer_architectures,
                trainable_parameters_names=trainable_parameters_names,
                layer_output_names=layer_output_names)

from model_tools.model_class import model














