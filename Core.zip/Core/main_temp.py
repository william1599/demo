# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 18:25:23 2020

@author: Philip
"""


import tensorflow as tf
import numpy as np
from Import_Data import MNIST
from matplotlib import pyplot as plt

#from Interface import gui
tf.reset_default_graph()

from model_tools.layer_lib import layers,layer_info

MNIST_data,MNIST_labels=MNIST.import_data_set()
MNIST_data=np.reshape(MNIST_data,[-1,28,28])




entry_data=[MNIST_data,MNIST_data,MNIST_labels]
entry_data_name=["MNIST_data","MNIST2_data","MNIST_Labels"]
entry_data_dims=[np.array([28, 28]), np.array([28, 28]), np.array([10])]

"""Run the Grafical User Interface"""

# input_data_dict,layer_architectures,trainable_parameters_names,layer_output_names,cost_string=gui(entry_data,entry_data_name,entry_data_dims)


""" Standard 2 layer network for classification"""
if True:
    data=[MNIST_data,MNIST_data,MNIST_labels]
    data_name=['MNIST_data', 'MNIST2_data', 'MNIST_Labels']
    # data_dims=[np.array([28, 28]), np.array([28, 28]), np.array([10])]
    data_dims=[[28, 28], [28, 28], [10]]
    
    
    input_data_dict=[]
    for i in range(len(data_name)):
        input_data_dict.append(dict(data_name=data_name[i],data_dims=data_dims[i]))
        
    dataset_dict=[]
    
    for i in range(len(data_name)):
        dataset_dict.append(dict(data=data[i],data_name=data_name[i],data_dims=data_dims[i]))
        
    
    layer_architectures=[{'layer_type': 'fully_connected',
   'n_hidden_values': 100.0,
   'activation_function': 'sigmoid',
   'input_tensor': 'MNIST_data'},
  {'layer_type': 'fully_connected',
   'n_hidden_values': 10.0,
   'activation_function': 'softmax',
   'input_tensor': 'layer_output-fully_connected-layer_0'},
  {'layer_type': 'cross_entropy_with_logits',
   'input_tensor_logits': 'layer_output-fully_connected-layer_1',
   'labels': 'MNIST_Labels'},
  {'layer_type': 'mean',
   'input_tensor': 'layer_output-cross_entropy_with_logits-layer_2'}]
    
    
    trainable_parameters_names=['trainable_parameter-fully_connected-layer_0-W',
  'trainable_parameter-fully_connected-layer_0-b',
  'trainable_parameter-fully_connected-layer_1-W',
  'trainable_parameter-fully_connected-layer_1-b']
    layer_output_names=['layer_output-fully_connected-layer_0',
  'layer_output-fully_connected-layer_1',
  'layer_output-cross_entropy_with_logits-layer_2',
  'layer_output-mean-layer_3']
    
    cost_string='layer_output-mean-layer_3'



"""Training Settings"""
training_settings={"n_epochs":100, #int
                        "batch_size":100, # int
                        "learning_rate":0.001, # float
                        "print_cost_every_n_batch":100, # El número de batches que se espera entre cada visualizacion de costos y guardado de registros
                        # Términos de relgularización, evitan que se sobre entrene sobre el set de entrenamiento
                        "early_stopping":3, # Valor int mayor igual a 1 o string "None" o 0 si no se aplica
                        "L1_lambda": 0., # hyperparametro que agrega costo a pesos elevados, valor float
                        "L2_lambda": 0., # hyperparametro que agrega costo a pesos elevados, valor float
                        "dropout":0., # hyper parametro que elimina connecciónes aleatoreamente durante entrenamiento, es una probabilidad entre 0. y 1., FALTA
                        # Aditional Stuff
                        "training_log_outputs":['layer_output-mean-layer_3']}# lista de los nombres de las salidas que se desean agregar al registro de entrenamiento


"""
Create Model
"""
# Output del GUI
parameters=dict(input_data_dict=input_data_dict,
                layer_architectures=layer_architectures,
                training_settings=training_settings,
                trainable_parameters_names=trainable_parameters_names,
                layer_output_names=layer_output_names,
                cost_string=cost_string)


from model_tools.model_class import model

tf.reset_default_graph()
model_1=model(parameters,-1)
model_1.train(dataset_dict)
model_1.save_model("model")


# """This is to restore a model """ 
# from model_tools.model_class import model
# tf.reset_default_graph()
# model_1=model.load_model("1_model")
# model_1.save_model("model")


layer_output_names=model_1.parameters["layer_output_names"]

outputs_eval=model_1.evaluate_with_names(layer_output_names,dataset_dict)




a=outputs_eval[1]
b=MNIST_labels
a_pred=[]
b_label=[]
correct=0
for i in range(np.shape(a)[0]):
    a_i=a[i,:]
    a_pred.append(np.argmax(a_i))
    b_i=b[i,:]
    b_label.append(np.argmax(b_i))
    if np.argmax(b_i)==np.argmax(a_i):
        correct+=1


accuraccy=100*correct/(np.shape(a)[0])

print(accuraccy)





