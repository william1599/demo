import util
import json
import pandas as pd

rutas = ["/mnt/d/Jano/Documents/IMA+P07/ejemplo1.csv",
"/mnt/d/Jano/Documents/IMA+P07/ejemplo2.csv",
"/mnt/d/Jano/Documents/IMA+P07/ejemplo3.csv"
]

colecciones = []
for ruta in rutas:
    dataframe = pd.read_csv(
                ruta,
                header=None)    
    colecciones.append(dataframe)

#unido = util.join_data_collections(colecciones)
unido = pd.concat(colecciones)
print(unido)


