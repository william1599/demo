# -*- coding: utf-8 -*-
"""
Created on Tue Apr  6 16:40:44 2021

@author: imap0
"""

import importar_datos.carga_de_datos as carga_de_datos
import os
import pandas as pd
from model_tools.model_class import model
import tensorflow as tf
import model_tools.data_operations as dp
import numpy as np

# Guardaremos la historia acumulada en  importar_datos/database/nombre_data_acumulada
nombre_data_acumulada="production_data_acumulado.csv"
# Guardamos la historia acumulada más la planificación en importar_datos/database/nombre_data_acumulada_planificacion
nombre_data_acumulada_planificacion="production_data_acumulado_planificado.csv" # esta es la historia con la planificación al final, lo utilizaremos para predecir


"Archivos de entrada"

"historia de produccion hasta ahora"
control_de_piso_archivo_nombre="producción 2019 a 2020.xlsx"

" Informacion de los rodillos"
info_rodillos_nombre="info_rodillos.xlsx"

" Informacion de mantenimiento"
mantenimiento_nombre="Mapeo rodillo LP700A.xlsx"

"Nueva produccion"
archivo_de_produccion_nueva="nueva_produccion.xlsx" #así se llamará el archivo en la carpeta excel

"Produccion planificada"
archivo_de_planificacion_nueva="planificacion.xlsx" #así se llamará el archivo en la carpeta excel



carga_planificacion="estandar" # puede ser baja alta o estandar



#"Eliminamos la historia anterior para partir de cero, lo hago por debbug"
#try:
#    os.remove("importar_datos"+os.sep+"database"+os.sep+nombre_data_acumulada)
#except:
#    print("No existe historia previa")
    

"Se guardan el historico completo de datos"
"Se tienen datos hasta el 2020-12-15"
carga_de_datos.guardar_data_produccion(control_de_piso_archivo_nombre,nombre_data_acumulada)

"pedimos los datos de producción desde del mes de diciembre para agregarlos al actual, estos son los nuevos datos de producción y debe haber sobrelape"
archivo_de_produccion_nueva="nueva_produccion.xlsx" #así se llamará el archivo en la carpeta excel
carga_de_datos.generar_datos_produccion(control_de_piso_archivo_nombre,
                                        fecha_de_inicio="2020_12_01",
                                        fecha_de_fin="2021_01_01",
                                        nombre_salida=archivo_de_produccion_nueva,
                                        carga="estandar")


"pedimos los datos de planificacion la primera semana de enero"
carga_de_datos.generar_datos_produccion(control_de_piso_archivo_nombre,
                                        fecha_de_inicio="2021_1_02",
                                        fecha_de_fin="2021_01_07",
                                        nombre_salida=archivo_de_planificacion_nueva,
                                        carga=carga_planificacion)



"Guardamos los datos de producción"
carga_de_datos.guardar_data_produccion(archivo_de_produccion_nueva,
                                       nombre_data_acumulada,
                                       verificar_superposicion=False) # IMPORTANTE, CAMBIAR A TRUE CUANDO TRABAJEMOS CON DATA REAL


"Guardamos los datos de planificación"
carga_de_datos.guardar_data_produccion(archivo_de_planificacion_nueva,
                                       nombre_data_acumulada,
                                       nombre_data_acumulada_planificacion,
                                       verificar_superposicion=False)# No se verifica superposicion de los datos ya que no existe

