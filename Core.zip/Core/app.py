import test_main
import evaluación_con_nucleo
import forecast_PK
import evaluacion_servicio_mant
import swarm_class

import config
import time
import os
import sys
import main_optimizer
import pandas as pd

from flask import Flask, request
from flask_restful import Resource, Api
from flask_cors import CORS
from errors import InternalServerError, LoadDataError, LoadEntryDataError, SchemaValidationError, UnauthorizedError, errors

app = Flask(__name__)
cors = CORS(app, resources={r"*": {"origins": "*"}})
api = Api(app, errors = errors)

print("AAAAAAAAAAA")
print(os.environ.get('DATA_FOLDER'))


# Funcion(nombre_funcion):
    #llamar(nombre_funcion)
    #Prediccion


class TrainMain(Resource):
    def get(self, id_config):
        return { 'message': 'No implementado' }

    def post(self, id_config):
        print('Entre al train')
        data = request.get_json()
        try:
            header = request.headers['authorization']
        except Exception as e:
            raise UnauthorizedError
        
        token = header.split(sep = " ")[1]
        path = config.DATA_FOLDER
        try:
            train = test_main.Train(path, token)
        except InternalServerError:
            raise InternalServerError
        
        try:
            train.start(id_config, data['first'], data['idmodelo'])
            return { 'ok': True, 'message': 'Entrenamiento terminado con exito' }
        except Exception:
            print("Salto un internal server error")
            return { 'ok': False, 'message': 'Entrenamiento fallido' }
            raise InternalServerError
            
        

class ForecastQualityMain(Resource):
    def get(self):
        return { 'message': 'No implementado' }
    
    def post(self):
        start_time = time.time()
        data = request.get_json()
        print(data)
        header = request.headers['authorization']
        token = header.split(sep = " ")[1]
        path = config.DATA_FOLDER
        qualityForecast = evaluación_con_nucleo.QualityForecast(path, token)
        qualityForecast.start(data['idconfig'], data['model'], data['forecast'], data['forecast_config'])
        print("--- %s seconds ---" % (time.time() - start_time))
        return { 'ok': True, 'message': 'Predicción realizada correctamente' }           

class ForecastMaintenance(Resource):
    def get(self):
        return { 'message': 'No implementado' }

    def post(self, id_forecast_config):
        try:
            data = request.get_json()
            print(data)
            try:
                header = request.headers['authorization']
                token = header.split(sep = " ")[1]
            except:
                raise UnauthorizedError
            path = config.DATA_FOLDER
            maintenanceForecast = forecast_PK.Forecast(path, token, data['modelPath'])
            output, error = maintenanceForecast.start(id_forecast_config)
            return { 'ok': True, 'message': 'Predicción realizada correctamente' }
        except UnauthorizedError:
            raise UnauthorizedError
        except SchemaValidationError:
            raise SchemaValidationError
        except Exception as e:
            raise InternalServerError

class ForecastMaintenanceRefactor(Resource):
    def get(self):
        return { 'message': 'No implementado' }

    def post(self, id_forecast_config):
        print("Entre a la prediccion")
        try:
            data = request.get_json()
            header = request.headers['authorization']
            token = header.split(sep = " ")[1]
            path = config.DATA_FOLDER
            data["token"] = token
            data["id_forecast_config"] = id_forecast_config
            funcion = main_optimizer.cargar_funcion(data["functionName"])
            print("data", data)
            #diccionario_entrada=data["filesBody"]
            maintenanceForecast = funcion(path, token, data['modelPath'], id_forecast_config)

            # maintenanceForecast = evaluacion_servicio_mant.Forecast(path, token, data['modelPath'])
            # output, error = maintenanceForecast.start(id_forecast_config)
            return { 'ok': True, 'message': 'Predicción realizada correctamente' }
        except Exception as e:
            raise InternalServerError

class Optimizer(Resource):
    def get(self):
        return { 'message': 'No implementado' }
    
    def post(self):
        try:
            data = request.get_json()
            print(data)
            header = request.headers['authorization']
            token = header.split(sep = " ")[1]
            path = config.DATA_FOLDER
            print("Entre al llamado")
            # main_optimizer.cargar_funcion("funcion_especifica")
            print("Sali al llamado")
            swarmClass = swarm_class.swarm_class(path, token, data["body"], data["modelo"], data["forecast"])
            # swarmClass.initialize()
            datos=pd.read_csv(data["csvPath"])
            json_entrada = data["json_entrada"]
            swarmClass.limites_variables(json_entrada, datos)
            swarmClass.optimizar(json_entrada)
            return { 'ok': True, 'message': 'Optimizador realizado correctamente' }
        except Exception as e:
            raise InternalServerError


class Testing(Resource):
    def get(self):
        return "<h1 style='color:blue'>Hello There!</h1>"

api.add_resource(TrainMain, '/train/<string:id_config>')
api.add_resource(ForecastQualityMain, '/qualityforecast')
api.add_resource(ForecastMaintenance, '/maintenanceforecast/<string:id_forecast_config>')
api.add_resource(ForecastMaintenanceRefactor, '/maintenance/forecast/<string:id_forecast_config>')
api.add_resource(Optimizer, '/optimizador')
api.add_resource(Testing, '/test')

if __name__ == "__main__":
    app.run(host='0.0.0.0')      
