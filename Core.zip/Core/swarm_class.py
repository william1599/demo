
import itertools
from re import S
import pyswarms as ps
import config
import numpy as np
import pandas as pd
import os
import json
import pathlib
import comm
import util
import model_tools.model_class as model
import tensorflow as tf
from ETL import ETL
model = model.model

class swarm_class():
    def __init__(self, path, token, optimizer, modelo, forecast):
        self.path = path
        self.comm = comm.Communication(token)
        self.forecast = forecast
        forecast_data = {}
        forecast_data["modelo"] = modelo
        forecast_data["train_conf"] = modelo["training_config"]
        forecast_data["transform_architecture"] = util.transform_conf(modelo["architecture"])

        nombre_modelo = util.make_model_name(forecast_data["modelo"])

        tf.reset_default_graph()
        self.model_1 = model.load_model_mix(self.path, nombre_modelo, forecast_data["train_conf"], forecast_data["transform_architecture"], forecast_data["modelo"]["idmodelo"])

        for layers in forecast_data["transform_architecture"]["layers_architecure"]:
            if(layers['cost_string']):
                self.outPutLayer = layers['labels']
                inputTensorName = layers['input_tensor']

        self.etl = ETL(self.outPutLayer)
        self.etl.set_path(self.path)
        self.etl.cargar_metadatos_ETL()

        self.setting_json = json.loads(optimizer)
        self.tipo_rango="Rango Original"

    def save_metadata(self,setting_json,name):
        
        path=str(pathlib.Path(__file__).parent.resolve())        
        path=path+os.sep+"save"+os.sep+name+".json"
        with open(path, 'w') as outfile:
            json.dump(setting_json, outfile)

    def initialize(self):
        #path=str(pathlib.Path(__file__).parent.resolve())        
        #path=path+os.sep+"save"+os.sep+name+".json"
        
        #with open(path) as json_file:
            #setting_json = json.load(json_file)

        self.setting_json=self.setting_json
        print("SETTINGS JSON")
        print(self.setting_json)
        options = self.setting_json["options"]
        numero_de_particulas=self.setting_json["numero_de_particulas"]
        numero_de_iteraciones=self.setting_json["numero_de_iteraciones"]
        
        col_varaibles=self.setting_json["col_variables"]
        col_constantes=self.setting_json["col_constantes"]
        col_salidas_modelo=self.setting_json["col_salidas_modelo"]
        ponderador_accuracy=self.setting_json["ponderador_accuracy"]
        ponderador_entradas=self.setting_json["ponderador_entradas"]

        dimension_busqueda=len(col_varaibles)
        bounds=(self.setting_json["valores_minimos"],self.setting_json["valores_maximos"])
        
        salida_del_modelo=self.setting_json["salida_del_modelo"] 
        optimizer = ps.single.GlobalBestPSO(n_particles=numero_de_particulas, dimensions=dimension_busqueda, options=options,bounds=bounds)

        # se define el optimizador


        def evaluar_modelo(particulas,constantes,salida_objetivo):
            print("Entre a la funcion evaluar_modelo")
            columnas=self.etl.columnas
            columnas_utilizadas=col_varaibles+col_constantes+col_salidas_modelo
            values=np.zeros([len(particulas),len(columnas)])
            df=pd.DataFrame(values,columns=columnas)
            for i in range(len(particulas)):
                for j in range(len(particulas[i])):
                    nombre_columna=col_varaibles[j]
                    df[nombre_columna][i]=particulas[i,j]

                for j in range(len(constantes)):
                    nombre_columna=col_constantes[j]
                    df[nombre_columna][i]=constantes[j]

                for j in range(len(salida_objetivo)):
                    nombre_columna=col_salidas_modelo[j]
                    df[nombre_columna][i]=salida_objetivo[j]
                
            data=[]
            for col in self.etl.columnas:
                data.append(df[col].values)
            self.etl.raw_data=df
            self.etl.datos=df.values
            self.etl.aplicar_operaciones()
            
            dataset_dict=self.etl.dataset_dict


            dataset_dict_norm=self.model_1.normalize(dataset_dict)
            outputs_eval=self.model_1.evaluate_with_names(salida_del_modelo,dataset_dict_norm)
            output=self.model_1.denormalize_model_output(outputs_eval, self.outPutLayer)["data"]
            return output


        def optimizar(json_entrada):
            print("Entre a la funcion optimizar")
            salida_objetivo=json_entrada["salida_objetivo"]
            constantes=json_entrada["constantes"]
            def crear_funcion_objetivo(salida_objetivo,constantes):
                def funcion_objetivo(particulas):
                    output =evaluar_modelo(particulas,constantes,salida_objetivo)
                    objetivo=0
                    for i in range(len(salida_objetivo)):
                        # se suma a la funcion objetivo la diferencia entre el objetivo y el valor encontrado
                        objetivo+=np.square(np.array(output[:,i])-salida_objetivo[i])*ponderador_accuracy[i]
                    for i in range(len(ponderador_entradas)):
                        # se resta a la funcion objetivo el valor de la entrada por un ponderador (es valor negativo para hacer intuitivo el valor del ponderador positivo maximiza, negativo minimiza)
                        objetivo-=particulas[:,i]*ponderador_entradas[i]
                    # a = [100,0,0]
                    # b = [ 0 ,10 ,0 ,-1]
                    # objetivo=a[0]*np.square(np.array(output[:,0])-salida_objetivo[0])+b[1]*particulas[:,1] + b[3]*particulas[:,3] # Minimizar-
                    return objetivo
                return funcion_objetivo
            f_obj=crear_funcion_objetivo(salida_objetivo,constantes)
            best_cost, best_pos=optimizer.optimize(f_obj,iters=numero_de_iteraciones)
            #output =evaluar_modelo([best_pos],constantes,salida_objetivo)[0]
            output =evaluar_modelo(np.array([best_pos]),constantes,salida_objetivo)[0]
            print("output", output)
            print("best_pos", best_pos)

            salida={}
            salida["data"]=best_pos.tolist()
            salida["data_names"]=col_varaibles
            salida["output_data"]=output.tolist()
            salida["output_data_names"]=col_salidas_modelo
            salida["tipo"]=self.tipo_rango

            dato = {
                "estado": config.ESTADOS.TERMINADO,
                "forecast": json.dumps(salida)
            }

            resp, error = self.comm.update_forecast(dato, self.forecast["idforecast"])
            return best_pos,output
        self.optimizar = optimizar


    def limites_variables(self,json_entrada,datos):
        data_original=datos
        print("JSON ENTRADA")
        print(json_entrada)
        col_constantes=self.setting_json["col_constantes"]
        import copy
        # Aplicamos el filtro por las constantes
        # Aplicamos el filtro por las constantes
        for i in range(len(col_constantes)):
            if i==0:
                df=copy.deepcopy(data_original)

            col_name=col_constantes[i]
            valor=json_entrada["constantes"][i]
            rango=0.1*(max(data_original[col_name])-min(data_original[col_name]))
            if rango==0:
                rango=1
            df=df[df[col_name]>valor-rango]
            df=df[df[col_name]<valor+rango]

        # Aplicamos el mismo filtro a las salidas
        col_salidas_modelo=self.setting_json["col_salidas_modelo"]
        for i in range(len(col_salidas_modelo)):

            col_name=col_salidas_modelo[i]
            valor=json_entrada["salida_objetivo"][i]
            rango=0.05*(max(data_original[col_name])-min(data_original[col_name]))
            if rango==0:
                print(1)
                rango=1
            df=df[df[col_name]>valor-rango]
            df=df[df[col_name]<valor+rango]
            


        mean=np.mean(df)
        std=np.std(df)
        max_c=np.max(df)
        min_c=np.min(df)
        print(std)

        if len (df)!=0:
            print("ENTRE A RANGO DINAMICO")
            col_variables=self.setting_json["col_variables"]
            min_=[]
            max_=[]
            
            for i in range(len(col_variables)):
                col=col_variables[i]
                valor_medio=mean[col]
                valor_std=std[col]
                valor_max=max_c[col]
                valor_min=min_c[col]
                min_.append(max(valor_medio-valor_std,valor_min))
                max_.append(min(valor_medio+valor_std,valor_max))
            
            # si existen casos nuevos
            self.setting_json["valores_minimos"]=min_
            self.setting_json["valores_maximos"]=max_
            self.tipo_rango="Rango Dinamico"
            self.initialize()
        else:
            print("ENTRE A RANGO ORIGINAL")
            self.setting_json=copy.deepcopy(self.setting_json)
            self.tipo_rango="Rango Original"
            self.initialize()
            print("No existe historial para la configuración solicitada")