def prueba():
    print("test")