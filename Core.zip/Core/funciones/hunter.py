import importar_datos.carga_de_datos as carga_de_datos
import os
import error
import pandas as pd
from model_tools.model_class import model
import tensorflow as tf
import model_tools.data_operations as dp
import numpy as np
import comm
import util
import config

def cargar_modelo(metadata="aca pones la metadata que se requiere para crear el modelo"):
    # se debe hacer una funcion que carge el modelo
    tf.reset_default_graph()
    model_1=model.load_model_mix(config.DATA_FOLDER, metadata["modelName"], metadata["train_conf"], metadata["transform_architecture"], metadata["idmodelo"])
    return model_1
    
def evaluar_modelo(dataframe_entrada,model_1):
    # esto es lo generico que utilizamos normalemnte para evaluaciones, por lo que su construcción debe salir de la base de datos
    def etl_para_entradas(dataframe_entrada):
        # En este caso se creo antes de usar el modulo de ETL por lo que esta funcion debería ser hecha por el modulo de ETL
        columnas_a_eliminar=["Nombre Rodillo","Material","Recurso","Fecha de creación","Diametro Eje","Largo Rodillo",
                                "KILOS ENTRADA","SALDO (KGS)","DESECHO (KGS)","Kilos Totales Op","Desarrollo","Espesor"] 

        data_produccion_entrada=dataframe_entrada.drop(columnas_a_eliminar,axis=1)
        output_dims=[len(data_produccion_entrada)]+model_1.parameters['input_data_dict'][1]["data_dims"]
        dummy_labels=np.zeros(shape=output_dims)
        dummy_labels=pd.DataFrame(dummy_labels,columns=model_1.parameters['input_data_dict'][1]["data_columns"])

        data=[data_produccion_entrada,dummy_labels]
        data_name=["Produccion_de_ciclo_de_vida","Vida_remanente_de_ciclo_de_vida"]
        input_data_dict,dataset_dict=dp.create_dataset_dictionaries(data,data_name)
        return input_data_dict,dataset_dict
    
    input_data_dict,dataset_dict=etl_para_entradas(dataframe_entrada)
    dataset_dict_norm=model_1.normalize(dataset_dict)

    model_output_norm=model_1.evaluate_with_names('layer_output_fully_connected_layer_2',dataset_dict_norm) # Valores brutos en formato de array

    # ahora creamos un diccionario y desnormalizamos al mismo tiempo con  model.denormalize_model_output
    # dataset name es el formato de dataset que se desea copiar para crear el diccionario

    model_output_dict=model_1.denormalize_model_output(model_output_norm,dataset_name="Vida_remanente_de_ciclo_de_vida")
    return model_output_dict

def etl_para_entradas(dataframe_entrada, modelo):        
    columnas_a_eliminar=["Nombre Rodillo","Material","Recurso","Fecha de creación","Diametro Eje","Largo Rodillo",
                        "KILOS ENTRADA","SALDO (KGS)","DESECHO (KGS)","Kilos Totales Op","Desarrollo","Espesor"] 

    data_produccion_entrada=dataframe_entrada.drop(columnas_a_eliminar,axis=1)
    output_dims=[len(data_produccion_entrada)]+modelo.parameters['input_data_dict'][1]["data_dims"]
    dummy_labels=np.zeros(shape=output_dims)
    print('aqui muero')
    print(modelo.parameters)
    # AQUI TIRABA EL ERROR DEL DATACOLUMNS, SE VE EN EL TEST MAIN 
    dummy_labels=pd.DataFrame(dummy_labels,columns=modelo.parameters['input_data_dict'][1]["data_columns"])
    print('Pase y nose como')
    data=[data_produccion_entrada,dummy_labels]
    # ESTO SE SACA DEL PARAMETERS
    ######################################
    data_name = []

    for input_data in modelo.parameters['input_data_dict']:
        data_name.append(input_data['data_name'])


    #data_name=["845","846"]
    print(data_name)
    ######################################
    input_data_dict,dataset_dict=dp.create_dataset_dictionaries(data,data_name)
    #dataset_dict = initialize_normalizer()
    return input_data_dict,dataset_dict

diccionario_requerimiento={"control_de_piso_archivo_nombre":"CONTROL DE PISO- 2021.xlsx",
                           "info_rodillos_nombre":"info_rodillos2.xlsx",
                           "mantenimiento_nombre":"Mapeo rodillo LP700A abril 2021.xlsx",
                           "archivo_de_producción_nueva":"nueva_produccion diciembre a abril.xlsx",
                           "archivo_de_planificación_nueva":"PLP 29-04-2021.xlsx"}

def hunter(dictBody):
    
    
    
    # Guardaremos la historia acumulada en  importar_datos/database/nombre_data_acumulada
    nombre_data_acumulada = dictBody["modelPath"] + "/predictions/" + "production_data_acumulado.csv"
    # Guardamos la historia acumulada más la planificación en importar_datos/database/nombre_data_acumulada_planificacion
    nombre_data_acumulada_planificacion = dictBody["modelPath"] + "/predictions/" + "production_data_acumulado_planificado.csv" # esta es la historia con la planificación al final, lo utilizaremos para predecir



    "Archivos de entrada"

    "historia de produccion hasta ahora"
    control_de_piso_archivo_nombre=dictBody["filesBody"]["historial_produccion"]
    " Informacion de los rodillos"
    info_rodillos_nombre="/home/jorge/Documentos/IMA07/Core/info_rodillos.xlsx"

    " Informacion de mantenimiento"
    mantenimiento_nombre=dictBody["filesBody"]["Archivo de mantenimiento"]

    # mantenimiento_nombre="Mapeo rodillo LP700A_prueba3_debería fallar.xlsx"
    "Nueva produccion"

    archivo_de_producción_nueva=None #así se llamará el archivo en la carpeta exce
    "Produccion planificada"

    archivo_de_planificación_nueva=None  #así se llamará el archivo en la carpeta excel


    # "Eliminamos la historia anterior para partir de cero, lo hago por debbug"
    # try:
    #     os.remove("importar_datos"+os.sep+"database"+os.sep+nombre_data_acumulada)
    # except:
    #     print("No existe historia previa")


    "Se guardan el historico completo de datos"
    "Se tienen datos hasta el 2020-12-15"
    carga_de_datos.guardar_data_produccion(control_de_piso_archivo_nombre,nombre_data_acumulada,verificar_superposicion=True)


    # carga_de_datos.guardar_data_produccion("consolidado control de piso 2019-abril 2021.xlsx",nombre_data_acumulada,verificar_superposición=True)




    "Guardamos los datos de planificación"

    if archivo_de_planificación_nueva:
        carga_de_datos.guardar_data_produccion(archivo_de_planificación_nueva,
                                                nombre_data_acumulada,
                                                nombre_data_acumulada_planificacion,
                                                verificar_superposición=False,
                                                tipo_de_data="planificacion")# No se verifica superposicion de los datos ya que no existe
    else:
        production_data_acumulado_antigua = None
        try:
            production_data_acumulado_antigua=pd.read_csv(nombre_data_acumulada)
        except Exception as e:
            raise Exception("###No se pudo abrir la base de datos de producción al cargar la planificación") from e
        production_data_acumulado_antigua.to_csv(nombre_data_acumulada_planificacion,index=False)


    "Creamos el dataset que puede leer el modelo"

    entrada_rodillos,existen_fallas=carga_de_datos.crear_dataset_evaluacion(info_rodillos_nombre,mantenimiento_nombre,nombre_data_acumulada_planificacion)
    # entrada_rodillos es una lista de dataframes con las historias de todos los rodillos excepto los que no tienen fallas previas

    communication = comm.Communication(dictBody["token"])
    """Cargamos el modelo"""

    
    forecast_data = get_data_from_DB(dictBody["id_forecast_config"], dictBody)

    forecast_obj, error = communication.crear_forecast(dictBody["id_forecast_config"], forecast_data["train_conf"]["idservicio"], forecast_data["forecast_config"]["nombre"], forecast_data["forecast_config"]["idmodelo"])
    if error:
        error_forecast = {
            "estado": config.ESTADOS.ERROR,
            "mensaje_error" : str(error)
        }
        comm.update_forecast(error_forecast, forecast_obj["idforecast"])
        return None, error

    nombre_modelo = util.make_model_name(forecast_data["modelo"])
    print("Abriendo modelo: "+nombre_modelo)
    dictBody["transform_architecture"] = forecast_data["transform_architecture"]
    dictBody["train_conf"] = forecast_data["train_conf"]
    dictBody["idmodelo"] = forecast_data["forecast_config"]["idmodelo"]
    dictBody["modelName"] = nombre_modelo

    model_1=cargar_modelo(dictBody)
    # Recorremos los rodillos y evaluamos su vida remananete particular
    salidas=[]
    kilos_producidos_por_entrada=[]
    outputLayer = None
    for entrada in entrada_rodillos:
        
        kilos_producidos=entrada["Kilos Acumulados Desde Reparación"] # Se extrae lo producido del dataset de entrada
        kilos_producidos_por_entrada.append(kilos_producidos)
        input_data_dict,dataset_dict=etl_para_entradas(entrada, model_1)
        dataset_dict_norm=model_1.normalize(dataset_dict)
        model_output_norm=model_1.evaluate_with_names(model_1.parameters['salida'], dataset_dict_norm) # Valores brutos en formato de array
        # model_output_dict= evaluar_modelo(entrada,model_1) # esta funcion 
        # salidas.append(model_output_dict)
        for layers in model_1.parameters['layers_architecure']:
            if(layers['cost_string']):
                outputLayer = layers['labels']

        model_output_dict=model_1.denormalize_model_output(model_output_norm,dataset_name=outputLayer)
        salidas.append(model_output_dict)

    salidas_formato_manuel={"variable":["abreviatura","nombre","kilos_remanentes","porcentaje","valido"],
                            "cabeceras":["Abreviatura","Nombre Rodillo","Kilos remanentes a la falla","Porcentaje de vida útil remanente","Rodillo valido"],
                            "tipo":["text","text","number","number","boolean"],
                            "datos":[]}
        
        
    print('LEN DE SALIDAS')      
    print(len(salidas))
    for i in range(len(salidas)):
        data=salidas[i]["data"]
        #print('datasalida')
        #print(data)
        #print('datasalida')
        kilos_producidos=kilos_producidos_por_entrada[i][len(kilos_producidos_por_entrada[i])-1]
        #print('kilos_producidos')
        #print(kilos_producidos)
        #print('kilos_producidos')
        abreviatura = util.abreviatura(entrada_rodillos[i]["Nombre Rodillo"][0])

        nombre_rodillo=entrada_rodillos[i]["Nombre Rodillo"][0]
        
        kilos_remanentes_a_la_falla=data.tolist()[-1][0]
        # se calcula el porcentaje y se agrega a la salida
        porcentaje_de_vida=100*(kilos_remanentes_a_la_falla)/(kilos_remanentes_a_la_falla+kilos_producidos)

        tiene_falla = True
        nombre_encontrado=False
        for tiene_falla_data in existen_fallas.values:
            nombre=tiene_falla_data[0]
            if nombre==nombre_rodillo:
                tiene_falla=tiene_falla_data[2] == "Con Fallas"
                nombre_encontrado=True
                break
        if nombre_encontrado==False:
            raise Exception("###No se encontro el nombre del rodillo en la lista de los rodillos con y sin falla")

        salidas_formato_manuel["datos"].append([abreviatura,nombre_rodillo,kilos_remanentes_a_la_falla, porcentaje_de_vida,tiene_falla])
        
    print('3')
    #7.- Armo objeto a guardar
    #resp , error = self.comm.save_forecast(salidas_formato_manuel, self.id_forecast_config, self.idservicio,self.forecast_config["nombre"])
    
    dato = {
        "forecast": dict(salidas_formato_manuel),
        "estado":config.ESTADOS.TERMINADO
    }
    resp , error = communication.update_forecast(dato, forecast_obj["idforecast"])
    if error:
        raise Exception("###No se pudo guardar la predicción")
    else:
        # Guardamos las salidas        
        #json_object = json.dumps(salidas_formato_manuel)
        #with open('salidas.txt', 'w') as outfile:
        #    json.dump(json_object, outfile)
        return resp

    # Se construye la data de salida requerida, tambien es especifico a cada proceso
    for i in range(len(salidas)):
        data=salidas[i]["data"]
        kilos_producidos=kilos_producidos_por_entrada[i][len(kilos_producidos_por_entrada[i])-1]
        nombre_rodillo=entrada_rodillos[i]["Nombre Rodillo"][0]
        kilos_remanentes_a_la_falla=data.tolist()[-1][0]
        porcentaje_de_vida=100*(kilos_remanentes_a_la_falla)/(kilos_remanentes_a_la_falla+kilos_producidos) # se calcula el porcentaje y se agrega a la salida
        nombre_encontrado=False
        for tiene_falla_data in existen_fallas.values:
            nombre=tiene_falla_data[0]
            if nombre==nombre_rodillo:
                tiene_falla=tiene_falla_data[2]
                nombre_encontrado=True
                break
        if nombre_encontrado==False:error.error("No se encontro el nombre del rodillo en la lista de los rodillos con y sin falla")


        salidas_formateadas["data"].append([nombre_rodillo,kilos_remanentes_a_la_falla,porcentaje_de_vida,tiene_falla])

    # Guardamos las salidas
    import json
    json_object = json.dumps(salidas_formateadas)
    with open('salidas.txt', 'w') as outfile:
        json.dump(json_object, outfile)
    # o las botamos como output
    return json_object

def get_data_from_DB(id_forecast_config, dict):

    communication = comm.Communication(dict["token"])

    #self.id_forecast_config = id_forecast_config
    data = {}
    #1.- obtener configuracion del forecast con id_config (✓)
    data["forecast_config"],error = communication.getForecastConfig(id_forecast_config)
    #self.forecast_config = data["forecast_config"]
    if error:
        raise Exception("###"+str(error))
    

    #2.- obtener colecciones definidas en input de la condfiguracion de forecast
    if("inputs" not in data["forecast_config"].keys()):            
        raise Exception("###No se paso 'inputs' en la configuracion")
    

    #3.- obtener modelo con el idmodelo
    data["modelo"], error = communication.getModelo(data["forecast_config"]["idmodelo"])
    if error:            
        raise Exception("###"+str(error))
    

    #4.- obtener la configuracion del modelo
    data["train_conf"], error = communication.getConf(data["modelo"]["idconf"])
    if error:
        raise Exception("###"+str(error))
    
    #self.idservicio = data["train_conf"]["idservicio"]
    #self.idmodelo = data["forecast_config"]["idmodelo"]

    #5.- obtener arquitectura (leer del parameters.json? o lo descrito en la base de datos?)  
    arquitectura, error = communication.getArquitectura(data["train_conf"]["id_architecture"])
    if error:
        raise Exception("###"+str(error))

    data["transform_architecture"] = util.transform_conf(arquitectura)
    #print(json.dumps(data["transform_architecture"],sort_keys=True, indent=4))
    
    return data