def funcion_especifica(diccionario):
    print("Entre a funcion especifica")
    for key in diccionario.keys():
        print ("Cargando archivo: "+diccionario[key])
    salida=1    
    return salida