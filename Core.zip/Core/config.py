import os
from collections import namedtuple


SEP = os.sep
DEBUG = "DEBUG" in os.environ
print(os.environ)
URL_TRAINMANAGER = os.environ['URL_TRAINMANAGER'] if "URL_TRAINMANAGER" in os.environ else "http://localhost:3112"
URL_COLLECTIONMANAGER = os.environ['URL_TRAINMANAGER'] if "URL_TRAINMANAGER" in os.environ else "http://rest-collections:3115"
URL_ARQUITECTURESMANAGER = os.environ['URL_TRAINMANAGER'] if "URL_TRAINMANAGER" in os.environ else "http://rest-arquitectures:3116"
URL_MODELSMANAGER = os.environ['URL_TRAINMANAGER'] if "URL_TRAINMANAGER" in os.environ else "http://rest-train:3117"
URL_FORECASTMANAGER = os.environ['URL_TRAINMANAGER'] if "URL_TRAINMANAGER" in os.environ else "http://rest-predictions:3018"
URL_ADMINMANAGER = os.environ['URL_TRAINMANAGER'] if "URL_TRAINMANAGER" in os.environ else "http://rest-admin:3119"
RUTA_MODELOS = "save"
RUTA_DATA = "data"
RUTA_CLIENTES = ["hunter_douglas"]
#DATA_FOLDER = SEP+"home"+SEP+"pc1"+SEP+"Documentos"+SEP+"colecciones"+SEP
#setear como variable de entorno!!!!!!!

#DATA_FOLDER = os.environ['DATA_FOLDER'] if "DATA_FOLDER" in os.environ else SEP+"home"+SEP+"jano"+SEP+"ima-p07"+SEP+"colecciones"+SEP
# DATA_FOLDER = "app/colecciones"
DATA_FOLDER = "/app"

Estados = namedtuple('Estados', ['CREADO', 'TERMINADO','ERROR'])
ESTADOS = Estados('CREADO', 'TERMINADO','ERROR')
