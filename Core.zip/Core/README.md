# Core
Computer inteligence core for project IMA-P07
it is very beautiful

## 0. Requerimientos con Docker

## 0. Requerimientos
```
Docker
```

## 1. Instalación

```
Mover archivo docker-compose.yml a carpeta raiz de proyectos
- Core
- ima-front
- rest-train
- rest-predictions
- rest-admin
- rest-collections
- rest-predictions
- docker-compose.yml (archivo movido desde el Core)
```

## 2. Ejecutar el proyecto

```
docker-compose up
```

## 0. Requerimientos sin Docker

```
Python 3
Python3-dev
Compilador de C
```

## 1. Instalación
### Crear ambiente virtual llamado 'virtual' en python3.* :
```bash
   python3 -m venv venv
```
### Activar el ambiente virtual:
```bash
   source venv/bin/activate
```

### Actualizar pip:
```bash
   pip3 install --upgrade pip
```

### Instalar dependencias:
```bash
   pip3 install -r requirements.txt
```

## Desactivar el ambiente virtual:
```bash
   deactivate
```
