import inspect
import pandas as pd
from model_tools.layer_lib import layers,layer_info
import model_tools.data_operations as dp

def transform_conf(conf):
    tmp = {}
    for key in conf:        
        if key == "layers_architecure":
            if "layers_architecure" not in tmp:
                tmp["layers_architecure"] = []
            layers = conf[key]
            for layer in layers:
                transformed_layer = transform_layer(layer)
                tmp["layers_architecure"].append(transformed_layer)
        elif key == "input_data_dict" or key == "trainable_parameters_names" or key == "layer_output_names" or key == "cost_string":
            tmp[key] = conf[key]
        else:
            if "extra" not in tmp:
                tmp["extra"] = {}
            tmp["extra"][key] = conf[key]

    return tmp

def transform_layer(layer):
    tmp = {}
    for key in layer:
        if key == "inputs" or key == "settings":
            arr = layer[key]
            for obj in arr:
                for obj_key in obj:
                    tmp[obj_key] = obj[obj_key]
        else:
            tmp[key] = layer[key]
    return tmp


def create_trainable_parameters_names(transformed_architecture):
    trainable_parameters_names = []
    layer_classes = inspect.getmembers(layers, inspect.isclass)
    for layer in transformed_architecture:
        clase = collect(layer_classes,layer["layer_type"])
        print("..............................")
        print(clase)
        print("..............................")
        trainable_parameters_names += get_trainable_parameters_list(clase, layer["nombre"])
    return trainable_parameters_names

def make_model_name(modelo):
    return str(modelo["idmodelo"])+"-"+modelo["nombre"].replace(" ","_")

def print_dictionary(dictionary):
    print(json.dumps(dictionary,sort_keys=True, indent=4))

def collect(lista, nombre_clase):
    index = 1
    clases = [row[index] for row in lista]
    for clase in clases:
        if(clase.info["variable_name"] == nombre_clase):
            return clase
    return None

def get_trainable_parameters_list(layer_class, layer_name):
    lista = []
    print("NAME:"+layer_name)
    ##tmp = layer_name.split("-")
    
    for parameter in layer_class.trainable_parameters():
        lista.append("trainable_parameter_"+layer_name+"_"+parameter)

    return lista


def etl_para_entradas(dataframe_entrada):
    
    columnas_a_eliminar=["Nombre Rodillo","Material","Recurso","Fecha de creación","Diametro Eje","Largo Rodillo",
                            "KILOS ENTRADA","SALDO (KGS)","DESECHO (KGS)","Kilos Totales Op","Desarrollo","Espesor"] 

    data_produccion_entrada=dataframe_entrada.drop(columnas_a_eliminar,axis=1)
    output_dims=[len(data_produccion_entrada)]+model_1.parameters['input_data_dict'][1]["data_dims"]
    dummy_labels=np.zeros(shape=output_dims)
    dummy_labels=pd.DataFrame(dummy_labels,columns=model_1.parameters['input_data_dict'][1]["data_columns"])
    
    data=[data_produccion_entrada,dummy_labels]
    data_name=["Produccion_de_ciclo_de_vida","Vida_remanente_de_ciclo_de_vida"]
    input_data_dict,dataset_dict=dp.create_dataset_dictionaries(data,data_name)
    return input_data_dict,dataset_dict


def abreviatura(rodillo):
    abreviaturas = {
        "Rodillo 1 superior ESTRUJADOR DESENGRASE": "R01-Sup-ESTR-DES",
        "Rodillo 2 Inferior ESTRUJADOR DESENGRASE": "R02-Inf-ESTR-DES",
        "Rodillo 3 superior ESTRUJADOR ENJUAGUE 1": "R03-Sup-ESTR-ENJ01",
        "Rodillo 4 Inferior ESTRUJADOR ENJUAGUE 1": "R04-Inf-ESTR-ENJ01",
        "Rodillo 5 superior ESTRUJADOR ENJUAGUE 2": "R05-Sup-ESTR-ENJ02",
        "Rodillo 6 Inferior ESTRUJADOR ENJUAGUE 2": "R06-Inf-ESTR-ENJ02",
        "Rodillo 7 superior ESTRUJADOR ENJUAGUE 3": "R07-Sup-ESTR-ENJ03",
        "Rodillo 8 Inferior ESTRUJADOR ENJUAGUE 3": "R08-Inf-ESTR-ENJ03",
        "Rodillo salida grande superior ESTRUJADOR ENJUAGUE 3": "RSG-Sup-ESTR-ENJ03",
        "Rodillo salida grande inferior ESTRUJADOR ENJUAGUE 3": "RSG-Inf-ESTR-ENJ03",
        "Rodillo inferior metálico Nanotecnología": "R-Inf-Met-Nano",
        "Rodillo  Superior Nanotecnología": "R-Sup-Nano",
        "RODILLO INFERIOR ENTRADA TORRE UV": "R-Inf-UV",
        "Rodillo 2 Superior TORRE UV": "R02-Sup-UV",
        "RODILLO SUPERIOR TORRE UV": "R-Sup-UV",
        "Rodillo Inferior entrada Esmaltadora 1": "R-Inf-ESM01",
        "Rodillo Superior Esmaltadora 1": "R-Sup-ESM01",
        "Rodillo 1 ENFRIADOR 1": "R01-ENF01",
        "Rodillo 2 Superior ENFRIADOR 1": "R02-Sup-ENF01",
        "Rodillo 3 Inferior ENFRIADOR 1": "R03-Inf-ENF01",
        "Rodillo Inferior entrada Esmaltadora 2": "R-Inf-ESM02",
        "Rodillo Superior Esmaltadora 2": "R-Sup-ESM02",
        "Rodillo 4 ENFRIADOR 2": "R04-ENF02",
        "Rodillo 5 Superior ENFRIADOR 2": "R05-Sup-ENF02",
        "Rodillo 6 Inferior ENFRIADOR 2": "R06-Inf-ENF02",
        "Rodillo Inferior entrada Esmaltadora 3": "R-Inf-ESM03",
        "Rodillo metálico Superior Esmaltadora 3": "R-Sup-Met-ESM03",
        "Rodillo fierro Superior torre Esmaltadora 3": "R-Fe-Sup-ESM03",
        "Rodillo 7 ENFRIADOR 3": "R07-ENF03",
        "Rodillo 8 Superior ENFRIADOR 3": "R08-Sup-ENF03",
        "Rodillo 9 Inferior ENFRIADOR 3": "R09-Inf-ENF03",
        "Rodillo 10 ENFRIADOR 4": "R10-ENF04",
        "Rodillo 11 Superior ENFRIADOR 4": "R11-Sup-ENF04",
        "Rodillo 12 Inferior ENFRIADOR 4": "R12-Inf-ENF04",
    }
    return abreviaturas[rodillo]
