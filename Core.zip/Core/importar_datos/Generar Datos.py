# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 15:04:15 2021

@author: imap0
"""
# =============================================================================
# Generar datos simulados
# =============================================================================

import pandas as pd
import numpy as np
import datetime
import os


fecha_de_inicio=datetime.datetime(year=2019, month=6, day=1)
fecha_de_fin=datetime.datetime(year=2021, month=6, day=1)

# Op

mapeo_de_rodillos="Mapeo rodillo LP700A.xlsx"

control_de_piso_nombre="consolidado control de piso 2019-2020.xlsx"
"Importar la data para generar datos consistentes"

control_de_piso=pd.read_excel("Excel"+os.sep+control_de_piso_nombre,engine='openpyxl')
control_de_piso_header=control_de_piso.columns




# Rango de ops por dia
min_ops_dia=10
max_ops_dia=15

control_de_piso_carga_fleje=control_de_piso.query("Opciones=='CARGA FLEJES'").values
control_de_piso_rollos_pintados=control_de_piso.query("Opciones=='ROLLOS PINTADOS'")

control_de_piso_rollos_pintados=control_de_piso_rollos_pintados.rename(columns={'Id Producción (OP)': 'op'})


n_datos_reales=len(control_de_piso_carga_fleje)

n_dias=(fecha_de_fin-fecha_de_inicio).days+1
control_de_piso_generado_datos=[]
fechas=[]

from tqdm import trange
for dia in trange(n_dias):
    fecha_hoy=fecha_de_inicio+datetime.timedelta(days=dia)
    # print(fecha_hoy)
    n_ops_hoy=np.random.randint(min_ops_dia,max_ops_dia)
    for i in range(n_ops_hoy):
        op_carga_de_fleje=control_de_piso_carga_fleje[np.random.randint(n_datos_reales),:]
        op=op_carga_de_fleje[0] # Número de Op
        
        control_de_piso_rollos_pintados_op=control_de_piso_rollos_pintados.query(
            "op.str.contains('"+str(op)+"')", engine='python')
        
        fechas.append(fecha_hoy)
        control_de_piso_generado_datos.append(op_carga_de_fleje)
        for j in range(len(control_de_piso_rollos_pintados_op.values)):
            
            op_control_de_piso=control_de_piso_rollos_pintados_op.values[j]
            control_de_piso_generado_datos.append(op_control_de_piso)
            fechas.append(fecha_hoy)
fechas=np.array(fechas)
control_de_piso_generado_datos=np.array(control_de_piso_generado_datos)
for i in range(len(control_de_piso_generado_datos)):
    control_de_piso_generado_datos[i,32]=fechas[i]



df_control_de_piso_generado=pd.DataFrame(control_de_piso_generado_datos,columns=control_de_piso_header)
    
df_control_de_piso_generado.to_excel("file",engine='openpyxl')
    






















