# -*- coding: utf-8 -*-
"""
Created on Tue Apr  6 16:37:26 2021

@author: imap0
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Jan 28 12:13:31 2021
Crear archivo a partir de mapeo de rodillos
@author: imap0
"""

import pandas as pd
import numpy as np
import datetime
import os
import json
from tqdm import trange
import error

import os,sys,inspect
#current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
#parent_dir = os.path.dirname(current_dir)
#sys.path.insert(0, parent_dir) 
def guardar_data_produccion(control_de_piso_archivo_nombre,nombre_data_acumulada,nombre_salida="",verificar_superposicion=True):
# =============================================================================
#     Genera y actualiza el csv con los datos de producción globales
# =============================================================================
    """
    control_de_piso_archivo_nombre: nombre del archivo en excel donde se saca la nueva produccion
    nombre_data_acumulada: nombre del archivo actual en csv donde se han guardado las producciones reals
    nombre_salida: nombre del archivo de salida en formato csv de produccion acumulada de salida
    verificar_superposicion: boolean que verifica la superposicion de la data
    """



    "Importar la data"
    if nombre_salida=="":
        nombre_salida=nombre_data_acumulada
    #current_path=os.path.abspath(os.getcwd())+os.sep+"importar_datos"
    #control_de_piso=pd.read_excel(current_path+os.sep+"Excel"+os.sep+control_de_piso_archivo_nombre,engine='openpyxl')
    control_de_piso=pd.read_excel(control_de_piso_archivo_nombre,engine='openpyxl')
    control_de_piso_header=control_de_piso.columns
    
    # Ordenar por fecha
    control_de_piso_ordenado=control_de_piso.sort_values(["Fecha de creación","Hora de creación"],ignore_index=True)
    # extraigo lo de la linea de pintura
    control_de_piso_lineapintado=control_de_piso_ordenado.query("Recurso=='LP700' or Recurso=='LP400' or Recurso=='LP700 BR'") 
    
    
    
    
    
    control_de_piso_lineapintado_carga_flejes=control_de_piso_lineapintado.query("Opciones=='CARGA FLEJES'") # incluye la información del fleje
    """Data Acumulada"""
    # indices que se mantienen, se guarda lo relevante de la producción
    indices=["Id Producción (OP)","KILOS ENTRADA","SALDO (KGS)","DESECHO (KGS)","DESCRIPCIÓN","Recurso","Hora de creación","Fecha de creación"]
    index_date=indices.index("Fecha de creación")
    index_time=indices.index("Hora de creación")
    index_op=indices.index("Id Producción (OP)")
    production_data_actual=control_de_piso_lineapintado_carga_flejes[indices]
    
    # se importa la data guardada antigua sobre la cual se agrega la nueva producción
    #if os.path.isfile(current_path+os.sep+"database"+os.sep+"production_data_acumulado.csv"): # si hay historia
    if os.path.isfile(nombre_data_acumulada): # si hay historia
        #production_data_acumulado_antigua=pd.read_csv(current_path+os.sep+"database"+os.sep+"production_data_acumulado.csv")
        production_data_acumulado_antigua=pd.read_csv(nombre_data_acumulada)
        
        production_data_acumulado_antigua_val=production_data_acumulado_antigua.values
        production_data_actual_val=production_data_actual.values
        index=0
        faltan_datos=True # boolean que permite saber si hay interseccion en los datasets, si no hay interseccion no se puede saber si faltan datos
        row_old=production_data_acumulado_antigua_val[-1]
        for i in range(len(production_data_actual_val)):
            # Ocurre que el objeto datetime tiene la hora incluida seteada en 00:00:00, la funcion date() elimina la hora de la fecha, la cual se encuentra en otra columna
            production_data_actual_val[i,index_date]=production_data_actual_val[i,index_date].date()
        # Se verifica si hay superposicion entre los datasets de producción
        
        for row_new in production_data_actual_val:
            if row_old[index_op]==row_new[index_op] and row_old[index_time]==str(row_new[index_time]) and row_old[index_date]==str(row_new[index_date]):
                faltan_datos=False
                break
            index+=1
        if not(verificar_superposicion):
            faltan_datos=False
            index=0

        if faltan_datos and verificar_superposicion: 
            error.error("No hay superposición entre los datos de produccion en la base de datos y los nuevos agregados")
        
        
        
        
        conc_val=np.concatenate((production_data_acumulado_antigua_val,production_data_actual_val[index+1:]),axis=0)
        production_data_completa=pd.DataFrame(conc_val,columns=indices)
        #production_data_completa.to_csv(current_path+os.sep+"database"+os.sep+nombre_salida,index=False)
        production_data_completa.to_csv(nombre_salida,index=False)
        fecha_ultima_op=production_data_completa["Fecha de creación"].values[-1]
        
        
        # fecha_ultima_op=datetime.utcfromtimestamp(fecha_ultima_op)
        json_object = json.dumps(fecha_ultima_op,default=str)
        #with open(current_path+os.sep+"database"+os.sep+nombre_salida[:-4]+'_fecha_ultima_op.txt', 'w') as outfile:
        with open(nombre_salida[:-4]+'_fecha_ultima_op.txt', 'w') as outfile:
            json.dump(json_object, outfile)

    else: #No existe historia, se gurada lo que se subio
        production_data_completa=production_data_actual
        #production_data_actual.to_csv(current_path+os.sep+"database"+os.sep+nombre_salida,index=False)
        production_data_actual.to_csv(nombre_salida,index=False)
        fecha_ultima_op=production_data_actual["Fecha de creación"].values[-1]
        
        # fecha_ultima_op=datetime.utcfromtimestamp(fecha_ultima_op)
        json_object = json.dumps(fecha_ultima_op.astype('M8[D]'),default=str)
        #with open(current_path+os.sep+"database"+os.sep+nombre_salida[:-4]+'_fecha_ultima_op.txt', 'w') as outfile:
        with open(nombre_salida[:-4]+'_fecha_ultima_op.txt', 'w') as outfile:
            json.dump(json_object, outfile)
    
        
def generar_datos_produccion(nombre_data_original,fecha_de_inicio,fecha_de_fin,nombre_salida,carga="standard"):
# =============================================================================
#  Construye datos generados a partir de la data real    
# =============================================================================
    """
    fecha_de_inicio="aaaa_mm_dd"
    fecha_de_fin="aaaa_mm_dd"
    carga=estandar,baja,alta
    
    """
    inicio_split=fecha_de_inicio.split("_")
    fin_split=fecha_de_fin.split("_")
    
    
    fecha_de_inicio=datetime.datetime(year=int(inicio_split[0]), month=int(inicio_split[1]), day=int(inicio_split[2]))
    fecha_de_fin=datetime.datetime(year=int(fin_split[0]), month=int(fin_split[1]), day=int(fin_split[2]))
    
    # Op
    
    carpeta_excel=os.path.abspath(os.getcwd())+os.sep+"importar_datos"+os.sep+"Excel"
    control_de_piso_nombre=nombre_data_original
    "Importar la data para generar datos consistentes"
    
    control_de_piso=pd.read_excel(carpeta_excel+os.sep+control_de_piso_nombre,engine='openpyxl')
    control_de_piso_header=control_de_piso.columns
    
    
    
    
    # Rango de ops por dia
    min_ops_dia=10
    max_ops_dia=15
    
    control_de_piso_carga_fleje=control_de_piso.query("Opciones=='CARGA FLEJES'").values
    control_de_piso_rollos_pintados=control_de_piso.query("Opciones=='ROLLOS PINTADOS'")
    
    control_de_piso_rollos_pintados=control_de_piso_rollos_pintados.rename(columns={'Id Producción (OP)': 'op'})
    
    
    n_datos_reales=len(control_de_piso_carga_fleje)
    
    n_dias=(fecha_de_fin-fecha_de_inicio).days+1

    control_de_piso_generado_datos=[]
    fechas=[]
    
    
    for dia in trange(n_dias):
        fecha_hoy=fecha_de_inicio+datetime.timedelta(days=dia)
        # print(fecha_hoy)
        n_ops_hoy=np.random.randint(min_ops_dia,max_ops_dia)
        for i in range(n_ops_hoy):
            if carga=="estandar":
                op_carga_de_fleje=control_de_piso_carga_fleje[np.random.randint(n_datos_reales),:]
                op=op_carga_de_fleje[0] # Número de Op
            elif carga=="baja" or carga=="alta":
                while True:
                    op_carga_de_fleje=control_de_piso_carga_fleje[np.random.randint(n_datos_reales),:]
                    op=op_carga_de_fleje[0] # Número de Op
                    kilos=int(op_carga_de_fleje[1])
                    if kilos<700 and carga=="baja":
                        break
                    elif kilos>=700 and carga=="alta":
                        break
            else:
                op_carga_de_fleje=control_de_piso_carga_fleje[np.random.randint(n_datos_reales),:]
                op=op_carga_de_fleje[0] # Número de Op
            control_de_piso_rollos_pintados_op=control_de_piso_rollos_pintados.query(
                "op.str.contains('"+str(op)+"')", engine='python')
            
            fechas.append(fecha_hoy)
            control_de_piso_generado_datos.append(op_carga_de_fleje)
            for j in range(min(len(control_de_piso_rollos_pintados_op),np.random.randint(3)+1)):
                
                op_control_de_piso=control_de_piso_rollos_pintados_op.values[np.random.randint(len(control_de_piso_rollos_pintados_op))]
                
                control_de_piso_generado_datos.append(op_control_de_piso)
                fechas.append(fecha_hoy)
    fechas=np.array(fechas)
    control_de_piso_generado_datos=np.array(control_de_piso_generado_datos)
    for i in range(len(control_de_piso_generado_datos)):
        control_de_piso_generado_datos[i,32]=fechas[i]
    
    
    
    df_control_de_piso_generado=pd.DataFrame(control_de_piso_generado_datos,columns=control_de_piso_header)
    
    #df_control_de_piso_generado.to_excel(carpeta_excel+os.sep+nombre_salida,engine='openpyxl',index=False)
    df_control_de_piso_generado.to_excel(nombre_salida,engine='openpyxl',index=False)
    

def convertir_descripcion_en_material_y_dimensiones(descripcion_str,materiales):

    material="S/I"
    for mat in materiales:
        if not(isinstance(descripcion_str, str)):break
        if mat in descripcion_str:
            material=mat
            break
    if material=="S/I" or descripcion_str.split(" ")[0]!="FLEJE":
        espesor=0
        desarrollo=0
        return material,desarrollo,espesor
    split=descripcion_str.split(" ")
    while("" in split) : 
        split.remove("") 
    espesorymaterial=split[1]
    desarrollo=float(split[3].replace(",","."))
    
    espesor=espesorymaterial[len(material):]
    espesor.replace(",",".")
    espesor=float(espesor)
    return material,desarrollo,espesor

def fecha_string_a_datetime(fecha_string):
        "Convierte una fecha en string a datetime"
        import datetime
        [y,m,d]=fecha_string.split("-")
        fecha_datetime=datetime.datetime(int(y),int(m),int(d))
        return fecha_datetime
def encontrar_indice_fecha(fecha_str,array_fechas_str):
    "esta funcion encuentra el punto donde se encuentra una fecha en un array de fechas en formato string"
    
    fecha=fecha_string_a_datetime(fecha_str)
    fecha_encotrada=False
    for i in range(len(array_fechas_str)):
        fecha_i=fecha_string_a_datetime(array_fechas_str[i])
        if fecha_i>fecha:
            fecha_encotrada=True
            break
    if fecha_encotrada==False:
        error.error("Fecha buscada en dataset no encontrada: "+str(fecha))
    return i-1
def ETL_dataframe_mantenimiento(df_hoja):
    """Esta funcion ajusta la hoja a un formato estandár"""
    # Eliminamos columnas NaN
    df=df_hoja.dropna(1,how="all")
    # Buscamos la ubicación de la columna "OT"
    valores=df.values
    ubicacion_OT=[] # ubicaciónes de la esquina superior izquierda de cada Tabla en la hoja
    for i in range(len(valores)): 
        for j in range(len(valores[0])):
            if valores[i,j]=="OT":
                ubicacion_OT.append((i,j))
    # Encontramós el nombre de la ubicación (dos filas más arriba de la primera "OT" desde la izquierda)
    nombre_ubicacion=valores[ubicacion_OT[0][0]-2,ubicacion_OT[0][1]]
    nombres_rodillos=[]
    data_rodillos=[]
    for pos in ubicacion_OT: #recorremos los rodillos a partir de cuantos columnas "OT" hay
        nombre_rodillo_sin_ubicacion=valores[pos[0]-1,pos[1]]
        # si no tiene nombre, se trata de una lista vacia ya que no existe este rodillo
        if type(nombre_rodillo_sin_ubicacion)==float:continue
        # Construimos el nombre completo, para identificación, unico para cada rodillo
        nombre_rodillo=nombre_rodillo_sin_ubicacion+" "+nombre_ubicacion
        nombres_rodillos.append(nombre_rodillo)
        # extraemos las columnas a partir de la ubicación de la clumna "OT"
        data=valores[pos[0]:,pos[1]:pos[1]+3]
        # Construimos el dataframe
        df_rodillo=pd.DataFrame(data[1:],columns=data[0])
        # eliminamos las filas con NaN (las que no tienen datos)
        df_rodillo=df_rodillo.dropna(0,how="all")
        a=df_rodillo.sort_values("FECHA") # se ordenan por fecha
        data_rodillos.append(a)
    
    return data_rodillos,nombres_rodillos


def crear_dataset_evaluacion(info_rodillos_nombre,mantenimiento_nombre,nombre_data_acumulada,elemento_estudiado="rodamientos"):
    #carpeta_excel=os.path.abspath(os.getcwd())+os.sep+"importar_datos"+os.sep+"Excel"
    # Se cargan todas las hojas y nombres del archivo mapeo
    
    #info_rodillos=pd.read_excel(carpeta_excel+os.sep+info_rodillos_nombre,engine='openpyxl')
    info_rodillos=pd.read_excel(info_rodillos_nombre,engine='openpyxl')
    
    #excel_file=pd.ExcelFile(carpeta_excel+os.sep+mantenimiento_nombre,engine='openpyxl')
    excel_file=pd.ExcelFile(mantenimiento_nombre,engine='openpyxl')
    hojas=excel_file.sheet_names
    # Se extrae el la linea de pintura involucrada
    linea_de_pintura=hojas[1].split(" ")[1]
    if linea_de_pintura=="LP700A":linea_de_pintura="LP700" # la linea LP700A se conoce como la LP700 en otros documentos
    
    # Se eliminan las primeras dos hojas "LP700A" y "Mapeo LP700A" para obtener las ubicaciónes
    ubicaiones=hojas[2:]
    
    df_list=[] # lista con las tablas de fallas por ubicación
    df_nombres=[] # lista con los nombres de la ubicación
    for i in range(len(ubicaiones)):
        # Se lee la hoja como dataframe
        df=pd.read_excel(excel_file,i+2,header=None)
        if df.empty:continue # se saltan las hojas vacias
        df_con_etl,nombres=ETL_dataframe_mantenimiento(df)
        
        # ponemos todos los dataframes en una lista concatenada
        for j in range(len(df_con_etl)):
            if len(df_con_etl[j])==0:continue # Saltarse los rodillos sin fallas
            df_list.append(df_con_etl[j])
            df_nombres.append(nombres[j])
    
    
    if elemento_estudiado=="rodamientos":
        tipos_de_falla=["R","Cambio rodamiento","Cambio rodamientos","Cambio Rodamiento","Cambio Rodamientos"] #Fallas que afectan rodamientos
    elif elemento_estudiado=="rodillos":
        tipos_de_falla=["EQ","ED","Cambio rodillo","Cambio rodillos"]
    
    def bool_tipo_de_falla(TIPO,tipos_de_falla=tipos_de_falla):
        "Retorna True si la falla se encuentra dentro de la lista tipos de falla"
        boolean=False
        for tipo in tipos_de_falla:
            if tipo==TIPO:
                boolean=True
        return boolean
        
    # Se encuentra la fecha de la última reparacion
    fechas_ultima_falla=[]
    for i in range(len(df_list)):
        "se cicla por cada set rodillo-rodamiento"
        
        data_mantenimiento=df_list[i].values
        nombre_completo=df_nombres[i]
        "Se busca la ultima falla"
        tiene_fallas=False # Bool indica si existe una falla del tipo buscado "rodamientos" o "rodillos"
        for j in range(len(data_mantenimiento)):
            "Se comienza de la ultima falla y se va en retroseso"
            j=len(data_mantenimiento)-1-j
            TIPO=data_mantenimiento[j,2]
            if bool_tipo_de_falla(TIPO):
                tiene_fallas=True
                ultima_falla_index=j
                break # Se sale del ciclo despues de la primera falla
        if tiene_fallas==False: 
            
            fechas_ultima_falla.append([nombre_completo,"Sin Fallas"])
            
            continue # el elemento no tiene fallas en el elemento investigado
        falla_anterior_index=ultima_falla_index # indice que indica donde se encuentra la falla anterior, se actualiza en cada ciclo hasta que no halla fallas en la ubicacion investigada
        fecha_de_inicio=str(data_mantenimiento[falla_anterior_index,1].date())
        fechas_ultima_falla.append([nombre_completo,fecha_de_inicio])
    
    fechas_ultima_falla=pd.DataFrame(fechas_ultima_falla,columns=(["Nombre completo","Fecha de Inicio"]))
    
    """
    Info rodillos
    """
    
    info_rodillos_values=info_rodillos.values
    info_rodillos_header=info_rodillos.columns
    info=info_rodillos_values[:,[0,3,4,5,6]]
    info_header=info_rodillos_header[[0,3,4,5,6]]
    """Agregar a los ciclos de vida la info rodillos"""
    def equal_string_anycase(string1,string2):
        return string1.lower()==string2.lower()
    Data=[]
    for i in range(len(fechas_ultima_falla)):
        data_ciclo=fechas_ultima_falla.values[i] # Extraer data del ciclo
        nombre_completo=data_ciclo[0] # Nombre utilizado para comparar con el nombre en info rodillos
        nombre_encontrado=False
        for j in range(len(info)):
            nombre_completo_info_rodillos=info[j][0]
            if equal_string_anycase(nombre_completo,nombre_completo_info_rodillos):
                nombre_encontrado=True
                
                Data.append(np.concatenate((info[j],[linea_de_pintura],data_ciclo[1:])))
                break
        if nombre_encontrado==False: print("No se encontro información acerca del rodillo")
    fechas_ultima_falla_header=np.concatenate((info_header,["Recurso"],fechas_ultima_falla.columns[1:]))
    fechas_ultima_falla_info=pd.DataFrame(Data,columns=fechas_ultima_falla_header) # Incluye el periodo de la falla y la información de los rodillos
    
    
    rodillos_sin_fallas=[]
    entrada_rodillos=[]
    for rodillo in fechas_ultima_falla_info.values:
        nombre_rodillo=rodillo[0]
        diametro_eje=rodillo[2]
        diametro_rodillo=rodillo[3]
        largo_rodillo=rodillo[4]
        recurso=rodillo[5]
        fecha_inicio=rodillo[6]
        if fecha_inicio=="Sin Fallas":
            rodillos_sin_fallas.append(nombre_rodillo)
            continue
        # Se extrae la produccion entre la última falla y ahora
        data_op_periodo,data_op_header=produccion_rango_de_fechas(nombre_data_acumulada,recurso,fecha_inicio)
        # Se añade la información del rodillo
        i=0
        for op in data_op_periodo:
            data_op_periodo[i]=[[nombre_rodillo]+
                [diametro_eje]+
                [diametro_rodillo]+
                [largo_rodillo]+
                op][0]
            i+=1
        
                
        
        data_header=[["Nombre Rodillo"]
                  +["Diametro Eje"]
                  +["Diametro Rodillo"]
                  +["Largo Rodillo"]
                  +data_op_header][0]
        data=pd.DataFrame(data_op_periodo,columns=data_header)
        entrada_rodillos.append(data)
    return entrada_rodillos



def crear_dataset_entrenamiento(info_rodillos_nombre,mantenimiento_nombre,nombre_data_acumulada,elemento_estudiado="rodamientos"):
    vida_util=350 # Dias de vida util
    
    #carpeta_excel=os.path.abspath(os.getcwd())+os.sep+"importar_datos"+os.sep+"Excel"
    # Se cargan todas las hojas y nombres del archivo mapeo
    
    #info_rodillos=pd.read_excel(carpeta_excel+os.sep+info_rodillos_nombre,engine='openpyxl')
    info_rodillos=pd.read_excel(info_rodillos_nombre,engine='openpyxl')
    
    #excel_file=pd.ExcelFile(carpeta_excel+os.sep+mantenimiento_nombre,engine='openpyxl')
    excel_file=pd.ExcelFile(mantenimiento_nombre,engine='openpyxl')
    hojas=excel_file.sheet_names
    # Se extrae el la linea de pintura involucrada
    linea_de_pintura=hojas[1].split(" ")[1]
    if linea_de_pintura=="LP700A":linea_de_pintura="LP700" # la linea LP700A se conoce como la LP700 en otros documentos
    
    # Se eliminan las primeras dos hojas "LP700A" y "Mapeo LP700A" para obtener las ubicaciónes
    ubicaiones=hojas[2:]
    primera_fecha=datetime.datetime(year=3000,month=1,day=1)
    df_list=[] # lista con las tablas de fallas por ubicación
    df_nombres=[] # lista con los nombres de la ubicación
    for i in range(len(ubicaiones)):
        # Se lee la hoja como dataframe
        df=pd.read_excel(excel_file,i+2,header=None)
        if df.empty:continue # se saltan las hojas vacias
        df_con_etl,nombres=ETL_dataframe_mantenimiento(df)
        
        # ponemos todos los dataframes en una lista concatenada
        for j in range(len(df_con_etl)):
            if len(df_con_etl[j])==0:continue # Saltarse los rodillos sin fallas
            for k in range(len(df_con_etl[j])):
                fecha=df_con_etl[j]["FECHA"][k].date()
                fecha_datetime=datetime.datetime(year=fecha.year,month=fecha.month,day=fecha.day)
                if fecha_datetime<primera_fecha:
                    primera_fecha=fecha_datetime
                
            df_list.append(df_con_etl[j])
            df_nombres.append(nombres[j])
    # primera_fecha=primera_fecha+datetime.timedelta(days=80)
    
    
    if elemento_estudiado=="rodamientos":
        tipos_de_falla=["R","Cambio rodamiento","Cambio rodamientos","Cambio Rodamiento","Cambio Rodamientos"] #Fallas que afectan rodamientos
    elif elemento_estudiado=="rodillos":
        tipos_de_falla=["EQ","ED","Cambio rodillo","Cambio rodillos"]
    
    def bool_tipo_de_falla(TIPO,tipos_de_falla=tipos_de_falla):
        "Retorna True si la falla se encuentra dentro de la lista tipos de falla"
        boolean=False
        for tipo in tipos_de_falla:
            if tipo==TIPO:
                boolean=True
        return boolean
        
    # Se encuentran las fechas entre fallas
    
    #carpeta_database=os.path.abspath(os.getcwd())+os.sep+"importar_datos"+os.sep+"database"
    #production_data_completa=pd.read_csv(carpeta_database+os.sep+nombre_data_acumulada)
    production_data_completa=pd.read_csv(nombre_data_acumulada)
    ultima_fecha=fecha_string_a_datetime(max(production_data_completa["Fecha de creación"]))
    primera_fecha2=fecha_string_a_datetime(min(production_data_completa["Fecha de creación"]))
    primera_fecha=max(primera_fecha,primera_fecha2)
    ciclos_de_vida=[]
    for i in range(len(df_list)):
        "se cicla por cada set rodillo-rodamiento"
        data_mantenimiento=df_list[i].values
        "Se busca la primera falla"
        tiene_fallas=False # Bool indica si existe una falla del tipo buscado "rodamientos" o "rodillos"
        for j in range(len(data_mantenimiento)):
            TIPO=data_mantenimiento[j,2]
            if bool_tipo_de_falla(TIPO):
                tiene_fallas=True
                primera_falla_index=j
                break # Se sale del ciclo despues de la primera falla
        if tiene_fallas==False: continue # el elemento no tiene fallas en el elemento investigado
        falla_anterior_index=primera_falla_index # indice que indica donde se encuentra la falla anterior, se actualiza en cada ciclo hasta que no halla fallas en la ubicacion investigada
        
        while True: # Se cicla hasta que no se tengan mas fallas
            existe_siguiente=False
            for j in range(falla_anterior_index+1,len(data_mantenimiento)): # se cicla desde la falla anterior hasta la última
                "se busca la siguiente falla del mismo tipo"
                TIPO_j=data_mantenimiento[j,2]
                if bool_tipo_de_falla(TIPO_j):
                    falla_siguiente_index=j
                    
                    fecha_de_fin=data_mantenimiento[falla_siguiente_index,1]
                    existe_siguiente=True
                    break
            fecha_de_inicio=data_mantenimiento[falla_anterior_index,1]
            if existe_siguiente==False:
                if (ultima_fecha-fecha_de_inicio).days>vida_util:
                    "Elemento sobrepasa la vida útil y debe cambiarse"
                    fecha_de_fin=fecha_de_inicio+datetime.timedelta(days=vida_util)
                elif (fecha_de_inicio-primera_fecha).days>vida_util:
                    
                    # print(fecha_de_inicio-primera_fecha)
                    fecha_de_fin=fecha_de_inicio
                    fecha_de_inicio=primera_fecha
                    # fecha_de_inicio=fecha_de_fin-datetime.timedelta(days=vida_util)
                else:
                    "Fin del ciclo"
                    "No hay falla siguiente en la ubiación, por lo que no existe otro ciclo de vida"
                    break
            
            dias_ciclo_de_vida=(fecha_de_fin-fecha_de_inicio).days
            ubicacion=df_nombres[i]
            data_ciclo_de_vida=[ubicacion,str(fecha_de_inicio.date()),str(fecha_de_fin.date()),dias_ciclo_de_vida]
            
            
            if fecha_de_inicio<datetime.datetime(year=2019,month=6,day=1):
                 falla_anterior_index=falla_siguiente_index# se elmininan los casos anteriores a junio del 2019 dado que no se tiene informacion de produccion de esa fecha
            else:
                ciclos_de_vida.append(data_ciclo_de_vida)
                # Se avanza en el ciclo while_true para eventualmente llegar al cierre
                falla_anterior_index=falla_siguiente_index
            if existe_siguiente==False: break
    ciclos_de_vida=pd.DataFrame(ciclos_de_vida,columns=["Ubicacion","Fecha de Inicio","Fecha de Fin","Dias Funcional"])
    
    
    
    """
    Info rodillos
    """
    
    info_rodillos_values=info_rodillos.values
    info_rodillos_header=info_rodillos.columns
    info=info_rodillos_values[:,[0,3,4,5,6]]
    info_header=info_rodillos_header[[0,3,4,5,6]]
    """Agregar a los ciclos de vida la info rodillos"""
    def equal_string_anycase(string1,string2):
        return string1.lower()==string2.lower()
    Data=[]
    for i in range(len(ciclos_de_vida)):
        data_ciclo=ciclos_de_vida.values[i] # Extraer data del ciclo
        nombre_completo=data_ciclo[0] # Nombre utilizado para comparar con el nombre en info rodillos
        nombre_encontrado=False
        for j in range(len(info)):
            nombre_completo_info_rodillos=info[j][0]
            if equal_string_anycase(nombre_completo,nombre_completo_info_rodillos):
                nombre_encontrado=True
                
                Data.append(np.concatenate((info[j],[linea_de_pintura],data_ciclo[1:])))
                break
        if nombre_encontrado==False: print("No se encontro información acerca del rodillo")
    ciclos_de_vida_header=np.concatenate((info_header,["Recurso"],ciclos_de_vida.columns[1:]))
    ciclos_de_vida_info=pd.DataFrame(Data,columns=ciclos_de_vida_header) # Incluye el periodo de la falla y la información de los rodillos
    
    
    
    entrada_rodillos=[]
    for i in range(len(ciclos_de_vida_info.values)):
        ciclo=ciclos_de_vida_info.values[i]
        nombre_rodillo=ciclo[0]
        diametro_eje=ciclo[2]
        diametro_rodillo=ciclo[3]
        largo_rodillo=ciclo[4]
        recurso=ciclo[5]
        fecha_inicio=ciclo[6]
        fecha_fin=ciclo[7]
        
        # Se extrae la produccion entre la última falla y ahora
        data_op_periodo,data_op_header=produccion_rango_de_fechas(nombre_data_acumulada,recurso,fecha_inicio,fecha_fin)
        # Se añade la información del rodillo
        i=0
        for op in data_op_periodo:
            data_op_periodo[i]=[[nombre_rodillo]+
                [diametro_eje]+
                [diametro_rodillo]+
                [recurso]+
                op][0]
            i+=1
        
                
        
        data_header=[["Nombre Rodillo"]
                  +["Diametro Eje"]
                  +["Diametro Rodillo"]
                  +["Largo Rodillo"]
                  +data_op_header][0]
        
        
        data=pd.DataFrame(data_op_periodo,columns=data_header)
        entrada_rodillos+=data_op_periodo
    #     
    
    dataset_produccion_ciclos=pd.DataFrame(entrada_rodillos,columns=data_header)
    
    # Creación de las etiquetas, se avanza en reversa
    labels=np.zeros([len(dataset_produccion_ciclos),1])
    inicio=True
    for i in range(len(dataset_produccion_ciclos)):# se calcula la vida remananente
        i=len(dataset_produccion_ciclos)-i-1
        
        
        kilos_acumulados_i=float(dataset_produccion_ciclos["Kilos Acumulados Desde Reparación"][i])
        kg_totales_op=float(dataset_produccion_ciclos["Kilos Totales Op"][i])
        if inicio:
            kg_restantes=kg_totales_op
            inicio=False
        elif kilos_acumulados_i>float(dataset_produccion_ciclos["Kilos Acumulados Desde Reparación"][i+1]):
            kg_restantes=kg_totales_op
        else:
            kg_restantes=kg_restantes+kg_totales_op
        labels[i,0]=kg_restantes
    
    
    # Se guarda en la carpeta entradas 
    labels=pd.DataFrame(labels,columns=["Kilos Remanentes"])
    

    #TODO: pasar este nombre de archivo como un parametro
    carpeta_entradas=os.path.abspath(os.getcwd())+os.sep+"importar_datos"+os.sep+"entradas"    
    labels.to_csv(carpeta_entradas+os.sep+"data_produccion_remanente_ciclos_de_vida.csv",index=False)
    dataset_produccion_ciclos.to_csv(carpeta_entradas+os.sep+"data_produccion_ciclos_de_vida.csv",index=False)
    
    
    return dataset_produccion_ciclos,labels
    

def produccion_rango_de_fechas(nombre_data_acumulada,recurso,fecha_de_inicio,fecha_de_fin=False):
    """
    Permite encontrar la produccion en una linea de pintura a partir de la base de datos entre un periodo de fechas en formato string "aaaa-mm-dd"
    
    """
    
    #carpeta_database=os.path.abspath(os.getcwd())+os.sep+"importar_datos"+os.sep+"database"
    #production_data_completa=pd.read_csv(carpeta_database+os.sep+nombre_data_acumulada)
    production_data_completa=pd.read_csv(nombre_data_acumulada)
    
    production_data_completa_val=production_data_completa.values
    production_data_completa_header=production_data_completa.columns
    
        
    index_op=production_data_completa_header.to_list().index('Id Producción (OP)')
    index_kg_entrada=production_data_completa_header.to_list().index('KILOS ENTRADA')
    index_kg_saldo=production_data_completa_header.to_list().index('SALDO (KGS)')
    index_kg_desecho=production_data_completa_header.to_list().index('DESECHO (KGS)')
    index_descripción=production_data_completa_header.to_list().index('DESCRIPCIÓN')
    index_recurso=production_data_completa_header.to_list().index('Recurso')
    index_hora_creacion=production_data_completa_header.to_list().index('Hora de creación')
    index_fecha_creacion=production_data_completa_header.to_list().index('Fecha de creación')
    columnas_a_conservar=[index_kg_entrada,index_kg_saldo,index_kg_desecho,index_recurso,index_fecha_creacion]
    
    materiales=["AZ","ACCO","AL","GA","INOX"] # lista de materiales soportados por el sistema
    
    
    
    
    fechas_de_produccion=production_data_completa["Fecha de creación"].values # array con con las fechas de cada op
    indice_inicio=encontrar_indice_fecha(fecha_de_inicio,fechas_de_produccion)+1
    if fecha_de_fin==False:
        indice_fin=len(fechas_de_produccion)-1
    else:
        indice_fin=encontrar_indice_fecha(fecha_de_fin,fechas_de_produccion)
    
    inicio=0
    data_op_periodo=[]
    data_op_header=[]
    for i in range(indice_inicio,indice_fin+1):
        data_de_producción_op=production_data_completa_val[i]
        if not(recurso==data_de_producción_op[index_recurso]):continue # Solo se concidera la linea de pintura del rodillo analisado
        descripcion=data_de_producción_op[index_descripción]
        material,desarrollo,espesor=convertir_descripcion_en_material_y_dimensiones(descripcion,materiales)
        kg_totales_op=data_de_producción_op[index_kg_entrada]-data_de_producción_op[index_kg_saldo]
        kg_totales_op=max(0.0,kg_totales_op) # son mayores que cero
        if inicio == 0:
            inicio=1
            kilos_acumulados=kg_totales_op
            
        else:
            kilos_acumulados+=kg_totales_op # total producido desde la última producción en kilos
        data_op=[list(data_de_producción_op[columnas_a_conservar])
                 +[kg_totales_op]
                 +[material]
                 +[desarrollo]
                 +[espesor]
                 +[kilos_acumulados]][0]
        data_op_periodo.append(data_op)
        data_op_header=[list(production_data_completa_header[columnas_a_conservar])
             +["Kilos Totales Op"]
             +["Material"]
             +["Desarrollo"]
             +["Espesor"]
             +["Kilos Acumulados Desde Reparación"]][0]
        
    return data_op_periodo,data_op_header





