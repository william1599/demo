# -*- coding: utf-8 -*-
"""
Created on Thu Jan 28 12:13:31 2021
Crear archivo a partir de mapeo de rodillos
@author: imap0
"""

import pandas as pd
import numpy as np
import datetime
import os

"""
Configuración
"""
"Archivos"
# La ubicación del archivo de mantenimiento, debe ser de la 700A
mapeo_de_rodillos="Mapeo rodillo LP700A-nov2020.xlsx"
mapeo_de_rodillos="Mapeo rodillo LP700A.xlsx"
info_rodillos_nombre="info_rodillos.xlsx" # Archivo estático

# Ubicacion de l archivo de producción
control_de_piso_nombre="consolidado control de piso 2019-2020.xlsx"# entrada7
# control_de_piso_nombre="consolidado control de piso 2020.xlsx"# archivo de prueba


elemento_estudiado="rodamientos" # puede ser el "rodillos" o el "rodamientos"


materiales=["AZ","ACCO","AL","GA","INOX"] # lista de materiales soportados por el sistema

if elemento_estudiado=="rodamientos":
    tipos_de_falla=["R","Cambio rodamiento","Cambio rodamientos"] #Fallas que afectan rodamientos
elif elemento_estudiado=="rodillos":
    tipos_de_falla=["EQ","ED","Cambio rodillo","Cambio rodillos"]

"""Fin Configuración"""
# Se cargan todas las hojas y nombres del archivo mapeo
excel_file=pd.ExcelFile("Excel"+os.sep+mapeo_de_rodillos,engine='openpyxl')
hojas=excel_file.sheet_names
# Se extrae el la linea de pintura involucrada
linea_de_pintura=hojas[1].split(" ")[1]
if linea_de_pintura=="LP700A":linea_de_pintura="LP700" # la linea LP700A se conoce como la LP700 en otros documentos



info_rodillos=pd.read_excel("Excel"+os.sep+info_rodillos_nombre,engine='openpyxl')

# Se eliminan las primeras dos hojas "LP700A" y "Mapeo LP700A" para obtener las ubicaciónes
ubicaiones=hojas[2:]

def ETL_dataframe_mantenimiento(df_hoja):
    """Esta funcion ajusta la hoja a un formato estandár"""
    """Esta funcion ajusta la hoja a un formato estandár"""
    values=df_hoja.values
    # Eliminamos columnas NaN
    df=df_hoja.dropna(1,how="all")
    # Buscamos la ubicación de la columna "OT"
    valores=df.values
    ubicación_OT=[] # ubicaciónes de la esquina superior izquierda de cada Tabla en la hoja
    for i in range(len(valores)): 
        for j in range(len(valores[0])):
            if valores[i,j]=="OT":
                ubicación_OT.append((i,j))
    # Encontramós el nombre de la ubicación (dos filas más arriba de la primera "OT" desde la izquierda)
    nombre_ubicacion=valores[ubicación_OT[0][0]-2,ubicación_OT[0][1]]
    nombres_rodillos=[]
    data_rodillos=[]
    for pos in ubicación_OT: #recorremos los rodillos a partir de cuantos columnas "OT" hay
        nombre_rodillo_sin_ubicacion=valores[pos[0]-1,pos[1]]
        # si no tiene nombre, se trata de una lista vacia ya que no existe este rodillo
        if type(nombre_rodillo_sin_ubicacion)==float:continue
        # Construimos el nombre completo, para identificación, unico para cada rodillo
        nombre_rodillo=nombre_rodillo_sin_ubicacion+" "+nombre_ubicacion
        nombres_rodillos.append(nombre_rodillo)
        # extraemos las columnas a partir de la ubicación de la clumna "OT"
        data=valores[pos[0]:,pos[1]:pos[1]+3]
        # Construimos el dataframe
        df_rodillo=pd.DataFrame(data[1:],columns=data[0])
        # eliminamos las filas con NaN (las que no tienen datos)
        df_rodillo=df_rodillo.dropna(0,how="all")
        data_rodillos.append(df_rodillo)
    
    return data_rodillos,nombres_rodillos
    


df_list=[] # lista con las tablas de fallas por ubicación
df_nombres=[] # lista con los nombres de la ubicación
for i in range(len(ubicaiones)):
    # Se lee la hoja como dataframe
    df=pd.read_excel(excel_file,i+2,header=None)
    if df.empty:continue # se saltan las hojas vacias
    df_con_etl,nombres=ETL_dataframe_mantenimiento(df)
    
    # ponemos todos los dataframes en una lista concatenada
    for j in range(len(df_con_etl)):
        if len(df_con_etl[j])==0:continue # Saltarse los rodillos sin fallas
        df_list.append(df_con_etl[j])
        df_nombres.append(nombres[j])


def bool_tipo_de_falla(TIPO,tipos_de_falla=tipos_de_falla):
    "Retorna True si la falla se encuentra dentro de la lista tipos de falla"
    boolean=False
    for tipo in tipos_de_falla:
        if tipo==TIPO:
            boolean=True
    return boolean
    
    
ciclos_de_vida=[]
for i in range(len(df_list)):
    "se cicla por cada set rodillo-rodamiento"
    data_mantenimiento=df_list[i].values
    "Se busca la primera falla"
    tiene_fallas=False # Bool indica si existe una falla del tipo buscado "rodamientos" o "rodillos"
    for j in range(len(data_mantenimiento)):
        TIPO=data_mantenimiento[j,2]
        if bool_tipo_de_falla(TIPO):
            tiene_fallas=True
            primera_falla_index=j
            break # Se sale del ciclo despues de la primera falla
    if tiene_fallas==False: continue # el elemento no tiene fallas en el elemento investigado
    falla_anterior_index=primera_falla_index # indice que indica donde se encuentra la falla anterior, se actualiza en cada ciclo hasta que no halla fallas en la ubicacion investigada
    
    while True: # Se cicla hasta que no se tengan mas fallas
        existe_siguiente=False
        for j in range(falla_anterior_index+1,len(data_mantenimiento)): # se cicla desde la falla anterior hasta la última
            "se busca la siguiente falla del mismo tipo"
            TIPO_j=data_mantenimiento[j,2]
            if bool_tipo_de_falla(TIPO_j):
                falla_siguiente_index=j
                existe_siguiente=True
                break
        if existe_siguiente==False:
            "Fin del ciclo"
            "No hay falla siguiente en la ubiación, por lo que no existe otro ciclo de vida"
            break
        fecha_de_inicio=data_mantenimiento[falla_anterior_index,1]
        fecha_de_fin=data_mantenimiento[falla_siguiente_index,1]
        dias_ciclo_de_vida=(fecha_de_fin-fecha_de_inicio).days
        ubicacion=df_nombres[i]
        data_ciclo_de_vida=[ubicacion,str(fecha_de_inicio.date()),str(fecha_de_fin.date()),dias_ciclo_de_vida]
        
        
        if fecha_de_inicio<datetime.datetime(year=2019,month=6,day=1):
             falla_anterior_index=falla_siguiente_index# se elmininan los casos anteriores a junio del 2019 dado que no se tiene informacion de produccion de esa fecha
        else:
            ciclos_de_vida.append(data_ciclo_de_vida)
            # Se avanza en el ciclo while_true para eventualmente llegar al cierre
            falla_anterior_index=falla_siguiente_index

ciclos_de_vida=pd.DataFrame(ciclos_de_vida,columns=["Ubicacion","Fecha de Inicio","Fecha de Fin","Dias Funcional"])




"""Info_Rodillos"""

info_rodillos_values=info_rodillos.values
info_rodillos_header=info_rodillos.columns

"""
Se extrae lo relevante
Nombre_completo,ID,Diametro Eje,Diametro Rodillos, Largo Total
"""

info=info_rodillos_values[:,[0,3,4,5,6]]
info_header=info_rodillos_header[[0,3,4,5,6]]
"""Agregar a los ciclos de vida la info rodillos"""
def equal_string_anycase(string1,string2):
    return string1.lower()==string2.lower()
Data=[]
for i in range(len(ciclos_de_vida)):
    data_ciclo=ciclos_de_vida.values[i] # Extraer data del ciclo
    nombre_completo=data_ciclo[0] # Nombre utilizado para comparar con el nombre en info rodillos
    nombre_encontrado=False
    for j in range(len(info)):
        nombre_completo_info_rodillos=info[j][0]
        if equal_string_anycase(nombre_completo,nombre_completo_info_rodillos):
            nombre_encontrado=True
            
            Data.append(np.concatenate((info[j],[linea_de_pintura],data_ciclo[1:])))
            break
    if nombre_encontrado==False: print("No se encontro información acerca del rodillo")
ciclos_de_vida_header=np.concatenate((info_header,["Recurso"],ciclos_de_vida.columns[1:]))
ciclos_de_vida_info=pd.DataFrame(Data,columns=ciclos_de_vida_header) # Incluye el periodo de la falla y la información de los rodillos



"""
Información de produccion
Esta debe de ser trabajada, acá se realizan varios etl especiicos
"""



"Importar la data"

control_de_piso=pd.read_excel("Excel"+os.sep+control_de_piso_nombre,engine='openpyxl')
control_de_piso_header=control_de_piso.columns

# Ordenar por fecha
control_de_piso_ordenado=control_de_piso.sort_values(["Fecha de creación","Hora de creación"],ignore_index=True)
# extraigo lo de la linea de pintura
control_de_piso_lineapintado=control_de_piso_ordenado.query("Recurso=='LP700' or Recurso=='LP400' or Recurso=='LP700 BR'") 
control_de_piso_lineapintado_report=control_de_piso_lineapintado.query("Opciones=='REPORT'") # Reporte de desechos
control_de_piso_lineapintado_rollos_pintados=control_de_piso_lineapintado.query("Opciones=='ROLLOS PINTADOS'") # Reporte de pinitados

control_de_piso_lineapintado_pintado=control_de_piso_lineapintado.query("Opciones=='REPORT' or Opciones=='ROLLOS PINTADOS'") # desecho y pintado

control_de_piso_lineapintado_carga_flejes=control_de_piso_lineapintado.query("Opciones=='CARGA FLEJES'") # incluye la información del fleje
a=control_de_piso_lineapintado_carga_flejes.drop_duplicates(subset=["Id Producción (OP)"])

" Agregamos el material y dimensiones"

descripcion=control_de_piso_lineapintado_carga_flejes[["Id Producción (OP)","DESCRIPCIÓN"]].values

control_de_piso_lineapintado_pintado_val=control_de_piso_lineapintado_pintado.values
index_descripcion=10
for i in range(len(control_de_piso_lineapintado_pintado_val)):
    data_i=control_de_piso_lineapintado_pintado_val[i]
    op_i=data_i[0]
    for j in range(len(descripcion)):
        op_j=descripcion[j,0]
        if op_i==op_j:
            control_de_piso_lineapintado_pintado_val[i,index_descripcion]=descripcion[j,1]
            break
for i in range(len(control_de_piso_lineapintado_pintado_val)): # se eliminan los valores NAN por sin informacion
    if not(isinstance(control_de_piso_lineapintado_pintado_val[i,index_descripcion],str)):
        control_de_piso_lineapintado_pintado_val[i,index_descripcion]="S/I"
control_de_piso_lineapintado_pintado_df=pd.DataFrame(control_de_piso_lineapintado_pintado_val,columns=control_de_piso_header)
"""Data Acumulada"""
# indices que se mantienen, se guarda lo relevante de la producción
indices=["Id Producción (OP)","KILOS","METROS","DESECHO (KG)","KILOS TOTALES","METROS TOTALES","DESCRIPCIÓN","Recurso","Hora de creación","Fecha de creación"]
index_date=9
index_time=8
index_op=0
production_data_actual=control_de_piso_lineapintado_pintado_df[indices]

# se importa la data guardada antigua sobre la cual se agrega la nueva producción
if os.path.isfile("database"+os.sep+"production_data_acumulado.csv"): # si hay historia
    production_data_acumulado_antigua=pd.read_csv("database"+os.sep+"production_data_acumulado.csv")
    
    production_data_acumulado_antigua_val=production_data_acumulado_antigua.values
    production_data_actual_val=production_data_actual.values
    index=0
    faltan_datos=True # boolean que permite saber si hay interseccion en los datasets, si no hay interseccion no se puede saber si faltan datos
    row_old=production_data_acumulado_antigua_val[-1]
    for i in range(len(production_data_actual_val)):
        # Ocurre que el objeto datetime tiene la hora incluida seteada en 00:00:00, la funcion date() elimina la hora de la fecha, la cual se encuentra en otra columna
        production_data_actual_val[i,index_date]=production_data_actual_val[i,index_date].date()
    # Los     
    for row_new in production_data_actual_val:
        if row_old[index_op]==row_new[index_op] and row_old[index_time]==str(row_new[index_time]) and row_old[index_date]==str(row_new[index_date]):
            faltan_datos=False
            break
        index+=1
    if faltan_datos: print("No hay superposición entre los datos de produccion en la base de datos y los nuevos agregados")
    
    
    
    
    conc_val=np.concatenate((production_data_acumulado_antigua_val,production_data_actual_val[index+1:]),axis=0)
    production_data_completa=pd.DataFrame(conc_val,columns=indices)
    production_data_completa.to_csv("database"+os.sep+"production_data_acumulado.csv",index=False)
else: #No existe historia, se gurada lo que se subio
    production_data_completa=production_data_actual
    production_data_actual.to_csv("database"+os.sep+"production_data_acumulado.csv",index=False)

production_data_completa=pd.read_csv("database"+os.sep+"production_data_acumulado.csv")

"""
Generar el dataset completo para entrenamiento
--------------
Se utilizan:
    production_data_completa: Información de producción por OP
    ciclos_de_vida_info: Información de los rodillos y periodo entre mantenimientos
    materiales: lisa de los materiales de fleje conocidos ['AZ', 'ACCO', 'AL', 'GA', 'INOX']
"""
# materiales=['AZ', 'ACCO', 'AL', 'GA', 'INOX'] # se encuentra definido en la configuración al principio del documento


def convertir_descripcion_en_material_y_dimensiones(descripcion_str,materiales):

    material="S/I"
    for mat in materiales:
        if not(isinstance(descripcion_str, str)):break
        if mat in descripcion_str:
            material=mat
            break
    if material=="S/I" or descripcion_str.split(" ")[0]!="FLEJE":
        espesor=0
        desarrollo=0
        return material,desarrollo,espesor
    split=descripcion_str.split(" ")
    while("" in split) : 
        split.remove("") 
    espesorymaterial=split[1]
    desarrollo=float(split[3].replace(",","."))
    
    espesor=espesorymaterial[len(material):]
    espesor.replace(",",".")
    espesor=float(espesor)
    return material,desarrollo,espesor

def fecha_string_a_datetime(fecha_string):
        "Convierte una fecha en string a datetime"
        import datetime
        [y,m,d]=fecha_string.split("-")
        fecha_datetime=datetime.datetime(int(y),int(m),int(d))
        return fecha_datetime
def encontrar_indice_fecha(fecha_str,array_fechas_str):
    "esta funcion encuentra el punto donde se encuentra una fecha en un array de fechas en formato string"
    
    fecha=fecha_string_a_datetime(fecha_str)
    for i in range(len(array_fechas_str)):
        fecha_i=fecha_string_a_datetime(array_fechas_str[i])
        if fecha_i>fecha:
            
            break
    return i-1

production_data_completa_val=production_data_completa.values
production_data_completa_header=production_data_completa.columns
ciclos_de_vida_info_val=ciclos_de_vida_info.values
fechas_de_produccion=production_data_completa["Fecha de creación"].values # array con 

# Crear la linea de tiempo, extraer información de las ops entre inicio y fin de vida
data=[]
indices_kilos=[1,3,4]
indices_metros=[2,5]


        

for ciclo in ciclos_de_vida_info_val:
    fecha_de_inicio=ciclo[6] # extraigo la fecha de inicio
    fecha_de_fin=ciclo[7]
    dias_funcional=ciclo[8]
    linea_de_pintura=ciclo[5]
    Nombre_rodillo=ciclo[0]
    diametro_eje=ciclo[2]
    diametro_rodillo=ciclo[3]
    largo_rodillo=ciclo[4]
    Linea_de_pintura=ciclo[5]
    indice_inicio=encontrar_indice_fecha(fecha_de_inicio,fechas_de_produccion)+1 # se considera el dia que se reparó como que la produccion no se realizó con el rodillo
    indice_fin=encontrar_indice_fecha(fecha_de_fin,fechas_de_produccion) # se considera el dia que falló como que la produccion se realizó con el rodillo
    a=indice_fin-indice_inicio
    # Se repiten las corridas más cortas
    inicio=0
    for i in range(indice_inicio,indice_fin+1):
        data_de_producción_op=production_data_completa_val[i]
        descripcion=data_de_producción_op[6]
        material,desarrollo,espesor=convertir_descripcion_en_material_y_dimensiones(descripcion,materiales)
        kg_totales_op=sum(data_de_producción_op[indices_kilos])
        metros_totales_op=sum(data_de_producción_op[indices_metros])
        if inicio == 0:
            inicio=1
            kilos_acumulados=kg_totales_op
            metros_acumulados=metros_totales_op
            
        else:
            kilos_acumulados+=kg_totales_op # total producido desde la última producción en kilos
            metros_acumulados+=metros_totales_op # en metros
        data_op=[[Nombre_rodillo]
                 +[diametro_eje]
                 +[diametro_rodillo]
                 +[largo_rodillo]
                 +list(data_de_producción_op[indices_kilos])
                 +list(data_de_producción_op[indices_metros])
                 +[kg_totales_op]
                 +[metros_totales_op]
                 +[material]
                 +[desarrollo]
                 +[espesor]
                 +[kilos_acumulados]
                 +[metros_acumulados]][0]

        data.append(data_op)
        
# asdasd
        
data_header=[["Nombre Rodillo"]
             +["Diametro Eje"]
             +["Diametro Rodillo"]
             +["Largo Rodillo"]
             +list(production_data_completa_header[indices_kilos])
             +list(production_data_completa_header[indices_metros])
             +["Kilos Totales Op"]
             +["Metros Totales Op"]
             +["Material"]
             +["Desarrollo"]
             +["Espesor"]
             +["Kilos Acumulados Desde Reparación"]
             +["Metros Acumulados Desde Reparación"]][0]

data=np.array(data)
data_producción_ciclos_de_vida=pd.DataFrame(data=data,columns=data_header)

# Creación de las etiquetas, se avanza en reversa
a=np.zeros([len(data_producción_ciclos_de_vida),2])
inicio=True
for i in range(len(data_producción_ciclos_de_vida)):# se calcula la vida remananente
    i=len(data_producción_ciclos_de_vida)-i-1
    kilos_acumulados_i=float(data_producción_ciclos_de_vida["Kilos Acumulados Desde Reparación"][i])
    metros_acumulados_i=float(data_producción_ciclos_de_vida["Metros Acumulados Desde Reparación"][i])
    kg_totales_op=float(data_producción_ciclos_de_vida["Kilos Totales Op"][i])
    metros_totales_op=float(data_producción_ciclos_de_vida["Metros Totales Op"][i])
    if inicio:
        kg_restantes=kg_totales_op
        metros_restantes=metros_totales_op
        inicio=False
    elif kilos_acumulados_i>float(data_producción_ciclos_de_vida["Kilos Acumulados Desde Reparación"][i+1]) or metros_acumulados_i>float(data_producción_ciclos_de_vida["Metros Acumulados Desde Reparación"][i+1]):
        kg_restantes=kg_totales_op
        metros_restantes=metros_totales_op
    else:
        kg_restantes=kg_restantes+kg_totales_op
        metros_restantes=metros_restantes+metros_totales_op
    a[i,0]=kg_restantes
    a[i,1]=metros_restantes

data_producción_remanente_ciclos_de_vida=pd.DataFrame(data=a,columns=["Metros Remanentes","Kilos Remanentes"])



#Se guarda la data de entrada en la carpeta entradas

data_producción_remanente_ciclos_de_vida.to_csv("entradas"+os.sep+"data_produccion_remanente_ciclos_de_vida.csv",index=False)
data_producción_ciclos_de_vida.to_csv("entradas"+os.sep+"data_produccion_ciclos_de_vida.csv",index=False)



from matplotlib import pyplot as plt
plt.plot(data_producción_remanente_ciclos_de_vida.values[:,0])












