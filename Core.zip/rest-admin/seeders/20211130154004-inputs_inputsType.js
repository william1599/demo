'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert('entrada_tipoentradas', [{
      tipoEntradaIdtipoentrada: '1',
      entradaIdentrada: '2',
      updatedAt: new Date(),
      createdAt: new Date()
    }, {
      tipoEntradaIdtipoentrada: '2',
      entradaIdentrada: '2',
      updatedAt: new Date(),
      createdAt: new Date()
    }, {
      tipoEntradaIdtipoentrada: '3',
      entradaIdentrada: '2',
      updatedAt: new Date(),
      createdAt: new Date()
    }, {
      tipoEntradaIdtipoentrada: '4',
      entradaIdentrada: '2',
      updatedAt: new Date(),
      createdAt: new Date()
    }, {
      tipoEntradaIdtipoentrada: '1',
      entradaIdentrada: '3',
      updatedAt: new Date(),
      createdAt: new Date()
    }, {
      tipoEntradaIdtipoentrada: '3',
      entradaIdentrada: '3',
      updatedAt: new Date(),
      createdAt: new Date()
    }, {
      tipoEntradaIdtipoentrada: '4',
      entradaIdentrada: '3',
      updatedAt: new Date(),
      createdAt: new Date()
    }, {
      tipoEntradaIdtipoentrada: '3',
      entradaIdentrada: '4',
      updatedAt: new Date(),
      createdAt: new Date()
    }, {
      tipoEntradaIdtipoentrada: '3',
      entradaIdentrada: '5',
      updatedAt: new Date(),
      createdAt: new Date()
    }, {
      tipoEntradaIdtipoentrada: '4',
      entradaIdentrada: '5',
      updatedAt: new Date(),
      createdAt: new Date()
    }, {
      tipoEntradaIdtipoentrada: '3',
      entradaIdentrada: '6',
      updatedAt: new Date(),
      createdAt: new Date()
    }, {
      tipoEntradaIdtipoentrada: '4',
      entradaIdentrada: '6',
      updatedAt: new Date(),
      createdAt: new Date()
    }])
    /*
      Add altering commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkInsert('People', [{
        name: 'John Doe',
        isBetaMember: false
      }], {});
    */
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('entrada_tipoentradas', null, {})
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkDelete('People', null, {});
    */
  }
};
