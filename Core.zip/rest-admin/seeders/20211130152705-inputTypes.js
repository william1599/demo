'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert('tipo_entradas', [{
      nombre: 'Selector',
      tipo: 'select',
      createdAt: new Date(),
      updatedAt: new Date()
    }, {
      nombre: 'Rango (Slider)',
      tipo: 'range',
      createdAt: new Date(),
      updatedAt: new Date()
    }, {
      nombre: 'Número',
      tipo: 'number',
      createdAt: new Date(),
      updatedAt: new Date()
    }, {
      nombre: 'Texto',
      tipo: 'text',
      createdAt: new Date(),
      updatedAt: new Date()
    }])
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('tipo_entradas', null, {})
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkDelete('People', null, {});
    */
  }
};
