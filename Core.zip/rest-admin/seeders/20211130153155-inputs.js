'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert('entradas', [{
      nombre: 'Nombre de la variable',
      controlType: 'textbox',
      tipo: 'text',
      valor: 'Temperatura',
      clave: 'label',
      createdAt: new Date(),
      updatedAt: new Date()
    }, {
      nombre: 'Ingrese valor mínimo',
      controlType: 'textbox',
      tipo: 'number',
      valor: '0',
      clave: 'min',
      createdAt: new Date(),
      updatedAt: new Date()
    }, {
      nombre: 'Ingrese valor máximo',
      controlType: 'textbox',
      tipo: 'number',
      valor: '1',
      clave: 'max',
      createdAt: new Date(),
      updatedAt: new Date()
    }])

  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('entradas', null, {})
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkDelete('People', null, {});
    */
  }
};
