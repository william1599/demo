# rest-trainmanager
microservicio encargado de ofrecer los servicios relacionados a tareas de entrenamiento

# Instalar dependencias
npm install

# Configurar datos de conexion

1. Abrir el archivo server/config/server.config.js
2. Definir los datos de conexion a postgres

# Correr localmente para desarrollo
./start_develop.sh

## Levantar instancia de postgresql en docker

1. docker pull postgres:12.4-alpine
2. correr script en server/scripts/launch_postgresql.sh


# Correr en modo producción

1. Crear un archivo en carpeta system

`sudo vim /lib/systemd/system/trainmanager.service`

2. Añadir el siguiente contenido
```
[Unit]
Description=rest-trainmanager/server.js - Servicio REST para el manejo de base de datos
Documentation=https://example.com
After=network.target

[Service]
Environment=NODE_ENV=production
Environment=PORT=3012
Environment=FILES_DEST=/home/manuel/colecciones
Environment=DB_USERNAME=nnmanager
Environment=DB_PASSWORD=rwe56ArZ135651ae
Environment=DB_NAME=nnmanager
Environment=DB_HOSTNAME=localhost
Type=simple
User=manuel
ExecStart=/usr/bin/node /home/manuel/rest-trainmanager/server.js
Restart=on-failure

[Install]
WantedBy=multi-user.target
```
3. Luego reiniciar el servicio systemcl `sudo systemctl daemon-reload`
4. Lanzar el servicio `sudo systemctl start trainmanager`




# Contenido del archivo para ambiente de desarrollo en el servidor
1. Crear un archivo en carpeta system

`sudo vim /lib/systemd/system/dev-trainmanager.service`

2. Añadir el siguiente contenido
```
[Unit]
Description=rest-trainmanager/server.js - Servicio REST para el manejo de base de datos
Documentation=https://example.com
After=network.target

[Service]
Environment=NODE_ENV=development_server
Environment=PORT=3112
Environment=FILES_DEST=/home/manuel/desarrollo/colecciones
Environment=DB_USERNAME=nnmanager
Environment=DB_PASSWORD=rwe56ArZ135651ae
Environment=DB_NAME=nnmanager_desarrollo
Environment=DB_HOSTNAME=localhost
Type=simple
User=manuel
ExecStart=/usr/bin/node /home/manuel/desarrollo/rest-trainmanager/server.js
Restart=on-failure

[Install]
WantedBy=multi-user.target
```
3. Luego reiniciar el servicio systemcl `sudo systemctl daemon-reload`
4. Lanzar el servicio `sudo systemctl start dev-trainmanager`

