'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addColumn(
        'modelos',
        'comentario_habilitado',
        Sequelize.BOOLEAN
    )
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeColumn(
        'modelos',
        'comentario_habilitado'
    )
  }
};
