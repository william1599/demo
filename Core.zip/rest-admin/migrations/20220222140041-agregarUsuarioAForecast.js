'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
  return queryInterface.addColumn(
      'forecasts',
      'userName',
      Sequelize.STRING
  )
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeColumn(
        'forecasts',
        'userName'
    )
  }
};
