'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addColumn(
      'parametros_prediccions',
      'column',
      Sequelize.STRING 
    )
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeColumn(
      'parametros_prediccions',
      'column'
    )
  }
};
