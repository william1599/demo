'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.changeColumn('datos_coleccions', 'min', {
      type: Sequelize.FLOAT
    })
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.changeColumn('datos_coleccions', 'min', {
      type: Sequelize.INTEGER
    })
  }
};
