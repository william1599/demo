'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addColumn(
        'forecast_configs',
        'comentario',
        Sequelize.TEXT
    )
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.removeColumn(
        'forecast_configs',
        'comentario'
    )
  }
};
