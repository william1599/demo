const { CustomError } = require('../errors/custom-error');
const models = require('../models/index.model');

class EmpresaController {

    // Entrada: Body de la empresa con propiedades
    // Función: Crear una empresa en la base de datos segun el body de la consulta
    // Salida: Objeto con status, mensaje y el dato
    static async creaEmpresa(empresa){
        //inserta en la base de datos
        

        let status;
        
        try {
          status = await models.Empresa.create(empresa);
        } catch(err) {
          throw new CustomError(err.message);
        }

        if(status) {
          return {
            status,
            message: 'Empresa creada correctamente',
            dato: status.dataValues
          }
        } else {
          return {
            status,
            message: `Empresa con nombre '${empresa.nombre}' ya existe`,
            dato: null
          }
        }
    }

    // Entrada: id de la empresa y el body con las propiedades
    // Función: Editar la empresa segun las propiedades ingresadas
    // Salida: Objeto con status, mensaje y el dato
    static async editarEmpresa(idEmpresa, empresaAEditar) {
      
      let actualizado;

      try {
        const empresaEnDB = await models.Empresa.findOne({
          where: { idempresa: idEmpresa}
        });
        for(const propiedad in empresaAEditar) {
          empresaEnDB[propiedad] = empresaAEditar[propiedad];
        }
  
        actualizado = await empresaEnDB.save();
      } catch(err) {
        throw new CustomError(err.message);
      }


      if (actualizado) {
        return {
        status: actualizado,
        message: `Empresa actualizada correctamente`,
        dato:actualizado.dataValues
        }
    } else {
        return {
        status: actualizado,
        message: `Empresa con id '${empresa.idempresa}' no se actualizó`,
        dato: null
        }
      }
    }

    //Obtiene lista de empresas
    static async getEmpresas(limit = 10, offset = 0, orderBy, descending){
        //consulta en la base de datos
        let desc;
        descending == 'true' ? desc = 'DESC' : desc = 'ASC'
        const datos = await models.Empresa.findAll({
          limit: limit,
          offset: offset,
          order: [[orderBy, desc]]
        })
        return {
          status:true,
          message: `Modelos recuperado correctamente`,
          datos: datos
          };
    }

    // Entrada: limite, offset, orderBy, descending, enabledService
    // Función: Obtener las empresas habilitadas y ordenar segun parametro
    // Salida: Objeto con status, mensaje y los datos
    static async getEmpresasHabilitadas(limit = 10, offset = 0, orderBy, descending, enabledService = null){
      //consulta en la base de datos
      let desc, datos;
      descending == 'true' ? desc = 'DESC' : desc = 'ASC';

      try {
        datos = await models.Empresa.findAll({
          limit: limit,
          offset: offset,
          order: [[orderBy, desc]],
          where: {
            habilitado: true,
          },
          include: [ {
            association: 'servicios',
            ... (enabledService && { where: { habilitado: enabledService } })
          } ]
        })
        return {
          status:true,
          message: `Modelos recuperado correctamente`,
          datos: datos
        };
      } catch(err) {
        throw new CustomError(err.message);
      }
    }

    // Entrada: Id de la empresa
    // Función: Obtiene la empresa de la base de datos segun la id entregada
    // Salida: Objeto con status, mensaje y el dato
    static async getEmpresa(idempresa){  
        let dato;
        
        try {
          dato = await models.Empresa.findOne({
            where:{
              idempresa:idempresa
            }
          });
          return {
            status:true,
            message: `Empresa recuperada correctamente`,
            dato:dato
          };
        } catch(err) {
          throw new CustomError(err.message);
        }
    }

    // Entrada: Id de la empresa
    // Función: Cambiar el esatdo de la empresa a habilitado o deshabilitado
    // Salida: Objeto con status, mensaje y el dato
    static async cambiarEstadoEmpresa(idempresa) {

      let empresaEnDB, actualizado;
      try {
        empresaEnDB = await models.Empresa.findOne({
          where: { idempresa: idempresa }
        });

        empresaEnDB['habilitado'] ? empresaEnDB['habilitado'] = false : empresaEnDB['habilitado'] = true
        actualizado = await empresaEnDB.save();
      } catch(err) {
        throw new CustomError(err.message);
      }

      if(actualizado) {
        return {
          status: actualizado,
          message: 'Empresa actualizada correctamente',
          dato: actualizado.dataValues
        }
      } else {
        return {
          status: actualizado,
          message: `Empresa con id '${idempresa}' no se actualizó`,
          dato: null
        }
      }

    }

    
}

module.exports = EmpresaController;