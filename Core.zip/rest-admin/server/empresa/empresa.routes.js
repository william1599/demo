const { response } = require("express");
const e = require("express");
const express = require("express");
const auth = require('../authentication/authenticateJWT.middleware');
// Controllers
const _empresaController = require('./empresa.controller');
const _util = require('../util/util')

const router = express.Router();

router.use((req, res, next) => {
  // Disponible para implementar MDW
  next();
});

// Ruta POST /empresa
// Funcion: Crear una empresa en la base de datos según propiedades ingresadas
router.post('/', async (req, res, next) => {
  const body = req.body;

  nueva = {
    nombre: body.nombre,
    descripcion: body.descripcion,
    habilitado: body.habilitado
  }

  error = _util.postValidator(nueva)

  if(error){
      res.status(400).json({
          ok: false,
          status: 400,
          error: null,
          message: `no se paso el atributo '${error}'`,
          dato: null
      });
  }
  else{
    let resp;

    try {
      resp = await _empresaController.creaEmpresa(nueva);    
    } catch(err) {
      return next(err);
    }

    if (resp.status) {
      res.status(200).json({
          ok: true,
          status: 200,
          message: resp.message,
          error: null,
          dato: resp.dato
      });
    } else {
      res.status(400).json({
          ok: false,
          status: 400,
          error: null,
          message: resp.message,
          dato: null
      });
    } 
  }
});

// Ruta PUT /empresa/<idempresa>
// Funcion: Editar una empresa segun la id y el body de la consulta
router.put('/:idempresa', async (req, res, next) => {

  const queryParams = req.params;
  const body = req.body;
  
  

  const bodyFinal = {}
  for(const key in body) {
    bodyFinal[key] = body[key];
  }

  let resp;

  try {
    resp = await _empresaController.editarEmpresa(queryParams.idempresa, bodyFinal);
  } catch(err) {
    return next(err);
  }

  if(resp.status) {
    res.status(200).json({
      ok: true,
      status: 200,
      message: resp.message,
      error: null,
      dato: resp.dato
    })
  } else {
    res.status(400).json({
      ok: false,
      status: 400,
      error: null,
      message: resp.message,
      dato: null
    })
  }
})

// Ruta GET /empresa
// Funcion: Obtener empresas de la BD segun los parametros ingresados
router.get('/', async (req, res, next) => {  

  const { limit, offset, param, descending } = req.query;
  let promesa;

  try {
    promesa = await _empresaController.getEmpresas(
      limit,
      offset,
      param,
      descending);
  } catch(err) {
    return next(err);
  }
  
  if (promesa.status){
      const resp = {
          ok: true,
          status: 200,
          message: promesa.message,
          error: null,
          datos: promesa.datos
      }
      res.status(200).json(resp);
  }   
});

// Ruta GET /empresa/habilitadas
// Funcion: Obtener las empresas que  se encuentran habilitadas
router.get('/habilitadas', async (req, res, next) => {  
  var { limit, offset, param, descending, enabledService } = req.query
  let promesa;

  const paramMissing = _util.queryParamMissing(req.query, ['param', 'descending']);

  if(paramMissing) {
    return next({ message: _util.noParamErrorMessage(paramMissing), statusCode: 400 });
  }

  try {
    promesa = await _empresaController.getEmpresasHabilitadas(
      limit,
      offset,
      param,
      descending,
      enabledService);
  } catch(err) {
    return next(err);
  }

  if (promesa.status){
      const resp = {
          ok: true,
          status: 200,
          message: promesa.message,
          error: null,
          datos: promesa.datos
      }
      res.status(200).json(resp);
  } else {
    const resp = {
      ok: false,
      status: 400,
      message: promesa.message,
      error: null,
      datos: promesa.datos
    }
    res.status(400).json(resp)
  }
});



// Ruta GET /empresa/<idempresa>
// Funcion: Obtener la empresa segun su id
router.get('/:idempresa', async (req, res, next) => {
  const { idempresa } = req.params;
  let promess;

  try {
    promess = await _empresaController.getEmpresa(idempresa);
  } catch(err) {
    return next(err);
  } 
  
  if (promess.status) {
      const resp = {
          ok: true,
          status: 200,
          message: promess.message,
          error: null,
          dato: promess.dato
      }
      res.status(200).json(resp);
  } else {
      const resp = {
          ok: false,
          status: 400,
          error: null,
          message: promess.message,
          estado: null
      };
      res.status(400).json(resp);
  }
});

// Ruta PUT /estado/<idempresa>
// Funcion: Cambiar estado de la empresa a habilitado o deshabilitado
router.put('/estado/:idempresa', async(req, res, next) => {
  
  
  const { idempresa } = req.params;
  let resp;

  try {
    resp = await _empresaController.cambiarEstadoEmpresa(idempresa);
  } catch(err) {
    return next(err);
  }

  if(resp.status) {
    res.status(200).json({
      ok: true,
      status: 200,
      message: resp.message,
      error: null,
      dato: resp.dato
    })
  } else {
    res.status(400).json({
      ok: false,
      status: 400,
      error: null,
      message: resp.message,
      dato: null
    })
  }
});



module.exports = router;
