module.exports = (sequelize, DataTypes) => {
    
    var Empresa = sequelize.define('empresa', {
      idempresa: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey : true,
        autoIncrement: true
      },
      nombre: DataTypes.STRING,
      descripcion:DataTypes.STRING,
      habilitado: {
        type: DataTypes.BOOLEAN,
        allowNull: true
      }      
    });  
    Empresa.associate = function(models) {
      Empresa.hasMany(models.Usuario, {as: 'usuarios'})
    };
    Empresa.associate = function(models) {
      Empresa.hasMany(models.Servicio, {as: 'servicios', foreignKey: 'idempresa'})
    };
    return Empresa;
  };