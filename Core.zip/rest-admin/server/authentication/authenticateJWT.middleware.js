const jwt = require('jsonwebtoken');


//definir como variable de entorno
const privateKey = "84985#$%sdfjnsdfyu89234D";
const authenticateJWT = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (authHeader) {
        const token = authHeader.split(' ')[1];

        jwt.verify(token, privateKey, (err, user) => {
            if (err) {
                
                return res.sendStatus(403);
            }

            req.user = user;
            //
            next();
        });
    } else {
        res.sendStatus(401);
    }
};

const checkRoles = (roles = []) => {
    if (typeof roles === 'string') {
        roles = [roles];
    }
    
    return function(req, res, next) {
        
        if (roles.length && !roles.includes(req.user.rol)) {
            // user's role is not authorized
            return res.status(401).json({ status:false, message: 'Unauthorized' });
        }
        // authentication and authorization successful
        next();
    }
}
module.exports = {authenticateJWT,checkRoles, privateKey};
