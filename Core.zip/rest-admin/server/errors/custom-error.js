//import { DomainError } from './domain-error';
const DomainError = require('./domain-error')

class CustomError extends DomainError {

    constructor(message) {
        super(message);

        this.message = message;
        this.statusCode = 500;
    }
}

module.exports = { CustomError }
