//import { DomainError } from './domain-error';
const DomainError = require('./domain-error')

class ResourceNotFoundError extends DomainError {

    constructor() {
        super();

        this.message = 'No existe';
        this.statusCode = 404;
    }
}

module.exports = { ResourceNotFoundError }
