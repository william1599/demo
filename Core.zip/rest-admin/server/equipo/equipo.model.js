module.exports = (sequelize, DataTypes) => {

    var Equipo = sequelize.define('equipo', {
        idequipo: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        nombre: DataTypes.STRING,
        descripcion: DataTypes.STRING,
        tipo: DataTypes.STRING,
        idpropio: DataTypes.STRING,
        habilitado: {
            type: DataTypes.BOOLEAN,
            allowNull: true
        },
        parametros: DataTypes.JSONB
    });

    return Equipo;
}