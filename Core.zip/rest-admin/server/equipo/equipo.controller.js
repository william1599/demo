const models = require('../models/index.model');
const XLSX = require("xlsx");
const { CustomError } = require('../errors/custom-error');

class EquipoController {

    // Entrada: Body del equipo en la consulta
    // Función: Crea un equipo en la base de datos
    // Salida: Objeto con estado y mensaje
    static async crea(nuevo) {
        let status;

        try {
            status = await models.Equipo.create({
                nombre: nuevo.nombre,
                tipo: nuevo.tipo,
                descripcion: nuevo.descripcion,
                habilitado: true,
                idlineaproduccion: nuevo.idlineaproduccion,
                idpropio: nuevo.idpropio,
                parametros: nuevo.parametros
            });
        } catch(err) {
            throw new CustomError(err.message);
        }

        if(status) {
            return {
                status,
                message: 'Equipo creado correctamente'
            }
        } else {
            return {
                status, 
                message: `Equipo con nombre '${nuevo.nombre} no pudo ser creado'`,
                dato: null
            }
        }
    }

    // Entrada: Limit, offset, parametro orderBy y descending
    // Función: Obtiene todos los equipos segun los parametros ingresados
    // Salida: Objeto con estado, mensaje y datos
    static async getAll(limit = 100, offset = 0, orderBy, descending) {

        let desc, datos;
        descending == 'true' ? desc = 'DESC' : desc = 'ASC';

        try {
            datos = await models.Equipo.findAll({
                limit: limit,
                offset: offset,
                order: [[orderBy, desc]],
                include: [{ 
                    association: 'lineaproduccion',
                    attributes: ['nombre'],
                    include: [{
                        association: 'empresa',
                        attributes: ['nombre']
                    }]
                 }]
                
            });
        } catch(err) {
            throw new CustomError(err.message);
        }

        if(datos) {
            return {
                status: true,
                message: `Equipos recuperados correctamente`,
                datos: datos
            }
        } else {
            return {
                status: false,
                message: `No se pudo recuperar lista de equipos`,
                datos: null
            }
        }
    }

    // Entrada: parametro orderBy, descending e la id de la linea de produccion
    // Función: Obtiene todos los equipos segun linea de produccion
    // Salida: Objeto con estado, mensaje y datos
    static async getAllByLineaProduccion(orderBy, descending, idlineaproduccion) {
        let desc, datos;
        descending == 'true' ? desc = 'DESC' : desc = 'ASC';

        try {
            datos = await models.Equipo.findAll({
                order: [[orderBy, desc]],
                include: [{
                    association: 'lineaproduccion',
                    //attributes: ['nombre']
                }],
                where: {
                    idlineaproduccion: idlineaproduccion
                }
            });
        } catch(err) {
            throw new CustomError(err.message);
        }

        if(datos) {
            return {
                status: true,
                message: `Equipos recuperados correctamente`,
                datos: datos
            }
        } else {
            return {
                status: false,
                message: `No se pudo recuperar lista de equipos`,
                datos: null
            }
        }
    }

    // Entrada: parametro orderBy, descending e la id de la empresa
    // Función: Obtiene todos los equipos segun la id de la empresa
    // Salida: Objeto con estado, mensaje y datos
    static async getAllByEmpresa(orderBy, descending, idempresa) {
        let desc, datos;
        descending == 'true' ? desc = 'DESC' : desc = 'ASC';

        try {
            datos = await models.Equipo.findAll({
                order: [[orderBy, desc]],
                include: [{
                    association: 'lineaproduccion',
                    attributes: ['nombre'],
                    where: {
                        idempresa
                    }
                }],
            });
        } catch(err) {
            throw new CustomError(err.message);
        }

        if(datos) {
            return {
                status: true,
                message: `Equipos recuperados correctamente`,
                datos: datos
            }
        } else {
            return {
                status: false,
                message: `No se pudo recuperar lista de equipos`,
                datos: null
            }
        }
    }

    // Entrada: Id de lequipo y los datos de los parametros
    // Función: Edita la columna parametros del equipo
    // Salida: Objeto con estado, mensaje y el dato
    static async editarParametros(idequipo, datos) {

        let actualizado;

        try {
            const equipo = await models.Equipo.findOne({
                where: { idequipo }
            });

            equipo['parametros'] = datos;
            actualizado = await equipo.save();
        } catch(err) {
            throw new CustomError(err.message);
        }
        
        if (actualizado) {
            return {
            status: actualizado,
            message: `Equipo actualizado correctamente`,
            dato:actualizado.dataValues
            }
        } else {
            return {
            status: actualizado,
            message: `Equipo con id '${idequipo}' no se actualizó`,
            dato: null
            }
        }

    }

    // Entrada: Id de lequipo y los datos del equipo 
    // Función: Edita las propiedades de la equipo segun los datos entregados
    // Salida: Objeto con estado, mensaje y el dato
    static async editarEquipo(idequipo, datos) {
        
        let actualizado;
        try {
            const equipo = await models.Equipo.findOne({
                where: { idequipo }
            })
    
            for (const propiedad in datos) {
                equipo[propiedad] = datos[propiedad];
            }
    
            actualizado = await equipo.save();
        } catch(err) {
            throw new CustomError(err.message);
        }
        
        if (actualizado) {
            return {
            status: actualizado,
            message: `Equipo actualizado correctamente`,
            dato:actualizado.dataValues
            }
        } else {
            return {
            status: actualizado,
            message: `Equipo con id '${idequipo}' no se actualizó`,
            dato: null
            }
        }

    }

    // Entrada: Id de lequipo 
    // Función: Cambiar estado habilitado o deshabilitado segun corresponda
    // Salida: Objeto con estado, mensaje y el dato
    static async cambiarEstadoEquipo(idequipo) {

        let actualizado;
        try {
            const equipo = await models.Equipo.findOne({
                where: { idequipo }
            });

            equipo['habilitado'] ? equipo['habilitado'] = false : equipo['habilitado'] = true
            actualizado = await equipo.save();
        } catch(err) {
            throw new CustomError(err.message);
        }

        if(actualizado) {
            return {
                status: actualizado,
                message: 'Equipo actualizado correctamente',
                dato: actualizado.dataValues
            }
        } else {
            return {
                status: actualizado,
                message: 'Equipo no actualizado',
                dato: null
            }
        }        
    }

    // Entrada: Archivo, tipo y linea de produccion
    // Función: Crear un equipo en la BD 
    // Salida: Objeto con estado, mensaje y los datos
    static async validarExcel(file, tipo, idlineaproduccion){

        let workbook = XLSX.readFile(file.path);   
        var sheet_name_list = workbook.SheetNames;
        
        var xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list]);   
        //si es un arreglo, no importa el nombre de la hoja
        //solo importan las cabeceras en el orden de la hoja      
        
        
        let promesa = null;
        
        
        for(let data of xlData) {
            //
            //
            let equipo = {
                nombre: data[Object.keys(data)[0]],
                tipo: 'Rodillo',
                descripcion: 'Soy un bonito rodillo',
                idlineaproduccion: idlineaproduccion,
                idpropio: data[Object.keys(data)[3]],
                parametros: data
            }
            try {
                promesa = await this.crea(equipo)
            } catch(e) {
                
            }
        }

        if(promesa) {
            
            return {
                status: true,
                message: 'Equipos creados correctamente',
                datos: xlData
            }
        } else {
            
            return {
                status: false,
                message: 'Error al crear equipos',
                datos: null
            }
        }
        
        //

      }



}

module.exports = EquipoController;