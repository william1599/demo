const express = require("express");
const auth = require('../authentication/authenticateJWT.middleware');
var multer  = require('multer');
// Controllers
const _equipoController = require('./equipo.controller');
const _util = require('../util/util');
const fs = require('fs');

const env = process.env.NODE_ENV || 'development';
const environmentsConfig = require('../config/environments.config')[env];

const allowedTypes = [
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-excel.sheet.binary.macroEnabled.12",
    //"application/vnd.ms-excel",//csv
    "application/vnd.ms-excel.sheet.macroEnabled.12",
    //"text/csv"
]

const router = express.Router();

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, environmentsConfig.FILES_DEST);
    },
    filename: function (req, file, cb) {
      //
      
      let extension = file.originalname.split(".")
      extension = extension[extension.length-1]
      //
      //
      cb(null, Date.now().toString()+"."+extension)
    }
});

var upload = multer({ storage: storage })

// Ruta POST /equipo
// Funcion: Crea un equipo en la BD
router.post('/', async (req, res, next) => {
    const body = req.body;
    
    nueva = {
        nombre: body.nombreQm,
        tipo: body.tipoQm,
        descripcion: body.descripcionQm,
        idlineaproduccion: body.idlineaproduccion,
        parametros: body.parameters,
    }
    
    error = _util.postValidator(nueva)
    if(error) {
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: `No se paso el atributo '${error}'`,
            dato: nueva
        })
    } else {
        let resp;

        try {
            resp = await _equipoController.crea(nueva);
        } catch(err) {
            return next(err);
        }

        if(resp.status) {
            res.status(201).json({
                ok: true,
                status: 201,
                message: resp.message,
                error: null,
                dato: resp.dato
            })
        } else {
            res.status(400).json({
                ok: false,
                status: 400,
                error: null,
                message: resp.message,
                dato: null
            })
        }
    }

})

// Ruta GET /equipo
// Funcion: Obtiene todos los equipos de la BD
router.get('/', async (req, res, next) => {
    
    const queryParams = req.query;

    let promesa = null;
    let error = null;

    if(queryParams.idlineaproduccion) {
        try {
            promesa = await _equipoController.getAllByLineaProduccion(
                queryParams.param,
                queryParams.descending,
                queryParams.idlineaproduccion
            )
        } catch(e) {
            return next(e);
        }
    } else if(queryParams.idempresa) {
        
        try {
            promesa = await _equipoController.getAllByEmpresa(
                queryParams.param,
                queryParams.descending,
                queryParams.idempresa
            )
        } catch(e) {
            return next(e);
        }
    } 
    else {
        try {
            promesa = await _equipoController.getAll(
                queryParams.limit,
                queryParams.offset,
                queryParams.param,
                queryParams.descending
            )
    
        } catch(e) {
            return next(e);
        }
    }
    if(promesa && promesa.status) {
        const resp = {
            ok: true,
            status: 200,
            message: promesa.message,
            error: null,
            datos: promesa.datos
        }
        res.status(200).json(resp)
    } else {
        const resp = {
            ok: false,
            status: 500,
            message: (promesa && promesa.message) ? promesa.message: "Ocurrió un error inesperado",
            error: error,
            datos: null
        }
        res.status(500).json(resp)
    }
})

// Ruta PUT /equipo/parametros/<idequipo>
// Funcion: Edita parametros de un equipo
router.put('/parametros/:idequipo', async (req, res, next) => {
    
    const queryParams = req.params;
    const body = req.body;
    let promess;

    try {
        promess = await _equipoController.editarParametros(queryParams.idequipo, body)
    } catch(err) {
        return next(err);
    }

    if (promess.status) {
        const resp = {
            ok: true,
            status: 200,
            message: promess.message,
            error: null,
            dato: promess.dato
        }
        res.status(200).json(resp);
    } else {
        const resp = {
            ok: false,
            status: 400,
            error: null,
            message: promess.message,
            dato: null
        };
        res.status(400).json(resp);
    }
})

// Ruta PUT /equipo/estado/<idequipo>
// Funcion: Cambia el estado del equipo
router.put('/estado/:idequipo', async(req, res, next) => {
    const queryParams = req.params;
    let resp;

    try {
        resp = await _equipoController.cambiarEstadoEquipo(queryParams.idequipo);
    } catch(err) {
        return next(err);
    }

    if(resp.status) {
        res.status(200).json({
            ok: true,
            status: 200,
            message: resp.message,
            error: null,
            dato: resp.dato
        })
    } else {
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: resp.message,
            dato: null
        })
    }
})

// Ruta PUT /equipo/<idequipo>
// Funcion: Edita el equipo segun llas propiedades del body
router.put('/:idequipo', async(req, res, next) => {
    const queryParams = req.params;
    const body = req.body;
    let resp;

    try {
        resp = await _equipoController.editarEquipo(queryParams.idequipo, body);
    } catch(err) {
        return next(err);
    }

    if(resp.status) {
        res.status(200).json({
            ok: true,
            status: 200,
            message: resp.message,
            error: null,
            dato: resp.dato
        })
    } else {
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: resp.message,
            dato: null 
        })
    }
})

// Ruta POST /equipo/subirArchivo
// Funcion: Crea un equipo con su archivo
router.post('/subirArchivo', upload.single("archivo"), async (req, res, next) => {
    
    const body = req.body;
    const file = req.file;
    //
    
    let promesa = null;
    let error = null;
    //if(!file.mimetype in allowedTypes){    
    if(!allowedTypes.includes(file.mimetype)){
        let m = `Tipo de archivo no soportado`;
        try {
            fs.unlinkSync(file.path);
            //file removed
        } catch(err) {
            console.error(err)
            m += `\n Error al eliminar el archivo '${file.path}' \n ${err}`
        }        
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: m,
            dato: null
        });
    } else {
        

        try {
            
            promesa = await _equipoController.validarExcel(file, body.tipo, body.idlineaproduccion);
        } catch(e) {
            return next(e);
        }
        
        if(promesa.status) {
            const resp = {
                ok: true,
                status: 201,
                message: promesa.message,
                error: null,
                datos: promesa.datos
            }

            res.status(201).json(resp);
        } else {
            const resp = {
                ok: false,
                status: 500,
                message: 'Ocurrio un error inesperado',
                error: error,
                datos: null
            }
            res.status(500).json(resp);
        }
    }
});

module.exports = router;
