// ruta de appmanager (aún no la uso)
//module.exports.URL_APPMANAGER = 'http://localhost:3014/api/v1/';


module.exports = {
    development: {
        username: 'nnmanager',
        password: 'rwe56ArZ135651ae',
        database: 'nnmanager',
        host: 'database'  
    }, 
    test: {
        username: process.env.DB_USER || 'nnmanager',
        password: process.env.DB_PASSWORD || 'rwe56ArZ135651ae',
        database: process.env.DB_NAME || 'nnmanager',
        host: process.env.DB_HOST || 'database' 
    }
}


// module.exports.SEQUELIZE_CONF = {

//     /* DataBase Name */
//     /*username: 'postgres',
//     password: 'postgres',
//     database: 'qr_experience',
//     host: '172.17.0.1'*/

//     /*  Local  */
//     username: 'nnmanager',
//     password: 'rwe56ArZ135651ae',
//     database: 'nnmanager',
//     host: 'localhost'  

// };