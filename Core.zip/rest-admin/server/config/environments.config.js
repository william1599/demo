
const SequelizeConf = require('./server.config').development;
const testSequelizeConf = require('./server.config').test;

module.exports = {
  development: {
    db: {
      username: testSequelizeConf.username,
      password: testSequelizeConf.password,
      database: testSequelizeConf.database,
      host: testSequelizeConf.host,
      dialect: "postgres",
      port: 5432
    },
    port:3119,
    FILES_DEST : '/app'
  },
  development_server: {
    db: {
      username: process.env.DB_USERNAME,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      host: process.env.DB_HOSTNAME,
      dialect: "postgres",
    },
    port:process.env.PORT,
    FILES_DEST :  process.env.FILES_DEST,
  },
  notebook:{
    db: {
      username: SequelizeConf.username,
      password: SequelizeConf.password,
      database: SequelizeConf.database,
      host: SequelizeConf.host,
      dialect: "postgres",
    },
    port:3112,
    FILES_DEST : '/home/pc1/Documentos/colecciones'
  },
  test: {
    dialect: "postgres"
  },
  production: {
    db: {
      username: process.env.DB_USERNAME,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      host: process.env.DB_HOSTNAME,
      dialect: 'postgres',      
      use_env_variable: 'DATABASE_URL'
    },
    port:process.env.PORT,
    FILES_DEST : process.env.FILES_DEST,
  },
  test: {
    db: {
      username: testSequelizeConf.username,
      password: testSequelizeConf.password,
      database: testSequelizeConf.database,
      host: testSequelizeConf.host,
      dialect: "postgres",
      port: 5430
    },
    port:3112,
    FILES_DEST : '/home/jorge/Documentos/IMA07/colecciones'
  },
};