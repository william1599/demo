const { query } = require("express");
const express = require("express");
const auth = require('../authentication/authenticateJWT.middleware');

// Controllers
const _modeloController = require('./modelo.controller');
const _servicioController = require('../servicio/servicio.controller');
const _util = require('../util/util')

const router = express.Router();

router.use((req, res, next) => {
  // Disponible para implementar MDW
  next();
});

// Ruta POST /modelo
// Funcion: Crear un modelo en la BD
router.post('/',auth.authenticateJWT, async (req, res) => {
  
  const body = req.body;
  
  nuevo_modelo = {
    nombre: body.nombre,
    id_architecture: body.id_architecture,
    entrenando: body.entrenando,
    estado: body.estado,
    idconf: body.idconf,
    fecha: body.fecha,
    stop: body.stop,
    trained_epochs: body.trained_epochs,
    idservicio: body.idservicio,
    version: 0
  }
  
  error = _util.postValidator(nuevo_modelo)
  if(error){
      res.status(400).json({
          ok: false,
          status: 400,
          error: null,
          message: `no se paso el atributo '${error}'`,
          dato: null
      });
      
  }
  else{
    let resp;

    try {
      resp = await _modeloController.saveModelo(nuevo_modelo);
    } catch(err) {
      return next(err);
    }

    if (resp.status) {
      res.status(200).json({
          ok: true,
          status: 200,
          message: resp.message,
          error: null,
          dato: resp.dato
        });
    } else {
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: resp.message,
            dato: null
        });
    }
  }  

});

// Ruta GET /modelo
// Funcion: Crear un modelo en la BD
router.get('/', async (req, res, next) => {
  let { status, limit, offset, param, descending, idservicio } = req.query;
  //let status = null;

  status ? status = status : status = null
  
  let promesa = null;
  if(!idservicio){
    try {
      promesa = await _modeloController.getModelos(limit, offset, param, descending);
    } catch (err) {
      return next(err);
    }
  }
  else{
    try {
      promesa = await _modeloController.getModelosByServicio(limit, offset, idservicio, param, descending, status);
    } catch (err) {
      return next(err);
    }
  }
  
  if (promesa.status){
      const resp = {
          ok: true,
          status: 200,
          message: promesa.message,
          error: null,
          datos: promesa.datos
      }
      res.status(200).json(resp);
  }
  else{
    const resp = {
      ok: false,
      status: 400,
      message: promesa.message,
      error: promesa.error,
      datos: null
    }
    res.status(400).json(resp);
  }
});

// Ruta GET /modelo/export/<idservicio>
// Funcion: Obtiene los modelos del servicio
router.get('/export/:idservicio', auth.authenticateJWT, async (req, res, next) => {
  const queryParams = req.params;
  let promess;

  try {
    promess = await _modeloController.getExportedModelo(queryParams.idservicio);
  } catch (err) {
    return next(err);
  }
  
  if (promess.status) {
    const resp = {
        ok: true,
        status: 200,
        message: promess.message,
        error: null,
        dato: promess.dato
    }
    res.status(200).json(resp);
} else {
    const resp = {
        ok: false,
        status: 400,
        error: null,
        message: promess.message,
        dato: null
    };
    res.status(400).json(resp);
}
  

});

// Ruta GET /modelo/<idmodelo>
// Funcion: Obtiene el modelo segun su id
router.get('/:idmodelo', async (req, res, next) => {
  const { idmodelo } = req.params; 
  let promess;

  try {
    promess = await _modeloController.getModelo(idmodelo);
  } catch (err) {
    return next(err);
  }
  
  if (promess.status) {
      const resp = {
          ok: true,
          status: 200,
          message: promess.message,
          error: null,
          dato: promess.dato
      }
      res.status(200).json(resp);
  } else {
      const resp = {
          ok: false,
          status: 400,
          error: null,
          message: promess.message,
          dato: null
      };
      res.status(400).json(resp);
  }
});

// Ruta GET /modelo/export/<idmodelo>
// Funcion: Obtiene el modelo segun su id
router.put('/export/:idmodelo', auth.authenticateJWT, async (req, res, next) => { 
  const { idmodelo } = req.params; 
  const body = req.body;  
  let promess;

  try {
    promess = await _modeloController.exportModelo(idmodelo);  
  } catch (err) {
    return next(err);
  }
  
  if (promess.status) {
      const resp = {
          ok: true,
          status: 200,
          message: promess.message,
          error: null,
          dato: promess.dato
      }
      res.status(200).json(resp);
  } else {
      const resp = {
          ok: false,
          status: 400,
          error: null,
          message: promess.message,
          dato: null
      };
      res.status(400).json(resp);
  }
});

// Ruta PUT /modelo/<idmodelo>
// Funcion: Edita un modelo segun propiedades ingresadas
router.put('/:idmodelo', auth.authenticateJWT, async (req, res, next) => {
  const { idmodelo } = req.params; 
  const body = req.body;
  
  const variables = ["nombre","estado","idconf","fecha","trained_epochs","stop","resultado", "entrenando", "error", "log_header", "tipo_error", "ruta", "version", "titulo", "comentario_habilitado"]
  const modelo = {}
  for(const key in body){
    if(variables.includes(key)){
      modelo[key] = body[key];
    }
  }

  let promess;
  try {
    promess = await _modeloController.editModelo(idmodelo, modelo);
  } catch (err) {
    return next(err);
  }
  
  if (promess.status) {
      const resp = {
          ok: true,
          status: 200,
          message: promess.message,
          error: null,
          dato: promess.dato
      }
      res.status(200).json(resp);
  } else {
      const resp = {
          ok: false,
          status: 400,
          error: null,
          message: promess.message,
          dato: null
      };
      res.status(400).json(resp);
  }
});

module.exports = router;
