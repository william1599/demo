const models = require('../models/index.model');
const { QueryTypes } = require('sequelize');
var fs = require('fs');
const { CustomError } = require('../errors/custom-error');

class ModelController {   
    
    // Entrada: Body con el modelo y sus propiedades
    // Función: Crear un modelo en la BD
    // Salida: Objeto con estado, mensaje y dato
    static async saveModelo(modelo){
        //inserta en la base de datos
        let status;

        try {
          status = await models.Modelo.create({
            nombre: modelo.nombre,
            estado: modelo.estado,
            entrenando: modelo.entrenando,
            id_architecture: modelo.id_architecture,
            idconf : modelo.idconf,
            tipo_error: modelo.tipo_error,
            fecha: modelo.fecha,
            trained_epochs: modelo.trained_epochs,
            idservicio: modelo.idservicio,
            stop:modelo.stop,
            version: modelo.version,
            resultado:{}
          })
        } catch (err) {
          throw new CustomError(err.message);
        }

        if (status) {
          return {
            status,
            message: `Modelo creado correctamente`,
            dato:status.dataValues
          }
        } else {
          return {
            status,
            message: `Modelo con nombre '${modelo.nombre}' ya existe`,
            dato: null
          }
        } 
    }
    
    // Entrada: Limit, offset, orderBy y descending
    // Función: Obtener todos los modelos ordenados por la entrada
    // Salida: Objeto con estado, mensaje y datos
    static async getModelos(limit = 10, offset = 0, orderBy, descending){
        //consulta en la base de datos
        let desc, datos;
        descending == 'true' ? desc = 'DESC' : desc = 'ASC';

        try {
          datos = await models.Modelo.findAll({		  
            limit: limit,
            offset: offset,
            order: [[orderBy, desc]],
            include: [{
              association: 'architecture'
            }, {
              association: 'training_config',
              attributes: ['nombre']
            }]          
          });
        } catch(err) {
          throw new CustomError(err.message);
        }

        if(datos){
          return {
            status:true,
            message: `Modelos recuperado correctamente`,
            datos:datos
            };
        }
        else{
          return {
            status:false,
            message: `Ocurrio un error`,
            datos:null
            };
        }
    }

    // Entrada: Limit, offset, id servicio, orderBy, descending y status
    // Función: Obtener todos los modelos segun servicio y ordenados por los parametros de entrada
    // Salida: Objeto con estado, mensaje y datos
    static async getModelosByServicio(limit = 1000, offset = 0, idservicio, orderBy, descending, status = null){
      
      let desc, error, datos;
      descending == 'true' ? desc = 'DESC' : desc = 'ASC';
      
      try {
        datos = await models.Modelo.findAll({		  
          limit: limit,
          offset: offset,
          order: [[orderBy, desc]],
          where:{
            idservicio:idservicio,
            ... (status && { estado: status })
          },
  
          include: [{
            association: 'architecture'
          }, {
            association: 'training_config',
            attributes: ['nombre']
          }]          
        })
      } catch(e) {
        throw new CustomError(e.message);
      }


      if(datos) {
        return {
          status:true,
          message: `Modelos recuperado correctamente`,
          datos:datos
        };
      } else {
        return {
          status: false,
          message: 'Los modelos no se lograron recuperar',
          datos: null,
          error
        }
      }
      
    }

    // Entrada: Id del modelo
    // Función: Obtiene el modelo de la BD segun su id
    // Salida: Objeto con estado, mensaje y dato
    static async getModelo(idmodelo){        
      //consultar a la base de datos
      
      try {
        const dato = await models.Modelo.findOne({
          where:{
            idmodelo: idmodelo,
          },
          include: [{
            association: 'architecture',
          }, {
            association: 'training_config'
          }, {
              association: 'parametros_prediccion'
          }]
        });
        return {
          status:true,
          message: `Modelo recuperado correctamente`,
          dato: dato
        };
      } catch(e) {
        throw new CustomError(e.message);
      }

    }

    // Entrada: Id del servicio
    // Función: Obtener todos los modelos del servicio
    // Salida: Objeto con estado, mensaje y datos
    static async getExportedModelo(idservicio){
      const modelo = await models.conn.query("select modelos.idmodelo, modelos.nombre, modelos.estado, modelos.idconf, modelos.fecha, modelos.trained_epochs, modelos.stop, modelos.resultado, modelos.idservicio, modelos.ruta from modelos inner join servicios on servicios.idmodelo = modelos.idmodelo where servicios.idservicio="+idservicio+" limit 1;",
      { 
        plain:true,       
        type: QueryTypes.SELECT 
      });
      
      if(modelo){
        return {
          status:true,
          message: `Modelo recuperado correctamente`,
          dato:modelo
        };
      }
      else{
        return {
          status:false,
          message: `Ocurrio un error`,
          dato:null
        };
      }
    }

    // Entrada: Id del modelo
    // Función: Obtener el modelo de la base de datos
    // Salida: Objeto con estado, mensaje y dato
    static async exportModelo(idmodelo){
      //consulta en la base de datos
      const modelo = await models.Modelo.findOne({
        where:{idmodelo:idModelo}
      });

      if(!modelo){
        return {
          status: false,
          message: `Modelo con id '${idmodelo}' no existe`,
          dato: null
        }
      }

      //consulta en la base de datos
      const servicio = await models.Servicio.findOne({
        where:{idservicio:dato.idservicio}
      });

      if(!servicio){
        return {
          status: false,
          message: `Servicio con id '${dato.idservicio}' no existe`,
          dato: null
        }
      }

      const t = await sequelize.transaction();
      let exito = null;

      try {

        servicio.idmodelo = idmodelo;
        const actualizado = await servicio.save({transaction:t});
        //modelo.estado = "EXPORTADO";
        const actualizado2 = await modelo.save({transaction:t});       
        
        // If the execution reaches this line, no errors were thrown.
        // We commit the transaction.
        exito = await t.commit();

      } catch (error) {
        // If the execution reaches this line, an error was thrown.
        // We rollback the transaction.
        await t.rollback();
      }

      if(exito){       
          return {
            status: true,
            message: `Modelo actualizado correctamente`,
            dato:modelo.dataValues
          }
      } else {
          return {
            status: false,
            message: `Modelo con id '${idColeccion}' no se actualizó`,
            dato: null
          }
      }      
    }

    // Entrada: Id del modelo y los datos actualizados en el body
    // Función: Editar el modelo segun los datos
    // Salida: Objeto con estado, mensaje y dato
    static async editModelo(idModelo,dataActualizada){
      //consulta en la base de datos
      
      let actualizado;

      if(idModelo == 'true') {
        return {
          status: true,
          message: 'Id modelo no es numero',
          dato: null
        }
      }

      try {
        const dato = await models.Modelo.findOne({
          where:{idmodelo:idModelo}
        });
        
        for (const propiedad in dataActualizada) {
          dato[propiedad] = dataActualizada[propiedad];
        }        

        actualizado = await dato.save();
      } catch (err) {
        throw new CustomError(err.message);
      }
      
      if (actualizado) {
          return {
          status: actualizado,
          message: `Modelo actualizado correctamente`,
          dato:actualizado.dataValues
          }
      } else {
          return {
          status: actualizado,
          message: `Modelo con id '${idColeccion}' no se actualizó`,
          dato: null
          }
      }
    }
    //elimina un modelo
    static async delModelo(idModelo){
        //inserta en la base de datos
    }


}

module.exports = ModelController;
