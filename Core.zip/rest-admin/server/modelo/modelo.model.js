module.exports = (sequelize, DataTypes) => {
    
    var Modelo = sequelize.define('modelo', {
      idmodelo: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
      },
      nombre: DataTypes.STRING, 
      estado: {
        type:DataTypes.ENUM,
        values:["CREADO","ENTRENANDO","ENTRENADO","CANCELADO", "ERROR", "PREPARANDO"]
      },
      //idscripts: DataTypes.INTEGER,
      idconf: DataTypes.INTEGER,
      ruta: DataTypes.STRING,
      version: DataTypes.INTEGER,
      id_architecture: DataTypes.INTEGER,
      error: DataTypes.BOOLEAN,
      entrenando: DataTypes.BOOLEAN,
      tipo_error: DataTypes.TEXT,
      fecha: DataTypes.DATE,
      trained_epochs:DataTypes.INTEGER,
      stop:DataTypes.BOOLEAN,
      resultado:DataTypes.JSON,
      idservicio:DataTypes.INTEGER,
      log_header: DataTypes.STRING,
      comentario_habilitado: DataTypes.BOOLEAN,
      titulo: DataTypes.TEXT
    });

    /*Modelo.associate = function(models) {
      
    };*/
  
    return Modelo;
  
  };
