module.exports = (sequelize, DataTypes) => {
    
    var Estructura = sequelize.define('estructura', {
      idestructura: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey : true,
        autoIncrement: true
      },
      nombre: DataTypes.STRING,      
      //se usa un json para los atributos para no caer en el tema de los EAV
      atributos: DataTypes.JSON,
      idservicio:DataTypes.INTEGER
    });  
    return Estructura;
  };

/*
    [
        {
            //nombre que se mostrará al usuario
            "nombre_visible":"Mi campo",
            //nombre que tendra el atributo en el json del elemento
            "nombre_variable":"mi_campo",
            //tipo de entrada: ["number","string","list","file","image", "file_url","image_url"]
            "tipo":"number",
            //opciones a mostrar en caso de haber elegido "list" anteriormente
            "options":["uno", "dos"]
            //el campo es obligatorio?
            "obligatorio":true,//false
        }
    ]
  
  
*/