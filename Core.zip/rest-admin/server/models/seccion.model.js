module.exports = (sequelize, DataTypes) => {
    
    var Seccion = sequelize.define('seccion', {

        idseccion: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        nombre: DataTypes.STRING,
        descripcion: DataTypes.STRING
    })

    return Seccion;
}