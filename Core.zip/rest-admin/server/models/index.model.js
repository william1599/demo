'use strict';

// Obtiene las variables de entorno
const env = process.env.NODE_ENV || 'development';

const environmentsConfig = require('../config/environments.config')[env];

// Importa sequelize
const Sequelize = require('sequelize');
var db = {};


//


// Inicializar Sequelize con sus datos
var sequelize = new Sequelize(
  environmentsConfig.db.database,
  environmentsConfig.db.username,
  environmentsConfig.db.password,
  {
    host: environmentsConfig.db.host,
    dialect: environmentsConfig.db.dialect,
    logging:false,
    port: environmentsConfig.db.port
  }
);

// Importar Entidades
db = {  
  LineaProduccion: sequelize.import('../linea-produccion/linea_produccion.model'),
  Empresa: sequelize.import('../empresa/empresa.model'),
  Equipo: sequelize.import('../equipo/equipo.model'),
  Servicio: sequelize.import('../servicio/servicio.model'),
  Usuario: sequelize.import('../usuario/user.model'),
  Modelo : sequelize.import('../modelo/modelo.model'),
  ParametrosPrediccion: sequelize.import('../variables-prediccion/parametros_prediccion.model'),
  Optimizador: sequelize.import('../optimizer/optimizer.model'),
  DatoColeccion: sequelize.import('../colecciones/datos-colecciones/dato_coleccion.model'),
};

Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

db.Servicio.belongsTo(db.LineaProduccion, { foreignKey: 'idlineaproduccion', as: 'lineaproduccions'});
db.LineaProduccion.hasMany(db.Servicio, { as: 'servicios', foreignKey: 'idlineaproduccion' });

db.LineaProduccion.hasMany(db.Equipo, { as: 'equipo', foreignKey: 'idlineaproduccion' });
db.Equipo.belongsTo(db.LineaProduccion, { foreignKey: 'idlineaproduccion', as: 'lineaproduccion'  });

// Asociacion linea de produccion - empresa.
db.LineaProduccion.belongsTo(db.Empresa, { foreignKey:  'idempresa', as: 'empresa'});
db.Empresa.hasMany(db.LineaProduccion, { foreignKey: 'idempresa', as: 'lineaproduccion' });

db.Modelo.hasMany(db.ParametrosPrediccion, { as: 'parametros_prediccion', foreignKey: 'idmodelo' });
db.ParametrosPrediccion.belongsTo(db.Modelo, { as: 'modelo', foreignKey: 'idmodelo' });

db.Servicio.hasMany(db.Modelo, {as: 'modelo', foreignKey: 'idservicio'});
db.Modelo.belongsTo(db.Servicio, {foreignKey: 'idservicio', as: 'servicio'});

db.Servicio.hasMany(db.Optimizador, { as: 'optimizador', foreignKey: 'idservicio'});
db.Optimizador.belongsTo(db.Servicio, { foreignKey: 'idservicio', as: 'servicio'});

db.Modelo.hasMany(db.Optimizador, { as: 'optimizadores', foreignKey: 'idmodelo' });
db.Optimizador.belongsTo(db.Modelo, { as: 'modelo', foreignKey: 'idmodelo' });

db.DatoColeccion.hasMany(db.ParametrosPrediccion, { as: 'parametros_prediccion', foreignKey: 'iddatocoleccion' });
db.ParametrosPrediccion.belongsTo(db.DatoColeccion, { as: 'dato_coleccion', foreignKey: 'iddatocoleccion' });

//instancia de conexión
db.conn = sequelize;
//librería
db.Sequelize = Sequelize;

module.exports = db;
