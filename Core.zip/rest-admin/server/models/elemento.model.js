module.exports = (sequelize, DataTypes) => {
    
    var Elemento = sequelize.define('elemento', {
      idelemento: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey : true,
        autoIncrement: true
      },
      nombre: DataTypes.STRING,      
      //se usa un json para los atributos para no caer en el tema de los EAV
      atributos: DataTypes.JSON,
      idservicio:DataTypes.INTEGER
    });  
    return Elemento;
  };