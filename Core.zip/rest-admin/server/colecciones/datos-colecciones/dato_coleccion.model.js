module.exports = (sequelize, DataTypes) => {

    var DatoColeccion = sequelize.define('datos_coleccion', {

        iddatocoleccion: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },

        nombre: DataTypes.STRING,
        tipo: DataTypes.STRING,
        max: DataTypes.INTEGER,
        min: DataTypes.INTEGER,
        idcoleccion: DataTypes.INTEGER
    })

    return DatoColeccion;
}