const { CustomError } = require('../../errors/custom-error');
const models = require('../../models/index.model');

class DatoColeccionController {

    // Entrada: Body del dato coleccion con sus propiedades
    // Funcion: Guardar dato coleccion en la base de datos
    // Salida: Objeto con estado, mensaje y dato
    static async create(newDataCollection) {

        let status;

        try {
            status = await models.DatoColeccion.create({
                idcoleccion: newDataCollection.idcoleccion,
                nombre: newDataCollection.nombre,
                tipo: newDataCollection.tipo,
                min: newDataCollection.min,
                max: newDataCollection.max
            });
        } catch(err) {
            throw new CustomError(err.message);
        }

        if(status) {
            return {
                status,
                message: 'Data coleccion creada correctamente',
                dato: status
            }
        } else {
            return {
                status,
                message: 'No se logro crear correctamente',
                dato: null
            }
        }
    }

    // Entrada: Id de la coleccion
    // Funcion: Obtener todos los datos de coleccion segun la id de coleccion
    // Salida: Objeto con estado, mensaje
    static async getByCollection(idcoleccion) {

        let status;

        try {
            status = await models.DatoColeccion.findAll({
                where: {
                    idcoleccion
                }
            })            
        } catch(err) {
            throw new CustomError(err.message);
        }

        if(status) {
            return {
                status,
                message: 'Datos coleccion recuperados correctamente',
                datos: status
            }
        } else {
            return {
                status,
                message: 'Datos coleccion no lograron recuperarse',
                datos: null
            }
        }
    }
}

module.exports = DatoColeccionController;
