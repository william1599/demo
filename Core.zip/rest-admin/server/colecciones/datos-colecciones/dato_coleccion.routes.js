const express = require("express");
const auth = require('../../authentication/authenticateJWT.middleware');

const _datoColeccionController = require('./dato_coleccion.controller')
const _util = require('../../util/util');

const router = express.Router();

// RUTA POST /datocoleccion
// Función: Guardar un dato coleccion 
router.post('/', async (req, res, next) => {
    const body = req.body;

    newDataCollection = {
        nombre: body.nombre,
        tipo: body.tipo,
        min: null,
        max: null
    }

    error = _util.postValidator(newDataCollection)
    if(error) {
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: `No se paso el atribuuto '${error}'`,
            dato: newDataCollection
        })
    } else {
        let resp;

        try {
            resp = await _datoColeccionController.create(newDataCollection);
        } catch(err) {
            return next(err);
        }

        if(resp.status) {
            res.status(201).json({
                ok: true,
                status: 201,
                message: resp.message,
                error: null,
                dato: resp.dato
            })
        } else {
            res.status(400).json({
                ok: false,
                status: 400,
                error: null,
                message: resp.message,
                dato: null
            })
        }

    }
})

// RUTA GET /datocoleccion/col/<idcoleccion>
// Función: Obtener los dato coleccion segun la id de la coleccion
router.get('/col/:idcoleccion', async (req, res, next) => {

    const { idcoleccion } = req.params;
    let resp;

    try {
        resp = await _datoColeccionController.getByCollection(idcoleccion);
    } catch(err) {
        return next(err);
    }

    if(resp.status) {
        res.status(200).json({
            ok: true,
            status: 200,
            message: resp.message,
            error: null,
            datos: resp.datos
        })
    } else {
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: resp.message,
            datos: null
        })
    }
})

module.exports = router;
