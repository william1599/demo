const express = require("express");
const auth = require('../authentication/authenticateJWT.middleware');
var multer  = require('multer');
const fs = require('fs');
var csv = require("csvtojson");

const env = process.env.NODE_ENV || 'development';
const environmentsConfig = require('../config/environments.config')[env];

// Controllers
const _coleccionController = require('./coleccion.controller');
const _datoColeccionController = require('./datos-colecciones/dato_coleccion.controller')
const _util = require('../util/util');
const e = require("express");
const allowedTypes = [
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-excel.sheet.binary.macroEnabled.12",
    "application/vnd.ms-excel",//csv
    "application/vnd.ms-excel.sheet.macroEnabled.12",
    "text/csv"
]

const allowedTypesSimple = [
    "text/csv",
    ".csv",
    "application/vnd.ms-excel"
]

const router = express.Router();

router.use((req, res, next) => {
  // Disponible para implementar MDW
  next();
});

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, environmentsConfig.FILES_DEST);
    },
    filename: function (req, file, cb) {
      
      
      let extension = file.originalname.split(".")
      extension = extension[extension.length-1]
      //
      
      cb(null, Date.now().toString()+"."+extension)
    }
});

var upload = multer({ storage: storage })


// Ruta POST /coleccion
// Funcion: Subir una coleccion con su archivo
router.post('/', auth.authenticateJWT, upload.single("archivo"), async (req, res) => {
    const body = req.body;
    const file = req.file;
    //
    
    //if(!file.mimetype in allowedTypes){    
    if(!allowedTypes.includes(file.mimetype)){
        let m = `Tipo de archivo no soportado`;
        try {
            fs.unlinkSync(file.path);
            //file removed
        } catch(err) {
            console.error(err)
            m += `\n Error al eliminar el archivo '${file.path}' \n ${err}`
        }        
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: m,
            dato: null
        });
    }
    else{
        
        
        
        let excel = _coleccionController.validarExcel(file, body.tipo);
        
        if(excel.valido){
            
            
            
            coleccion = {
                nombre : file.originalname,
                ruta : file.path,
                transformacion : {"transformacion":body.transformacion},
                idempresa : parseInt(body.idempresa),
                idtipo : parseInt(body.idtipo),
                idanterior : parseInt(body.idanterior),
                header : null
                //dimensiones:body.dimensiones
            }
            
            error = _util.postValidator(coleccion)    
            if(error){
                let m = `No se paso el atributo '${error}'`;
                try {
                    fs.unlinkSync(file.path);
                    //file removed
                } catch(err) {
                    console.error(err)
                    m += `\n Error al eliminar el archivo '${file.path}' \n ${err}`
                }
                
                res.status(400).json({
                    ok: false,
                    status: 400,
                    error: null,
                    message: m,
                    dato: null
                });
            }
            else{
                _coleccionController.creaColeccion(coleccion).then(resp => {
                    if (resp.status) {
                        res.status(200).json({
                            ok: true,
                            status: 200,
                            message: resp.message,
                            error: null,
                            dato: resp.dato
                        });
                    } else {
                        res.status(400).json({
                            ok: false,
                            status: 400,
                            error: null,
                            message: resp.message,
                            dato: null
                        });
                    }        
                });
            }
        }
        else{
            
            
            
            
            res.status(500).json({
                ok: false,
                status: 400,
                error: null,
                message: excel.error,
                dato: null
            });
        }

    }
});

// Ruta POST /coleccion/simple
// Funcion: Subir una coleccion con su archivo
router.post('/simple', upload.single('archivo'), async (req, res) => {
    const body = req.body;
    const file = req.file;

    if(!allowedTypesSimple.includes(file.mimetype)){  
        
        
        let m = `Error al subir archivo: tipo de archivo no soportado`;
        try {
            fs.unlinkSync(file.path);
            //file removed
        } catch(err) {
            console.error(err)
            m += `\n Error al eliminar el archivo '${file.path}' \n ${err}`
        }        
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: m,
            dato: null
        });
    } else {

        const jsonArray = await csv({ checkType: true }).fromFile(file.path)

        var dataTypes = {}
        var dataKeys = Object.keys(jsonArray[0])
        
        for(let i = 0, len = dataKeys.length; i < len; i++) {
            //
            
            dataTypes[dataKeys[i]] = typeof jsonArray[0][dataKeys[i]]
        }

        

         
        coleccion = {
            nombre: body.nombre,
            archivo_original: file.originalname,
            descripcion: body.descripcion,
            ruta: file.path,
            transformacion: {},
            idlineaproduccion: parseInt(body.idlineaproduccion),
            idempresa: parseInt(body.idempresa),
            idtipo: parseInt(body.idtipo),
            idanterior: parseInt(body.idanterior),
            header: JSON.stringify(Object.keys(jsonArray[0])),
            etl: {}
        }

        error = _util.postValidator(coleccion)
        if(error) {
            let m = `No se paso el atributo '${error}'`
            try {
                fs.unlinkSync(file.path)
            } catch(err) {
                console.error(err)
            }

            res.status(400).json({
                ok: false,
                status: 400,
                error: null,
                message: m,
                dato: null
            })

        } else {
            _coleccionController.creaColeccion(coleccion).then(resp => {
                if(resp.status) {
                    for(let i = 0, len = dataKeys.length; i < len; i++) {
                        
                        
                        let dataType = typeof jsonArray[0][dataKeys[i]]

                        if(dataType == 'number') {
                            let tmpMax = Math.max.apply(Math, jsonArray.map(function(o) { return o[dataKeys[i]]; }))
                            let tmpMin = Math.min.apply(Math, jsonArray.map(function(o) { return o[dataKeys[i]]; }))

                            newDataCollection = {
                                nombre: dataKeys[i],
                                idcoleccion: resp.dato.idcoleccion,
                                tipo: dataType,
                                min: tmpMin,
                                max: tmpMax
                            }
                        } else {
                            newDataCollection = {
                                nombre: dataKeys[i],
                                idcoleccion: resp.dato.idcoleccion,
                                tipo: dataType,
                                min: null,
                                max: null
                            }
                        }
        
                        _datoColeccionController.create(newDataCollection).then(resp => {
                            if(!resp.status) {
                                res.status(400).json({
                                    ok: false,
                                    status: 400,
                                    error: null,
                                    message: resp.message,
                                    dato: null
                                })
                            }
                        })
                    }
                    res.status(200).json({
                        ok: true,
                        status: 200,
                        message: resp.message,
                        error: null,
                        dato: resp.dato
                    })
                } else {
                    res.status(400).json({
                        ok: false,
                        status: 400,
                        error: null,
                        message: resp.message,
                        dato: null
                    })
                }
            })



        }
  }
})

// Ruta POST /coleccion/<idcoleccion>
// Función: Edita un archivo según el body y si viene un archivo nuevo 
router.post('/:idcoleccion', upload.single('archivo'), async (req, res, next) => {
    const body = req.body;
    const file = req.file;
    const queryParams = req.params;
    
    let promess;

    
    if(file && !allowedTypes.includes(file.mimetype)){
        let m = `Tipo de archivo no soportado`;
        try {
            fs.unlinkSync(file.path);
            //file removed
        } catch(err) {
            console.error(err)
            m += `\n Error al eliminar el archivo '${file.path}' \n ${err}`
        }        
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: m,
            dato: null
        });
    } else {

        const variables = ["nombre", "descripcion", "idlineaproduccion"]
        const coleccion = {}
        for(const key in body) {
            if(variables.includes(key)) {
                coleccion[key] = body[key]
            }
        }

        if(file) {
            coleccion['ruta'] = file.path
        }
        
        try {
            promess = _coleccionController.editColeccion(queryParams.idcoleccion, coleccion)
        } catch(err) {
            return next(err);
        }

        if(promess) {
            res.status(200).json({
                ok: true,
                status: 200,
                message: promess.message,
                error: null,
                dato: promess.dato
            })
        } else {
            res.status(400).json({
                ok: false,
                status: 400,
                error: null,
                message: promess.message,
                dato: null
            })
        }
    }
})



// Ruta GET /coleccion
// Función: Obtiene las colecciones segun los parametros de la consulta
router.get('/', async (req, res, next) => {

    const { limit, offset, param, descending } = req.query;
    let promesa;

    try {
        promesa = await _coleccionController.getColecciones(
            limit,
            offset,
            1,
            param,
            descending);
    } catch(err) {
        return next(err);
    }

    if (promesa.status){
        const resp = {
            ok: true,
            status: 200,
            message: promesa.message,
            error: null,
            datos: promesa.datos
        }
        res.status(200).json(resp);
    }   
  });

// Ruta GET /coleccion/linea/<idlineaproduccion>
// Función: Obtiene las colecciones segun los parametros de la consulta
router.get('/linea/:idlineaproduccion', async (req, res, next) => {
    let promess;

    const queryParams = req.params;
    const queryP = req.query
    

    const badKey = _util.queryParamValidator(req.query);
    const keyMissing = _util.queryParamMissing(req.query, ['param', 'descending', 'idempresa']);

    if(badKey) {
        next({ message: `parámetro incorrecto o no definido' ${badKey}'`, statusCode: 400});
    }
    if(keyMissing) {
        next({ message: `No se pasó el parámetro' ${keyMissing}'`, statusCode: 400});
    }

    try {
        promess = await _coleccionController.getColecciones(
            queryParams.limit,
            queryParams.offset,
            queryParams.idlineaproduccion,
            queryP.param,
            queryP.descending, 
            queryP.idempresa);
    } catch(e) {
        return next(e);
    }

    //
    if (promess.status){
        const resp = {
            ok: true,
            status: 200,
            message: promess.message,
            error: null,
            datos: promess.datos
        }
        res.status(200).json(resp);
    }   
});

// Ruta GET /coleccion/datos/<idcoleccion>
// Función: Obtiene los datos de la coleccion
router.get('/datos/:idcoleccion', async (req, res, next) => {
    const { idcoleccion } = req.params;
    const { cols, ranges, indexes } = req.query;
    let promesa;

    const badKey = _util.queryParamValidator(req.query);
    const keyMissing = _util.queryParamMissing(req.query, ['cols', 'ranges', 'indexes']);
    const paramKeyMissing = _util.queryParamMissing(req.params, ['idcoleccion']);
    const badParamKey = _util.queryParamValidator(req.params);

    if (badKey) {
        return next({ message: _util.invalidParamErrorMessage(badKey), statusCode: 400});
    }
    if (keyMissing) {
        return next({ message: _util.noParamErrorMessage(keyMissing), statusCode: 400});
    }
    if (paramKeyMissing) {
        return next({ message: _util.noParamErrorMessage(paramKeyMissing), statusCode: 400});
    }
    if (badParamKey) {
        return next({ message: _util.invalidParamErrorMessage(badParamKey), statusCode: 400});
    }

    try {
        promesa = await _coleccionController.leerDatosColeccion(idcoleccion, cols, ranges, indexes)
    } catch(err) {
        return next(err);
    }

    if (promesa.status){
        const resp = {
            ok: true,
            status: 200,
            message: promesa.message,
            error: null,
            datos: promesa.datos
        }
        res.status(200).json(resp);
    }   
});

// Ruta GET /coleccion/data/<idcoleccion>
// Función: Obtiene los datos de la coleccion segun la filtracion ingresada
router.get('/data/:idcoleccion', async (req, res, next) => {
    const { idcoleccion } = req.params;
    const { idcoleccionfiltrada } = req.query;
    let promess;

    const queryParamMissing = _util.queryParamMissing(req.query, ['idcoleccionfiltrada']);

    if(queryParamMissing) {
        return next({ message: _util.noParamErrorMessage(queryParamMissing), statusCode: 400 });
    }

    try {
        promess = await _coleccionController.getFilterData(idcoleccion, idcoleccionfiltrada)
    } catch(err) {
        return next(err);
    }

    if (promess.status){
        const resp = {
            ok: true,
            status: 200,
            message: promess.message,
            error: null,
            datos: promess.dato
        }
        res.status(200).json(resp);
    } else {
        const resp = {
            ok: false,
            status: 400,
            message: promess.message,
            error: null,
            datos: promess.dato
        }
    }   
});

// Ruta GET /coleccion/etl/<idcoleccion>
// Función: Guarda la configuracion etl ingresada en la consulta
router.put('/etl/:idcoleccion', async (req, res, next) => {
    const { idcoleccion } = req.params;
    const { config } = req.body;
    let promess;

    try {
        promess = await _coleccionController.saveEtlConfig(idcoleccion, config);   
    } catch(err) {
        return next(err);
    }

    if(promess.status) {
        const resp = {
            ok: true,
            status: 200, 
            message: promess.message,
            error: null,
            datos: promess.dato
        }
        res.status(200).json(resp);
    } else {
        const resp = {
            ok: false,
            status: 400,
            error: null,
            message: promess.message,
            dato: null
        }
        res.status(400).json(resp);
    }
})


// Ruta GET /coleccion/<idcoleccion>
// Función Obtiene una coleccion segun su id
router.get('/:idcoleccion', async (req, res, next) => {
    const { idcoleccion } = req.params;
    let promess;

    try {
        promess = await _coleccionController.getColeccion(idcoleccion);
    } catch(err) {
        return next(err);
    }

    if (promess.status) {
        const resp = {
            ok: true,
            status: 200,
            message: promess.message,
            error: null,
            dato: promess.dato
        }
        res.status(200).json(resp);
    } else {
        const resp = {
            ok: false,
            status: 400,
            error: null,
            message: promess.message,
            dato: null
        };
        res.status(400).json(resp);
    }
});

module.exports = router;
