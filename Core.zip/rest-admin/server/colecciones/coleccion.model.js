module.exports = (sequelize, DataTypes) => {
    
    var Coleccion = sequelize.define('coleccion', {
      idcoleccion: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
      },
      nombre: DataTypes.STRING,
      archivo_original: DataTypes.STRING,
      descripcion: DataTypes.STRING,
      ruta: DataTypes.STRING,
      transformacion: DataTypes.JSON,
      idempresa: DataTypes.INTEGER,
      idlineaproduccion: DataTypes.INTEGER,
      etl: DataTypes.JSONB,
      idtipo: DataTypes.INTEGER,
      idanterior:  DataTypes.INTEGER,
      header : DataTypes.STRING
      //dimensiones: DataTypes.ARRAY(DataTypes.INTEGER)
      //idservicio:DataTypes.INTEGER,
    });  
    Coleccion.associate = function(models) {
      Coleccion.belongsTo(models.Tipocapa, {foreignKey: 'idtipo', as: 'tipocapa'})
      //Usuario.belongsTo(models.Empresa, {foreignKey: 'idempresa', as: 'empresa'});
    }
    return Coleccion;  
  };