const models = require('../models/index.model');
const XLSX = require("xlsx");
const util = require("../util/util")
var fs = require('fs'); 
var parse = require('csv-parse');
var csv = require("csvtojson");
var etlUtil = require("../util/etl-util");
const { CustomError } = require('../errors/custom-error');

const cabecerasMinimas = [
  "Id Producción (OP)",
  "KILOS",
  "KILOS ENTRADA",
  "METROS",
  "SALDO (KGS)",
  "DESECHO (KG)",
  "DESECHO (KGS)",
  "SERIE FLEJE",
  "DESCRIPCIÓN",
  //"SERIE FLEJE2",
  "KILOS TOTALES",
  "Modulo",
  "Opciones",
  //"DESCRIPCIÓN4",
  "Recurso",
  "Hora de creación",
  "Fecha de creación"
]
const cabecerasMinimas2 = [
  "Tiempo",
  "# Setup",
  "P",
  "Orden",
  "Programa",
  "Item",
  "OP-Producción",
  "Vel Teo.",
  "Obra",
  "Setup",
  "Producto",
  "Material",
  "E.",
  "Des.",
  "Color Cara / Color Trascara",
  "Cantidad metros",
  "T (hrs)",
  "F. Entrega",
  "Hora inicio",
  "Hora Término",
  "Colaciones",
  "SEGUIMIENTO OP"
]
const cabecerasMinimas_LP700A = [
  "Tiempo",
  "# Setup",
  "Prior.",
  "Orden",
  "Programa",
  "Item",
  "OP-Producción",
  "Vel Teo.",
  "Obra",
  "Setup",
  "Producto",
  "Material",
  "E.",
  "Des.",
  "Color Cara / Color Trascara",
  "Cantidad metros",
  "T (hrs)",
  "F. Entrega",
  "Hora inicio",
  "Hora Término",
  "Colaciones",
  "SEGUIMIENTO OP"
]
const validaciones = {
  'historial_produccion':{
    "nombre" : "Actualización de producción",
    //si es un arreglo, no importa el nombre de la hoja
    //solo importan las cabeceras en el orden de la hoja
    "sheets":[
      //si header es un arreglo, me fijo que cada cabecera exista en la primera fila
      //si header fuese un objeto, debe tener {fila: 0, columna:0, valor:"cabecera"}
      {"header":[cabecerasMinimas]}
    ],    
  },
  'historial_mantenimiento':{
    "nombre" : "Historial de mantenimiento",
    //si "sheets" es un objeto
    //me fijo en los nombres de las hojas
    //y luego en cada hoja las restricciones por 
    //cabeceras. Si es null no valido cabeceras
    "sheets":{
      "700A":{"header":null},
      "Mapeo LP700A":{"header":null},
      "Estr. Desengrase":{"header":null},
      "Enjuague 1":{"header":null},
      "Enjuague 2":{"header":null},
      "Enjuague 3":{"header":null},
      "Nano":{"header":null},
      "UV":{"header":null},
      "Esm.1":{"header":null},
      "Enf. 1":{"header":null},
      "Esm.2":{"header":null},
      "Enf. 2":{"header":null},
      "Esm.3":{"header":null},
      "Enf. 3":{"header":null},
      "Esm.4":{"header":null},
      "Enf. 4":{"header":null},
    },    
  },
  'planificacion-old':{
    "nombre":"Planificación",
    "sheets":[
      {"header":[cabecerasMinimas]}
    ],    
  },
  'planificacion':{
    "nombre" : "Planificación",
    "sheets":{
      "LP400":{
        "header":[ [], [], cabecerasMinimas2]
      },
      "LP700 A":{
        "header":[ [], [], cabecerasMinimas_LP700A]
      },
      "LP700 BR":{
        "header":[ [], [], cabecerasMinimas2]
      }
    }
  }
}



class ColeccionController {   
    
    // Entrada: body data de la colección
    // Función: Crea la colección en la base de datos
    // Salida: Objeto con status, mensaje y el dato creado
    static async creaColeccion(data){
      
        return models.Coleccion.create({
            nombre : data.nombre,
            descripcion: data.descripcion,
            archivo_original: data.archivo_original,
            ruta : data.ruta,
            transformacion : data.transformacion,
            idempresa : data.idempresa,
            idlineaproduccion: data.idlineaproduccion,
            idtipo : data.idtipo,
            idanterior : data.idanterior,
            //header : data.header,
            etl: data.etl
            //dimensiones:data.dimensiones
          }).then(status => {
            if (status) {
              return {
                status,
                message: `Colección creada correctamente`,
                dato:status.dataValues
              }
            } else {
              return {
                status,
                message: `Colección con nombre '${data.nombre}' ya existe`,
                dato: null
              }
            }    
          })
    }
  
    // Entrada: Limite, offset, id lineaproduccion, orderBy, descending e idempresa
    // Función: Obtener la lista de colecciones segun los parametros ingresados
    // Salida: Objeto con status, mensaje y los datos
    static async getColecciones(limit = 10, offset = 0, idlineaproduccion, orderBy, descending, idempresa){
      let desc, lista;
      descending == 'true' ? desc = 'DESC' : desc = 'ASC';

      try {
        //consulta una lista paginada
        lista = await models.Coleccion.findAll({
          order: [[orderBy, desc]],
          include: [{
            association: 'lineaproduccion',
            attributes: ['nombre', 'idlineaproduccion'],
            where: {
              idempresa
            }
          }],
          where: {
            idtipo: 1,
            ...(idlineaproduccion != -1 && { idlineaproduccion })
          }
        })
      } catch(e) {
        throw new CustomError(e.message);
      }

      return {
        status:true,
        message: `Colecciones recuperadas correctamente`,
        datos:lista
      };
    }

    // Entrada: id de la coleccion y la configuracion ingresada
    // Función: Guardar la configuracion ingresada en la coleccion
    // Salida: Objeto con status, mensaje y los datos
    static async saveEtlConfig(idcoleccion, config) {
      let data, updatedData;

      try {
        data = await models.Coleccion.findOne({
          where: { idcoleccion }
        })

        data['etl'] = config;
  
        updatedData = await data.save();
      } catch(err) {
        throw new CustomError(err.message);
      }

      if(updatedData) {
        return {
          status: updatedData,
          message: 'Etl guardada correctamente',
          dato: updatedData.dataValues
        }
      } else {
        return {
          status: updatedData,
          message: `Colección con id '${idcoleccion}' no se logró actualizar`,
          dato: null
        }
      }

    }

    // Entrada: Id de la coleccion
    // Función: Obtiene la coleccion segun la id ingresada
    // Salida: Objeto con status, mensaje y los datos
    static async getColeccion(idColeccion){
        //consulta un objeto
        let objeto;

        try {
          objeto = await models.Coleccion.findOne({
            where:{
                idcoleccion:idColeccion
            }
        });

        return {
            status:true,
            message: `Modelo recuperado correctamente`,
            dato:objeto
        };
        } catch(err) {
          throw new CustomError(err.message);
        }
    }

    static async leerDatosColeccion(idColeccion, cols, ranges, indexes) {

      cols = JSON.parse(cols);
      ranges = JSON.parse(ranges);
      indexes = JSON.parse(indexes);
      let coleccion, jsonArray;

      try {
        coleccion = await models.Coleccion.findOne({
          where: {idcoleccion: idColeccion}
        })
      } catch(err) {
        throw new CustomError(err.message);
      }

      try {
        jsonArray = await csv({ checkType: true }).fromFile(coleccion.ruta)
      } catch(err) {
        throw new CustomError(err.message);
      }

      if(cols && cols.length != 0) {
        
        for(let val of cols) {
          for(let i = 0, len = jsonArray.length; i < len; i++){
            delete jsonArray[i][val]
          }
        }
      }

      // Formato de rangos:
      // [["Nombre Columna 1", valor_minimo, valor_maximo], ["Nombre columna 2"]]
      // let auxiliar = [ { "nombre": '0', 'max': '1000', 'min': '0'  }, { "nombre": '39', 'max': '30', 'min': '0'  } ]
      
      if(ranges) {
        
        for(let obj of ranges) {
          var j = jsonArray.length;
          
          
          
          if(obj['max'].length != 0 || obj['min'] != 0) {
            while(j--) {
              if((jsonArray[j][obj['name']] > obj['max'] || jsonArray[j][obj['name']] < obj['min'])) {
                jsonArray.splice(j, 1)
              }
            }
          }
        }
      }

      if(indexes) {
        
        jsonArray.splice(indexes['lower'], indexes['upper']);
      }

      // Formato indices: 
      // { "lower": 0, upper: "10"  }
      
      if(jsonArray) {
        return {
          status: true,
          message: 'Datos recuperados',
          datos: jsonArray
        }
      } else {
        return {
          status: false,
          message: `Datos no recuperados`,
          datos: null
        }
      }
    }

    static async generateFile() {
      var text = "hello world";
      
    }



    static async getFilterData(idcoleccion, idcoleccionfiltrada) {

      let filterCollection = null
      let arrayData = [];

      try {
        const coleccion = await models.Coleccion.findOne({
          where: { idcoleccion }
        })
  
        const dataCollection = await models.DatoColeccion.findAll({
          raw: true,
          where: { idcoleccion }
        })
  
        if(idcoleccionfiltrada != 'null') {
          
          filterCollection = await models.ColeccionFiltrada.findOne({
            where: {
              idColeccionFiltrada: idcoleccionfiltrada
            }
          })
        }
  
        if(filterCollection && filterCollection['etl']) {
          
          const { Entrada, Rangos, Indice, Salida } = filterCollection['etl']
          arrayData = await etlUtil.filterData(coleccion, dataCollection, Entrada, Rangos, Indice);
        } else {
          arrayData = await etlUtil.filterData(coleccion, null, null, null, null);
        }
      } catch(err) {
          throw new CustomError(err.message);
      }

      if(arrayData) {
        return {
          status: true,
          message: 'Datos recuperados correctamente',
          dato: arrayData
        }
      } else {
        return {
          status: false,
          message: 'No se logró recuperar los datos',
          dato: null
        }
      }
    }

    //edita una coleccion

    // Entradas: Id de la colección, body con los datos para actualizar
    // Funcion: Edita la colección en la base de datos según las filas en dataActualizada
    // Salida: Objecto con el status, un mensaje y el dato actualizado
    static async editColeccion(idColeccion, dataActualizada){
        let coleccion, actualizado;

        try {
          coleccion = await models.Coleccion.findOne({
            where:{idcoleccion:idColeccion}
          });

          for (const propiedad in dataActualizada) {
              coleccion[propiedad] = dataActualizada[propiedad];
          }

          actualizado = await coleccion.save();
        } catch(err) {
          throw new CustomError(err.message);
        }

        if (actualizado) {
            return {
            status: actualizado,
            message: `Coleccion actualizada correctamente`,
            dato:actualizado.dataValues
            }
        } else {
            return {
            status: actualizado,
            message: `Coleccion con id '${idColeccion}' no se actualizó`,
            dato: null
            }
        }
    }
    //elimina una coleccion
    static async delColeccion(idColeccion){
        //inserta en la base de datos
    }

    static validarExcel(file, tipo){
      if(!(tipo in validaciones)){
        //return false, "El tipo '"+tipo+"' no existe";
        return {valido:false, "error":{
          tipo:tipo,
          //message:"Faltan las siguientes columnas: "+faltan.join(","),
          message: "El tipo '"+tipo+"' no existe",
          file:file.originalname
          }
        }
      }
      let workbook = XLSX.readFile(file.path);      
      //si es un arreglo, no importa el nombre de la hoja
      //solo importan las cabeceras en el orden de la hoja      
      if(Array.isArray(validaciones[tipo]["sheets"])){
        let valido = true;     
        let faltan = {};
        
        for(let iHoja in validaciones[tipo]["sheets"]){
          let cabeceraRequerida = validaciones[tipo]["sheets"][iHoja];


          let actualSheet = workbook.Sheets[workbook.SheetNames[iHoja]];
          //let jsonSheet = XLSX.utils.sheet_to_json(actualSheet);
          let csv_sheet = XLSX.utils.sheet_to_csv(actualSheet);
          let filas = csv_sheet.split("\n");
          //recupero la primera fila 
          let row = 0;
          
          //
          //let cabeceraColeccion = Object.keys(jsonSheet[row]); 
          let cabeceraColeccion = filas[row].split(",").map((elem)=>elem.trim());
          for(let fila of cabeceraRequerida["header"]){
            for(let cabecera of fila){
              
              if(!cabeceraColeccion.includes(cabecera)){
                
                valido = false;
                if(workbook.SheetNames[iHoja] in faltan){
                  faltan[workbook.SheetNames[iHoja]].push(cabecera);
                }
                else{
                  faltan[workbook.SheetNames[iHoja]] = [cabecera];
                }                
              }
              else{
                
              }
            }
          }

          
        }
        
        return {valido, "error":{
          tipo:tipo,
          faltan: faltan,
          //message:"Faltan las siguientes columnas: "+faltan.join(","),
          message: "El archivo "+file.originalname+" no cumple el formato de "+validaciones[tipo]["nombre"],
          file:file.originalname
          }
        };
        
      }
      else if(util.isObject(validaciones[tipo]["sheets"])){
        //let validationSheets = Object.keys(validaciones[tipo]["sheets"]).map((e)=>e.trim());
        //saco el trim por que al guardar me aseguro que los nombres de hojas esten trimeados
        let validationSheets = Object.keys(validaciones[tipo]["sheets"]);
        let valido = true;
        let faltanHojas = {};
        //
        //
        let hojas = workbook.SheetNames.map((elem)=>elem.trim());
        for(let iSheet in validationSheets){
          faltanHojas[validationSheets[iSheet]] = null;

          if(!hojas.includes(validationSheets[iSheet])){
            //
            valido = false;
            //hojas.push(iSheet);
            //debemos revisar la siguiente hoja ahora
            continue;
          }
          //si la hoja está, ahora debo fijarme en el contenido de la hoja
          else{
            let actualSheet = workbook.Sheets[workbook.SheetNames[iSheet]];
            let csvSheet = XLSX.utils.sheet_to_csv(actualSheet);

            //

            let filas = csvSheet.split("\n");
            //
            //
            let cabecerasNecesarias = validaciones[tipo]["sheets"][validationSheets[iSheet]]["header"];
            if(cabecerasNecesarias!=null){
              for(let iFila in cabecerasNecesarias){
                //
                //let cabeceraColeccion = Object.keys(jsonSheet[iFila]);
                let cabeceraColeccion = filas[iFila].split(",").map((elem)=>elem.trim());
                //
                for(let cabeceraNecesaria of cabecerasNecesarias[iFila]){
                  if(!cabeceraColeccion.includes(cabeceraNecesaria.trim())){
                    valido = false;
                    if(faltanHojas[validationSheets[iSheet]] == null){
                      faltanHojas[validationSheets[iSheet]] = [cabeceraNecesaria]
                    }
                    else{
                      faltanHojas[validationSheets[iSheet]].push(cabeceraNecesaria);
                    }
                    //
                  }
                }
              }
            }
          }
        }
        return {valido, "error":{
          tipo:tipo,
          faltan:faltanHojas,          
          message: "El archivo "+file.originalname+" no cumple el formato de "+validaciones[tipo]["nombre"],
          file:file.originalname
        }};

      }      
    }
}

module.exports = ColeccionController;