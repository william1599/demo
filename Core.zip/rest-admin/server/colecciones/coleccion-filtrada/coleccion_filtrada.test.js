const { app } = require("../../../server");
const request = require('supertest');

describe('Test /coleccionfiltrada endpoints', () => {

    const testColecctionData = {
      nombre: "Dato de prueba",
      tipo: "string"
    }

    it('Testing GET /coleccionfiltrada endpoint', async () => {
      const res = await request(app).get('/coleccionfiltrada')
      expect(res.status).toEqual(200)
      expect(res.body).toHaveProperty('datos')
    })

    it('Testing POST /coleccionfiltrada endpoint', async () => {
      const res = await request(app).post('/datocoleccion')
                                    .send(testColecctionData)
      expect(res.status).toEqual(201)
      expect(res.body).toHaveProperty('dato')
    })
})