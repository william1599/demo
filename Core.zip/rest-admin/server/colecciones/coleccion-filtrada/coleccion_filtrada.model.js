module.exports = (sequelize, DataTypes) => {

    var ColeccionFiltrada = sequelize.define('coleccion_filtrada', {

        idColeccionFiltrada: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        nombre: DataTypes.STRING,
        idcoleccion: DataTypes.INTEGER,
        etl: DataTypes.JSONB
    });

    return ColeccionFiltrada;
}