const { CustomError } = require('../../errors/custom-error');
const models = require('../../models/index.model');
const etlUtil = require('../../util/etl-util');

class ColeccionFiltradaController {

    /// Entrada: Objeto coleccion filtrada con las propiedades de la consulta
    //  Funcion: Crear una coleccion filtrada y guardarla en base de datos
    //  Salida: Objeto con estado, mensaje y dato
    static async create(newFilterCollection) {

        
        let status;

        try {
            status = await models.ColeccionFiltrada.create({
                idcoleccion: newFilterCollection.idcoleccion,
                nombre: newFilterCollection.nombre,
                etl: newFilterCollection.config
            })
        } catch(err) {
            throw new CustomError(err.message);
        }

        status['etl'] = newFilterCollection.config;
        await status.save();

        if(status) {
            return {
                status,
                message: 'Coleccion filtrada creada correctamente',
                dato: status
            }
        } else {
            return {
                status,
                message: `Coleccion filtrada no se pudo crear`,
                dato: null
            }
        }
    }

    // Entrada: Sin entradas
    // Funcion: Obtener todas las colecciones filtradas de la base de datos
    // Salida: Objeto con estado, mensaje y datos
    static async getAll() {
        let data;

        try {
            data = await models.ColeccionFiltrada.findAll({
                include: [{ 
                    association: 'coleccions',
                    attributes: ['nombre']
                }]
            })
        } catch(err) {
            throw new CustomError(err.message);
        }

        if(data) {
            return {
                status: true,
                message: 'Colecciones filtradas recuperadas correctamente',
                datos: data
            }
        } else {
            return {
                status: false,
                message: 'No se logro recuperar las colecciones filtradas',
                datos: null
            }
        }
    }

    // Entrada: Id de la coleccion de la consulta
    // Funcion: Obtener todas las colecciones filtradas de la coleccion de entrada
    // Salida: Objeto con estado, mensaje y datos
    static async getByCollection(idcoleccion) {

        let etls;

        try {
            etls = await models.ColeccionFiltrada.findAll({
                where: {
                    idcoleccion
                }
            })
        } catch(err) {
            throw new CustomError(err.message);
        }

        if(etls) {
            return {
                status: true,
                message: 'Colecciones filtradas recuperadas correctamente',
                datos: etls
            }
        } else {
            return {
                status: false,
                message: 'Las colecciones filtradas no lograron recuperarse',
                datos: null
            }
        }
    }

    // Entrada: Id de la linea de producción de la consulta
    // Funcion: Obtener todas las colecciones filtradas de una linea de producción
    // Salida: Objeto con estado, mensaje y datos
    static async getByLineaProduccion(idlineaproduccion) {

        let etls;

        try {
            etls = await models.ColeccionFiltrada.findAll({
                order: [['idColeccionFiltrada', 'DESC']],
                include: [{
                    association: 'coleccions',
                    order: [['idcoleccion', 'DESC']],
                    where: {
                        idlineaproduccion
                    },
                    include: [{
                        association: 'lineaproduccion',
                        attributes: ['nombre', 'idlineaproduccion'],
                    }]
                }]
            })          
        } catch(err) {
            throw new CustomError(err.message);
        }

        if(etls) {
            return {
                status: true,
                message: 'Colecciones filtradas recuperadas correctamente',
                datos: etls
            }
        } else {
            return {
                status: false,
                message: 'Las colecciones filtradas no lograron recuperarse',
                datos: null
            }
        }
    }

    // Entrada: Id de la linea de la coleccion filtrada
    // Funcion: Obtener la coleccion filtrada segun la entrada
    // Salida: Objeto con estado, mensaje y dato
    static async getById(idcoleccionfiltrada) {

        let etl;

        try {
            etl = await models.ColeccionFiltrada.findOne({
                where: {
                    idColeccionFiltrada: idcoleccionfiltrada
                },
    
                include: [{
                    association: 'coleccions',
                    include: [{
                        association: 'dato_coleccion'
                    }]
                }]
            })
        } catch(err) {
            throw new CustomError(err.message);
        }

        if(etl) {
            return {
                status: true,
                message: 'Coleccion filtrada recuperada correctamente',
                dato: etl
            }
        } else {
            return {
                status: false,
                message: 'Coleccion filtrada no logro recuperarse',
                dato: null
            }
        }
    }

    // Entrada: Id de la linea de la coleccion filtrada y el body con las propiedades
    // Funcion: Editar la coleccion filtrada de la base de datos 
    // Salida: Objeto con estado, mensaje y dato
    static async editFilterCollection(idcoleccionfiltrada, filterCollection) {

        let filterCollectionInDB, updated;

        try {
            filterCollectionInDB = await models.ColeccionFiltrada.findOne({

                where: {
                    idColeccionFiltrada: idcoleccionfiltrada
                }
            });

            for(const property in filterCollection) {
                filterCollectionInDB[property] = filterCollection[property];
            }
    
            updated = await filterCollectionInDB.save();
        } catch(err) {
            throw new CustomError(err.message);
        }

        if(updated) {
            return {
                status: updated,
                message: `Colección filtrada actualizada correctamente`,
                dato: updated.dataValues
            }
        } else {
            return {
                status: updated,
                message: `Coleccion filtrada no se actualizo`,
                dato: null
            }
        }
    } 
}

module.exports = ColeccionFiltradaController;
