const express = require("express");
const auth = require('../../authentication/authenticateJWT.middleware');

const _coleccionFiltradaController = require('./coleccion_filtrada.controller');
const _util = require('../../util/util');

const router = express.Router();

// RUTA POST /coleccionfiltrada
// Función: Crear una colección filtrada y guardar en base de datos
router.post('/', async (req, res, next) => {
    const { nombre, idcoleccion, config } = req.body;

    
    newFilterCollection = {
        nombre,
        idcoleccion,
        config
    }

    error = _util.postValidator(newFilterCollection)
    if(error) {
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: `No se paso el atributo '${error}'`,
            dato: newFilterCollection
        })
    } else {
        let resp;

        try {
            resp = await _coleccionFiltradaController.create(newFilterCollection);
        } catch(err) {
            return next(err);
        }

        if(resp.status) {
            res.status(201).json({
                ok: true,
                status: 201,
                message: resp.message,
                error: null,
                dato: resp.dato
            })
        } else {
            res.status(400).json({
                ok: false,
                status: 400,
                error: null,
                message: resp.message,
                dato: null
            })
        }

    }
});

// RUTA GET /coleccionfiltrada
// Función: Obtiene todas las colecciones filtradas de la base de datos
router.get('/', async (req, res, next) => {

    let promess, error = null;

    try {
        promess = await _coleccionFiltradaController.getAll();
    } catch(err) {
        return next(err);
    }

    if(promess && promess.status) {
        const resp = {
            ok: true,
            status: 200,
            message: promess.message,
            error: null,
            datos: promess.datos
        }
        res.status(200).json(resp);
    } else {
        const resp = {
            ok: false,
            status: 500,
            message: (promess && promess.message) ? promess.message: "Ocurrio un error inesperado",
            error: error,
            datos: null
        }
        res.status(500).json(resp);
    }

})

// RUTA GET /coleccionfiltrada/<idcoleccion>
// Función: Obtiene todas las colecciones filtradas de una colección
router.get('/:idcoleccion', async (req, res, next) => {
    const { idcoleccion } = req.params;
    let promess, error = null

    try {
        promess = await _coleccionFiltradaController.getByCollection(idcoleccion);
    } catch(err) {
        return next(err);
    }

    if(promess && promess.status) {
        const resp = {
            ok: true,
            status: 200,
            message: promess.message,
            error: null,
            datos: promess.datos
        }
        res.status(200).json(resp);
    } else {
        const resp = {
            ok: false,
            status: 500,
            message: ( promess && promess.message ) ? promess.message: "Ocurrio un error inesperado",
            datos: null
        }
        res.status(500).json(resp);
    }
})

// RUTA GET /coleccionfiltrada/linea/<idlineaproduccion>
// Función: Obtiene todas las colecciones filtradas de una linea de produccion
router.get('/linea/:idlineaproduccion', async (req, res, next) => {

    const { idlineaproduccion } = req.params;
    let promess, error = null

    try {
        promess = await _coleccionFiltradaController.getByLineaProduccion(idlineaproduccion)
    } catch(err) {
        return next(err);
    }

    if(promess && promess.status) {
        const resp = {
            ok: true,
            status: 200,
            message: promess.message,
            error: null,
            datos: promess.datos
        }
        res.status(200).json(resp);
    } else {
        const resp = {
            ok: false,
            status: 500,
            message: ( promess && promess.message ) ? promess.message: "Ocurrio un error inesperado",
            datos: null
        }
        res.status(500).json(resp);
    }
})

// RUTA GET /coleccionfiltrada/cf/<idcoleccionfiltrada>
// Función: Obtiene una coleccion filtrada segun id
router.get('/cf/:idcoleccionfiltrada', async (req, res, next) => {

    const { idcoleccionfiltrada } = req.params;
    let promess, error = null;

    try {
        promess = await _coleccionFiltradaController.getById(idcoleccionfiltrada)
    } catch (err) {
        return next(err);
    }

    if(promess && promess.status) {
        const resp = {
            ok: true,
            status: 200,
            message: promess.message,
            error: null,
            dato: promess.dato
        }
        res.status(200).json(resp);
    } else {
        const resp = {
            ok: false,
            status: 500,
            message: ( promess && promess.message ) ? promess.message: "Ocurrio un error inesperado",
            dato: null
        }
        res.status(500).json(resp);
    }
})

// RUTA GET /coleccionfiltrada/<idcoleccionfiltrada>
// Función: Edita una coleccion filtrada segun su id y el body de la consulta
router.put('/:idcoleccionfiltrada', async (req, res, next) => {
    
    const { idcoleccionfiltrada } = req.params;
    const body = req.body;

    

    let promess, error = null;

    try {
        promess = await _coleccionFiltradaController.editFilterCollection(idcoleccionfiltrada, body)
    } catch(err) {
        return next(err);
    }

    if(promess && promess.status) {
        const resp = {
            ok: true,
            status: 200,
            message: promess.message,
            error: null,
            dato: promess.dato
        }
        res.status(200).json(resp);
    } else {
        const resp = {
            ok: false,
            status: 500,
            message: ( promess && promess.message ) ? promess.message : "Ocurrió un error inesperado",
            dato: null
        }
        res.status(500).json(resp);
    }
})

module.exports = router;
