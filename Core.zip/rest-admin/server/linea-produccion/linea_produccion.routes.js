const express = require("express");
const auth = require('../authentication/authenticateJWT.middleware');
// Controllers
const _lineaProduccionController = require('./linea_produccion.controller');
const _util = require('../util/util')

const router = express.Router();

// Ruta POST /lineaproduccion
// Funcion: Crea una linea de produccion en la BD
router.post('/', async (req, res, next) => {
    const body = req.body;
    nueva = {
        nombre: body.nombre,
        tipo: body.tipo,
        descripcion: body.descripcion,
        idempresa: body.idempresa,
        codigo: body.codigo

    }

    error = _util.postValidator(nueva)
    if(error) {
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: `No se paso el atributo '${error}'`,
            dato: nueva
        })
    } else {

        let resp;
        try {
            resp = await _lineaProduccionController.crea(nueva);
        } catch (err) {
            return next(err);
        }

        if(resp.status) {
            res.status(200).json({
                ok: true,
                status: 200,
                message: resp.message,
                error: null,
                dato: resp.dato
            })
        } else {
            res.status(400).json({
                ok: false,
                status: 400,
                error: null,
                message: resp.message,
                dato: null

            });
        }
    }
});

// Ruta GET /lineaproduccion
// Funcion: Obtiene las lineas de prodccion en la BD segun parametros ingresados
router.get('/', async (req,res, next) => {
    var { limit, offset, param, descending, companyId } = req.query

    let promesa = null;
    let error = null;

    try {
        promesa = await _lineaProduccionController.getAll(
            limit,
            offset,
            param,
            descending,
            companyId
        );
    } catch(err) {
        return next(err);
    }

    if(promesa && promesa.status) {
        const resp = {
            ok: true,
            status: 200,
            message: promesa.message,
            error: null,
            datos: promesa.datos
        }
        res.status(200).json(resp);
    } else {
        const resp = {
            ok: false,
            status: 500,
            message: (promesa && promesa.message) ? promesa.message: "Ocurrió un error inesperado",
            error: error,
            datos: null
        }
        res.status(500).json(resp);
    }

})

// Ruta GET /lineaproduccion/empresa/<idempresa>
// Funcion: Obtiene todas las lineas de produccion por empresa
router.get('/empresa/:idempresa', async (req, res, next) => {
    
    const params = req.params;
    const { param, descending } = req.query;
    let promesa = null;
    let error = null;

    const badKey = _util.queryParamValidator(req.query);
    const keyMissing = _util.queryParamMissing(req.query, ['param', 'descending']);

    if(badKey) {
        next({ message: `parámetro incorrecto o no definido' ${badKey}'`, statusCode: 400});
    }
    if(keyMissing) {
        next({ message: `No se pasó el parámetro' ${keyMissing}'`, statusCode: 400});
    }

    try {
        promesa = await _lineaProduccionController.getAllByEmpresa(
            param,
            descending,
            params.idempresa
        );
    } catch(err) {
        return next(err);
    }

    if(promesa && promesa.status) {
        const resp = {
            ok: true,
            status: 200,
            message: promesa.message,
            error: null,
            datos: promesa.datos
        }
        res.status(200).json(resp);
    } else {
        const resp = {
            ok: false,
            status: 500,
            message: (promesa && promesa.message) ? promesa.message: "Ocurrió un error inesperado",
            error: error,
            datos: null
        }
        res.status(500).json(resp);
    }

})

// Ruta GET /lineaproduccion/<idlineaproduccion>
// Funcion: Obtiene una linea de produccion segun su id
router.get('/:idlineaproduccion', async(req, res, next) => {
    const { idlineaproduccion } = req.params;
    
    let promesa = null;
    let error = null;
    try {
        promesa = await _lineaProduccionController.getById(idlineaproduccion)
    } catch(err) {
        return next(err);
    }

    if(promesa) {
        const resp = {
            ok: true,
            status: 200,
            message: promesa.message,
            error: null,
            dato: promesa.dato
        }
        res.status(200).json(resp);
    } else {
        const resp = {
            ok: false,
            status: 500,
            message: 'Ocurrió un error',
            error: error,
            datos: null
        }
        res.status(500).json(resp);
    }
    
})

// Ruta PUT /lineaproduccion/<idlineaproduccion>
// Funcion: Edita una linea de produccion segun su id y el body de la consulta
router.put('/:idlineaproduccion', async(req, res, next) => {

    const { idlineaproduccion } = req.params;
    const body = req.body;
  
    const variables = ["nombre", "descripcion", "tipo", "codigo"]
    const bodyFinal = {}
    for(const key in body) {
      bodyFinal[key] = body[key];
    }
    let resp;

    try {
        resp = await _lineaProduccionController.editarLineaProduccion(idlineaproduccion, bodyFinal)
    } catch (err) {
        return next(err);
    }

    if(resp.status) {
        res.status(200).json({
          ok: true,
          status: 200,
          message: resp.message,
          error: null,
          dato: resp.dato
        })
    } else {
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: resp.message,
            dato: null
        })
    }
})

// Ruta PUT /estado/<idlineaproduccion>
// Funcion: Cambia el estado de la linea de produccion a habilitado o no habilitado segun corresponda
router.put('/estado/:idlineaproduccion', async(req,res, next) => {
    const { idlineaproduccion }  = req.params;
    let resp;

    try {
        resp = await _lineaProduccionController.cambiarEstadoLineaProduccion(idlineaproduccion);
    } catch (err) {
        return next(err);
    }

    if(resp.status) {
        res.status(200).json({
            ok: true,
            status: 200,
            message: resp.message,
            error: null,
            dato: resp.dato
        })
    } else {
        res.status(400).json({
            ok: false,
            status: 400,
            error: null,
            message: resp.message,
            dato: null
        })
    }
})

module.exports = router;
