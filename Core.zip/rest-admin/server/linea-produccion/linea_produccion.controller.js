const { CustomError } = require('../errors/custom-error');
const models = require('../models/index.model');

class LineaProduccionController {

    // Entrada: Body nuevo con las propiedades de la linea de produccion
    // Función: Crear una linea de produccion en la BD
    // Salida: Objeto con estado, mensaje y dato
    static async crea(nuevo) {

        let status;
        try {
            status = await models.LineaProduccion.create({
                nombre: nuevo.nombre,
                tipo: nuevo.tipo,
                descripcion: nuevo.descripcion,
                codigo: nuevo.codigo,
                idempresa: nuevo.idempresa,
                habilitado: true
            });
        } catch (err) {
            throw new CustomError(err.message);
        }

        if(status) {
            return {
                status,
                message: 'Linea de produccion creada correctamente',
                dato: status
            }
        } else {
            return {
                status,
                message: `Linea de produccion con nombre '${nuevo.nombre} no pudo ser creado'`,
                dato: null
            }
        }
    }

    // Entrada: Limite, offset, orderBy, desceding e idempresa
    // Función: Obtener las lineas de produccion de la BD segun la id de la empresa y el filtro orderBy con descending
    // Salida: Objeto con estado, mensaje y dato
    static async getAll(limit = 10, offset = 0, orderBy, descending, idempresa = null) {

        let desc, datos;
        descending == 'true' ? desc = 'DESC' : desc = 'ASC';

        try {
            datos = await models.LineaProduccion.findAll({
                limit: limit,
                offset: offset,
                order: [[orderBy, desc]],
                include: [{
                    association: 'equipo',
                    attributes: ['nombre']
                }, {
                    association: 'empresa',
                    attributes: ['nombre']
                }],
                where: {
                    ... (idempresa && { idempresa: idempresa })
                }
            });
        } catch (err) {
            throw new CustomError(err);
        }

        if(datos) {
            return {
                status: true,
                message: `Lineas de produccion recuperados correctamente`,
                datos: datos
            }
        } else {
            return {
                status: false,
                message: `No se pudo recuperar las lineas de produccion`,
                datos: null
            }
        }
    }

    // Entrada: orderBy, descending y la id de la empresa
    // Función: Obtener las lineas de produccion segun la empresa
    // Salida: Objeto con estado, mensaje y datos
    static async getAllByEmpresa(orderBy, descending, idempresa) {

        let desc, datos;
        descending == 'true' ? desc = 'DESC' : desc = 'ASC';

        try {
            datos = await models.LineaProduccion.findAll({
                order: [[orderBy, desc]],
                include: [{
                    association: 'equipo',
                    attributes: ['nombre']
                }, {
                    association: 'empresa',
                    attributes: ['nombre']
                }],
                where: {
                    idempresa
                }
            })
        } catch(e) {
            throw new CustomError(e.message);
        }


        if(datos) {
            return {
                status: true,
                message: `Lineas de produccion recuperados correctamente`,
                datos: datos
            }
        } else {
            return {
                status: false,
                message: `No se pudo recuperar las lineas de produccion`,
                datos: null
            }
        }
    }

    // Entrada: Id de la linea de produccion
    // Función: Obtener la linea de produccion segun su id
    // Salida: Objeto con estado, mensaje y dato
    static async getById(idlineaproduccion) {

        let dato;
        try {
            dato = await models.LineaProduccion.findOne({
                where: {
                    idlineaproduccion
                },
                include: [{
                    association: 'equipo',
                    attributes: ['nombre']
                }, {
                    association: 'empresa',
                    attributes: ['nombre']
                }]
            });
        } catch (err) {
            throw new CustomError(err.message);
        }


        if(dato) {
            return {
                status: true,
                message: 'Linea de produccion recuperado correctamente',
                dato: dato
            }
        } else {
            return {
                status: false,
                message: 'Linea de produccion no pudo ser recuperado',
                dato: null
            }
        }
    }

    // Entrada: Id de la linea de produccion y la linea a editar
    // Función: Obtener la linea de produccion segun su id
    // Salida: Objeto con estado, mensaje y dato
    static async editarLineaProduccion(idlineaproduccion, lineaAEditar) {

        let actualizado;

        try {
            const lineaEnDB = await models.LineaProduccion.findOne({
                where: { idlineaproduccion }
            });
    
            for(const propiedad in lineaAEditar) {
                lineaEnDB[propiedad] = lineaAEditar[propiedad];
            }
    
            actualizado = await lineaEnDB.save();
        } catch (err) {
            throw new CustomError(err.message);
        }


        if(actualizado) {
            return {
                status: actualizado,
                message: 'Linea produccion actualizada correctamente',
                dato: actualizado.dataValues
            }
        } else {
            return {
                status: actualizado,
                message: `Linea de produccion con id '${idlineaproduccion}' no se actualizó`,
                dato: null
            }
        }

    }

    // Entrada: Id de la linea de produccion 
    // Función: Cambiar columna habilitado de la linea de produccion a false o a true
    // Salida: Objeto con estado, mensaje y dato
    static async cambiarEstadoLineaProduccion(idlineaproduccion) {

        let actualizado;

        try {
            const lineaEnDB = await models.LineaProduccion.findOne({
                where: { idlineaproduccion }
            });
    
            lineaEnDB['habilitado'] ? lineaEnDB['habilitado'] = false : lineaEnDB['habilitado'] = true;
    
            actualizado = await lineaEnDB.save();
        } catch (err) {
            throw new CustomError(err.message);
        }
        
        if(actualizado) {
            return {
                status: actualizado,
                message: 'Linea produccion actualizada correctamente',
                dato: actualizado.dataValues
            }
        } else {
            return {
                status: actualizado,
                message: `Linea de produccion con id '${idlineaproduccion}' no se actualizó`,
                dato: null
            }
        }
    }
}

module.exports = LineaProduccionController;