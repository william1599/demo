module.exports = (sequelize, DataTypes) => {

    var LineaProduccion = sequelize.define('linea_produccion', {

        idlineaproduccion: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        nombre: DataTypes.STRING,
        codigo: DataTypes.STRING,
        descripcion: DataTypes.STRING,
        tipo: {
            type: DataTypes.STRING,
        },
        habilitado: {
            type: DataTypes.BOOLEAN
        }
    });

    // LineaProduccion.associate = function(models) {
    //     LineaProduccion.hasMany(models.Servicio, { as: 'servicios', foreignKey: 'idlineaproduccion' })
    // }

    return LineaProduccion;
};