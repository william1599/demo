//const { ResourceNotFoundError } = require("../errors/not-found-error");

const errorHandler = (err, req, res, next) => {
    
    
    res.status(err.statusCode).send({ message: err.message, statusCode: err.statusCode });
}
const errorLogger = (err, req, res, next) => {
    console.error('\x1b[31m', err); 
    next(err);
}

module.exports = { errorHandler, errorLogger }