module.exports = (sequelize, DataTypes) => {
    
    var Estado = sequelize.define('estado', {
      idestado: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
      },
      nombre: DataTypes.STRING
    });  
    
    return Estado;  
  };