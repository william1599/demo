const { CustomError } = require('../errors/custom-error');
const models = require('../models/index.model');

class ModelController {   

    // Entrada: Objeto estado con propiedades
    // Función: Crear estado en la BD con el body entregado
    // Salida: Objeto con estado, mensaje y el dato
    static async saveEstado(estado){
        //inserta en la base de datos
        return models.Estado.create({
            nombre: estado.nombre            
          }).then(status => {
            if (status) {
              return {
                status,
                message: `Estado creado correctamente`,
                dato:status.dataValues
              }
            } else {
              return {
                status,
                message: `Estado con nombre '${estado.nombre}' ya existe`,
                dato: null
              }
            }    
          })
    }

    // Entrada: Limite y offset
    // Función: Obtener los estados de la BD
    // Salida: Objeto con estado, mensaje y los datos
    static async getEstados(limit = 10, offset = 0){
        //consulta en la base de datos
        let estados;

        try {
          estados = await models.Estado.findAll({		  
            limit: limit,
            offset: offset
          });
        } catch(err) {
          throw new CustomError(err.message);
        }

        return {
          status:true,
          message: `Modelos recuperado correctamente`,
          datos: estados
        };
    }

    // Entrada: Id del estado
    // Función: Obtener el estado segun el id entregado
    // Salida: Objeto con estado, mensaje y el dato
    static async getEstado(idestado){ 
      
        let estado;

        try {
          estado = await models.Estado.findOne({
            where:{
              idestado:idestado
            }
          });
        } catch(err) {
          throw new CustomError(err.message);
        }
        
        return {
          status: true,
          message: `Estado recuperado correctamente`,
          dato: estado
        };

    }
}

module.exports = ModelController;