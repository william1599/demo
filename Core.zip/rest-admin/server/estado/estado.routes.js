const express = require("express");
const auth = require('../authentication/authenticateJWT.middleware');
// Controllers
const _estadoController = require('./estado.controller');
const _util = require('../util/util')

const router = express.Router();

router.use((req, res, next) => {
  // Disponible para implementar MDW
  next();
});

// Ruta POST /estado
// Funcion: Crea un estado en la BD
router.post('/', auth.authenticateJWT, async (req, res, next) => {
  const body = req.body;
  nuevo_estado = {
    nombre: body.nombre    
  }
  error = _util.postValidator(nuevo_estado)
  if(error){
      res.status(400).json({
          ok: false,
          status: 400,
          error: null,
          message: `no se paso el atributo '${error}'`,
          dato: null
      });
      
  }
  else{
    let resp;
    try {
      resp = await _estadoController.saveEstado(nuevo_estado);
    } catch(err) {
      return next(err);
    }
    
    if (resp.status) {
      res.status(200).json({
          ok: true,
          status: 200,
          message: resp.message,
          error: null,
          dato: resp.dato
      });
    } else {
      res.status(400).json({
          ok: false,
          status: 400,
          error: null,
          message: resp.message,
          dato: null
      });
    } 
  }  
});

// Ruta GET /estado
// Funcion: Obtener los estados de la BD
router.get('/', auth.authenticateJWT,  async (req, res, next) => {
  const { limit, offset } = req.query;
  let promesa;

  try {
    promesa = await _estadoController.getEstados(limit, offset);
  } catch(err) {
    return next(err);
  }
  
  if (promesa.status){
      const resp = {
          ok: true,
          status: 200,
          message: promesa.message,
          error: null,
          datos: promesa.datos
      }
      res.status(200).json(resp);
  }   
});

// Ruta GET /estado/<idestado>
// Funcion: Obtener un estado por su id
router.get('/:idestado', auth.authenticateJWT, async (req, res, next) => {
  const { idestado } = req.params;
  let promess;

  try {
    promess = await _estadoController.getEstado(idestado);
  } catch(err) {
    return next(err);
  }
  
  if (promess.status) {
      const resp = {
          ok: true,
          status: 200,
          message: promess.message,
          error: null,
          dato: promess.dato
      }
      res.status(200).json(resp);
  } else {
      const resp = {
          ok: false,
          status: 400,
          error: null,
          message: promess.message,
          dato: null
      };
      res.status(400).json(resp);
  }
});



module.exports = router;
