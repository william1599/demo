#!/bin/bash
ng build --prod
mv dist/ html/
rm -fr /var/www/html/
mv html/ /var/www/
