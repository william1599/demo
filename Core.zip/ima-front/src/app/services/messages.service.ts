import { Injectable, TemplateRef  } from '@angular/core';
import { timer } from 'rxjs';

@Injectable({providedIn:'root'})
export class MessageService {
  messages: any[] = [];

  show(textOrTpl: string | TemplateRef<any>, options: any = {classname:"alert-info"}, timing:number ) {
    //console.log("mensaje agregado");
    options.classname = "fadein alert " + options.classname;
    let m = { textOrTpl, ...options };
    this.messages.push(m);
    //añadir un temporizador que elimine este mensaje luego de pasado el tiempo
    let s = timer(timing);
    s.subscribe(v => this.remove(m));
  }

  success(textOrTpl: string | TemplateRef<any>, timing = 2500){
    this.show(textOrTpl,{classname:"alert-success"},timing);
  }
  alert(textOrTpl: string | TemplateRef<any>,timing = 5000){
    this.show(textOrTpl,{classname:"alert-warning"}, timing)
  }
  error(textOrTpl: string | TemplateRef<any>, timing = 5000){
    this.show(textOrTpl,{classname:"alert-danger"}, timing)
  }
  remove(message) {
    //console.log("mensaje eliminado");
    message.classname += " fadeout2";
    let s = timer(2000);
    s.subscribe(v => this.messages = this.messages.filter(m => m !== message));
  }
}