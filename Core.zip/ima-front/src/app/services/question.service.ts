import { Injectable } from '@angular/core';

import { DropdownQuestion } from '../models/question-models/question-dropdown';
import { QuestionBase } from '../models/question-models/question-base';
import { TextboxQuestion } from '../models/question-models/question-textbox';
import { ApiRestService } from './api-rest.service';
import { TipoCapa } from 'src/app/models/tipocapa';



@Injectable()
export class QuestionService {
  colecciones:Array<any>;

  constructor(public _apiRestService: ApiRestService){
    this.colecciones = new Array<any>();
  }
  async getQuestions(idlineaproduccion) {
    this.getColecciones(idlineaproduccion);
    const tipoCapas : TipoCapa[] = []

    let resultados = await this._apiRestService.getTipoCapas();

    if(resultados.status == 200){
        let tipos = resultados.datos;

        for(let i = 0; i < tipos.length; i++){
          var obj_tipo = new TipoCapa(i);

          obj_tipo.visible_name = tipos[i].visible_name;
          obj_tipo.variable_name = tipos[i].variable_name;
          obj_tipo.descripcion = tipos[i].descripcion;
          obj_tipo.outputs = tipos[i].outputs;

          //inputs
          var tmp = new Array();
          for(let input of tipos[i].inputs){
            tmp.push(new DropdownQuestion({
              key: input.variable_name,
              label : input.visible_name,
              options:this.colecciones,
              descripcion: input.descripcion
            }))
          }
          obj_tipo.setInputs(tmp);
          //settings
          tmp = new Array();
          for(let set of tipos[i].settings){
            if(set.type=='float' || set.type=='string'){
              tmp.push(new TextboxQuestion({
                key: set.variable_name,
                label: set.visible_name,
                value: '',
                type:(set.type=='float')?'number':'text',
                required: true,
                descripcion: set.descripcion
              }))
            }
            if(set.type instanceof Array){
              var options = [];
              for(let opt of set.type){
                options.push({key: opt,  value: opt})
              }
              tmp.push(new DropdownQuestion({
                key: set.variable_name,
                label: set.visible_name,
                options: options,
                required: true,
                descripcion: set.descripcion
              }))
            }

          }
          obj_tipo.setSettings(tmp);
          tipoCapas.push(obj_tipo);
        }
      }
      return tipoCapas;

  }

  async getColecciones(idlineaproduccion){
    let resultados = await this._apiRestService.getTensores(idlineaproduccion);
    console.log('Las colecciones son: ', resultados)
    if(resultados.status == 200){
      for(let col of resultados.datos){
        this.colecciones.push({
          key:col.idColeccionFiltrada,
          value:col.nombre,
          lineaprod: col.coleccions.lineaproduccion.nombre
        })
      }
    }
    else{
      console.log("error"+resultados.status)
    }
  }
}
