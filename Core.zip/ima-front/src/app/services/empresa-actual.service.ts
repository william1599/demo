import { Injectable } from '@angular/core';
import { ApiRestService } from './api-rest.service';
import { AuthenticationService } from './authentication.service';

export interface Empresa {
    idempresa:number;
    nombre:string;
    descripcion:string;
}

@Injectable({
  providedIn: 'root'
})
export class EmpresaActualService {
    private empresa:Empresa; 
    constructor(
        private _apiRestService:ApiRestService,
        private _authenticationService: AuthenticationService){        
    }
    public async setEmpresaById(idempresa:number){
        console.log("Set empresa by id");
        //ir a buscar los datos a la base de datos       
        let r = await this._apiRestService.getEmpresa(idempresa);
        if(r.ok){
            console.log("Seteado ok");
            this.empresa = r.dato;
        }
        else{
            console.log("Fallo el seteo :O");
        }
    }
    public setEmpresa(empresa:Empresa){
        console.log("Set empresa");
        this.empresa = empresa;
    }
    public getEmpresa():Empresa{
        if(this.empresa == null){
            let user = this._authenticationService.currentUserValue;
            this.empresa = user.empresa;
        }
        return this.empresa;
    }
}