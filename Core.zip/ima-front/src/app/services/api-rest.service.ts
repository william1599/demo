import { Injectable } from '@angular/core';
import { env, URLS } from '../config/config';
import { HttpClient, HttpParams } from '@angular/common/http';
import * as modelos from 'src/app/models/respuesta.model';

import { map, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiRestService {
  public configuration = 0;

  public config: any[];

  constructor(
    private http: HttpClient,
  ) { }

  async getModelos() {
    const url = URLS[env].MODELS_MANAGER + '/modelo';
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  async getModelosByServicio(idservicio, param, descending) {
    const url = URLS[env].MODELS_MANAGER + '/modelo';
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        idservicio,
        param,
        descending
      }
    }).toPromise();
    return data;
  }

  async getModelVariables(idmodelo, enabled, output, isConst) {
    const url = URLS[env].MODELS_MANAGER + '/variablesprediccion/' + idmodelo;
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        enabled,
        isOutput: output,
        isConst
      }
    } ).toPromise();
    return data;
  }

  async postOptimizer(optimizer) {
    const url = URLS[env].MODELS_MANAGER + '/optimizador';
    const data = await this.http.post<modelos.RespuestaDato>( url, optimizer ).toPromise();
    return data;
  }

  async getOptimizersInService(idservicio) {
    const url = URLS[env].MODELS_MANAGER + '/optimizador/servicio/' + idservicio;
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  postModelConfig(archivo, body) {
    const formData = new FormData();
    formData.append('archivo', archivo);
    for (const attr in body) {
      if (body.hasOwnProperty(attr)) {
        formData.append(attr, body[attr]);
        console.log('ATTTR: ', body[attr]);
      }
    }
    const url = URLS[env].MODELS_MANAGER + '/modelconfig';
    return this.http.post<modelos.RespuestaDato>( url, formData, {
      reportProgress: true,
      observe: 'events'
    });
  }

  // subirArchivoColeccion(archivo, moreData: any) {
  //   const formData = new FormData();
  //   formData.append('archivo', archivo);
  //   for (const attr in moreData) {
  //     if (moreData.hasOwnProperty(attr)) {
  //       formData.append(attr, moreData[attr]);
  //     }
  //   }
  //   const url = URLS[env].COLLECTION_MANAGER + '/coleccion/simple';
  //   return this.http.post<modelos.RespuestaDato>( url , formData,
  //     {
  //       reportProgress: true,
  //       observe: 'events'
  //     });
  // }

  async getModelConfig(idmodelo) {
    const url = URLS[env].MODELS_MANAGER + '/modelconfig/' + idmodelo;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async getOptimizersInModel(idmodelo) {
    const url = URLS[env].MODELS_MANAGER + '/optimizador/modelo/' + idmodelo;
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  async getOptimizerById(idoptimizador) {
    const url = URLS[env].MODELS_MANAGER + '/optimizador/' + idoptimizador;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async activateOptimizer(body, idservicio) {
    const url = URLS[env].ADMIN_MANAGER + '/servicio/' + idservicio;
    const data = await this.http.put<modelos.RespuestaDato>( url, body ).toPromise();
    return data;
  }

  async getOptions(idvariable) {
    const url = URLS[env].MODELS_MANAGER + '/opciones/' + idvariable;
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  async postModelVariable(variable) {
    const url = URLS[env].MODELS_MANAGER + '/variablesprediccion';
    const data = await this.http.post<modelos.RespuestaDato>( url, variable ).toPromise();
    return data;
  }

  async editMinAndMaxOfVariables(varBody) {
    const url = URLS[env].MODELS_MANAGER + '/variablesprediccion/variables/limites';
    const data = await this.http.put<modelos.RespuestaDato>( url, varBody ).toPromise();
    return data;
  }

  async editModelVariable(idvariable, variable) {
    const url = URLS[env].MODELS_MANAGER + '/variablesprediccion/' + idvariable;
    const data = await this.http.put<modelos.RespuestaDato>( url, variable ).toPromise();
    return data;
  }

  async deleteModelVariables(idvariable) {
    const url = URLS[env].MODELS_MANAGER + '/variablesprediccion/' + idvariable;
    const data = await this.http.delete<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async getDatosGraficos(idmodelo) {
    const url = URLS[env].MODELS_MANAGER + '/resultconfig';
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        idmodelo
      }
    } ).toPromise();
    return data;
  }

  async getInputsType() {
    const url = URLS[env].MODELS_MANAGER + '/tipoentrada';
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  async getModeloActivo(idservicio) {
    const url = URLS[env].ADMIN_MANAGER + '/servicio/modelo/' + idservicio;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async getModeloExportado(idservicio) {
    const url = URLS[env].MODELS_MANAGER + '/modelo/export/' + idservicio;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async getModeloPorId(idmodelo) {
    const url = URLS[env].MODELS_MANAGER + '/modelo/' + idmodelo;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async delModelo(idmodelo) {
    const url = URLS[env].MODELS_MANAGER + '/modelo/' + idmodelo;
    const data = await this.http.delete<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }
  async login(credenciales) {

    const url = URLS[env].ADMIN_MANAGER + '/usuarios/autenticar';
    console.log("URL: ", url);
    const data = await this.http.post<modelos.RespuestaDato>( url, credenciales).toPromise();
    return data;
  }

  async launchTrain(configid, first, idmodelo) {
    const url = URLS[env].APP_FLASK + '/train/' + configid;
    console.log("URL TRAIN: ", url);
    const data = await this.http.post<modelos.RespuestaDato>( url, {first, idmodelo}).toPromise();
    return data;
  }

  launchTrainPy(config, first, idmodelo) {
    //const url = 'http://localhost/train/' + config;
    const url =  URLS[env].APP_FLASK + '/train/' + config;
    console.log("URL TRAIN: ", url);
    console.log("URL TRAIN: ", first, idmodelo, config);
    const data = this.http.post<modelos.RespuestaDato>( url, { first, idmodelo } ).toPromise();
    return data;
  }

  async getForecasts(idservicio, detalle: boolean) {
    const url = URLS[env].FORECAST_MANAGER + '/prediccion?idservicio=' + idservicio + '&detalle=' + detalle;
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }
  async getForecastsByModel(idservicio, detalle, idmodelo) {
    // const url = URLS[env].TRAIN_MANAGER + '/prediccion?idservicio=' + idservicio + '&detalle=' + detalle;
    const url = URLS[env].FORECAST_MANAGER + '/prediccion';
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        idservicio,
        detalle,
        idmodelo: '-1',
        idciclo: '-1'
      }
    } ).toPromise();
    return data;
  }
  async getForecast(idforecast) {
    const url = URLS[env].FORECAST_MANAGER + '/prediccion/' + idforecast;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async getForecastRecord(idmodelo, idciclo, isNormalize, variable) {
    const url = URLS[env].FORECAST_MANAGER + '/prediccion/record/' + idmodelo;
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        idciclo,
        isNormalize,
        variable
      }
    } ).toPromise();
    return data;
  }

  async getForecastResults(idforecast) {
    const url = URLS[env].FORECAST_MANAGER + '/prediccion/output/' + idforecast;
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  async getOptimizerResults(idforecast, idmodelo) {
    const url = URLS[env].FORECAST_MANAGER + '/prediccion/output/optimizer/' + idforecast;
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        idmodelo
      }
    } ).toPromise();
    return data;
  }

  async postForecast(body) {
    const url = URLS[env].FORECAST_MANAGER + '/prediccion';
    const data = await this.http.post<modelos.RespuestaDato>( url, body ).toPromise();
    return data;
  }

  async getForecastCycles(idservicio) {
    const url = URLS[env].FORECAST_MANAGER + '/cicloforecast';
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        idservicio
      }
    }).toPromise();
    return data;
  }

  async postChartConfig(chartBody) {
    const url = URLS[env].MODELS_MANAGER + '/resultconfig';
    const data = await this.http.post<modelos.RespuestaDato>( url, chartBody ).toPromise();
    return data;
  }

  async editChartConfig(chartBody) {
    const url = URLS[env].MODELS_MANAGER + '/resultconfig';
    const data = await this.http.put<modelos.RespuestaDato>( url, chartBody ).toPromise();
    return data;
  }

  async getChartConfig(idmodelo) {
    const url = URLS[env].MODELS_MANAGER + '/resultconfig';
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        idmodelo
      }
    }).toPromise();
    return data;
  }

  async getForecastCyclesByModel(idmodelo) {
    const url = URLS[env].FORECAST_MANAGER + '/cicloforecast/modelo';
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        idmodelo
      }
    }).toPromise();
    return data;
  }

  async editComentariosForecast(idforecast, comentarios) {
    const url = URLS[env].FORECAST_MANAGER + '/prediccion/' + idforecast;
    const data = await this.http.put<modelos.RespuestaDato>( url, {comentarios}).toPromise();
    return data;
  }

  async editVerifiedForecast(idforecast, body) {
    const url = URLS[env].FORECAST_MANAGER + '/prediccion/' + idforecast;
    const data = await this.http.put<modelos.RespuestaDato>( url, body).toPromise();
    return data;
  }

  async getHistorialElemento(idelemento, idservicio, campo) {
    const url = URLS[env].FORECAST_MANAGER + '/prediccion/historial?idelemento=' + idelemento + '&campoid=' + campo + '&idservicio=' + idservicio;
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  async launchForecast(idForecastConfig, modelPath, filesBody, functionName) {
    // const url = URLS[env].APP_MANAGER + '/instance/forecast/' + idForecastConfig;
    const url = URLS[env].APP_FLASK + '/maintenanceforecast/' + idForecastConfig;
    //const url = URLS[env].APP_FLASK + '/maintenance/forecast/' + idForecastConfig;
    // const data = await this.http.post<modelos.RespuestaDato>( url, { modelPath }, {
    //   params: {
    //     modelPath
    //   }
    // }).toPromise();
    const data = await this.http.post<modelos.RespuestaDato>( url, { modelPath, filesBody, functionName }).toPromise();
    return data;
  }

  async launchQualityForecast(idconfig, idmodelo, nombreEtl) {
    console.log('launchQualityForecast');
    const url = URLS[env].APP_MANAGER + '/instance/qualityforecast';
    const data = await this.http.post<modelos.RespuestaDato> ( url, {}, {
      params: {
        idforecast_config: idconfig,
        idmodelo,
        nombreEtl
      }
    }).toPromise();
    return data;
  }

  async launchQualityForecastPy(idconfig, idmodelo, nombreEtl, model, forecast, forecast_config) {
    // const url =  URLS[env].APP_FLASK + 'http://127.0.0.1:5000/qualityforecast';
    const url =  URLS[env].APP_FLASK + '/qualityforecast';
    const data = await this.http.post<modelos.RespuestaDato>( url, { idmodelo, idconfig, model, forecast, forecast_config } ).toPromise();
    return data;
  }

  async launchOptimizerForecast(body, modelo, json_entrada, forecast, csvPath) {
    const url = URLS[env].APP_FLASK + '/optimizador';
    const data = await this.http.post<modelos.RespuestaDato>( url, { body, modelo, json_entrada, forecast, csvPath } ).toPromise();
    return data;
  }

  async getTrainConfs(idservicio: string) {
    const url = URLS[env].MODELS_MANAGER + '/trainconf?idservicio=' + idservicio;
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  async getServicios(idempresa, param, descending, limit= 10, offset= 0) {
    const url = URLS[env].ADMIN_MANAGER + '/servicio';
    const params = [];
    console.log('La id al entrar a la funcion es: ', idempresa);
    idempresa ? params.push('idempresa=' + idempresa) : console.log('No va la id empresa');
    params.push('limit=' + limit.toString());
    params.push('offset=' + offset.toString());
    let data;
    if (idempresa) {
      data = await this.http.get<modelos.RespuestaArray>( url , {
        params: {
          idempresa,
          param,
          descending
        }
      }).toPromise();
    } else {
      data = await this.http.get<modelos.RespuestaArray>( url , {
        params: {
          param,
          descending
        }
      }).toPromise();
    }

    return data;
  }

  async getServiciosHabilitados(idempresa, limit= 10, offset= 0) {
    const url = URLS[env].ADMIN_MANAGER + '/servicio';
    const params = [];
    console.log('La id al entrar a la funcion es: ', idempresa);
    idempresa ? params.push('idempresa=' + idempresa) : console.log('No va la id empresa');
    params.push('habilitado=' + 'true');
    params.push('limit=' + limit.toString());
    params.push('offset=' + offset.toString());
    const data = await this.http.get<modelos.RespuestaArray>( url + '?' + params.join('&')).toPromise();
    return data;
  }

  async postServicio(servicio) {
    const url = URLS[env].ADMIN_MANAGER + '/servicio';
    const data = await this.http.post<modelos.RespuestaDato>( url , servicio).toPromise();
    return data;
  }

  async getServicio(idservicio: string) {
    const url = URLS[env].ADMIN_MANAGER + '/servicio/' + idservicio;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async cambiarEstadoServicio(idservicio) {
    const url = URLS[env].ADMIN_MANAGER + '/servicio/estado/' + idservicio;
    const data = await this.http.put<modelos.RespuestaDato>( url, null ).toPromise();
    return data;
  }

  async editarServicio(idservicio, servicio) {
    const url = URLS[env].ADMIN_MANAGER + '/servicio/' + idservicio;
    const data = await this.http.put<modelos.RespuestaDato>(url, servicio).toPromise();
    return data;
  }

  async getFiles(idforecast: string) {
    const url = URLS[env].FORECAST_MANAGER + '/prediccion/files/' + idforecast;
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  subirArchivo(archivo, moreData: any) {
    const formData = new FormData();
    formData.append('archivo', archivo);
    for (const attr in moreData) {
      if (moreData.hasOwnProperty(attr)) {
        formData.append(attr, moreData[attr]);
      }
    }
    const url = URLS[env].COLLECTION_MANAGER + '/coleccion';
    return this.http.post<modelos.RespuestaDato>( url , formData,
      {
        reportProgress: true,
        observe: 'events'
      });
  }

  subirArchivoColeccion(archivo, moreData: any) {
    const formData = new FormData();
    formData.append('archivo', archivo);
    for (const attr in moreData) {
      if (moreData.hasOwnProperty(attr)) {
        formData.append(attr, moreData[attr]);
      }
    }
    const url = URLS[env].COLLECTION_MANAGER + '/coleccion/simple';
    return this.http.post<modelos.RespuestaDato>( url , formData,
      {
        reportProgress: true,
        observe: 'events'
      });
  }

  uploadForecastCollecion(archivo, moreData) {
    const formData = new FormData();
    formData.append('archivo', archivo);
    for (const attr in moreData) {
      if(moreData.hasOwnProperty(attr)) {
        formData.append(attr, moreData[attr]);
      }
    }

    const url = URLS[env].COLLECTION_MANAGER + '/coleccion/forecast';
    return this.http.post<modelos.RespuestaDato>( url, formData, {
      reportProgress: true,
      observe: 'events'
    });
  }

  editarArchivoColeccion(idcoleccion, archivo, moreData) {
    const formData = new FormData();
    formData.append('archivo', archivo);
    for (const attr in moreData) {
      if (moreData.hasOwnProperty(attr)) {
        formData.append(attr, moreData[attr]);
      }
    }
    const url = URLS[env].COLLECTION_MANAGER + '/coleccion/' + idcoleccion;
    return this.http.post<modelos.RespuestaDato>( url, formData, {
      reportProgress: true,
      observe: 'events'
    } );
  }

  async postMultipleForecastConfig(nuevo, name, idmodelo, idforecast) {
    const url = URLS[env].FORECAST_MANAGER + '/predicion/configuracion/multiple';
    const data = await this.http.post<modelos.RespuestaDato>( url , nuevo, {
      params: {
        nombre: name,
        idmodelo,
        idforecast
      }
    }).toPromise();
    return data;
  }

  async postForecastConfig(nuevo) {
    const url = URLS[env].FORECAST_MANAGER + '/predicion/configuracion';
    const data = await this.http.post<modelos.RespuestaDato>( url , nuevo ).toPromise();
    return data;
  }

  async getForecastConfigByForecast(idforecast, isOutput) {
    const url = URLS[env].FORECAST_MANAGER + '/predicion/configuracion/forecast/' + idforecast;
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        isOutput
      }
    }  ).toPromise();
    return data;
  }

  async editValuesForConfig(body) {
    const url = URLS[env].FORECAST_MANAGER + '/predicion/configuracion/valores';
    const data = await this.http.put<modelos.RespuestaDato>( url, body ).toPromise();
    return data;
  }

  subirArchivoEquipos(archivo, body) {
    console.log('Entre al apirest');
    const formData = new FormData();
    formData.append('archivo', archivo);
    formData.append('idlineaproduccion', body);
    const url = URLS[env].ADMIN_MANAGER + '/equipo/subirArchivo';
    return this.http.post<modelos.RespuestaDato>( url, formData );


  }

  async editarParametrosEquipo(idequipo, equipoActualizado) {
    const url = URLS[env].ADMIN_MANAGER + '/equipo/parametros/' + idequipo;
    const data = await this.http.put<modelos.RespuestaDato>( url, equipoActualizado ).toPromise();
    return data;
  }

  async editarEquipo(idequipo, equipoActualizado) {
    const url = URLS[env].ADMIN_MANAGER + '/equipo/' + idequipo;
    const data = await this.http.put<modelos.RespuestaDato>( url, equipoActualizado ).toPromise();
    return data;
  }

  async cambiarEstadoEquipo(idequipo) {
    const url = URLS[env].ADMIN_MANAGER + '/equipo/estado/' + idequipo;
    const data = await this.http.put<modelos.RespuestaDato>( url, null ).toPromise();
    return data;
  }


  async stopTraining(idmodelo: number) {
    const url = URLS[env].MODELS_MANAGER + '/train/stop/' + idmodelo + '?stop=true';
    const data = await this.http.put<modelos.RespuestaDato>( url , null).toPromise();
    return data;
  }


  async postConfiguracion(configuracion) {
    const url = URLS[env].MODELS_MANAGER + '/trainconf';
    const data = await this.http.post<modelos.RespuestaDato>( url , configuracion).toPromise();
    return data;
  }
  async postArquitectura(arquitectura) {
    const url = URLS[env].ARQUITECTURES_MANAGER + '/arquitectura';
    const data = await this.http.post<modelos.RespuestaCrea>( url , arquitectura).toPromise();
    return data;
  }

  async cambiarEstadoEntrenadoArchitectura(id_architecture) {
    const url = URLS[env].ARQUITECTURES_MANAGER + '/arquitectura/entrenado/' + id_architecture;
    const data = await this.http.put<modelos.RespuestaDato>( url, null ).toPromise();
    return data;

  }

  async nuevaEmpresa(empresa) {
    const url = URLS[env].ADMIN_MANAGER + '/empresa';
    const data = await this.http.post<modelos.RespuestaDato>( url , empresa).toPromise();
    return data;
  }

  async editarEmpresa(id, empresa) {
    const url = URLS[env].ADMIN_MANAGER + '/empresa/' + id;
    const data = await this.http.put<modelos.RespuestaDato>( url, empresa).toPromise();
    return data;
  }

  async cambiarEstadoEmpresa(idempresa) {
    const url = URLS[env].ADMIN_MANAGER + '/empresa/estado/' + idempresa;
    const data = await this.http.put<modelos.RespuestaDato>( url, null ).toPromise();
    return data;
  }

  async getEmpresas(param, descending) {
    const url = URLS[env].ADMIN_MANAGER + '/empresa';
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        param,
        descending
      }
    } ).toPromise();
    return data;
  }

  async getEmpresasHabilitadas(param, descending, enabledService) {
    const url = URLS[env].ADMIN_MANAGER + '/empresa/habilitadas';
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        param,
        descending,
        ... (enabledService && { enabledService })
      }
    } ).toPromise();
    return data;
  }

  async getEmpresa(idempresa: number) {
    const url = URLS[env].ADMIN_MANAGER + '/empresa/' + idempresa;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async getTipoCapas() {
    const url = URLS[env].ARQUITECTURES_MANAGER + '/tipocapa';
    console.log("Llamando a URL: ", url);
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  async getColecciones(idlineaproduccion, param, descending, idempresa) {
    console.log('Mando la id', idlineaproduccion);
    const url = URLS[env].COLLECTION_MANAGER + '/coleccion/linea/' + idlineaproduccion;
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        param,
        descending,
        idempresa
      }
    } ).toPromise();
    return data;
  }

  async getTensores(idlineaproduccion) {
    const url = URLS[env].COLLECTION_MANAGER + '/coleccionfiltrada/linea/' + idlineaproduccion;
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  async getCollection(idcoleccion) {
    const url = URLS[env].COLLECTION_MANAGER + '/coleccion/' + idcoleccion;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;

  }

  async getDatosColecciones(idcoleccion, cols, ranges, indexes) {
    console.log("Obteniendo datos colecciones...");
    const url = URLS[env].COLLECTION_MANAGER + '/coleccion/datos/' + idcoleccion;
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        cols,
        ranges,
        indexes
      }
    } ).toPromise();
    return data;
  }

  async getCollectiondata(idcoleccion) {
    const url = URLS[env].COLLECTION_MANAGER + '/datocoleccion/col/' + idcoleccion;
    const data = await this.http.get<modelos.RespuestaArray> ( url ).toPromise();
    return data;
  }

  async getFilterDataCollections(idcoleccion, idfiltercollection) {
    console.log("Obteniendo filter data colecciones...");
    const url = URLS[env].COLLECTION_MANAGER + '/coleccion/data/' + idcoleccion;
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        idcoleccionfiltrada: idfiltercollection
      }
    } ).toPromise();
    return data;
  }

  async getEtlsCollection(idcoleccion) {
    const url = URLS[env].COLLECTION_MANAGER + '/coleccionfiltrada/' + idcoleccion;
    const data = await this.http.get<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  async saveEtlColection(body) {
    const url = URLS[env].COLLECTION_MANAGER + '/coleccionfiltrada';
    const data = await this.http.post<modelos.RespuestaDato>( url, body ).toPromise();
    return data;

  }

  async saveEtlConfig(idcoleccion, config) {
    const url = URLS[env].COLLECTION_MANAGER + '/coleccion/etl/' + idcoleccion;
    const data = await this.http.put<modelos.RespuestaDato>( url, { config } ).toPromise();
    return data;
  }

  async editEtl(idcoleccionfiltrada, etl) {
    const url = URLS[env].COLLECTION_MANAGER + '/coleccionfiltrada/' + idcoleccionfiltrada;
    const data = await this.http.put<modelos.RespuestaDato>( url, etl ).toPromise();
    return data;
  }

  async getEtlById(id) {
    const url = URLS[env].COLLECTION_MANAGER + '/coleccionfiltrada/cf/' + id;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async getArquitecturas(param, descending, idservicio) {
    const url = URLS[env].ARQUITECTURES_MANAGER + '/arquitectura/servicio/' + idservicio;
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        param,
        descending
      }
    } ).toPromise();
    return data;
  }

  async getArquitecturasByTipo(param, descending, tipo, idservicio) {
    const url = URLS[env].ARQUITECTURES_MANAGER + '/arquitectura/servicio/' + idservicio;
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        param,
        descending,
        tipo
      }
    } ).toPromise();
    return data;
  }

  async getArquitecturasByEstado(param, descending, estado, idservicio) {
    const url = URLS[env].ARQUITECTURES_MANAGER + '/arquitectura/servicio/' + idservicio;
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        param,
        descending,
        estado
      }
    } ).toPromise();
    return data;
  }

  async getArquitecturasByTipoAndEstado(param, descending, tipo, estado, idservicio) {
    const url = URLS[env].ARQUITECTURES_MANAGER + '/arquitectura/servicio/' + idservicio;
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        param,
        descending,
        tipo,
        estado
      }
    } ).toPromise();
    return data;
  }

  async getArquitectura(id_arquitectura) {
    const url = URLS[env].ARQUITECTURES_MANAGER + '/arquitectura/' + id_arquitectura;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async editArquitectura(id_arquitectura, arquitectura) {
    const url = URLS[env].ARQUITECTURES_MANAGER + '/arquitectura/' + id_arquitectura;
    const data = await this.http.put<modelos.RespuestaDato>( url, arquitectura ).toPromise();
    return data;
  }

  async delArquitectura(id_arquitectura) {
    const url = URLS[env].ARQUITECTURES_MANAGER + '/arquitectura/' + id_arquitectura;
    const data = await this.http.delete<modelos.RespuestaArray>( url ).toPromise();
    return data;
  }

  async guardaConfiguracion(configuracion) {
    const url = URLS[env].COLLECTION_MANAGER + '/coleccion';
    const data = await this.http.post<modelos.RespuestaCrea>( url , configuracion).toPromise();
    return data;
  }

  async getResultsMetadata(idmodelo) {
    const url = URLS[env].MODELS_MANAGER + '/train/meta/result/' + idmodelo;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async getTotalResultados(idmodelo) {
    const url = URLS[env].MODELS_MANAGER + '/train/result/' + idmodelo;
    const data = await this.http.get<modelos.RespuestaDato>(url).toPromise();
    return data;
  }

  async getTotalResults(idmodelo) {
    const url = URLS[env].MODELS_MANAGER + '/train/result/' + idmodelo;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async deleteResults(idmodelo) {
    const url = URLS[env].MODELS_MANAGER + '/train/' + idmodelo;
    const data = await this.http.delete<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async putModelo(idmodelo, nuevo_estado) {
    const url = URLS[env].MODELS_MANAGER + '/modelo/' + idmodelo;
    const data = await this.http.put<modelos.RespuestaDato>( url , {estado: nuevo_estado}).toPromise();
    return data;
  }

  async putModeloEntrenando(idmodelo, modelo) {
    const url = URLS[env].MODELS_MANAGER + '/modelo/' + idmodelo;
    const data = await this.http.put<modelos.RespuestaDato>( url , modelo).toPromise();
    return data;
  }

  async postModelo(modelo) {
    const url = URLS[env].MODELS_MANAGER + '/modelo';
    const data = await this.http.post<modelos.RespuestaDato>( url, modelo ).toPromise();
    return data;
  }

  async exportarModelo(idmodelo, idservicio) {
    const url = URLS[env].ADMIN_MANAGER + '/servicio/' + idservicio;
    const data = await this.http.put<modelos.RespuestaDato>( url , {idmodelo: idmodelo, esOptimizador: false}).toPromise();
    return data;
  }

  async getUsuarios(idempresa, param, descending) {
    if (!idempresa) {
      const url = URLS[env].ADMIN_MANAGER + '/usuarios';
      const data = await this.http.get<modelos.RespuestaArray>( url, {
        params: {
          param,
          descending
        }
      } ).toPromise();
      return data;
    } else {
      const url = URLS[env].ADMIN_MANAGER + '/usuarios';
      const data = await this.http.get<modelos.RespuestaArray>( url, {
        params: {
          idempresa,
          param,
          descending
        }
      } ).toPromise();
      return data;
    }

  }

  async nuevoUsuario(usuario) {
    const url = URLS[env].ADMIN_MANAGER + '/usuarios/registrar';
    const data = await this.http.post<modelos.RespuestaDato>( url, usuario ).toPromise();
    return data;
  }

  async editarUsuario(id, usuarioAEditar) {
    const url = URLS[env].ADMIN_MANAGER + '/usuarios/' + id;
    const data = await this.http.put<modelos.RespuestaDato>(url, usuarioAEditar).toPromise();
    return data;
  }

  async cambiarEstadoUsuario(id) {
    const url = URLS[env].ADMIN_MANAGER + '/usuarios/estado/' + id;
    const data = await this.http.put<modelos.RespuestaDato>( url, null ).toPromise();
    return data;
  }


  async getLineasProduccion(param, descending, companyId) {
    const url = URLS[env].ADMIN_MANAGER + '/lineaproduccion';
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        param,
        descending,
        ... (companyId && { companyId })
      }
    } ).toPromise();
    return data;
  }

  async getLineaPorId(idlineaproduccion) {
    const url = URLS[env].ADMIN_MANAGER + '/lineaproduccion/' + idlineaproduccion;
    const data = await this.http.get<modelos.RespuestaDato>( url ).toPromise();
    return data;
  }

  async getLineasPorEmpresa(param, descending, idempresa) {
    console.log(idempresa);
    const url = URLS[env].ADMIN_MANAGER + '/lineaproduccion/empresa/' + idempresa;
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        param,
        descending
      }
    } ).toPromise();
    return data;
  }

  async crearLineaProduccion(lineaProduccion) {
    const url = URLS[env].ADMIN_MANAGER + '/lineaproduccion';
    const data = await this.http.post<modelos.RespuestaDato>( url, lineaProduccion ).toPromise();
    return data;
  }

  async editarLineaProduccion(idlineaproduccion, lineaProduccion) {
    const url = URLS[env].ADMIN_MANAGER + '/lineaproduccion/' + idlineaproduccion;
    const data = await this.http.put<modelos.RespuestaDato>( url, lineaProduccion ).toPromise();
    return data;
  }

  async cambiarEstadoLineaProduccion(idlineaproduccion) {
    const url = URLS[env].ADMIN_MANAGER + '/lineaproduccion/estado/' + idlineaproduccion;
    const data = await this.http.put<modelos.RespuestaDato>( url, null ).toPromise();
    return data;
  }


  async getEquipos(param, descending) {
    const url = URLS[env].ADMIN_MANAGER + '/equipo';
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        param,
        descending
      }
    } ).toPromise();
    return data;
  }

  async getEquiposPorLineaProduccion(idlineaproduccion, param, descending) {
    const url = URLS[env].ADMIN_MANAGER + '/equipo';
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        param,
        descending,
        idlineaproduccion
      }
    } ).toPromise();
    return data;
  }

  async getEquiposPorEmpresa(idempresa, param, descending) {
    const url = URLS[env].ADMIN_MANAGER + '/equipo';
    const data = await this.http.get<modelos.RespuestaArray>( url, {
      params: {
        param,
        descending,
        idempresa
      }
    } ).toPromise();
    return data;
  }

  async crearEquipo(body) {
    const url = URLS[env].ADMIN_MANAGER + '/equipo';
    const data = await this.http.post<modelos.RespuestaDato>( url, body ).toPromise();
    return data;
  }

  /************************************ */


/*
  deleteElement(tipo, id){
    let url = URLS[env].SERVICIOS + `/${tipo}/${id}`;
    let body: any;
    return this.http.delete( url, body).pipe(
      map( ( resp: any ) => resp )
    );
  }

  updateElement(tipo, id, newData){
    let url = URLS[env].SERVICIOS + `/${tipo}/${id}`;
    return this.http.put( url, newData ).pipe(
      map( ( resp: any ) => resp )
    );
  }*/
}


