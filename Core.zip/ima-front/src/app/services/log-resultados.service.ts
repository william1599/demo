import { Injectable, OnDestroy } from '@angular/core';
import { Observable, timer, Subscription, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { switchMap, tap, share, retry, takeUntil } from 'rxjs/operators';
import { env,URLS } from '../config/config';
import * as modelos from 'src/app/models/respuesta.model'

@Injectable()
export class ResultadosService implements OnDestroy {
    private resultados$: Observable<modelos.RespuestaDato>;
    private stopPolling = new Subject();
    private limit = 10;
    private offset = 0;    
    private idmodelo:number;
    private url:string;
    
    
    constructor(private _http: HttpClient) {   
        console.log("Objeto instanciado");     
    }
    
    start(idmodelo:number){
        this.url = URLS[env].MODELS_MANAGER+'/train/result/'+idmodelo+'?limit='+this.limit+'&offset='+this.offset;
        console.log("Iniciando servicio en url "+this.url);

        this.idmodelo = idmodelo;
        this.resultados$ = timer(1,10000).pipe(
            switchMap(() => this._http.get<modelos.RespuestaDato>(this.url)),            
            retry(),
            tap((x)=>console.log("datos recibidos")),
            share(),
            takeUntil(this.stopPolling)
        );
    }
    restart(){
        this.stop();
        this.start(this.idmodelo);
        return this.getResultados();
    }
    stop(){
        console.log("Parando servicio de log de resultados de "+this.idmodelo);
        this.stopPolling.next();
    }
    getResultados(): Observable<modelos.RespuestaDato> {
        console.log("pidiendo resultados");
        return this.resultados$;
        //return this.modelos$.pipe(tap(() => console.log('data sent to subscriber')));
    }
    setLimit(limit:number){
        this.limit = limit;
    }
    setOffset(offset:number){
        this.offset = offset;
    }    
    setUrl(idmodelo, limit, offset){
        this.url = URLS[env].TRAIN_MANAGER+'/train/result/'+idmodelo+'?limit='+limit+'&offset='+offset;
    }
    ngOnDestroy() {
        this.stop();
    }
}