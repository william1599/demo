// excel-export.service.ts

import { utils as XLSXUtils, writeFile } from 'xlsx';
import { WorkBook } from 'xlsx';

import { Injectable } from '@angular/core';

export interface IExportAsExcelProps {
  readonly data: any[];
  readonly fileName: string;
  readonly sheetName?: string;
  readonly header?: string[];
  readonly table?: HTMLElement;
}

@Injectable({
  providedIn: 'root'
})
export class ExcelExportService {
  fileExtension = '.xlsx';
  actualWb: WorkBook;
  public exportAsExcel({
    data,
    fileName,
    title,
    date,
    creacion,
    comments,
    username,
    email,
    sheetName = 'Data',
    header = [],
    archivos
  }): void {
    const wb = XLSXUtils.book_new();
    const fechaCreacion = new Date();
    wb.Props = {
      Title: fileName,
      Subject: 'Prediccion',
      Author: 'QM2Gain',
      CreatedDate: fechaCreacion
    };
    sheetName = sheetName.substr(0, 30);
    wb.SheetNames.push(sheetName);
    const ws_data = [];
    ws_data.push(['Titulo', title]);
    ws_data.push(['Historial de mantenimiento', archivos.historial_mantenimiento]);
    ws_data.push(['Actualizacion de producción reciente', archivos.historial_produccion]);
    ws_data.push(['Planificacion', archivos.planificacion]);
    ws_data.push(['Fecha de predicción', date]);
    ws_data.push(['Fecha de exportación', creacion]);
    ws_data.push(['Comentarios', comments]);
    ws_data.push(['Usuario', username, email]);
    if (header.length > 0) {
      ws_data.push(header);
    }
    for (const d of data) {
      const temp = [];
      for (const key in d) {
        temp.push(d[key]);
      }
      ws_data.push(temp);
    }
    console.log(ws_data);

    const ws = XLSXUtils.aoa_to_sheet(ws_data);
    wb.Sheets[sheetName] = ws;

    writeFile(wb, `${fileName}${this.fileExtension}`);
  }

  public newWorkBook(fileName: string, fechaCreacion: Date) {
    this.actualWb = XLSXUtils.book_new();
    this.actualWb.Props = {
      Title: fileName,
      Subject: 'Prediccion',
      Author: 'QM2Gain',
      CreatedDate: fechaCreacion
    };
  }

  public exportActualWorkBook() {
    writeFile(this.actualWb, `${this.actualWb.Props.Title}${this.fileExtension}`);
  }

  public createSheet(
    sheetName: string,
    data: Array<any>,
    date: string,
    creacion: string,
    title: string,
    comments: string,
    username: string,
    email: string,
    header = [],
    archivos: {historial_mantenimiento: string,
      historial_produccion: string,
      planificacion: string}
  ) {
    sheetName = sheetName.substr(0, 30);
    this.actualWb.SheetNames.push(sheetName);
    const ws_data = [];
    ws_data.push(['Titulo', title]);
    ws_data.push(['Historial de mantenimiento', archivos.historial_mantenimiento]);
    ws_data.push(['Actualizacion de producción reciente', archivos.historial_produccion]);
    ws_data.push(['Planificacion', archivos.planificacion]);
    ws_data.push(['Fecha de predicción', date]);
    ws_data.push(['Fecha de exportación', creacion]);
    ws_data.push(['Comentarios', comments]);
    ws_data.push(['Usuario', username, email]);
    if (header.length > 0) {
      ws_data.push(header);
    }
    for (const d of data) {
      const temp = [];
      for (const key in d) {
        temp.push(d[key]);
      }
      ws_data.push(temp);
    }
    const ws = XLSXUtils.aoa_to_sheet(ws_data);
    ws['!cols'] = fitToColumn(ws_data);

    function fitToColumn(arrayOfArray) {
      // get maximum character of each column
      return arrayOfArray[0].map((a, i) => ({ wch: Math.max(...arrayOfArray.map(a2 => a2[i] ? a2[i].toString().length : 0)) }));
    }

    this.actualWb.Sheets[sheetName] = ws;
  }


  public exportHistorial({
    data,
    fileName,
    title,
    dateString,
    fechas,
    nombres,
    historial_mantenimiento,
    historial_produccion,
    planificacion,
    username,
    email,
    sheetName,
    header = []
  }) {
    const wb = XLSXUtils.book_new();
    wb.Props = {
      Title: fileName,
      Subject: 'Historial de prediccion',
      Author: 'QM2Gain',
      CreatedDate: new Date()
    };
    sheetName = String(sheetName).substr(0, 30);
    wb.SheetNames.push(sheetName);
    const ws_data = [];

    ws_data.push(['Titulo', title]);
    ws_data.push(['Fecha de exportación', dateString]);
    ws_data.push(['Usuario', username, email]);


    if (header.length > 0) {
      header.unshift('Nombre de la prediccion');
      header.unshift('Fecha');
      header.push('Historial de mantenimiento');
      header.push('Actualización de produccion');
      header.push('Planificacion');
      ws_data.push(header);
    }

    for (const i in data) {
      const tmp = data[i];
      tmp.unshift(nombres[i]);
      tmp.unshift(fechas[i]);
      tmp.push(historial_mantenimiento[i]);
      tmp.push(historial_produccion[i]);
      tmp.push(planificacion[i]);
      ws_data.push(tmp);
    }


    const ws = XLSXUtils.aoa_to_sheet(ws_data);
    wb.Sheets[sheetName] = ws;

    writeFile(wb, `${fileName}${this.fileExtension}`);
  }

  public createSheetLogs(
    sheetName: string,
    data: any,
    arqName: string,
    trainConfig: string,
    trainingDate: string,
    username: string,
    email: string,
    header = []
  ) {
    console.log('Los datos son: ', data);
    sheetName = sheetName.substr(0, 30);
    this.actualWb.SheetNames.push(sheetName);
    const ws_data = [];
    ws_data.push(['Fecha del entrenamiento', trainingDate]);
    ws_data.push(['Arquitectura utilizada', arqName]);
    ws_data.push(['Configuración utilizada', trainConfig]);
    ws_data.push(['Usuario', username, email]);
    if (header.length > 0) {
      ws_data.push(header);
    }

    for (const d of data) {
      const temp = [];
      for (const value of d['valor']) {
        temp.push(value);
      }
      ws_data.push(temp);
    }
    const ws = XLSXUtils.aoa_to_sheet(ws_data);
    this.actualWb.Sheets[sheetName] = ws;
  }

  public createSheetQuality(
    sheetName: string,
    data: Array<any>,
    date: string,
    creacion: string,
    title: string,
    comments: string,
    username: string,
    email: string,
    header = [],
    config = []
  ) {
    sheetName = sheetName.substr(0, 30);
    this.actualWb.SheetNames.push(sheetName);
    const ws_data = [];
    ws_data.push(['Titulo', title]);
    ws_data.push(['Fecha de predicción', date]);
    ws_data.push(['Fecha de exportación', creacion]);
    ws_data.push(['Comentarios', comments]);
    ws_data.push(['Usuario', username, email]);
    ws_data.push(['\n']);
    ws_data.push(['Configuración']);
    ws_data.push(['\n']);
    for (const conf of config) {
      ws_data.push(conf);
    }
    ws_data.push(['\n']);
    ws_data.push(['Resultados']);
    ws_data.push(['\n']);
    for (const head of header) {
      for (const d of data) {
        for (const key in d) {
          ws_data.push([head, d[key]]);
        }
      }
    }

    const ws = XLSXUtils.aoa_to_sheet(ws_data);
    this.actualWb.Sheets[sheetName] = ws;
  }

  public createSheetOptimizer(sheetName, data, dates, title, comments, headers, limits, config, usernames, usermails) {
    console.log("header en create: ", headers);
    console.log("data en create: ", data);
    console.log("data en createaa: ", limits);
    console.log("titulos en createaa: ", title);

    console.log("Limites: ", limits);
    sheetName = sheetName.substr(0, 30);
    this.actualWb.SheetNames.push(sheetName);
    const ws_data = [];
    
    title.unshift('Orden de producción')
    ws_data.push(title);

    dates.unshift('Fecha de predicción');
    ws_data.push(dates);

    usernames.unshift('Usuarios');
    ws_data.push(usernames);

    usermails.unshift('Correos');
    ws_data.push(usermails);

    ws_data.push(['\n']);
    ws_data.push(['Configuración']);
    ws_data.push(['\n']);
    let finalConf = [];
    let confLength;
    confLength = config[0]?.configName.length;

    for(let i = 0; i < confLength; i++) {
      let lists = [];
      finalConf.push(lists);
    }
    for(let conf of config) {
      confLength = conf.configName.length;
      


      for(let i = 0; i < confLength; i++) {
        finalConf[i].push(conf.values[i]);
        finalConf[i].push(' ');
      }
    }

    for(let i = 0; i < confLength; i++) {
      finalConf[i].unshift(config[0].configName[i]);
    }

    // finalConf.push([' ']);
    for(let confTmp of finalConf) {
      ws_data.push(confTmp);
    }

    ws_data.push(['\n']);
    ws_data.push(['Resultados']);
    ws_data.push(['\n']);

    let finalRes = [];
    let resLength;
    resLength = data[0]?.length;
    console.log("RESLEN: ", resLength);

    for(let i = 0; i < resLength; i++) {
      let tmpList = [];
      finalRes.push(tmpList);
    }

    for(let res of data) {
      for(let i = 0; i < resLength; i++) {
        // finalRes[i].push(res[i].name);
        finalRes[i].push(res[i].value.toFixed(1));
        finalRes[i].push(' ');
      }
    }

    for(let i = 0; i < resLength; i++) {
      finalRes[i].unshift(data[0][i].name);
    }

    for(let resTmp of finalRes) {
      ws_data.push(resTmp);
    }

    console.log("limites en create: ", limits);
    console.log("len en create: ", limits[0]?.length);

    ws_data.push(['\n']);
    ws_data.push(['Límites'])
    ws_data.push(['\n']);
    const limitLen = limits[0]?.length;
    let finalLimits = [];
    let limitHeader = [''];
    for(let i = 0; i < limitLen; i++) {
      let lists = [];
      lists.push(limits[0][i]?.parametro?.etiqueta)
      finalLimits.push(lists);
    }

    for(let i = 0; i < data?.length; i++) {
      limitHeader.push('Mínimo');
      limitHeader.push('Máximo');
      // limitHeader.push(' ');
      // limitHeader.push(' ');
    }

    for(let limTmp of limits) {
        for(let i = 0; i < limitLen; i++) {
          finalLimits[i].push(limTmp[i]?.minimo);
          finalLimits[i].push(limTmp[i]?.maximo);
          // finalLimits[i].push(' ');
          // finalLimits[i].push(' ');
        }
    }

    ws_data.push(limitHeader);
    ws_data.push(['\n']);

    for(let finLimTmp of finalLimits) {
      ws_data.push(finLimTmp);
    }

    ws_data.push(['\n']);
    comments.unshift('Comentarios');
    ws_data.push(comments);

    const ws = XLSXUtils.aoa_to_sheet(ws_data);
    // ws['!cols'] = fitToColumn(ws_data);

    // function fitToColumn(arrayOfArray) {
    //   // get maximum character of each column
    //   return arrayOfArray[0].map((a, i) => ({ wch: Math.max(...arrayOfArray.map(a2 => a2[i] ? a2[i].toString().length : 0)) }));
    // }
    
    this.actualWb.Sheets[sheetName] = ws;
  }


}
