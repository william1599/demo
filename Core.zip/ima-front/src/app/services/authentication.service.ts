import { Injectable } from '@angular/core';
import { ApiRestService } from './api-rest.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../models/user';
import { Router } from '@angular/router';


@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    //private currentUserSubject: BehaviorSubject<User>;
    private currentUser: User;
    private localStorageVar = "currentUser";

    constructor(
        private _apiRestService: ApiRestService,
        private router:Router) {
        //this.currentUserSubject = new BehaviorSubject<User>(null);
        //this.currentUserSubject.subscribe(this.update);
        //this.currentUser = this.currentUserSubject.asObservable();
        console.log("CREADO!!!!!!")
    }

    public get currentUserValue(): User {
        return JSON.parse(localStorage.getItem(this.localStorageVar));
    }

    private update(user){
        this.currentUser = user;
    }

    async login(email: string, password: string) {
      console.log("Entre al login")
        const resp = await this._apiRestService.login({email:email, password: password});
        if(resp.status == 200){
            localStorage.setItem(this.localStorageVar, JSON.stringify(resp.dato));
            //this.currentUserSubject.next(resp.dato);
        }
        console.log("La respuesta del login es: ", resp)
        return resp;
    }

    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem(this.localStorageVar);
        //this.currentUserSubject.next(null);
        this.router.navigate(['/login']);
    }

    /*refreshToken(){
        localStorage.getItem(this.localStorageVar);
    }*/
}
