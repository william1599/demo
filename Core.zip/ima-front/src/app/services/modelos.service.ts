import { Injectable, OnDestroy } from '@angular/core';
import { Observable, timer, Subscription, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { switchMap, tap, share, retry, takeUntil } from 'rxjs/operators';
import { Modelo } from 'src/app/models/modelo'
import { env,URLS } from '../config/config';
import * as modelos from 'src/app/models/respuesta.model'

@Injectable()
export class ModelosService implements OnDestroy {
    private modelos$: Observable<modelos.RespuestaArray>;
    private stopPolling = new Subject();
    private limit = 100;
    private offset = 0;
    constructor(private http: HttpClient) {

    }
    getModelos(param, descending, idservicio, status): Observable<modelos.RespuestaArray> {
        //console.log('Los modelos son: ', this.modelos$)
        this.modelos$ = timer(1, 10000).pipe(
          switchMap(() => this.http.get<modelos.RespuestaArray>(URLS[env].MODELS_MANAGER+'/modelo'+'?limit='+this.limit+'&offset='+this.offset, {
            params: {
              param,
              descending,
              idservicio,
              ... (status && { status })
            }
          })),
          retry(),
          //tap(console.log),
          share(),
          takeUntil(this.stopPolling)
        );
        //console.log("Modelos son", this.modelos$)
        return this.modelos$;
        //return this.modelos$.pipe(tap(() => console.log('data sent to subscriber')));
    }
    setLimit(limit:number){
        this.limit = limit;
    }
    setOffset(offset:number){
        this.offset = offset;
    }
    ngOnDestroy() {
        this.stopPolling.next();
    }
}
