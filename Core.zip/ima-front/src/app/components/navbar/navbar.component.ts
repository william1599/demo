import { Component, OnInit, ElementRef } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { version } from 'src/app/config/config';

import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  public home:string;
  public user:any;
  public ver = version;
  public ambiente = environment.production;
  constructor(
    private _authenticationService:AuthenticationService) {
  }

  ngOnInit() {
    let CLIENTES = ["ADMIN-EMPRESA","ING-PLANTA"];
    console.log(this._authenticationService.currentUserValue);
    this.user = this._authenticationService.currentUserValue;
    //let rol = this._authenticationService.currentUserValue.rol;
    //console.log(CLIENTES.includes(rol));
    this.home = (CLIENTES.includes(this.user.rol))?"/servicios":"/empresas";
  }
  logout(){
    console.log("salir!")
    this._authenticationService.logout();
  }
}
