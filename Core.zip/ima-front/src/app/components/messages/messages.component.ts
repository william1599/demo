import { Component , TemplateRef} from '@angular/core';
import { MessageService } from 'src/app/services/messages.service';

@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.css'],
  host: {'[class.ngb-toasts]': 'true'}
})
export class MessagesComponent  {

  constructor(public messageService: MessageService) {}

  isTemplate(message) { return message.textOrTpl instanceof TemplateRef; }


}


