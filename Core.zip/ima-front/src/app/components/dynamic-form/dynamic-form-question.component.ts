import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { QuestionBase } from '../../models/question-models/question-base';

@Component({
  selector: 'app-question',
  templateUrl: './dynamic-form-question.component.html'
})
export class DynamicFormQuestionComponent {
  @Input() public question: QuestionBase<string>;
  @Input() public genericForm: FormGroup;
  get isValid() { return this.genericForm.controls[this.question.key].valid; }
}