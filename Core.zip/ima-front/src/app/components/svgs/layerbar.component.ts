import { Component, Input } from '@angular/core';

@Component({
  selector: 'layerbar',
  templateUrl: './layerbar.component.svg'
})
export class LayerBarComponent {
  @Input()
  get color(): string { return this._color; }
  set color(color: string) {
    this._color = (color && color.trim());
  }
  private _color = '';
  private capas:any[];
  private WIDTH:number;
  private HEIGHT:number;

  private ancho:number;
  private alto:number;

  constructor(){
    this.WIDTH = 600;
    this.HEIGHT = 80;
  }

  addLight = (color, amount)=>{
    let cc = parseInt(color,16) + amount;
    let c = (cc > 255) ? 255 : (cc);
    c = (c.toString(16).length > 1 ) ? c.toString(16) : `0${c.toString(16)}`;
    return c;
  }
  
  /* Aclara un color hexadecimal de 6 caracteres #RRGGBB segun el porcentaje indicado */
  lighten = (color, amount)=> {
    color = (color.indexOf("#")>=0) ? color.substring(1,color.length) : color;
    amount = Math.trunc((255*amount)/100);
    return color = `#${this.addLight(color.substring(0,2), amount)}${this.addLight(color.substring(2,4), amount)}${this.addLight(color.substring(4,6), amount)}`;
  }
  
  /* Resta el porcentaje indicado a un color (RR, GG o BB) hexadecimal para oscurecerlo */
  subtractLight = (color, amount)=>{
    let cc = parseInt(color,16) - amount;
    let c = (cc < 0) ? 0 : (cc);
    let strc = (c.toString(16).length > 1 ) ? c.toString(16) : `0${c.toString(16)}`;
    return strc;
  }
  
  /* Oscurece un color hexadecimal de 6 caracteres #RRGGBB segun el porcentaje indicado */
  darken = (color, amount) =>{
    color = (color.indexOf("#")>=0) ? color.substring(1,color.length) : color;
    amount = Math.trunc((255*amount)/100);
    return color = `#${this.subtractLight(color.substring(0,2), amount)}${this.subtractLight(color.substring(2,4), amount)}${this.subtractLight(color.substring(4,6), amount)}`;
  }

  stopColor(tipo, color){
      switch(tipo){        
        case "light":
            return "stop-color:"+this.lighten(color,10);
        case "dark":
            return "stop-color:"+this.darken(color,10);
        default:
            return "stop-color:"+color;
      }
  }
}