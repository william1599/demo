import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { Empresa } from 'src/app/services/empresa-actual.service';
import { ApiRestService } from 'src/app/services/api-rest.service';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-middlebar',
  templateUrl: './middlebar.component.html',
  styleUrls: ['./middlebar.component.scss']
})
export class MiddlebarComponent implements OnInit {
  @Input()
  get idservicio():string{ return this._idservicio }
  set idservicio(id:string){
    this._idservicio = id;    
  }
  private _idservicio:string;
  @Input()
  get active():string{ return this._active }
  set active(active:string){
    this._active = active;    
  }  
  private _active:string;  
  @Input()
  get empresa():Empresa{ return this._empresa }
  set empresa(empresa:Empresa){
    this._empresa = empresa;    
  }
  private _empresa:Empresa=null;
  public _servicio;
  public _usuario;
  constructor(
    private _apiRestService:ApiRestService,
    private _authenticationService:AuthenticationService,
    private router: Router,
    private location:Location) { }

  ngOnInit() {
    this.getServicio();
    this._usuario = this._authenticationService.currentUserValue;
  }
  async getServicio(){
    let resp = await this._apiRestService.getServicio(this.idservicio);
    if(resp.ok){
      this._servicio = resp.dato;
      this.empresa = resp.dato.empresa;
    }
  }
}
