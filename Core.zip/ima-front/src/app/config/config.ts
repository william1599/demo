/*********************************/
/***** URL API REST ****/
/*********************************/
import { environment } from 'src/environments/environment';
/* DEVELOP*/
export const version = 'v0.9';
export const env = environment.production;
export const URLS = {
    develop: {
        TRAIN_MANAGER : 'http://localhost:3112',
        APP_MANAGER : 'http://localhost:3114',
        APP_FLASK: 'http://localhost:5000',
        FORECAST_MANAGER: 'http://localhost:3018',
        COLLECTION_MANAGER: 'http://localhost:3115',
        MODELS_MANAGER: 'http://localhost:3117',
        ARQUITECTURES_MANAGER: 'http://localhost:3116',
        ADMIN_MANAGER: 'http://localhost:3119'
    },
    production: {
        TRAIN_MANAGER : 'http://158.170.66.171/trainmanager',
        APP_MANAGER : 'http://158.170.66.171/appmanager',
        APP_FLASK: 'http://158.170.66.171',
        FORECAST_MANAGER: 'http://158.170.66.171/predictionmanager',
        COLLECTION_MANAGER: 'http://158.170.66.171/collectionmanager',
        MODELS_MANAGER: 'http://158.170.66.171/trainingmanager',
        ARQUITECTURES_MANAGER: 'http://158.170.66.171/arquitecturemanager',
        ADMIN_MANAGER: 'http://158.170.66.171/adminmanager'
    },
    desarrollo_servidor: {
        TRAIN_MANAGER : 'http://158.170.66.171/api/desarrollo/trainmanager',
        APP_MANAGER : 'http://158.170.66.171/api/desarrollo/appmanager',
        APP_FLASK: 'http://158.170.66.171',
        FORECAST_MANAGER: 'http://158.170.66.171/api/desarrollo/predictionmanager',
        COLLECTION_MANAGER: 'http://158.170.66.171/api/desarrollo/collectionmanager',
        MODELS_MANAGER: 'http://158.170.66.171/api/desarrollo/trainingmanager',
        ARQUITECTURES_MANAGER: 'http://158.170.66.171/api/desarrollo/arquitecturemanager',
        ADMIN_MANAGER: 'http://158.170.66.171/api/desarrollo/adminmanager'

    }
};


