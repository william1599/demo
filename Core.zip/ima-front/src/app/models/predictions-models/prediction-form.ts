export class PredictionsBase<T> {
  value: any;
  key: string|number;
  label: string;
  required: boolean;
  order: number;
  controlType: string;
  type: string;
  min: number;
  max: number;
  unidad: string;
  descripcion: string;
  options: {key: string, value: string}[];
  gridClass: string;
  idparametros: number;
  isOutput: any;
  esConstante: any;
  optimizerMin: number;
  optimizerMax: number;

  constructor(options: {
      value?: any;
      key?: string;
      label?: string;
      min?: number;
      max?: number;
      required?: boolean;
      order?: number;
      controlType?: string;
      type?: string;
      options?: {key: string, value: string}[];
      unidad?: string;
      descripcion?: string;
      gridClass?: string;
      idparametros?: number;
      isOutput?: any;
      esConstante?: any;
      optimizerMin?: any;
      optimizerMax?: any;
    } = {}) {
    this.value = options.value;
    this.key = options.key || '';
    this.label = options.label || '';
    this.required = !!options.required;
    this.order = options.order === undefined ? 1 : options.order;
    this.controlType = options.controlType || '';
    this.type = options.type || '';
    this.options = options.options || [];
    this.min = options.min;
    this.max = options.max;
    this.unidad = options.unidad;
    this.descripcion = options.descripcion;
    this.gridClass = options.gridClass;
    this.idparametros = options.idparametros;
    this.isOutput = options.isOutput;
    this.esConstante = options.esConstante;
    this.optimizerMax = options.optimizerMax;
    this.optimizerMin = options.optimizerMin;
  }
}
