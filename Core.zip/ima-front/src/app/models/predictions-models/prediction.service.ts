import { Injectable } from '@angular/core';
import {of, Subject} from 'rxjs';
import { ApiRestService } from 'src/app/services/api-rest.service';
import { PredictionDropdown } from './prediction-dropdown';
import { PredictionsBase } from './prediction-form';
import { TextboxPrediction } from './prediction-textbox';


@Injectable( {providedIn: 'root'} )
export class PredictionService {

  constructor(private _apiRestService: ApiRestService) {
    this.predictions = [];
  }
  predictionChanged = new Subject();
  private predictions: PredictionsBase<string>[] = [
  ];
  private predictionDB = [];

  getPredictions() {
    console.log('ENTRE AL GET PREDICTIONSSSSSSSS');
    console.log('PREDICTIONS: ', this.predictions);
    return of(this.predictions.sort((a, b) => a.order - b.order));
    // return this.predictions.sort((a, b) => a.order - b.order)
  }

  getPredictions2() {
    return this.predictions.sort((a, b) => a.order - b.order);
  }

  async updatePrediction(idmodelo) {
    console.log("ENTRE AL UPDATE")
    await this.getModelVariables(idmodelo, true, 'false', 'false');
    this.predictionChanged.next(this.predictionDB.slice());
  }

  async updateMinAndMaxOfPredictions(predBody) {
    const resp = await this._apiRestService.editMinAndMaxOfVariables(predBody);

    if(resp.ok) {
      return true;
    }
    return false;
  }

  addPrediction(prediction) {
    console.log("AAA");
    let parameter = null;
    if (prediction.type === 'number') {
      parameter = new TextboxPrediction({
        key: prediction.key,
        label: prediction.name,
        type: prediction.type,
        value: prediction.value,
        min: prediction.min,
        max: prediction.max,
        required: true,
        order: 1
      });
    } else if (prediction.type === 'text') {
      console.log('TIPO: ', prediction.type);
      parameter = new TextboxPrediction({
        key: prediction.key,
        label: prediction.name,
        type: prediction.type,
        value: prediction.value,
        min: prediction.min,
        max: prediction.max,
        required: true,
        order: 2
      });
    } else {
      const finalOptions = [];

      for (const opt of prediction.options) {
        const tmpObj = {};

        tmpObj['key'] = opt;
        tmpObj['value'] = opt;
        finalOptions.push(tmpObj);

      }

      parameter = new PredictionDropdown({
        key: prediction.key,
        label: prediction.name,
        options: finalOptions,
        order: 3,
        required: true
      });
    }

    this.predictions.push(parameter);
    console.log('Estoy en el servicio', this.predictions);
    // this.predictions.push(...prediction)
  }

  async getModelVarFromDB(idmodelo, enabled, output) {
    const resp = await this._apiRestService.getModelVariables(idmodelo, enabled, output, 'false');
    if (resp.ok) {
      this.predictionDB = resp.datos;
      this.predictionChanged.next(this.predictionDB.slice());
      return this.predictionDB;
    } else {
      console.log('ERROR');
    }
    this.predictionChanged.next(this.predictionDB.slice());
  }

  async getModelVariables(idmodelo, enabled, isOutput, isConst) {
    this.predictions = [];
    const resp = await this._apiRestService.getModelVariables(idmodelo, enabled, isOutput, isConst);
    if (resp.ok) {
      const variables = resp.datos;
      this.predictionDB = resp.datos;
      console.log('MODEL VARIABLES: ', variables);
      if (variables.length <= 0) {
        this.predictions = [];
      }

      for (let i = 0; i < variables.length; i++) {
        const variable = variables[i];
        if (variable.tipo === 'number' || variable.tipo === 'text') {
          this.predictions.push(new TextboxPrediction({
            key: variable.dato_coleccion?.nombre,
            label: variable.etiqueta,
            type: variable.tipo,
            value: variable.valor,
            min: variable.dato_coleccion?.min,
            max: variable.dato_coleccion?.max,
            optimizerMin: variable.minimo,
            optimizerMax: variable.maximo,
            order: variable.orden,
            unidad: variable.unidad,
            descripcion: variable.descripcion,
            gridClass: variable.gridClass,
            idparametros: variable.idparametros,
            isOutput: variable.isOutput,
            esConstante: variable.esConstante
          }));
        } else if (variable.tipo === 'file') {
          this.predictions.push(new TextboxPrediction({
            key: variable.llave,
            label: variable.etiqueta,
            type: variable.tipo,
            value: variable.valor,
            order: variable.orden,
            unidad: variable.unidad,
            optimizerMin: variable.minimo,
            optimizerMax: variable.maximo,
            descripcion: variable.descripcion,
            idparametros: variable.idparametros,
            isOutput: variable.isOutput,
            esConstante: variable.esConstante
          }));
        } else if (variable.controlType === 'select') {
          console.log('ENTRE AL SELECT AAAAAAAAAA');
          console.log(variable);
          const resp = await this._apiRestService.getOptions(variable.idparametros);
          console.log('OPCIONES: ', resp);
          console.log('OPCIOENS PARSE: ', typeof JSON.parse(variable.opciones));
          console.log('OPCIOENS PARSE: ', JSON.parse(variable.opciones));

          const tmpOptions = [];

          for (const opt of resp.datos) {
            const tmpObj = {};
            tmpObj['key'] = opt['nombre'];
            tmpObj['value'] = opt['nombre'];
            tmpOptions.push(tmpObj);
          }

          this.predictions.push(new PredictionDropdown({
            key: variable.llave,
            label: variable.etiqueta,
            options: tmpOptions,
            order: 1,
            descripcion: variable.descripcion,
            idparametros: variable.idparametros,
            optimizerMin: variable.minimo,
            optimizerMax: variable.maximo,
            isOutput: variable.isOutput,
            esConstante: variable.esConstante
          }));
        } else if (variable.tipo == 'range') {
          this.predictions.push(new TextboxPrediction({
            key: variable.llave,
            label: variable.etiqueta,
            type: variable.tipo,
            value: variable.valor,
            order: variable.orden,
            min: variable.minimo,
            max: variable.maximo,
            optimizerMin: variable.minimo,
            optimizerMax: variable.maximo,
            descripcion: variable.descripcion,
            gridClass: variable.gridClass,
            idparametros: variable.idparametros,
            isOutput: variable.isOutput,
            esConstante: variable.esConstante
          }));
        }

      }

    } else {
      console.log('Error al obtener variables');
    }
    return this.predictions;
  }

}
