import { PredictionsBase } from "./prediction-form";


export class TextboxPrediction extends PredictionsBase<string> {
  controlType = 'textbox';
}
