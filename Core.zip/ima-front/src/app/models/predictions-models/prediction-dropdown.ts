import { PredictionsBase } from "./prediction-form";

export class PredictionDropdown extends PredictionsBase<string> {

  controlType = 'dropdown';
}
