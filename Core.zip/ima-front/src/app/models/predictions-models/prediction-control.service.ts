import { Injectable } from "@angular/core";
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import { PredictionsBase } from "./prediction-form";

@Injectable( { providedIn: 'root' } )
export class PredictionControlService {
  constructor() {

  }

  toFormGroup( predictions: PredictionsBase<string>[] ) {
    const group: any = {};
    console.log("PREDICTION$$$:", predictions);
    predictions.forEach( prediction => {
      //console.log("PRED: ", prediction)
      if (prediction.max || prediction.min) {
        group[prediction.key] = new FormControl(prediction.value || '', Validators.compose(
          [Validators.required, Validators.pattern('^\\d*\\.?\\d+$')]));
      } else {
        group[prediction.key] = new FormControl(prediction.value || '', Validators.compose(
          [Validators.required]));
      }
      group[prediction.key]['unidad'] = new FormControl(prediction.unidad);
    });

    console.log("GROUPPPPPPPPPPPP:", group);

    return new FormGroup(group);
  }
}
