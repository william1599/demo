export class QuestionBase<T> {
    value: T;
    key: string;
    label: string;
    required: boolean;
    order: number;
    controlType: string;
    type: string;
    options: {key: string, value: string}[];
    descripcion: string;

    constructor(options: {
        value?: T;
        key?: string;
        label?: string;
        required?: boolean;
        order?: number;
        controlType?: string;
        type?: string;
        options?: {key: string, value: string}[];
        descripcion?: string;
      } = {}) {
      this.value = options.value;
      this.key = options.key || '';
      this.label = options.label || '';
      this.required = !!options.required;
      this.order = options.order === undefined ? 1 : options.order;
      this.controlType = options.controlType || '';
      this.type = options.type || '';
      this.options = options.options || [];
      this.descripcion = options.descripcion || '';
    }

    addOption(option:{key: string, value: string}){
      if(! this.checkKey(option.key)){
        console.log(option.key+" agregada :D")
        this.options.unshift(option);
        console.log("Las opciones son: ", this.options)
      }
    }

    removeOption(key) {
      console.log("Key es: ", key)
      console.log("Antes option", this.options)
      for(let i in this.options) {
        if(this.options[i].key == key) {
          this.options.splice(parseInt(i), 1)
        }
      }
      console.log("Despues option: ", this.options)
    }

    checkKey(newkey:string){
      for(let i in this.options){
        if( this.options[i].key == newkey){
          return true;
        }
      }
      return false;
    }
  }
