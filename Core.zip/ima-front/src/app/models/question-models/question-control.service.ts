import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { QuestionBase } from './question-base';
import { TipoCapa } from 'src/app/models/tipocapa';

@Injectable()
export class QuestionControlService {
  constructor() { }

  inputsToFormGroup(tipo: TipoCapa ) {
    const group: any = {};    
    //inputs
    tipo.inputs.forEach(question =>{
      group[question.key] = question.required ? new FormControl(question.value || '', Validators.required)
                                            : new FormControl(question.value || '');
    })
    return new FormGroup(group);
  }
  settingsToFormGroup(tipo: TipoCapa ) {
    const group: any = {};
    //settings
    tipo.settings.forEach(question=>{
      group[question.key] = question.required ? new FormControl(question.value || '', Validators.required)
                                              : new FormControl(question.value || '');
    })
    return new FormGroup(group);
  }
}