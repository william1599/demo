export class RespuestaDato {
    constructor(
        public ok: boolean,
        public status : number,
        public message: string,        
        public error: string | null,
        public dato: any
    ){}
}
export class RespuestaArray {
    constructor(
        public ok: boolean,
        public status : number,
        public message: string,        
        public error: string | null,
        public datos: Array<any> | any
    ){}
}
export class RespuestaTipos {
    constructor(
        public ok: boolean,
        public status : number,
        public message: string,        
        public error: string | null,
        public tipos: Array<any>
    ){}
}
export class RespuestaResultados {
    constructor(    
        public ok: boolean,
        public status : number,
        public message: string,        
        public error: string | null,
        public resultado: Array<any>,
        public total:number
    ){}
}
export class RespuestaContador {
    constructor(    
        public ok: boolean,
        public status : number,
        public message: string,        
        public error: string | null,
        public total: number
    ){}
}

export class RespuestaColecciones {
    constructor(    
        public ok: boolean,
        public status : number,
        public message: string,        
        public error: string | null,    
        public colecciones: Array<any>      
    ){}
}

export class RespuestaArquitectura {
    constructor(    
        public ok: boolean,
        public status : number,
        public message: string,        
        public error: string | null,    
        public architectures: Array<any>      
    ){}
}

export class RespuestaModelos {
    constructor(    
        public ok: boolean,
        public status : number,
        public message: string,        
        public error: string | null,    
        public modelos: Array<any>      
    ){}
}
export class RespuestaModelo {
    constructor(    
        public ok: boolean,
        public status : number,
        public message: string,        
        public error: string | null,    
        public modelo: any
    ){}
}
export class RespuestaConfiguraciones {
    constructor(    
        public ok: boolean,
        public status : number,
        public message: string,        
        public error: string | null,    
        public configuraciones: Array<any>      
    ){}
}

export class RespuestaCrea {
    constructor(    
        public ok: boolean,
        public status : number,
        public message: string,        
        public error: string | null
    ){}
}

export class RespuestaAppmanager {
    constructor(    
        public pid: number,
        public exitCode : number | null,
        public killed: boolean,        
        public connected: string | null,
        public signalCode: string | null
    ){}
}