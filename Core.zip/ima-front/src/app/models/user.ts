export class User {
    idusuario?: number;
    email: string;
    nombres: string;
    apellidos: string;
    idempresa: number;
    habilitado: boolean;
    rol: string;
    jwt?: string;
    empresa?:any;
}
