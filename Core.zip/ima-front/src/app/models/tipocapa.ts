import { of } from 'rxjs';
import { QuestionBase } from './question-models/question-base';
export class TipoCapa{
    public idtipo: number;
    public layer_type : string;
    public trainable_parameters: object;
    public settings: QuestionBase<string>[];
    public inputs: QuestionBase<string>[];
    public outputs: Array<any>;
    public visible_name : string;
    public variable_name : string;
    public descripcion: string;
    constructor(index:number){
        this.idtipo = index;
    }
    setSettings(settings:QuestionBase<string>[]){
        this.settings = settings;
    }
    setInputs(inputs:QuestionBase<string>[]){
        this.inputs = inputs;
    }    
    setTrainableParameters(params:object){
        this.trainable_parameters = params;
    }
}