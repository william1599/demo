export interface EtlConfig {
  outputs: Array<any>,
  inputs: Array<any>,
  ranges: Array<any>,
  indexes: Array<any>
}
