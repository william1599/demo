export type Estados = 'CREADO'|'ENTRENANDO'|'ENTRENADO'|'EXPORTADO'|'CANCELADO';
export interface Modelo {    
    idmodelo: number,
    nombre : string,
    estado: Estados,    
    idconf: number,
    fecha: Date,
    trained_epochs: number ,
    stop : boolean,
    resultado: any,
    updatedAt: Date
}