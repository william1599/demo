export class FormCapa{
    idtipo:number;
    
}