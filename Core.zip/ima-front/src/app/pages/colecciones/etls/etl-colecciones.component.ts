import { ChangeDetectorRef, Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { Subscription } from "rxjs";
import { EtlConfig } from "src/app/models/ETL/etl-model";
import { ApiRestService } from "src/app/services/api-rest.service";
import { MessageService } from "src/app/services/messages.service";
import { animate, style, transition, trigger, query, stagger, state } from '@angular/animations';
import { Location } from "@angular/common";





@Component({
  selector: 'app-etl',
  templateUrl: './etl-colecciones.component.html',
  styleUrls: ['./etl-colecciones.component.css'],
  animations: [
    trigger("listAnimation", [
      transition("* => *", [
        // each time the binding value changes
        query(
          ":leave",
          [stagger(100, [animate("0.5s", style({ opacity: 0 }))])],
          { optional: true }
        ),
        query(
          ":enter",
          [
            style({ opacity: 0 }),
            stagger(100, [animate("0.5s", style({ opacity: 1 }))])
          ],
          { optional: true }
        )
      ])
    ]),
    trigger(
      'enterAnimation', [
        transition(':enter', [
          style({transform: 'translateX(-100px)', opacity: 0}),
          animate('300ms', style({transform: 'translateX(0)', opacity: 1, 'overflow-x': 'hidden'}))
        ]),
      ]
    ),
    trigger('slideIn', [
      state('*', style({ 'overflow-y': 'hidden' })),
      state('void', style({ 'overflow-y': 'hidden' })),
      transition('* => void', [
        style({ height: '*' }),
        animate(250, style({ height: 0 }))
      ]),
      transition('void => *', [
        style({ height: '0' }),
        animate(250, style({ height: '*' }))
      ])
    ])
  ]
})

export class ETLComponent implements OnInit {

  idservicio: any;
  _object = Object;
  idcoleccion: any;
  collection: any;
  refreshTable = true;
  datosColeccion: any;
  subscription: Subscription;
  headerDatos: any;
  actualHeaders: Array<String>;
  numberDatos: any;
  outputDatos: any;
  pageDatos = 1;
  rangesForm: FormGroup;
  pageSizeDatos = 50;
  columnasForm: FormGroup;
  salidasForm: FormGroup;
  indexForm: FormGroup;
  selectedColumns: Array<string>;
  selectedRanges: Array<string>;
  selectedIndexes: any;
  showEtlTable = true;
  etls: Array<any>;
  tensorForm: FormGroup;
  editTensorForm: FormGroup;
  etlToEdit: any;
  config: EtlConfig;
  collectionData: any;

  constructor(
    private _apiRestService: ApiRestService,
    private _route: ActivatedRoute,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private _messageService: MessageService,
    private changeDetection: ChangeDetectorRef,
    private location: Location
  ) {
    this.variablesInit()
    this.idservicio = this._route.snapshot.paramMap.get('idservicio');
    this.idcoleccion = this._route.snapshot.paramMap.get('idcoleccion');
    this.columnasForm = this.formBuilder.group({
      columns: new FormArray([])
    })
    this.rangesForm = this.formBuilder.group({
      ranges: new FormArray([])
    })
    this.salidasForm = this.formBuilder.group({
      outputs: new FormArray([])
    })
    this.indexForm = this.formBuilder.group({
      lower: ['', Validators.required],
      upper: ['', Validators.required]
    })
    this.tensorForm = this.formBuilder.group({
      name: ['', Validators.required]
    })
    this.editTensorForm = this.formBuilder.group({
      nombre: ['', Validators.required]
    })
    this.getCollection();
    //this.getInitialData();
    this.getCollectionData();
    this.getEtlsCollection();
  }

  ngOnInit(): void {
  }

  // Obtengo los controls del formArray de salidas
  get salidasForArray() {
    return this.salidasForm.controls.outputs as FormArray;
  }

  // Obtengo los controls del formArray de columnas
  get columnsForArray() {
    return this.columnasForm.controls.columns as FormArray;
  }

  // Obtengo los controls del formArray de rangos
  get rangesForArray() {
    return this.rangesForm.controls.ranges as FormArray;
  }

  // Elimino los items de rangos
  removeRangeItem(index) {
    if(index < this.rangesForArray.length - 1) {
      this.rangesForArray.removeAt(index);
    }
  }

  // Se agregan los checkboxes segun el header
  private addCheckboxes() {
    console.log("AGREGUE CHECK")
    this.headerDatos?.forEach((data) => {
      if(this.outputDatos.includes(data)) {
        this.columnsForArray.push(new FormControl(true))
      } else {
        this.columnsForArray.push(new FormControl(false))
      }
    })
  }

  // Se agregan los rangos segun las variables numericas del conjunto
  private agregarRanges() {
    this.numberDatos?.forEach((dato) => {
      this.rangesForArray.push(new FormGroup({
        name: new FormControl(dato),
        max: new FormControl(''),
        min: new FormControl('')
      }))
    })
  }

  // Se agregan las salidas
  private agregarOutputs() {
    this.outputDatos?.forEach(() => this.salidasForArray.push(new FormControl(false)))
  }

  // Función que selecciona las columnas a eliminar
  async inputsSelect(modal) {
    const columnasSeleccionadas = this.columnasForm.value.columns
      .map((checked, i) => !checked ? this.headerDatos[i] :null)
      .filter(v => v !== null)

    const selectInputs = this.columnasForm.value.columns
      .map((checked, i) => checked ? this.headerDatos[i]: null)
      .filter(v => v !== null)

    this.config['inputs'] = selectInputs;
    this.selectedColumns = columnasSeleccionadas;
    console.log('Config es: ', this.config)

    await this.getData(this.idcoleccion, JSON.stringify(this.selectedColumns), JSON.stringify(this.selectedRanges), JSON.stringify(this.selectedIndexes));
    modal.close();
    this._messageService.success('Operación realizada correctamente');
  }

  // Aplica los rangos seleccionados
  rangeApply(modal) {
    const selectedRange = this.rangesForm.value.ranges;
    console.log('selectedRanges: ', selectedRange);
    console.log('sdas', this.rangesForArray.controls);
    this.config['ranges'] = selectedRange;
    this.selectedRanges = selectedRange;

    this.getData(this.idcoleccion, JSON.stringify(this.selectedColumns), JSON.stringify(this.selectedRanges), JSON.stringify(this.selectedIndexes));
    this._messageService.success('Operación realizada correctamente');
    modal.close();
  }

  // Aplica los indices seleccionados
  indexApply(modal) {
    const selectedIndex =  this.indexForm.value;
    this.selectedIndexes = selectedIndex;
    this.config['indexes'] = selectedIndex;
    this.getData(this.idcoleccion, JSON.stringify(this.selectedColumns), JSON.stringify(this.selectedRanges), JSON.stringify(this.selectedIndexes));
    this._messageService.success('Operación realizada correctamente');
    modal.close();
  }

  // Aplica las salidas seleccionadas
  outputsSelect(modal) {
    console.log('Config antes: ', this.config);

    let inputs = null;
    if(this.config['inputs']) {
      inputs = this.config['inputs']
    }

    const selectedOutputs = this.salidasForm.value.outputs
      .map((checked, i) => checked ? this.outputDatos[i] : null)
      .filter(v => v !== null)

    this.config['outputs'] = selectedOutputs;

    if(inputs) {
      for(let i = 0; i < selectedOutputs.length; i++) {
        var index = inputs.indexOf(selectedOutputs[i]);
        if(index !== -1) {
          inputs.splice(index, 1);
        }
      }
    }

    console.log('Selected outputs es: ', selectedOutputs);
    console.log('Config es: ', this.config);
    this._messageService.success('Operación realizada correctamente');
    modal.close();
  }

  // Se guarda la configuración
  async saveConfig(modal) {
    console.log('Config a guardar', this.config);
    let finalConfig = {
      "Entrada": this.config['inputs'] ? this.config['inputs'] : [],
      "Salida": this.config['outputs'] ? this.config['outputs'] : [],
      "Rangos": this.config['ranges'] ? this.config['ranges'] : [],
      "Indice": this.config['indexes'] ? this.config['indexes'] : [],
      "Tipos": this.collectionData
    }
    //let response = await this._apiRestService.saveEtlConfig(this.idcoleccion, this.config);
    console.log(this.tensorForm.value)
    let body = { idcoleccion: this.idcoleccion, nombre: this.tensorForm.value.name, config: finalConfig }

    // Guarda la configuracion etl
    let response2 = await this._apiRestService.saveEtlColection(body);
    response2.ok ? console.log(response2) : this._messageService.error(response2.message);
    await this.getEtlsCollection();
    this.showEtlTable = true;
    this.resetInputs();
    this.resetSalidas();
    this._messageService.success('ETL guardado correctamente');
    modal.close();
  }

  async saveEditEtl(modal) {
    console.log("ETL: ", this.editTensorForm.value)
    console.log("A EDITAR: ", this.etlToEdit.idColeccionFiltrada)
    let body = this.editTensorForm.value;

    let response = await this._apiRestService.editEtl(this.etlToEdit.idColeccionFiltrada, body)
    if(response) {
      await this.getEtlsCollection();
      modal.close();
      this._messageService.success("Etl editado correctamente")
    } else {
      this._messageService.error("Error al actualizar ETL")
    }

  }

  // Se obtienen los datos del servidor segun los parametros de columnas, rango e indices
  async getData(idcoleccion, cols, ranges, indexes) {
    let datosColeccion = await this._apiRestService.getDatosColecciones(idcoleccion, cols, ranges, indexes);
    this.datosColeccion = datosColeccion.datos;
    if(!cols) {
      this.headerDatos = [];
      for (let dato in datosColeccion.datos[0]) {
        // if(typeof(datosColeccion.datos[0][dato]) === "number") {
        //   this.numberDatos.push(dato);
        // }
        this.headerDatos.push(dato);
      }
      console.log("PASE")
      this.addCheckboxes();
    }

    this.numberDatos = [];
    this.outputDatos = [];
    this.resetSalidas();

    for(let dato in datosColeccion.datos[0]) {
      this.outputDatos.push(dato)
      if(typeof(datosColeccion.datos[0][dato]) == "number") {
        this.numberDatos.push(dato)
      }
    }
    this.agregarRanges();
    this.agregarOutputs();

    console.log('Los datos son: ', this.datosColeccion)
  }

  // Se obtiene la configuracion inicial de los datos segun lo guardado en el servidor
  async getInitialData(idfiltercollection) {
    let datosColeccion = await this._apiRestService.getFilterDataCollections(this.idcoleccion, idfiltercollection)
    this.datosColeccion = datosColeccion.datos;
    this.numberDatos = [];
    this.outputDatos = [];
    this.resetSalidas();

    for(let dato in datosColeccion.datos[0]) {
      this.outputDatos.push(dato)
      if(typeof(datosColeccion.datos[0][dato]) == "number") {
        this.numberDatos.push(dato)
      }
    }

    this.addCheckboxes();
    this.agregarRanges();
    this.agregarOutputs();

    console.log('Los datos son: ', this.datosColeccion)
  }

  // Se resetea el form de salidas
  resetSalidas() {
    while(this.salidasForArray.length !== 0) {
      this.salidasForArray.removeAt(0)
    }
    while(this.rangesForArray.length !== 0) {
      this.rangesForArray.removeAt(0)
    }

  }

  resetInputs() {
    while(this.columnsForArray.length !== 0) {
      this.columnsForArray.removeAt(0)
    }
  }

  // Se obtiene la coleccion del servidor
  async getCollection() {
    try {
      let collection = await this._apiRestService.getCollection(this.idcoleccion);
      this.collection = collection.dato;
      this.config = this.collection.etl;
      console.log("COllection: ", this.collection)
      this.headerDatos = JSON.parse(this.collection.header);
    } catch(e) {
      console.log(e);
      this._messageService.error('Error al recuperar colección');
    }
  }

  async getEtlsCollection() {
    try {
      let etls = await this._apiRestService.getEtlsCollection(this.idcoleccion);
      console.log("ETLS", etls)
      this.etls = etls.datos;
    } catch(e) {
      console.log(e);
      this._messageService.error('Error al obtener etls')
    }
  }

  async getCollectionData() {
    try {
      const collData = await this._apiRestService.getCollectiondata(this.idcoleccion);
      //this.collectionData = collData.datos;
      console.log("COLDATA: ", collData)
      let dataTypes = {}
      if(collData.datos) {
        for(let data of collData.datos) {
          dataTypes[data['nombre']] = data['tipo'];
        }

        this.collectionData = dataTypes;
        this.headerDatos = Object.keys(dataTypes)
        console.log('datatypes: ', dataTypes)
        }
    } catch(e) {
      console.log(e);
      this._messageService.error('Error al obtener datos de la colección')
    }
  }

  // Se inician las variables
  variablesInit() {
    this.config = {
      outputs: [''],
      indexes: [''],
      inputs: [''],
      ranges: ['']
    };
    this.config['outputs'] = [];
    this.config['inputs'] = [];
    this.config['ranges'] = [];
    this.config['indexes'] = [];

    this.selectedColumns = [];
    this.selectedRanges = [];
    this.selectedIndexes = [];
    console.log("THIS CONFIG: ", this.config)
    console.log("THIS CONFIG: ", this.config['outputs'])
    console.log("THIS CONFIG: ", this.config['outputs'].includes(''))
  }

  // Para abrir los modales
  openModal(modal) {
    this.modalService.open(modal);
  }

  openEditModal(modal, etlToEdit) {
    this.editTensorForm.setValue({ nombre: etlToEdit.nombre })
    this.etlToEdit = etlToEdit;
    console.log(etlToEdit)
    this.modalService.open(modal)
  }



  async goToConfig(etl) {
    //console.log("etl a mandar: ", etl)
    this.resetSalidas();
    this.resetInputs();
    await this.getInitialData(etl.idColeccionFiltrada);
    this.config = etl.etl
    console.log("this.config: ", this.config)
    this.config = {
      inputs: etl.etl['Entrada'],
      outputs: etl.etl['Salida'],
      indexes: etl.etl['Indice'],
      ranges: etl.etl['Rango']
    }
    this.showEtlTable = false;
  }

  async goToNewTensor() {
    console.log("ASDSA")
    await this.getInitialData(null);
    this.showEtlTable = false;
  }

  backToTensors() {
    this.showEtlTable = !this.showEtlTable
    this.resetSalidas();
    this.resetInputs();
  }
}
