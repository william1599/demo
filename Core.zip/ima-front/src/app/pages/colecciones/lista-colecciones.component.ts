import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable, of } from 'rxjs';
import { ApiRestService } from 'src/app/services/api-rest.service';
import * as modelos from 'src/app/models/respuesta.model'
import { catchError } from 'rxjs/operators';
import { MessageService } from 'src/app/services/messages.service';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { FileDetector } from 'protractor';
import * as XLSX from 'xlsx';
import { animate, style, transition, trigger, query, stagger, state } from '@angular/animations';
import { PlainFileService } from 'src/app/services/plain-file.service';

const FILTER_PAG_REGEX = /[^0-9]/g;

@Component({
  selector: 'app-listacolecciones',
  templateUrl: './lista-colecciones.component.html',
  styleUrls: ['./lista-colecciones.component.css'],
  animations: [
    trigger("listAnimation", [
      transition("* => *", [
        // each time the binding value changes
        query(
          ":leave",
          [stagger(100, [animate("0.5s", style({ opacity: 0 }))])],
          { optional: true }
        ),
        query(
          ":enter",
          [
            style({ opacity: 0 }),
            stagger(100, [animate("0.5s", style({ opacity: 1 }))])
          ],
          { optional: true }
        )
      ])
    ]),
    trigger(
      'enterAnimation', [
        transition(':enter', [
          style({transform: 'translateX(-100px)', opacity: 0}),
          animate('300ms', style({transform: 'translateX(0)', opacity: 1, 'overflow-x': 'hidden'}))
        ]),
      ]
    ),
    trigger('slideIn', [
      state('*', style({ 'overflow-y': 'hidden' })),
      state('void', style({ 'overflow-y': 'hidden' })),
      transition('* => void', [
        style({ height: '*' }),
        animate(250, style({ height: 0 }))
      ]),
      transition('void => *', [
        style({ height: '0' }),
        animate(250, style({ height: '*' }))
      ])
    ])
  ]
})
export class ListaColeccionesComponent implements OnInit {
  public colecciones: any[];
  idservicio: any;
  lineaProduccionSeleccionada: any;
  page = 1;
  pageSize = 10;
  pageDatos = 1;
  pageSizeDatos = 8;
  uploadForm: FormGroup;
  editForm: FormGroup;
  acceptFiles:Array<string>;
  coleccionSeleccionada: any;
  fileInForm: Boolean;
  datosColeccion: any;
  headerDatos: any;
  lineasProduccion: any;
  idColeccionEditar: any;
  archivoOriginalEditar: any;
  servicio: any;
  parametrosColecciones = {
    idDesc: true,
    nombreDesc: false,
    descripcionDesc: false,
    lineaDesc: false,
    plantaDesc: false,
    fechaSubidaDesc: false,
    fechaActualizacionDesc: false
  }
  data: any;
  mostrarDatos = false;
  textoEnBotonPreVisualizar = 'Previsualizar datos';

  constructor(
    private route: ActivatedRoute,
    public _apiRestService: ApiRestService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private _messageService: MessageService,
    private _plainFileService: PlainFileService,
    private http: HttpClient) {
  }

  async ngOnInit() {
    this.inicialUploadForm();
    this.iniciarEditForm();
    this.idservicio = this.route.snapshot.paramMap.get('idservicio');
    await this.getServicio()
    this.lineaProduccionSeleccionada = this.servicio.idlineaproduccion;
    this.getColecciones('idcoleccion', 'true');
    this.getLineasProduccion()
    console.log('El id del servicio es: ', this.idservicio)
}

  async getColecciones(param, descending){
    console.log("Entre al colecciones")
    let resultados = await this._apiRestService.getColecciones(this.lineaProduccionSeleccionada, param, descending, this.servicio.idempresa);
    if(resultados.status == 200){
      this.colecciones = resultados.datos;
      console.log(this.colecciones)
    }
    else{
      console.log("error"+resultados.status)
      console.log(resultados)
    }
  }


  submitColeccion(modal) {
    console.log("ENTRE AL SUBMITCOLECCION")
    if(this.validacionesSubirColeccion()) {
      return;
    }
    let archivo = this.uploadForm.get('archivo_coleccion').value;
    console.log('El nombre es: ', this.uploadForm.get('nombre').value)
    let moreData = {
      nombre: this.uploadForm.get('nombre').value,
      descripcion: this.uploadForm.get('descripcion').value,
      idlineaproduccion: this.uploadForm.get('idlineaproduccion').value,
      idempresa: this.servicio.idempresa,
      idtipo: 1,
      idanterior: -1,
      tipo: 'blabla'
    }

    console.log('El archivo es: ', archivo)

    let success = false;

    this._apiRestService.subirArchivoColeccion(archivo, moreData).subscribe(resp => {
      if(resp.type === HttpEventType.Response) {
        console.log("UPLOAD COMPLETE")
        this.getColecciones('idcoleccion', this.parametrosColecciones.idDesc)
        this._messageService.success("Colección subida correctamente")
        success = true;
      }

      if(resp.type === HttpEventType.UploadProgress) {
        const percentDone = Math.round(100 * resp.loaded / resp.total);
        console.log('Progress ' + percentDone + '%')
      }

      console.log("La respuesta es: ", resp)
      modal.close()
    }, error => {
      console.log("Error: ", error)
      this._messageService.error(error)
    })

  }

  validacionesSubirColeccion() {
    if(this.uploadForm.controls['nombre'].errors?.required ||
       this.uploadForm.controls['descripcion'].errors?.required ||
       this.uploadForm.controls['idlineaproduccion'].errors?.required ||
       this.uploadForm.controls['archivo_coleccion'].errors?.required) {
         this._messageService.error('Faltan campos por rellenar')
         return true;
       } else {
         return false;
       }
  }

  validacionesEditarColeccion() {
    if(this.editForm.controls['nombre'].errors?.required ||
    this.editForm.controls['descripcion'].errors?.required ||
    this.editForm.controls['idlineaproduccion'].errors?.required ||
    this.editForm.controls['archivo_coleccion'].errors?.required) {
      this._messageService.error('Faltan campos por rellenar')
      return true;
    } else {
      return false;
    }
  }


  async submitEdiccionColeccion(modal) {

    if(this.validacionesEditarColeccion()) {
      return;
    }

    let archivo = this.editForm.get('archivo_coleccion').value;
    console.log('El archivo es', archivo)
    let moreData = {
      nombre: this.editForm.get('nombre').value,
      descripcion: this.editForm.get('descripcion').value,
      idlineaproduccion: this.editForm.get('idlineaproduccion').value
    }

    console.log('Los datos son: ', moreData)

    let success = false;

    await this._apiRestService.editarArchivoColeccion(this.idColeccionEditar, archivo, moreData).subscribe(resp => {
      if(resp.type === HttpEventType.Response) {
        this._messageService.success('Colección subida correctamente')
        success = true
      }
      this.getColecciones('idcoleccion', this.parametrosColecciones.idDesc);
      modal.close();
      console.log('La respues es: ', resp)
    }, error => {
      console.log('Error: ', error)
    })
  }

  openNuevaColeccionModal(modal) {
    this.modalService.open(modal);
  }

  abrirModalEditar( modal, idcoleccion, nombre, descripcion, idlineaproduccion, archivoOriginal ) {
    this.archivoOriginalEditar = archivoOriginal;
    this.idColeccionEditar = idcoleccion;
    console.log(idlineaproduccion)
    this.editForm.setValue({ nombre, descripcion, idlineaproduccion, archivo_coleccion: [''] })
    this.modalService.open(modal);

  }

  getCsvData(ruta) {
    console.log("La ruta es: ", ruta)
    //return this.http.get(ruta, {responseType: 'text'})
    //console.log('Los datos son: ', datos)
  }

  async getDataCsv(idcoleccion, modal) {
    let datos = await this._apiRestService.getDatosColecciones(idcoleccion, null, null, null);
    console.log("Los datos de colecciones son: ", datos)
    this.datosColeccion = datos.datos;
    this.headerDatos = [];
    for(let dato in datos.datos[0]) {
      console.log('El dato es: ', dato)
      this.headerDatos.push(dato);
    }

    // for(var i = 0; i < datos.datos.length; i++) {
    //   var obj = datos.datos[i]
    //   for (var key in obj) {
    //     var value = obj[key]
    //     console.log("El valor es: ", value)
    //   }


    // }

    this.modalService.open(modal)

  }


  inicialUploadForm() {
    this.uploadForm = this.formBuilder.group({
      nombre: ['', Validators.required],
      descripcion: ['', Validators.required],
      idlineaproduccion: ['', Validators.required],
      archivo_coleccion: ['', Validators.required]
    })

    this.acceptFiles = [
      "text/csv",
      ".csv",
      //"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      //"application/vnd.ms-excel.sheet.binary.macroEnabled.12",
      //"application/vnd.ms-excel",//csv
      //"application/vnd.ms-excel.sheet.macroEnabled.12"];
    ]
  }

  iniciarEditForm() {
    this.editForm = this.formBuilder.group({
      nombre: ['', Validators.required],
      descripcion: ['', Validators.required],
      idlineaproduccion: ['', Validators.required],
      archivo_coleccion: ['']
    })

    this.acceptFiles = [
      "text/csv",
      ".csv",
      //"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      //"application/vnd.ms-excel.sheet.binary.macroEnabled.12",
      //"application/vnd.ms-excel",//csv
      //"application/vnd.ms-excel.sheet.macroEnabled.12"];
    ]
  }

  botonPreVisualizar() {
    this.mostrarDatos = !this.mostrarDatos;
    this.mostrarDatos ? this.textoEnBotonPreVisualizar = 'Cerrar previsualización' : this.textoEnBotonPreVisualizar = 'Previsualizar datos'
  }

  onFileChange(evt: any) {
    /* wire up file reader */
    const file = evt.target.files[0];

    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      this.data = <XLSX.AOA2SheetOpts>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
      console.log(this.data);
    };
    reader.readAsBinaryString(target.files[0]);
    // const target: DataTransfer = <DataTransfer>(evt.target);
    // if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    // const reader: FileReader = new FileReader();
    // reader.onload = (e: any) => {
    //   /* read workbook */
    //   const bstr: string = e.target.result;
    //   const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

    //   /* grab first sheet */
    //   const wsname: string = wb.SheetNames[0];
    //   const ws: XLSX.WorkSheet = wb.Sheets[wsname];

    //   /* save data */
    //   this.data = <XLSX.AOA2SheetOpts>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
    //   console.log(this.data);
    // };
    // reader.readAsBinaryString(target.files[0]);
    this.uploadForm.get(evt.target.name).setValue(file)
    this.fileInForm = true;
  }

  onFileChangeEdit(evt: any) {
    /* wire up file reader */
    const file = evt.target.files[0];
    this.editForm.get(evt.target.name).setValue(file)
    this.fileInForm = true;
  }

  getPageSymbol(current: number) {
    return ['A', 'B', 'C', 'D', 'E', 'F', 'G'][current - 1];
  }

  selectPage(page: string) {
    this.page = parseInt(page, 10) || 1;
  }

  formatInput(input: HTMLInputElement) {
    input.value = input.value.replace(FILTER_PAG_REGEX, '');
  }

  async getServicio() {
    console.log("Entre al get servicio")
    let response = await this._apiRestService.getServicio(this.idservicio);
    if(response.ok) {
      console.log("El servicio es: ", response.dato);
      this.servicio = response.dato;
    } else {
      console.log("Hubo un error", response.error)
    }
  }

  async getLineasProduccion() {
    let response = await this._apiRestService.getLineasPorEmpresa('nombre', 'true', this.servicio.idempresa);
    if(response.ok) {
      this.lineasProduccion = response.datos
      console.log('Las lineas de produccion son: ', this.lineasProduccion)
    } else {
      console.log('Error', response.error)
    }

  }

  cambioLineaProduccion(idlineaproduccion) {
    console.log("Nuevo id linea prod: ", idlineaproduccion);
    if(idlineaproduccion) {
      this.lineaProduccionSeleccionada = idlineaproduccion;
    } else {
      console.log("UNDEFINED")
      this.lineaProduccionSeleccionada = "-1"
    }
    this.getColecciones('idcoleccion', 'true');
  }

  abrirModalVerMas(col, modal) {
    this.coleccionSeleccionada = col;
    console.log('Coleccion seleccionada: ', this.coleccionSeleccionada)
    this.modalService.open(modal)
  }

  downloadTxtFile() {
    const text = `ID: ${this.coleccionSeleccionada.idcoleccion} \nnombre: ${this.coleccionSeleccionada.nombre} \noriginal: ${this.coleccionSeleccionada.archivo_original} \nSubida: ${this.coleccionSeleccionada.createdAt} \nactualización: ${this.coleccionSeleccionada.updatedAt} \nPlanta: ${this.servicio.planta} \nServicio: ${this.servicio.nombre} \nLinea: ${this.coleccionSeleccionada.lineaproduccion.nombre}`

    this._plainFileService.dyanmicDownloadByHtmlTag({
      fileName: `Información colección ${this.coleccionSeleccionada.idcoleccion}`,
      text: text
    })
  }


}
