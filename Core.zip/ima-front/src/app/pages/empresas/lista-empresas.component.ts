import { Component, OnInit } from '@angular/core';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';

import { ApiRestService } from 'src/app/services/api-rest.service';
import { AuthenticationService } from 'src/app/services/authentication.service';

import { ActivatedRoute, Router } from '@angular/router';


import { User } from 'src/app/models/user';
import { Empresa } from 'src/app/services/empresa-actual.service';
import { RouterExtService } from 'src/app/services/router-ext-service';

export let empresaActual = {'nombre': 'Hunter Douglas'};
@Component({
  selector: 'app-lista-empresa',
  templateUrl: './lista-empresas.component.html',
  styleUrls: ['lista-empresas.component.scss']
})
export class ListaEmpresaComponent implements OnInit {
  formEmpresa: FormGroup;
  empresas: Array<any>;
  usuario: User;
  empresaActual: Empresa;
  seleccionEmpresa: boolean;

  constructor(
      private router: Router,
      private formBuilder: FormBuilder,
      private modalService: NgbModal ,
      private _apiRestService: ApiRestService,
      private _authenticationService: AuthenticationService,
      private routerExtService: RouterExtService,
      private _route: ActivatedRoute) {

        if (this.router.getCurrentNavigation().extras.state) {
          console.log(this.router.getCurrentNavigation().extras.state.empresa);
          this.empresaActual = this.router.getCurrentNavigation().extras.state.empresa;
          this.seleccionEmpresa = true;
        } else {
          this.seleccionEmpresa = false;
        }
  }


  ngOnInit(): void {
    // console.log("La ruta anterior fue: ", this.routerExtService.getPreviousUrl())
    const rutaAnterior = this.routerExtService.getPreviousUrl();
    console.log('LA RUTA ANTERIOR ES: ', rutaAnterior);
    if (rutaAnterior.includes('paginabaseoperacion')) {
      console.log('AKSDJAKSDJSKDASJKSDJA');
      console.log(this.router.getCurrentNavigation());
    }
    this.formEmpresa = this.creaEmpresa();
    // this.seleccionEmpresa = false;
    this.usuario = this._authenticationService.currentUserValue;
    // this.empresaActual = {
    //   idempresa:-1,
    //   nombre:"",
    //   descripcion:"string"
    // };
    this.getEmpresas();

  }

  async getEmpresas() {
    const result = await this._apiRestService.getEmpresasHabilitadas('idempresa', 'false', true);
    console.log('Empresas son: ', result.datos);
    if (result.ok) {
      this.empresas = result.datos;
    }
  }

  creaEmpresa() {
    return this.formBuilder.group({
      nombre: ['', Validators.required],
      descripcion: ['', Validators.required]
    });
  }
  selectEmpresa(e) {
    console.log(e);
    this.seleccionEmpresa = !this.seleccionEmpresa;
    this.empresaActual = e;
  }

  guardar(modal) {
    this._apiRestService.nuevaEmpresa(this.formEmpresa.value).then((response) => {
      if (response.ok) {
        this.formEmpresa.reset();
        modal.close('Exito');
        this.empresas.push(response.dato);
      } else {
        modal.close();
      }
    },
    (error) => {
      modal.close('Error');
    });
  }

  async abrirModal(modal) {
    this.modalService.open(modal).
      result.then((result) => {
        console.log('Cerrada con exito');
      }, (reason) => {
        console.log('cerrada por ' + reason);
      });
  }
}
