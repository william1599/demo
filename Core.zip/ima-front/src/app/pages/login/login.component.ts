import { Component, OnInit, OnDestroy, NgModule } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from '../../services/authentication.service';
import { Router,  ActivatedRoute } from '@angular/router';
import {environment} from 'src/environments/environment';
import { MessageService } from 'src/app/services/messages.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
  email = new FormControl('', Validators.required);
  password= new FormControl('', Validators.required);
  returnUrl:string;
  valida:any;
  fieldTextType: any;
  ambiente;
  constructor(private _authentication: AuthenticationService,
     private _router: Router,
     private _messagesService:MessageService,
     private route:ActivatedRoute) {
      const user = this._authentication.currentUserValue;
      if (user) {
        //1 es el id de la empresa del usua
        //this._router.navigate(['/servicios/'+user.idempresa]);
      }
      this.ambiente = environment.production;

  }

  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'];
    this.valida = {
      email:false,
      password:false
    }
  }
  ngOnDestroy() {
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  async autenticar(){
    console.log("Entre a autenticar")
    let email = this.email.value;
    let password = this.password.value;

    this.valida.email = email=="";
    this.valida.password = password=="";
    if(this.valida.email || this.valida.password){
      console.log("EEEE")
      return;
    }
    let success = null;
    try{
      console.log("Hare el llamado")
      success = await this._authentication.login(email, password);
      console.log("Sali del llamado")
      if(success.ok){
        let url = this.returnUrl;
        if(success.dato.rol == "ADMIN") {
          url = url || '/paginabaseadmin'
        }
        else if(success.dato.rol == "ING-DATOS"){
          url = url || '/servicios';
        } else if(success.dato.rol == "ADMIN-EMPRESA") {
          url = url || '/administracion'
        }
        else if(success.dato.rol == "ING-PLANTA"){
          url = url || '/servicios';
        }
        this._router.navigate([url]);
      }
      else{
        console.log('aaaaaaaaaaaaaaaaaaa');
        this._messagesService.alert(success.message);
      }
    }
    catch(error){
      console.log("QUE ESTA PASANDO")
      //console.log(error);
      //this._messagesService.alert(error.error.message);
      this._messagesService.alert(error);
    }
  }

}
