import { Location } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { User } from "src/app/models/user";
import { ApiRestService } from "src/app/services/api-rest.service";
import { AuthenticationService } from "src/app/services/authentication.service";
import { animate, style, transition, trigger, query, stagger, state } from '@angular/animations';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: 'app-pagina-base-operacion',
  templateUrl: './pagina-base-operacion.component.html',
  styleUrls: ['./pagina-base-operacion.component.scss'],
  animations: [
    trigger("listAnimation", [
      transition("* => *", [
        // each time the binding value changes
        query(
          ":leave",
          [stagger(100, [animate("0.5s", style({ opacity: 0 }))])],
          { optional: true }
        ),
        query(
          ":enter",
          [
            style({ opacity: 0 }),
            stagger(100, [animate("0.5s", style({ opacity: 1 }))])
          ],
          { optional: true }
        )
      ])
    ]),
    trigger(
      'enterAnimation', [
        transition(':enter', [
          style({opacity: 0}),
          animate('600ms', style({opacity: 1, 'overflow-x': 'hidden'}))
        ]),
      ]
    ),
    trigger('slideIn', [
      state('*', style({ 'overflow-y': 'hidden' })),
      state('void', style({ 'overflow-y': 'hidden' })),
      transition('* => void', [
        style({ height: '*' }),
        animate(250, style({ height: 0 }))
      ]),
      transition('void => *', [
        style({ height: '0' }),
        animate(250, style({ height: '*' }))
      ])
    ])
  ]
})

export class PaginaBaseOPeracionComponent implements OnInit {

  usuario: User;
  idservicio: any;
  servicio: any;

  constructor(
    private _authenticationService: AuthenticationService,
    private _apiRestService: ApiRestService,
    private _route: ActivatedRoute,
    private location: Location,
    private router: Router,
    private _modalService: NgbModal
  ) {}

    ngOnInit(): void {
      this.idservicio = this._route.snapshot.paramMap.get('idservicio')
      console.log(this.idservicio);
      this.usuario = this._authenticationService.currentUserValue;
      console.log(this.usuario)
      this.getServicio();
    }

    async getServicio() {
      let response = await this._apiRestService.getServicio(this.idservicio);
      if(response.ok) {
        console.log("El servicio es: ", response.dato);
        this.servicio = response.dato;
      } else {
        console.log("Hubo un error", response.error)
      }
    }

    goToOptimizer(modal) {
      if(this.servicio.idmodelo) {
        this.router.navigate(['servicio', this.idservicio, 'optimizer'])
      } else {
        this._modalService.open(modal);
      }
    }

    volverEnNavegacion() {
      this.location.back();
    }

    volverAServicios() {
      console.log("La empresa que voy a mandar es: ", this.servicio.empresa)
      this.router.navigateByUrl('/empresas', {state: { empresa: this.servicio.empresa }})
    }

}
