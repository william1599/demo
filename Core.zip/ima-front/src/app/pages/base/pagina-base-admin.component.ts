import { Component, OnInit } from "@angular/core";
import { User } from "src/app/models/user";
import { AuthenticationService } from "src/app/services/authentication.service";


@Component({
  selector: 'app-pagina-base-admin',
  templateUrl: './pagina-base-admin.component.html',
  styleUrls: ['./pagina-base-admin.component.scss']
})

export class PaginaBaseAdminComponent implements OnInit {

  usuario: User;


  constructor(
    private _authenticationService: AuthenticationService
  ) {

  }

  ngOnInit(): void {
    this.usuario = this._authenticationService.currentUserValue;
  }

  logout(){
    console.log("salir!")
    this._authenticationService.logout();
  }
}
