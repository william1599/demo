import {Component, Input, OnInit} from "@angular/core";
import { Subscription } from "rxjs";
import { ApiRestService } from "src/app/services/api-rest.service";
import { UrlService } from "src/app/services/url.service";
import { OptimizerService } from "../services/optimizer.service";

@Component({
  selector: 'app-optimizer-list',
  templateUrl: './optimizer-list.component.html'
})
export class OptimizerListComponent implements OnInit {
  optimizers: any;
  subscription: Subscription;
  @Input() activedOptimizer: any;
  @Input() idservicio: any;
  @Input() idmodelo: any;
  @Input() isOptimizer: any;
  servicio: any;
  previousUrl: string = '';
  constructor(private _optimizerService: OptimizerService,
              private urlService: UrlService,
              private _apiRestService: ApiRestService) {
    
  }

  ngOnInit() {
    console.log("activateOptimizer: ", this.activedOptimizer);
    console.log("isOpti: ", this.isOptimizer);
    console.log("ismodelo: ", this.isOptimizer);
    console.log("idservicio: ", this.idservicio);
    this.urlService.previousUrl$.subscribe(( previousUrl: string ) => {
      this.previousUrl = previousUrl;
    })
    this.subscription = this._optimizerService.optimizersChanged.subscribe(
      (optimizers: any) => {
        this.optimizers = optimizers;
        console.log("THISOPTIs:", this.optimizers);
      }
    )
    this.getServicio();
  }

  async getActivatedOptimizer() {
    const resp = await this._optimizerService.getOptimizerById(this.idmodelo);

  }

  async getServicio() {
    let response = await this._apiRestService.getServicio(this.idservicio);
    if(response.ok) {
      console.log("El servicio es: ", response.dato);
      this.servicio = response.dato;
      this.isOptimizer = this.servicio.esOptimizador;
      if(this.isOptimizer) {
        const resp = await this._optimizerService.getOptimizerById(this.servicio.idoptimizador);
        this.activedOptimizer = resp;
        console.log("RESP: ", this.activedOptimizer)
      }
      if(this.servicio.idmodelo) {
        this.idmodelo = this.servicio.idmodelo;
      }
      this.getOptimizers();
    } else {
      console.log("Hubo un error", response.error)
    }
  }

  async getOptimizers() {
    console.log("THISSERVICIO: ", this.servicio)
    this.optimizers = await this._optimizerService.getOptimizersByModel(this.servicio.idmodelo);
    console.log("AA", this.optimizers)
  }

  async activateOptimizer(optimizer, isActivating) {
    console.log("activar optimizador: ", optimizer);
    const newService = await this._optimizerService.actvateOptimizer(optimizer, this.idservicio, isActivating);
    console.log("newService: ", newService);
    this.getServicio();
  }
}
