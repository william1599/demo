import {Component, Input, OnInit} from "@angular/core";
import { FormArray, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { MessageService } from "src/app/services/messages.service";
import { ModelService } from "../../training/services/model.service";
import { OptimizerService } from "../services/optimizer.service";


@Component({
  selector: 'app-optimizer-create',
  templateUrl: './optimizer-create.component.html'
})
export class OptimizerCreateComponent implements OnInit {
  @Input() modal: any;
  @Input() models: any;
  @Input() idmodelo: any;
  outputInputs: any;
  modeloActivo: any;
  inputs: any;
  showInputs: boolean = false;
  optimizerForm: FormGroup;
  constructor(private formBuilder: FormBuilder,
              private _optimizerService: OptimizerService,
              private modelService: ModelService,
              private _messageService: MessageService) {
  }

  ngOnInit() {
    console.log("models: ", this.models);
    console.log("idmodelo create: ", this.idmodelo);
    this.optimizerForm = this.optimizerFormCreate();
    this.getModelo();
  }

  get getInputs(): FormArray {
    return this.optimizerForm.get('inputs') as FormArray;
  }

  get getOutputs(): FormArray {
    return this.optimizerForm.get('outputs') as FormArray;
  }

  async getModelo() {
    const model = await this.modelService.getModel(this.idmodelo);
    console.log("MODEL: ", model);
    this.modeloActivo = model;
    this.changeModelo(model);
  }

  optimizerFormCreate() {
    return this.formBuilder.group({
      nombre: ['', Validators.required],
      idmodelo: [this.idmodelo, Validators.required],
      num_particulas: ['', Validators.required],
      num_iteraciones: ['', Validators.required],
      inputs: this.formBuilder.array([]),
      outputs: this.formBuilder.array([])
    })
  }

  changeModelo(model) {
    // var result = this.models.filter(obj => {
    //   return obj.idmodelo === parseInt(idmodelo);
    // })

    let variables = model.parametros_prediccion;

    this.outputInputs = variables.filter(obj => {
      return obj.isOutput === true;
    });

    this.inputs = variables.filter(obj => {
      return obj.isOutput === false;
    });

    for(let outputs of this.outputInputs) {
      this.getOutputs.push(this.formBuilder.control(''));
    }

    for(let input of this.inputs) {
      this.getInputs.push(this.formBuilder.control(''));
    }

    this.showInputs = true;
  }

  async submit() {
    console.log("FORM: ", this.optimizerForm.value);
    let formValues = this.optimizerForm.value;
    let inputsForm = this.optimizerForm.value.inputs;
    let outputsForm = this.optimizerForm.value.outputs;
    let inputObj = {};
    console.log("this.inputs", this.inputs);
    this.inputs.forEach(function (inp, i) {
      inputObj[inp.idparametros] = inputsForm[i];
    });
    this.outputInputs.forEach(function (inp, i) {
      inputObj[inp.idparametros] = outputsForm[i];
    });

    console.log("inputsObj: ", inputObj);

    const optimizerBody = {
      "nombre": formValues.nombre,
      "idmodelo": formValues.idmodelo,
      "num_iteraciones": formValues.num_iteraciones,
      "num_particulas": formValues.num_particulas,
      "ponderadores": inputObj
    }

    await this._optimizerService.saveOptimizer(optimizerBody);
    await this._optimizerService.updateOptimizers(formValues.idmodelo);
    this._messageService.success("Optimizador creado con éxito");
    this.modal.close();
  }
}
