import {Component, OnInit} from "@angular/core";
import {ActivatedRoute} from "@angular/router";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import { ApiRestService } from "src/app/services/api-rest.service";
import { ModelService } from "../training/services/model.service";
import { OptimizerService } from "./services/optimizer.service";

@Component({
  selector: 'app-optimizer',
  templateUrl: './optimizer.component.html',
  styleUrls: ['./optimizer.component.css']
})
export class OptimizerComponent implements OnInit {
  idservicio: string;
  idmodelo: any;
  modelsInService: any;
  optimizersInService: any;
  servicio: any;
  isOptimizer: any;

  constructor(private route: ActivatedRoute,
              private modalService: NgbModal,
              private _modelService: ModelService,
              private _apiRestService: ApiRestService) {
    this.idservicio = this.route.snapshot.paramMap.get('idservicio'); 
  }
  ngOnInit() {
    this.getOptimizers();
    this.getServicio();
    this.modelsInService = this._modelService.getModels();
  }

  async getServicio() {
    let response = await this._apiRestService.getServicio(this.idservicio);
    if(response.ok) {
      console.log("El servicio es: ", response.dato);
      this.servicio = response.dato;
      this.isOptimizer = this.servicio.esOptimizador;
      if(this.servicio.idmodelo) {
        this.idmodelo = this.servicio.idmodelo;
      }
    } else {
      console.log("Hubo un error", response.error)
    }
  }

  async getOptimizers() {
    await this._modelService.getModelsByService(this.idservicio);
  }

  openModal(modal) {
    this.modalService.open(modal);
  }
}
