import { Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { ApiRestService } from "src/app/services/api-rest.service";
import { MessageService } from "src/app/services/messages.service";

@Injectable({ providedIn: 'root' })
export class OptimizerService {
    private optimizers = [];
    private optimizer: any;
    private optimizerById: any;

    optimizersChanged = new Subject();
    constructor(private _apiRestService: ApiRestService,
                private _messageService: MessageService) {

    }

    async saveOptimizer(optimizer) {
        const resp = await this._apiRestService.postOptimizer(optimizer);
        if (resp.ok) {
            this.optimizer = resp.dato;
            this.optimizersChanged.next(this.optimizers.slice());
            return this.optimizer;
        } else {
            console.log('Error al guardar optimizador');
        }
    }

    async updateOptimizers(idmodelo) {
        this.getOptimizersByModel(idmodelo);
    }

    async getOptimizersByService(idservicio) {
        const resp = await this._apiRestService.getOptimizersInService(idservicio);
        if(resp.ok) {
            this.optimizers = resp.datos;
            this.optimizersChanged.next(this.optimizers.slice());
            return this.optimizers;
        } else {
            console.log('Error al obtener optimizadores');
        }
    }

    async getOptimizersByModel(idmodelo) {
        const resp = await this._apiRestService.getOptimizersInModel(idmodelo);
        if(resp.ok) {
            this.optimizers = resp.datos;
            this.optimizersChanged.next(this.optimizers.slice());
            return this.optimizers;
        } else {
            console.log('Error al obtener optimizadores');
        }
    }

    async getOptimizerById(idoptimizador) {
        const resp = await this._apiRestService.getOptimizerById(idoptimizador);
        if(resp.ok) {
            this.optimizerById = resp.dato;
            return this.optimizerById;
        } else {
            console.log("Error al obtener el optimizador por su id");
        }
    }

    async actvateOptimizer(optimizer, idservicio, isActivating) {
        const obj = {
            "esOptimizador": isActivating,
            "idoptimizador": optimizer.idoptimizador
        }

        const resp = await this._apiRestService.activateOptimizer(obj, idservicio);
        console.log("RESP ACTIADO: ", resp);
        if(resp.ok) {
            this._messageService.success('Optimizador activado correctamente');
            return resp.dato;
        } else {
            this._messageService.error('Error al activar optimizador');
        }
    }

    getOptimizersInService() {
        return this.optimizers;
      }

    
}