import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';

import { ApiRestService } from '../../services/api-rest.service';
import { Subscription } from 'rxjs';
import { Router } from "@angular/router"

import { RespuestaArquitectura} from 'src/app/models/respuesta.model'

@Component({
  selector: 'app-nuevo-rodillo',
  templateUrl: './nuevo-rodillo.component.html'  
})
export class NuevoRodilloComponent implements OnInit {  
  formRodillo : FormGroup; 
  constructor(
      private router:Router,
      private formBuilder: FormBuilder, 
      private modalService: NgbModal , 
      private _apiRestService: ApiRestService) {
  }


  ngOnInit(): void {
    this.formRodillo = this.formBuilder.group({
      identificador: ['',Validators.required],
      nombre: ['',Validators.required],
      ubicacion: ['',Validators.required],
      diametro_eje: ['',Validators.required],
      diametro_rodillo: ['',Validators.required],
      largo: ['',Validators.required],
      tipo_rodillo: ['',Validators.required],
      tipo_rodamiento: ['',Validators.required],
      cod_descanso: ['',Validators.required],
      cod_rodamiento: ['',Validators.required],
    });
  }

}
