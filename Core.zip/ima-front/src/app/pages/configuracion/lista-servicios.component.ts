import { Component, Input, OnInit } from '@angular/core';
import { ApiRestService } from 'src/app/services/api-rest.service';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Empresa } from 'src/app/services/empresa-actual.service';
import { User } from 'src/app/models/user';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import { MessageService } from 'src/app/services/messages.service';


@Component({
  selector: 'app-listaservicios',
  templateUrl: './lista-servicios.component.html',
  styleUrls: ['./lista-servicios.component.css']
})
export class ListaServiciosComponent implements OnInit {
  @Input()
  get empresa(): Empresa {return this._empresa};
  set empresa(empresa: Empresa){
    this._empresa = (empresa.idempresa>=0)?empresa:null
    if(empresa.idempresa>=0){
      this.getServicios();
    }
  };
  private _empresa: Empresa;
  servicios: Array<any>;
  usuario:User;
  detalle_link:string;
  nuevo_servicio:string;
  formServicio : FormGroup;
  servicioActual:any;

  constructor(
      private _apiRestService:ApiRestService,
      private modalService: NgbModal ,
      private formBuilder: FormBuilder,
      public _messagesService: MessageService,
      private _authenticationService: AuthenticationService) {

  }

  ngOnInit(): void {
    this.servicios = [];
    console.log("en lista de servicios");
    this.usuario = this._authenticationService.currentUserValue;
    this.detalle_link = "/entrenar";
    if(this.usuario.rol == "ING-PLANTA"){
      this.detalle_link = "/predecir";
    }
    if(!this.empresa){
      this.empresa = this.usuario.empresa;
    }

    this.getServicios();
    this.formServicio = this.creaServicio();

  }

  async getServicios(){
    let resp = await this._apiRestService.getServiciosHabilitados(this.empresa.idempresa);
    if(resp.ok){
      this.servicios = resp.datos;
      console.log(this.servicios);
    }
  }

  creaServicio() {
    return this.formBuilder.group({
      nombre: ['',Validators.required],
      tipo: ['',Validators.required],
      descripcion: ['',Validators.required]
    });
  }

  enConstruccion(modal, servicio){
    //this._messagesService.show("Servicio "+servicio.nombre+" en construccion")
    this.servicioActual = servicio;
    this.abrirModal(modal);
  }

  async abrirModal(modal){
    this.modalService.open(modal).
      result.then((result)=>{
        console.log("Cerrada por "+result);
      },(reason)=>{
        console.log("cerrada por "+reason);
      });
  }
  guardar(modal){
    let nueva = this.formServicio.value;
    nueva = {...nueva, idempresa:this.empresa.idempresa};
    this._apiRestService.postServicio(nueva).then((response)=>{
      if(response.ok){
        this.formServicio.reset();
        modal.close("Exito");
        console.log(response.dato);
        this.servicios.push(response.dato);
        this._messagesService.success(response.message);
      }
    },
    (error)=>{
      modal.close("ERROR!!");
      console.log(error);
      this._messagesService.alert(error);
      });
  }


}
