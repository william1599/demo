import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';

import { ApiRestService } from '../../services/api-rest.service';
import { Subscription } from 'rxjs';
import { Router } from "@angular/router"

import { RespuestaArquitectura} from 'src/app/models/respuesta.model'

@Component({
  selector: 'app-nueva-empresa',
  templateUrl: './nueva-empresa.component.html'  
})
export class NuevaEmpresaComponent implements OnInit {  
  formEmpresa : FormGroup; 
  idempresa:number; 
  constructor(
      private router:Router,
      private formBuilder: FormBuilder, 
      private modalService: NgbModal , 
      private _apiRestService: ApiRestService) {
  }


  ngOnInit(): void {
    this.formEmpresa = this.formBuilder.group({
      nombre: ['',Validators.required],
      descripcion: ['',Validators.required]
    });
  }  

  guardar(modal){
    this._apiRestService.postConfiguracion(this.formEmpresa.value).then((response)=>{
      console.log();      
    },
    (error)=>{
      modal.close("Error");
    });    
  }  
}
