import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';

import { ApiRestService } from '../../services/api-rest.service';
import { Subscription } from 'rxjs';
import { Router } from "@angular/router"

import { RespuestaArquitectura} from 'src/app/models/respuesta.model'

@Component({
  selector: 'app-configuracion',
  templateUrl: './configuracion.component.html'  
})
export class ConfiguracionComponent implements OnInit {  
  formRodillo : FormGroup; 
  constructor(
      private router:Router,
      private formBuilder: FormBuilder, 
      private modalService: NgbModal , 
      private _apiRestService: ApiRestService) {
  }
  
  ngOnInit(): void {
  }

}
