import { Component, OnInit } from '@angular/core';
import { ApiRestService } from '../../../services/api-rest.service';
import { QuestionService } from '../../../services/question.service';
import { DropdownQuestion } from '../../../models/question-models/question-dropdown'
import { TipoCapa } from 'src/app/models/tipocapa';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from "@angular/router"
import { Location } from '@angular/common';
import { MessageService } from 'src/app/services/messages.service';

@Component({
  selector: 'app-nueva-configuracion',
  templateUrl: './nuevaarquitectura.component.html'  ,
  styleUrls:['./nuevaarquitectura.component.css'],
  providers:[QuestionService]
})
export class NuevaArquitecturaComponent implements OnInit {
  tipoCapas:Array<TipoCapa>;
  idArquitecturaAEditar: any;
  //tipoCapasCounter : Array<number>;1
  capas_counter:number;
  editCapaCounter: number;
  colecciones:Array<any>;
  formNuevaCapa: FormGroup;
  formConfiguracion : FormGroup;
  showInputs:boolean;
  showSettings:boolean;
  tituloVista: string;
  vistaEdicion: boolean;
  drawNuevaCapa: any;
  subscription:Subscription;
  servicio: any;
  public configuracion:any;
  idservicio: string;
  constructor(
    private router:Router,
    public _qs:QuestionService,
    private formBuilder: FormBuilder,
    private modalService: NgbModal ,
    private route: ActivatedRoute,
    public _apiRestService: ApiRestService,
    private location: Location,
    private _messageService: MessageService)

    {

      if(this.router.getCurrentNavigation().extras.state) {
        //console.log('Id de la arquitectura: ', this.router.getCurrentNavigation().extras.state.id_architecture);
        this.idArquitecturaAEditar = this.router.getCurrentNavigation().extras.state.id_architecture;
        this.getArquitectura();
        this.tituloVista = 'Edición de arquitectura'
        this.vistaEdicion = true;
      } else {
        this.tituloVista = 'Creación de arquitectura'
        this.vistaEdicion = false;
        this.capas_counter = 0
      }

    }

  ngOnInit(): void {
    this.idservicio = this.route.snapshot.paramMap.get('idservicio');
    //this.getServicio();
    //this.getColecciones();
    this.getTipoCapas();
    this.formConfiguracion = this.formBuilder.group({
      nombre: ['',Validators.required],
      tipo: ['', Validators.required],
      estado: ['']
    });

    this.configuracion = {
      layers_architecure:[],
      layers_output_names:[],
      cost_string:"",
      training_log_outputs:[],
      salida:"",
      idservicio:this.idservicio
    }
    this.formNuevaCapa = this.creaCapa();
    this.drawNuevaCapa = {
      inputs:[],
      settings:[]
    };

    this.showInputs = false;
    this.showSettings = false;
  }

  volverEnNavegacion() {
    this.location.back();
  }

  creaCapa(){
    const grupo = this.formBuilder.group({
      tipo: ['-1',Validators.required],
      layer_type: [''],
      color: [this.getRandomColor()],
      nombre : ['',Validators.required],
      inputs : this.formBuilder.array([]),
      settings : this.formBuilder.array([]),
      cost_string : [false],
      log:[false],
      salida:[false]
    });
    this.subscription = grupo.get('tipo').valueChanges.subscribe(val => {
      this.tipoCapaCambiada(val);
    });
    return grupo;
  }

  editaCapa() {
    const grupo = this.formBuilder.group({
      tipo: ['-1',Validators.required],
      layer_type: [''],
      color: [this.getRandomColor()],
      nombre : ['',Validators.required],
      inputs : this.formBuilder.array([]),
      settings : this.formBuilder.array([]),
      cost_string : [false],
      log:[false],
      salida:[false]
    });
    this.subscription = grupo.get('tipo').valueChanges.subscribe(val => {
      this.tipoCapaCambiadaEdicion(val);
    });
    return grupo;
  }

  public tipoCapaCambiadaEdicion(indexTipo){
    this.resetNuevaCapa();
    console.log("nuevo tipo"+indexTipo)
    //setear el nombre de la capa automaticamente
    //let nuevonombre = this.tipoCapas[indexTipo].variable_name+"_"+this.tipoCapasCounter[indexTipo]
    let nuevonombre = this.tipoCapas[indexTipo].variable_name+"_"+this.editCapaCounter;

    console.log("Nuevo nombre:"+nuevonombre)

    this.formNuevaCapa.get('nombre').setValue(nuevonombre);
    this.formNuevaCapa.get('layer_type').setValue(this.tipoCapas[indexTipo].variable_name);

    //si aun no elije capa, setear showinputs como false y terminar
    if(indexTipo < 0){
      this.showInputs = false;
      this.showSettings = false;
      return
    }

    //asigno el tipo capa elegido a la capa actual
    //this.formNuevaCapa.patchValue({tipo: indexTipo});

    this.drawNuevaCapa = {
      inputs:[],
      settings:[]
    };
    //inputs
    for(let entrada of this.tipoCapas[indexTipo].inputs){
      this.inputs.push(this.formBuilder.control(''))
      for(let name of this.configuracion.layers_output_names){

        entrada.addOption({key:name,value:name})
      }
      this.drawNuevaCapa.inputs.push(entrada)
    }

    //settings
    for(let entrada of this.tipoCapas[indexTipo].settings){
      console.log(entrada)
      if(entrada.type == "number"){
        this.settings.push(this.formBuilder.control('',Validators.pattern("^[0-9.e]*")))
      }
      else{
        this.settings.push(this.formBuilder.control(''))
      }
      this.drawNuevaCapa.settings.push(entrada)
    }
    if(this.drawNuevaCapa.inputs.length > 0){
      this.showInputs = true;
    }
    if(this.drawNuevaCapa.settings.length > 0){
      this.showSettings = true;
    }

  }

  get inputs(): FormArray{
    return this.formNuevaCapa.get('inputs') as FormArray;
  }

  get settings(): FormArray{
    return this.formNuevaCapa.get('settings') as FormArray;
  }

  async getTipoCapas(){
    console.log('El servicio es: ', this.servicio)
    await this.getServicio();
    this.tipoCapas = await this._qs.getQuestions(this.servicio.idlineaproduccion);
    console.log('Las capas son: ', this.tipoCapas)
    //this.tipoCapasCounter = new Array(this.tipoCapas.length).fill(0);
  }

  async getColecciones(){
    let resultados = await this._apiRestService.getColecciones(this.servicio.idlineaproduccion, 'idcoleccion', true, this.servicio.idempresa);
    if(resultados.status == 200){
      this.colecciones = resultados.datos;
      console.log(this.colecciones)
    }
    else{
      console.log("error"+resultados.status)
      console.log(resultados)
    }
  }

  get isValid() {
    return this.formNuevaCapa.controls[this.drawNuevaCapa.inputs.key].errors?.required;
  }

  nuevaCapa(content) {
    this.formNuevaCapa = this.creaCapa();
    this.modalService.open(content, {scrollable: true,size: 'lg',ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {

      //console.log('Printeando el formNuevaCapa', this.formNuevaCapa)
      let tmp = this.formNuevaCapa.value;
      console.log('Printeando el tmp', tmp);
      //this.tipoCapasCounter[tmp.tipo]+=1;
      this.capas_counter++;

      let salida = "layer_output-"+tmp.nombre;
      console.log("La salida es: ", salida)
      if(this.tipoCapas[tmp.tipo].outputs.length == 0){
        this.configuracion.layers_output_names.push(salida);
      }
      else{
        for(let out of this.tipoCapas[tmp.tipo].outputs){
          this.configuracion.layers_output_names.push(salida+"_"+out.variable_name)
          console.log("La salida 2 es: ", this.configuracion.layers_output_names.push(salida+"_"+out.variable_name))
        }
      }
      let tmpInputs = []
      for(let i = 0; i < this.tipoCapas[tmp.tipo].inputs.length; i++){
        tmpInputs.push({
          [this.tipoCapas[tmp.tipo].inputs[i].key] : tmp.inputs[i]
        })
        console.log("tmp inputs", tmpInputs)
      }
      tmp.inputs = tmpInputs;
      let tmpSettings = []
      for(let i = 0; i < this.tipoCapas[tmp.tipo].settings.length; i++){
        tmpSettings.push({
          [this.tipoCapas[tmp.tipo].settings[i].key] : tmp.settings[i]
        })
        console.log('tmp settings', tmpSettings)
      }
      if(tmp.log){
        console.log("Se agrega al log la capa: "+tmp.nombre);
        this.configuracion.training_log_outputs.push(salida);
      }
      if(tmp.cost_string){
        //this.configuracion.cost_string = tmp.nombre;
        this.configuracion.cost_string = salida
      }
      if(tmp.salida){
        this.configuracion.salida = salida;
      }

      //elimino las propiedades del objeto temporal, ya que no las quiero guardar en la base de datos
      //delete tmp.log;
      //delete tmp.cost_string;
      //delete tmp.salida;

      tmp.settings = tmpSettings;
      this.configuracion.layers_architecure.push(tmp);
      console.log("COnfiguracion es: ", this.configuracion)
      console.log("Tipos capas: ", this.tipoCapas)

      this.resetNuevaCapa();
      this.subscription.unsubscribe();
    }, (reason) => {
      this.resetNuevaCapa();
      this.subscription.unsubscribe();
      console.log('Dismissed'+ reason);
    });
  }

  getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }


  //se encarga de actualizar el formulario donde se guarda la informacion
  public tipoCapaCambiada(indexTipo){
    this.resetNuevaCapa();
    console.log("nuevo tipo"+indexTipo)
    //setear el nombre de la capa automaticamente
    //let nuevonombre = this.tipoCapas[indexTipo].variable_name+"_"+this.tipoCapasCounter[indexTipo]
    let nuevonombre = this.tipoCapas[indexTipo].variable_name+"_"+this.capas_counter;

    console.log("Nuevo nombre:"+nuevonombre)

    this.formNuevaCapa.get('nombre').setValue(nuevonombre);
    this.formNuevaCapa.get('layer_type').setValue(this.tipoCapas[indexTipo].variable_name);

    //si aun no elije capa, setear showinputs como false y terminar
    if(indexTipo < 0){
      console.log("Por aqui ando")
      this.showInputs = false;
      this.showSettings = false;
      return
    }

    //asigno el tipo capa elegido a la capa actual
    //this.formNuevaCapa.patchValue({tipo: indexTipo});

    this.drawNuevaCapa = {
      inputs:[],
      settings:[]
    };
    //inputs
    console.log("inputs: ", this.tipoCapas[indexTipo].inputs)
    console.log("configuracion layers output names: ", this.configuracion.layers_output_names)
    for(let entrada of this.tipoCapas[indexTipo].inputs){
      this.inputs.push(this.formBuilder.control(''))
      console.log("THISINPUTS", this.inputs)
      for(let name of this.configuracion.layers_output_names){
        entrada.addOption({key:name,value:name})
        console.log("ENTRADA", entrada)
      }
      this.drawNuevaCapa.inputs.push(entrada)
    }

    console.log("NEWCAPA", this.drawNuevaCapa)

    //settings
    console.log("Settings: ", this.tipoCapas[indexTipo].settings)
    for(let entrada of this.tipoCapas[indexTipo].settings){
      console.log(entrada)
      if(entrada.type == "number"){
        this.settings.push(this.formBuilder.control('',Validators.pattern("^[0-9.e]*")))
      }
      else{
        this.settings.push(this.formBuilder.control(''))
      }
      this.drawNuevaCapa.settings.push(entrada)
      console.log("draw Nueva Capa Settings: ", this.drawNuevaCapa.settings)
    }
    if(this.drawNuevaCapa.inputs.length > 0){
      this.showInputs = true;
    }
    if(this.drawNuevaCapa.settings.length > 0){
      this.showSettings = true;
    }

  }
  public eliminaCapa(modal){
    console.log('La configuracion es la siguiente: ', this.configuracion)
    this.capas_counter = this.capas_counter - 1;
    this.configuracion.layers_architecure.splice(-1, 1);
    this.configuracion.layers_output_names.splice(-1, 1);
    console.log('La configuracion despues es la siguiente: ', this.configuracion)
    modal.close();
  }

  public resetNuevaCapa(){
    this.showInputs = false;
    this.showSettings = false;
    this.settings.clear();
    this.inputs.clear();
    //this.subscription.unsubscribe();
  }

  //TODO: Actualizar el nombre de la capa al editar!!!!
  public showEdit(capa,edita_capa, index_capa){
    console.log('La capa a editar es: ', capa)
    console.log("La config de capa es: ", this.configuracion.salida)
    console.log("Index capa es: ", index_capa)
    console.log("El tipo de la capa es: ", capa.tipo)
    console.log("AAA", this.configuracion.layers_output_names)
    //this.capas_counter = index_capa;
    this.editCapaCounter = index_capa;
    this.formNuevaCapa = this.editaCapa();
    this.formNuevaCapa.get('color').patchValue(capa.color);
    this.formNuevaCapa.get('tipo').patchValue(capa.tipo);
    this.formNuevaCapa.get('nombre').setValue(capa.nombre);
    this.formNuevaCapa.get('log').setValue(capa.log);
    this.formNuevaCapa.get('salida').setValue(capa.salida);
    this.formNuevaCapa.get('cost_string').setValue(capa.cost_string);

    // if(this.vistaEdicion || !this.vistaEdicion) {
    //   this.formNuevaCapa.get('cost_string').setValue(capa.cost_string);
    //   //this.formNuevaCapa.get('cost_string').setValue("layer_output-"+capa.nombre == this.configuracion.cost_string);
    //   //this.formNuevaCapa.get('salida').setValue("layer_output-"+capa.nombre == this.configuracion.salida);
    // } else {
    //   this.formNuevaCapa.get('cost_string').setValue(capa.nombre == this.configuracion.cost_string);
    //   this.formNuevaCapa.get('salida').setValue(capa.nombre == this.configuracion.salida);
    // }



    let tmpInputs = []
    for(let tmp of capa.inputs){
      for (var [key, value] of Object.entries(tmp)){
        tmpInputs.push(value)
      }
    }
    this.inputs.patchValue(tmpInputs);
    let tmpSettings = []
    for(let tmp of capa.settings){
      for (var [key, value] of Object.entries(tmp)){
        tmpSettings.push(value)
      }
    }
    this.settings.patchValue(tmpSettings);
    this.modalService.open(edita_capa, {scrollable: true,size: 'lg',ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {

      for(let entrada of this.tipoCapas[capa.tipo].inputs){
        //this.inputs.push(this.formBuilder.control(''))
        entrada.removeOption("layer_output-"+capa.nombre)
      }

      let tmp = this.formNuevaCapa.value;
      console.log("Antes", this.configuracion.layers_output_names)
      var indexTmp = this.configuracion.layers_output_names.indexOf("layer_output-"+capa.nombre);
      this.configuracion.layers_output_names.splice(indexTmp, 1);
      console.log("Despues", this.configuracion.layers_output_names)

      let salida = "layer_output-"+tmp.nombre;
      if(this.tipoCapas[tmp.tipo].outputs.length == 0){
        this.configuracion.layers_output_names.push(salida);
      }
      else{
        for(let out of this.tipoCapas[tmp.tipo].outputs){
          this.configuracion.layers_output_names.push(salida+"_"+out.variable_name)
          console.log("La salida 2 es: ", this.configuracion.layers_output_names.push(salida+"_"+out.variable_name))
        }
      }
      //this.tipoCapasCounter[tmp.tipo]+=1;
      //this.capas_counter++;
      let tmpInputs = []
      for(let i = 0; i < this.tipoCapas[tmp.tipo].inputs.length; i++){
        tmpInputs.push({
          [this.tipoCapas[tmp.tipo].inputs[i].key] : tmp.inputs[i]
        })
      }
      tmp.inputs = tmpInputs;
      let tmpSettings = []
      for(let i = 0; i < this.tipoCapas[tmp.tipo].settings.length; i++){
        tmpSettings.push({
          [this.tipoCapas[tmp.tipo].settings[i].key] : tmp.settings[i]
        })
      }
      tmp.settings = tmpSettings;

      if(tmp.log){
        //si el nombre de la capa no estaba, lo agrego
        if(!this.configuracion.training_log_outputs.includes(tmp.nombre)){
          this.configuracion.training_log_outputs.push(tmp.nombre);
        }
        //si ya estaba no hago nada
      }else{
        let pos = this.configuracion.training_log_outputs.indexOf(tmp.nombre);
        //si el nombre de la capa estaba en el arreglo, debo eliminarlo
        if(pos > 0){
          //remuevo 1 elemento en la posicion dada
          this.configuracion.training_log_outputs.splice(pos, 1);
        }
        //si no estaba, no hago nada
      }
      if(tmp.cost_string){
        this.configuracion.cost_string = salida;
      }
      if(tmp.salida){
        this.configuracion.salida = salida;
      }
      //elimino las propiedades del objeto temporal, ya que no las quiero guardar en la base de datos
      //delete tmp.log;
      //delete tmp.cost_string;
      //delete tmp.salida;

      this.configuracion.layers_architecure[index_capa] = tmp;

      console.log('Configuracion hasta el momento: ', this.configuracion)
      this.resetNuevaCapa();
      this.subscription.unsubscribe();
    }, (reason) => {
      this.resetNuevaCapa();
      this.subscription.unsubscribe();
    });
  }
  async guardarConfiguracion(){
      console.log("guardando...");
      this.configuracion = {...this.configuracion,...this.formConfiguracion.value};
      console.log('Config final: ', this.configuracion);
      if(this.validacionesArquitectura()) {
        return;
      }
      this.verificarConfig()
      let response;
      if(!this.idArquitecturaAEditar) {
        console.log('Entre al crear')
        response = await this._apiRestService.postArquitectura(this.configuracion);
      }
      else {
        console.log('Entre al editar')
        console.log('La config es: ', this.configuracion)
        response = await this._apiRestService.editArquitectura(this.idArquitecturaAEditar, this.configuracion)
      }
      if(response.ok){
        console.log("guardado ok");
        //redireccionar
        //this.router.navigate(['/entrenar/configuracion'])
        this.router.navigate(['/servicio/'+this.idservicio+'/entrenar/configuracion']);
      }
      else{
        console.log("Fallo el guardado");
        console.log(response);
      }
  }

  validacionesArquitectura() {
    console.log(this.capas_counter)
    if(this.formConfiguracion.controls['nombre'].errors?.required ||
       this.formConfiguracion.controls['tipo'].errors?.required) {
        this._messageService.error("Faltan campos a rellenar")
        return true;
    } else if(this.capas_counter == 0) {
      this._messageService.error("La arquitectura debe tener al menos 1 capa")
        return true;
    } else {
      return false;
    }
  }

  verificarConfig() {
    let capaSalida = false;
    let capaCostos = false;

    for(let layer in this.configuracion.layers_architecure) {
      if(this.configuracion.layers_architecure[layer].salida) {
        capaSalida = true;
      }

      if(this.configuracion.layers_architecure[layer].cost_string) {
        capaCostos = true;
      }
    }
    if(!capaSalida) {
      this.configuracion.salida = null
    }
    if(!capaCostos) {
      this.configuracion.cost_string = null;
    }
  }

  async getArquitectura() {
    let response = await this._apiRestService.getArquitectura(this.idArquitecturaAEditar);
    this.configuracion = response.dato;
    console.log('La arquitectura es2: ', this.configuracion)
    this.capas_counter = this.configuracion.layers_architecure.length;
    console.log("Capas counter es: ", this.capas_counter)
    this.formConfiguracion.setValue({ nombre: response.dato.nombre, tipo: response.dato.tipo, estado: response.dato.estado })
  }

  abrirModalEliminar(modal) {
    this.modalService.open(modal);
  }

  async getServicio() {
    console.log("Entre al get servicio")
    let response = await this._apiRestService.getServicio(this.idservicio);
    if(response.ok) {
      console.log("El servicio es: ", response.dato);
      this.servicio = response.dato;
    } else {
      console.log("Hubo un error", response.error)
    }
  }

}






