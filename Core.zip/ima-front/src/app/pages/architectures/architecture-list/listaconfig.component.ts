import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';

import { Modelo } from 'src/app/models/modelo';
import { ApiRestService } from '../../../services/api-rest.service';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from "@angular/router"
import { MessageService } from 'src/app/services/messages.service';

import { RespuestaArquitectura} from 'src/app/models/respuesta.model'
import { Location } from '@angular/common';
import { animate, style, transition, trigger, query, stagger, state } from '@angular/animations';
import { PlainFileService } from 'src/app/services/plain-file.service';

@Component({
  selector: 'app-listaconfig',
  templateUrl: './listaconfig.component.html',
  styleUrls: ['./listaconfig.component.css'],
  animations: [
    trigger("listAnimation", [
      transition("* => *", [
        // each time the binding value changes
        query(
          ":leave",
          [stagger(100, [animate("0.5s", style({ opacity: 0 }))])],
          { optional: true }
        ),
        query(
          ":enter",
          [
            style({ opacity: 0 }),
            stagger(100, [animate("0.5s", style({ opacity: 1 }))])
          ],
          { optional: true }
        )
      ])
    ]),
    trigger(
      'enterAnimation', [
        transition(':enter', [
          style({transform: 'translateX(-100px)', opacity: 0}),
          animate('300ms', style({transform: 'translateX(0)', opacity: 1, 'overflow-x': 'hidden'}))
        ]),
      ]
    ),
    trigger('slideIn', [
      state('*', style({ 'overflow-y': 'hidden' })),
      state('void', style({ 'overflow-y': 'hidden' })),
      transition('* => void', [
        style({ height: '*' }),
        animate(250, style({ height: 0 }))
      ]),
      transition('void => *', [
        style({ height: '0' }),
        animate(250, style({ height: '*' }))
      ])
    ])
  ]
})
export class ListaConfiguracionesComponent implements OnInit {
  public arquitecturas: any[];
  public configuraciones: any[];

  public closeResult = '';
  public nombre_modulo = "";
  imod: number;
  formModelo : FormGroup;
  //listaConf: FormControl;
  subscription: Subscription;
  conf_actual: any;
  idservicio:string;
  idArquitecturaAEliminar: any;
  filtroTipo: any;
  valorFiltroTipo: any;
  filtroEstado: any;
  valorFiltroEstado: any;
  filtroActivo: any;
  filtroActivoDesc: any;
  nombreArchAEntrenar: any;
  archSeleccionada: any;
  page = 1;
  pageSize = 7;
  filtros: any;
  numberOfCol: any = 'col-md-4';
  constructor(
    private router:Router,
    private formBuilder: FormBuilder,
    private modalService: NgbModal ,
    private _messageService: MessageService,
    private route: ActivatedRoute,
    public _apiRestService: ApiRestService,
    private _plainFileService: PlainFileService,
    private location: Location) {
  }


  ngOnInit(): void {
    this.iniciarFiltros();
    this.filtroEstado = false;
    this.filtroTipo = false;
    this.formModelo = this.formBuilder.group({
      nombre: ['', Validators.required],
      modelo: ['', Validators.required],
      n_epochs: ['', Validators.required],
      batch_size: ['', Validators.required],
      learning_rate: ['', Validators.required],
      print_cost_every_n_batch: ['', Validators.required],
      early_stopping: ['', Validators.required],
      L1_lambda: ['', Validators.required],
      L2_lambda: ['', Validators.required],
      dropout: ['', Validators.required],
      id_architecture: [0],
      listaConf: [''],
      lower_bound: ['', Validators.required],
      upper_bound: ['', Validators.required],
      trainset: ['', Validators.required],
      testset: ['', Validators.required]
    });
    this.subscription = this.formModelo.get('listaConf').valueChanges.subscribe(val => {
      this.confCambiada(val);
    });
    this.idservicio = this.route.snapshot.paramMap.get('idservicio');
    console.log(this.idservicio);
    this.getArquitecturas('updatedAt', 'true');
    this.getConfiguraciones();
  }

  volverEnNavegacion() {
    this.location.back();
  }

  iniciarFiltros() {
    this.filtros = {
      'idArquitectureDesc': false,
      'nombreArchDesc': false,
      'createdAtDesc': false,
      'updatedAtDesc': false,
      'tipoDesc': false,
      'estadoDesc': false
    }
  }
  open(content, mod, nombre) {
    this.imod = mod;
    this.nombreArchAEntrenar = nombre;
    this.formModelo.get('id_architecture').setValue(this.arquitecturas[mod].id_architecture);
    console.log('La config a entrenar es: ', this.formModelo.value)
    this.modalService.open(content, {
      windowClass: 'modal-holder',
      scrollable: true,
      //size: 'lg',
      ariaLabelledBy: 'modal-basic-title'
    }).result.then((result) => {
      console.log(result);
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  async guardar(modal, retornar = false){
    let nueva = this.formModelo.value;
    nueva = {...nueva, idservicio:this.idservicio}
    console.log(nueva);

    let response = await this._apiRestService.postConfiguracion(nueva);
    if(response.ok){
      console.log(response);
      //this.getConfiguraciones();
      this.configuraciones.push(response.dato);
      if(retornar){
        return response.dato;
      }
    }
    else{
      modal.close("Error");
      this._messageService.error(response.message);
    }
  }

  async entrenar(modal){
    console.log('Entre al entrenar')
    console.log('AAAAA', this.formModelo)
    if(this.validacionesForm()) {
      return;
    }
    let conf_actual = await this.guardar(modal, true);
    let resp2 = await this._apiRestService.cambiarEstadoEntrenadoArchitectura(this.formModelo.get('id_architecture').value);
    let modelo = await this.guardarModelo(conf_actual)
    //let resp = await this._apiRestService.launchTrain(conf_actual.idconf, 'true', modelo.idmodelo);
    modal.close();
    this.router.navigate(['/servicio/'+this.idservicio+'/entrenar']);
    try {
      let resp3 = this._apiRestService.launchTrainPy(conf_actual.idconf, 'true', modelo.idmodelo);
    } catch(e) {
      console.log("ERROR: ", e)
    }

  }

  validacionesForm() {
    const trainSetValue = this.formModelo.controls['trainset'].value;
    const testSetValue = this.formModelo.controls['testset'].value;

    var error = 0;

    if( (trainSetValue + testSetValue) != 1) {
      this._messageService.error('La suma del conjunto test y entrenamiento debe ser 1')
      error = 1;
    }

    if(this.formModelo.controls['n_epochs'].errors?.required ||
       this.formModelo.controls['nombre'].errors?.required ||
       this.formModelo.controls['modelo'].errors?.required ||
       this.formModelo.controls['batch_size'].errors?.required ||
       this.formModelo.controls['learning_rate'].errors?.required ||
       this.formModelo.controls['early_stopping'].errors?.required ||
       this.formModelo.controls['L1_lambda'].errors?.required ||
       this.formModelo.controls['L2_lambda'].errors?.required ||
       this.formModelo.controls['dropout'].errors?.required ||
       this.formModelo.controls['lower_bound'].errors?.required ||
       this.formModelo.controls['upper_bound'].errors?.required ||
       this.formModelo.controls['trainset'].errors?.required ||
       this.formModelo.controls['testset'].errors?.required) {

        this._messageService.error('Faltan campos a rellenar')
        error = 1;
    }

    if(error == 1) {
      return true;
    } else {
      return false;
    }

  }

  async guardarModelo(conf_actual) {
    let modelo = {
      "nombre":"MD-"+conf_actual.modelo,
      "id_architecture": this.formModelo.get('id_architecture').value,
      "estado": "PREPARANDO",
      "entrenando": false,
      "idconf": conf_actual.idconf,
      "fecha": Date.now(),
      "stop": false,
      "trained_epochs": 0,
      "idservicio": this.idservicio
    }

    let resp1 = await this._apiRestService.postModelo(modelo)
    console.log("El modelo es:  ", resp1.dato)
    return resp1.dato
  }

  async eliminar(modal){
    //this.imod = arquitectura;
    await this._apiRestService.delArquitectura(this.idArquitecturaAEliminar);
    this._messageService.success('Arquitectura eliminada correctamente');
    this.getArquitecturas(this.filtroActivo, this.filtroActivoDesc);
    modal.close();
  }

  openEliminarModal(modal, id_architecture) {
    this.idArquitecturaAEliminar = id_architecture;
    this.modalService.open(modal);
  }

  getArquitecturas(param, descending){
    console.log("llamando a backend")
    this.filtroActivo = param;
    this.filtroActivoDesc = descending;

    if(this.filtroEstado && this.filtroTipo) {
      this._apiRestService.getArquitecturasByTipoAndEstado(param, descending, this.valorFiltroTipo, this.valorFiltroEstado, this.idservicio).then( ( resultados: any ) => {
        if(resultados.status == 200){
          this.arquitecturas = resultados.datos;
          console.log("Lista de arquitecturas: ", this.arquitecturas)
        }
      });
    } else if(this.filtroTipo) {
      this._apiRestService.getArquitecturasByTipo(param, descending, this.valorFiltroTipo, this.idservicio).then( ( resultados: any ) => {
        if(resultados.status == 200){
          this.arquitecturas = resultados.datos;
          console.log("Lista de arquitecturas: ", this.arquitecturas)
        }
      });
    } else if(this.filtroEstado) {
      this._apiRestService.getArquitecturasByEstado(param, descending, this.valorFiltroEstado, this.idservicio).then( ( resultados: any ) => {
        if(resultados.status == 200){
          this.arquitecturas = resultados.datos;
          console.log("Lista de arquitecturas: ", this.arquitecturas)
        }
      });
    } else {
      this._apiRestService.getArquitecturas(param, descending, this.idservicio).then( ( resultados: any ) => {
        if(resultados.status == 200){
          this.arquitecturas = resultados.datos;
          console.log("Lista de arquitecturas: ", this.arquitecturas)
        }
      });
    }
  }

  getConfiguraciones(){
    console.log("backend")
    this._apiRestService.getTrainConfs(this.idservicio).then( ( resultados: any ) => {
      if(resultados.status == 200){
        this.configuraciones = resultados.datos;
        console.log("Lista de configuraciones: ", this.configuraciones)
      }
    });
  }

  cambioFiltroTipo(tipo) {
    if(tipo != -3) {
      this.filtroTipo = true;
      this.valorFiltroTipo = tipo;
      this.getArquitecturas(this.filtroActivo, this.filtroActivoDesc);
    } else {
      this.filtroTipo = false;
      this.valorFiltroTipo = null;
      this.getArquitecturas(this.filtroActivo, this.filtroActivoDesc)
    }
  }

  cambioFiltroEstado(estado) {
    if(estado != -3) {
      this.filtroEstado = true;
      this.valorFiltroEstado = estado;
      this.getArquitecturas(this.filtroActivo, this.filtroActivoDesc)
    } else {
      this.filtroEstado = false;
      this.valorFiltroEstado = null;
      this.getArquitecturas(this.filtroActivo, this.filtroActivoDesc)
    }

  }


  confCambiada(conf){
    this.conf_actual = this.configuraciones[conf];
    console.log(this.configuraciones[conf]);
    this.formModelo.get('nombre').setValue(this.configuraciones[conf].nombre);
    this.formModelo.get('n_epochs').setValue(this.configuraciones[conf].n_epochs);
    this.formModelo.get('batch_size').setValue(this.configuraciones[conf].batch_size);
    this.formModelo.get('learning_rate').setValue(this.configuraciones[conf].learning_rate);
    this.formModelo.get('print_cost_every_n_batch').setValue(this.configuraciones[conf].print_cost_every_n_batch);
    this.formModelo.get('early_stopping').setValue(this.configuraciones[conf].early_stopping);
    this.formModelo.get('L1_lambda').setValue(this.configuraciones[conf].L1_lambda);
    this.formModelo.get('L2_lambda').setValue(this.configuraciones[conf].L2_lambda);
    this.formModelo.get('dropout').setValue(this.configuraciones[conf].dropout);
    this.formModelo.get('id_architecture').setValue(this.arquitecturas[this.imod].id_architecture);
    this.formModelo.get('lower_bound').setValue(this.configuraciones[conf].lower_bound);
    this.formModelo.get('upper_bound').setValue(this.configuraciones[conf].upper_bound);
    this.formModelo.get('trainset').setValue(this.configuraciones[conf].trainset);
    this.formModelo.get('testset').setValue(this.configuraciones[conf].testset);
  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  irAEditarConfig(id_architecture) {
    //[routerLink]="'/servicio/'+idservicio+'/entrenar/configuracion/nueva'"
    this.router.navigateByUrl('/servicio/'+this.idservicio+'/entrenar/configuracion/nueva', {state: { id_architecture }});
  }

  abrirModalVerMas(arq, modal) {
    this.archSeleccionada = arq;
    console.log("Arquitectura seleccionada es: ", this.archSeleccionada)
    this.modalService.open(modal)
  }

  downloadTxtFile() {
    var layersText = ''
    for(let layer of this.archSeleccionada.layers_architecure) {
      layersText = layersText + `\n ${layer.nombre}`
    }
    const text = `ID arquitectura: ${this.archSeleccionada.id_architecture}\nNombre arquitectura: ${this.archSeleccionada.nombre}\nTipo arquitectura ${this.archSeleccionada.tipo}\nEstado arquitectura ${this.archSeleccionada.estado}\nFecha de creación ${this.archSeleccionada.createdAt}\nFecha última actualización ${this.archSeleccionada.updatedAt}\nCapas: ${layersText}`
    this._plainFileService.dyanmicDownloadByHtmlTag({
      fileName: `Información arquitectura ${this.archSeleccionada.id_architecture}`,
      text: text
    })
  }
}
