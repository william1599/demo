import { Component, Input, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ApiRestService } from "src/app/services/api-rest.service";
import { OptimizerService } from "../../optimizer/services/optimizer.service";


@Component({
    selector: 'app-forecast-optimizer',
    templateUrl: './forecasts-optimizer.component.html'
})
export class ForecastOptimizerComponent implements OnInit {
    @Input() modal: any;
    @Input() optimizer: any;
    optimizerTmp: any;
    forecastOptForm: FormGroup

    constructor(
        private _apiRestService: ApiRestService,
        private _optimizerService: OptimizerService,
        private formBuilder: FormBuilder
    ) {}

    ngOnInit() {        
        console.log("Optimizador: ", this.optimizer);
        this.getOptimizerById();
        this.forecastOptForm = this.forecastOptFormCreate();
    }

    forecastOptFormCreate() {
        return this.formBuilder.group({
            desarrollo: ['', Validators.required],
            espesor: ['', Validators.required],
            pmth1: ['', Validators.required]
        });
    }

    async submit() {
        console.log("optimizerTMP: ", this.optimizerTmp);
        let col_variables = [];
        let col_salidas_modelos = [];
        let col_constantes = [];
        let ponderador_entradas = [];
        let ponderador_accuracy = [];
        let valores_maximos = [];
        let valores_minimos = [];
        let options = {
            "c1": 0.5,
            "c2": 0.3,
            "w": 0.9
        }

        let obj = {
            "numero_de_particulas": this.optimizerTmp.num_particulas,
            "numero_de_iteraciones": this.optimizerTmp.num_iteraciones,
            "salida_del_modelo": this.optimizerTmp.modelo?.architecture?.salida,
            "options": options
        }

        let variables = this.optimizerTmp.modelo?.parametros_prediccion;
        console.log("Variables: ", variables);

        for(let variable of variables) {
            if (variable.esConstante) {
                col_constantes.push(variable.dato_coleccion?.nombre);
            }
            if (variable.isOutput) {
                col_salidas_modelos.push(variable.dato_coleccion?.nombre);
                ponderador_accuracy.push(parseInt(variable.ponderador));
            }
            if(!variable.isOutput && !variable.esConstante) {
                col_variables.push(variable.dato_coleccion?.nombre);
                ponderador_entradas.push(parseInt(variable.ponderador));
                valores_maximos.push(variable.dato_coleccion?.max);
                valores_minimos.push(variable.dato_coleccion?.min);
            }
        }

        //col_constantes.push("desarrollo");
        //col_constantes.push("espesor");

        obj["valores_maximos"] = valores_maximos;
        obj["valores_minimos"] = valores_minimos;
        obj["col_variables"] = col_variables;
        obj["col_salidas_modelo"] = col_salidas_modelos;
        obj["ponderador_accuracy"] = ponderador_accuracy;
        obj["ponderador_entradas"] = ponderador_entradas;
        obj["col_constantes"] = col_constantes;

        const objJSON = JSON.stringify(obj);
        console.log("obj", obj);
        console.log("FORM: ", this.forecastOptForm.value);

        const json_entrada = {
            "salida_objetivo": [parseInt(this.forecastOptForm.value.pmth1)],
            "constantes": [parseInt(this.forecastOptForm.value.desarrollo)]
        }

        //const resp = await this._apiRestService.launchOptimizerForecast(objJSON, this.optimizerTmp?.modelo, json_entrada);
    }

    async getOptimizerById() {
        this.optimizerTmp = await this._optimizerService.getOptimizerById(this.optimizer.idoptimizador);
        console.log("optimizerTMP: ", this.optimizerTmp);
    }
}