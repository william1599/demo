import { Injectable, OnDestroy } from '@angular/core';
import { Observable, timer, Subscription, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { switchMap, tap, share, retry, takeUntil } from 'rxjs/operators';
import { env, URLS } from '../../../config/config';
import * as modelos from 'src/app/models/respuesta.model';

@Injectable()
export class ForecastsService implements OnDestroy {
    private predicciones$: Observable<modelos.RespuestaArray>;
    private stopPolling = new Subject();
    private limit = 10;
    private offset = 0;
    private idservicio: number;
    private url: string;


    constructor(private _http: HttpClient) {
        console.log('Objeto instanciado');
    }

    start(idservicio: number, idmodelo, idciclo) {
        this.url = URLS[env].FORECAST_MANAGER + '/prediccion?idservicio=' + idservicio + '&limit=' + this.limit + '&offset=' + this.offset;

        console.log('Iniciando servicio en url ' + this.url);

        this.idservicio = idservicio;
        this.predicciones$ = timer(1, 5000).pipe(
            switchMap(() => this._http.get<modelos.RespuestaArray>( this.url, {
                params: {
                    idmodelo,
                    idciclo,
                    habilitado: 'true'
                }
            } )),
            retry(),
            // tap((x)=>console.log("datos recibidos")),
            share(),
            takeUntil(this.stopPolling)
        );
    }
    continue(idmodelo, idciclo) {
        console.log('CONTINUE', idmodelo);
        this.start(this.idservicio, idmodelo, idciclo);
        return this.getPredicciones();
    }
    restart(idmodelo, idciclo) {
        this.stop();
        return this.continue(idmodelo, idciclo);
    }
    stop() {
        console.log('Parando servicio de log de predicciones');
        this.stopPolling.next();
    }
    getPredicciones(): Observable<modelos.RespuestaArray> {
        console.log('pidiendo predicciones');
        return this.predicciones$;
        // return this.modelos$.pipe(tap(() => console.log('data sent to subscriber')));
    }
    setLimit(limit: number) {
        this.limit = limit;
    }
    setOffset(offset: number) {
        this.offset = offset;
    }
    setUrl(idservicio, limit, offset) {
        this.url = URLS[env].TRAIN_MANAGER + '/prediccion?idservicio=' + idservicio + '&limit=' + this.limit + '&offset=' + this.offset;
    }
    ngOnDestroy() {
        this.stop();
    }
}
