import {Injectable} from '@angular/core';
import { ApiRestService } from '../../../services/api-rest.service';
import {MessageService} from '../../../services/messages.service';

@Injectable()
export class RecordChartService {
  private chartRecordObj: any;
  private chartRecordValues: any;
  private chart: any;
  constructor(private apiRestService: ApiRestService,
              private _messageService: MessageService) {}
  async getChartRecord(activeModelId, selectedForecastCycle, isNormalize, variable) {
    let resp = null;
    try {
      resp = await this.apiRestService.getForecastRecord(activeModelId, selectedForecastCycle, isNormalize, variable);
    } catch (e) {
      this._messageService.error('Sin datos de historial para el ajuste');
    }
    if (resp.ok) {
      console.log("RESP: ", resp);
      this.chartRecordObj = resp.datos;
      const chartData = JSON.parse(this.chartRecordObj.finalChartData);
      this.chartRecordObj['parsedData'] = chartData;
      this.chartRecordValues = chartData;
    } else {
      console.log('Error al obtener historial de prediccion');
    }
    this.createChart();
    return this.getChart();
  }
  getChartObj() {
    return this.chartRecordObj;
  }
  getChartData() {
    return this.chartRecordValues;
  }
  createChart() {
    this.chart = {
      lineChartData: this.chartRecordValues,
      lineChartLabels: this.chartRecordObj.labels,
      lineChartType: 'bar',
      lineChartLegend: true,
      lineChartOptions: {
        scales: {
          xAxes: [{
            display: true,
            scaleLabel: {
              display: true,
              labelString: 'Predicción'
            },
            ticks: {
              maxRotation: 60,
              minRotation: 60,
            }
          }]
        },
        tooltips: {
          callbacks: {
            // funcion que permite ver el tooltip, kilos remanentes
            label: function(tooltipItem, data) {
              const auxLabels = data.labels;
              let valueIdx;
              auxLabels.forEach(function (value, i) {
                if (value === tooltipItem.xLabel) {
                  valueIdx = i;
                }
              });
              if (data.datasets[tooltipItem.datasetIndex].isNormalize === 'true') {
                const firstValue = 'Dato real: ' + parseFloat(data.datasets[tooltipItem.datasetIndex].auxData[valueIdx]).toFixed(2);
                const secondValue = 'Dato normalizado: ' + parseFloat(tooltipItem.value).toFixed(2);
                const tmpLabel = [];
                tmpLabel.push(firstValue);
                tmpLabel.push(secondValue);
                const etiqueta = 'Dato real: ' + firstValue + '\n' + 'Dato normalizado: ' + secondValue;
                return tmpLabel;
              } else {
                const secondValue = 'Dato normalizado: ' + parseFloat(data.datasets[tooltipItem.datasetIndex].auxData[valueIdx]).toFixed(2);
                const firstValue = 'Dato real: ' + parseFloat(tooltipItem.value).toFixed(2);
                const etiqueta = 'Dato real: ' + firstValue + ' Dato normalizado: ' + secondValue;
                const tmpLabel = [];
                tmpLabel.push(firstValue);
                tmpLabel.push(secondValue);
                return tmpLabel;
              }
              // const firstValue = parseFloat(data.datasets[tooltipItem.datasetIndex].auxData[valueIdx]).toFixed(2);
              // const secondValue = parseFloat(tooltipItem.value).toFixed(2);

            }
          }
        },
      },
      firstDate: this.chartRecordObj.startDate,
      lastDate: this.chartRecordObj.lastDate
    };
    console.log("FINAL CHART: ", this.chart);
  }
  getChart() {
    return this.chart;
  }
}
