import { Injectable } from "@angular/core";
import { ApiRestService } from "src/app/services/api-rest.service";

@Injectable({ providedIn: 'root' })
export class ForecastConfigService {
    private forecastsConfig = [];

    constructor(private apiRestService: ApiRestService) {}

    async getForecastConfigsByForecast(idforecast, isOutput) {
        const resp = await this.apiRestService.getForecastConfigByForecast(idforecast, isOutput);
        if(resp.ok) {
            this.forecastsConfig = resp.datos;
            return this.forecastsConfig;
        } else {
            console.log("Error al obtener configuraciones")
        }
    }

    async editRealValuesForConfig(body) {
        const resp = await this.apiRestService.editValuesForConfig(body);
        if(resp.ok) {
            return resp;
        } else {
            console.log("Error al obtener configuraciones")
        }
    }
}