import {Injectable, Input, OnInit} from '@angular/core';
import { ApiRestService } from '../../../services/api-rest.service';
import { MessageService } from '../../../services/messages.service';

@Injectable()
export class ForecastCycleService {
  private forecastCycles: any;
  private forecastCycle: any;
  constructor(private apiRestService: ApiRestService,
              private messagesService: MessageService) {}
  async getForecastsCycles(activeModel) {
    const resp = await this.apiRestService.getForecastCycles(activeModel);
    if (resp.ok) {
      this.forecastCycles = resp.datos;
      console.log('Forecast cycles: ', this.forecastCycles);
      return this.forecastCycles;
    } else {
      this.messagesService.error('Error al obtener ciclos');
    }
  }
  async getCycleById() {

  }
  getCycles() {
    return this.forecastCycles;
  }
  getCycle() {
    return this.forecastCycle;
  }
}
