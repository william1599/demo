import {Component, Input, OnInit} from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import {ApiRestService} from '../../../../services/api-rest.service';
import {MessageService} from '../../../../services/messages.service';
import { ForecastConfigService } from '../../services/forecasts-config.service';

@Component({
  selector: 'app-forecast-results',
  templateUrl: './forecast-results.component.html',
  styleUrls: ['./forecast-result.component.css']
})

export class ForecastResultsComponent implements OnInit {
  @Input() servicio: any;
  @Input() modeloActivo: any;
  @Input() prediccionActual: any;
  @Input() finalResults: any;
  @Input() modal: any;
  @Input() inputsConfig: any;
  @Input() isOptimizer: any;
  activeIdString: any;
  verifiedForecast: any;
  showOutInputs: any = false;
  outputVariables: any;
  outputForm: FormGroup;
  showSuccessMessage: any = false;
  parsedResult: any;
  constructor(private _apiRestService: ApiRestService,
              private _messageService: MessageService,
              private _forecastConfigService: ForecastConfigService) {
  }

  ngOnInit() {
    if(this.isOptimizer) {

    }

    console.log("Prediccion actual: ", JSON.parse(this.prediccionActual.forecast));
    this.parsedResult = JSON.parse(this.prediccionActual.forecast);
    console.log("FinalRESULT: ", this.finalResults);
    this.getForecastConfigs(this.prediccionActual.idforecast, 'true');
    this.verifiedForecast = this.prediccionActual.verificado;
    this.prediccionActual.forecast_configs.sort((a,b) => (a.variable_prediccion.orden > b.variable_prediccion.orden) ? 1 : ((b.variable_prediccion.orden > a.variable_prediccion.orden) ? -1 : 0));
  }

  async getForecastConfigs(idforecast, isOutput) {
    this.outputVariables = await this._forecastConfigService.getForecastConfigsByForecast(idforecast, isOutput);
    const group: any = {};
    this.outputVariables.forEach(outVar => {
      // Cambiar en el form control a la columna nueuva que se debe hacer en la BD
      if(outVar.valorReal) {
        group[outVar.idconfig] = new FormControl(outVar.valorReal)  
      } else {
        group[outVar.idconfig] = new FormControl('')
      }
    })
    this.outputForm = new  FormGroup(group);
    console.log("outputvar: ", this.outputVariables);

    if(this.verifiedForecast) {
      this.showOutInputs = true;
    }
  }

  async checkVerifiedChange() {
    console.log(this.verifiedForecast = !this.verifiedForecast);
    console.log('NUEVO VALOR: ', this.verifiedForecast);
    if(this.verifiedForecast) {
      this.showOutInputs = false;
    } else {
      this.showOutInputs = true;
    }
    const body = {
      verificado: this.verifiedForecast = !this.verifiedForecast
    };
    try {
      await this._apiRestService.editVerifiedForecast(this.prediccionActual.idforecast, body);
    } catch (e) {
      this._messageService.error('Error al cambiar el estado de la predicción');
    }

    //this.outputForm = group;

  }

  async submitValues() {
    console.log("FORM: ", this.outputForm.value);
    const resp = await this._forecastConfigService.editRealValuesForConfig(this.outputForm.value);
    if(resp.ok) {
      this._messageService.success('Valores ingresados correctamente. Gracias por tu colaboración.');
      this.showSuccessMessage = true;
    } else {
      this._messageService.error('Error al guardar los valores.');
    }
    console.log("RESP: ", resp);
  }

  closeAlert() {
    console.log("ENTRE AL CLOSE")
    this.showSuccessMessage = false;
  }
}
