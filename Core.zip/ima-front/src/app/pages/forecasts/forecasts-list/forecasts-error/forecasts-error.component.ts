import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-forecasts-error',
  templateUrl: './forecasts-error.component.html'
})

export class ForecastsErrorComponent implements OnInit {
  @Input() prediccionActual: any;
  @Input() modal: any;
  constructor() {
  }
  ngOnInit() {
    console.log("ForecastsErrorComponent");
  }
}
