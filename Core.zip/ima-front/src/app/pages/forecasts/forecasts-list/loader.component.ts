import { Component, Input, OnInit } from "@angular/core";


@Component({
  selector: 'app-loader',
  template: `
  <div *ngIf="saveSpinner" class="loader">
      <span class="sr-only">Cargando...</span>
  </div>
  `
})

export class LoaderComponent implements OnInit {
  @Input() saveSpinner : boolean = false

  ngOnInit(): void {

  }
}
