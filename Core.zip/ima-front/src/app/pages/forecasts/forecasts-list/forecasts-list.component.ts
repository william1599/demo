import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { ApiRestService } from 'src/app/services/api-rest.service';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { Form, FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { HttpEventType } from '@angular/common/http';
import * as modelos from 'src/app/models/respuesta.model';
import { asyncScheduler, forkJoin, Observable, of, scheduled, Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { MessageService } from 'src/app/services/messages.service';
import { ForecastsService } from '../services/forecasts.service';

import { DatePipe, DecimalPipe, Location } from '@angular/common';
import { ExcelExportService } from 'src/app/services/excel-export.service';

import { registerLocaleData } from '@angular/common';
import es from '@angular/common/locales/es';
import { catchError } from 'rxjs/operators';
import { NgChartjsDirective, NgChartjsService } from 'ng-chartjs';
// import { Chart } from 'chart.js';
import { ChartDataSets, ChartType, RadialChartOptions } from 'chart.js';
// import { Label } from 'ng2-charts';

import { PredictionService } from 'src/app/models/predictions-models/prediction.service';
import { PredictionsBase } from 'src/app/models/predictions-models/prediction-form';
import { PredictionControlService } from 'src/app/models/predictions-models/prediction-control.service';
import { DynamicFormComponent } from '../forecasts-quality-create/forecasts-create-dynamic-form.component';
import {RecordChartService} from '../services/record-chart.service';
import {ForecastCycleService} from '../services/forecasts-cycles.service';
import { OptimizerService } from '../../optimizer/services/optimizer.service';


const gris = 'rgba(0, 0, 0, 0)';
const amarillo = 'rgba(219, 190, 0, 1)';
const rojo = 'red';
const MAX_FILE_SIZE = 10 * 1024 * 1024;

interface uploadedFile {
  field: string;
  body: modelos.RespuestaDato;
}

@Component({
  selector: 'app-listaforecasts',
  templateUrl: './forecasts-list.component.html',
  styleUrls: ['./forecasts-list.component.css']
})
export class ListaForecastsComponent implements OnInit {

  predictions: PredictionsBase<string>[] | null = [];
  predictions$: Observable<PredictionsBase<any>[]>;
  chartOneTest: any;
  chartRecordObj: any;
  form!: FormGroup;
  rol: string;
  uploadForm: FormGroup;
  invalid = {
    nombre: false,
    historial_produccion: false,
    historial_mantenimiento: false
  };
  progress: any;
  disable_predecir: boolean;
  acceptFiles: Array<string>;
  idservicio: any;
  servicio: any;
  modelos: Array<any>;
  modeloActivo: any;
  idModeloActivo: any;
  predicciones: Array<any>;
  prediccionActual: any;
  prediccionLoading: boolean;
  datosGrafico;
  chartDatos: any;
  historialLoading: boolean;
  changePlot: any;
  modelosServicio: any;
  activeId = 1;
  activeIdString = 'tab-selectbyid1';
  inputsConfig: any;
  modalReference: any;
  defaultFormValues: any;
  prediccionPMT = true;
  mantForm: FormGroup;
  graficoHistorial: any;
  datosHistorial: any;
  modal_historial;
  usuarioActual;
  selectedCycle: any = -1;
  selectedModel: any = -1;
  selectedForecastCycle: any = -1;
  forecastCycles: any;
  forecastResults: any;
  idCycle: any = undefined;
  newCycle: any = undefined;
  recordChartValues: any;
  isOptimizer: any;
  optimizer: any;
  modelCnf: any;
  private prediccionAEliminar: any;
  paginacion = {
    pagina: 1,
    paginas: 9,
    limit: 10,
    total: 100
  };
  prediccionesSubscripcion: Subscription;
  MAX_BAR_THICKNESS = 25;

  constructor(
    private _apiService: ApiRestService,
    private location: Location,
    private datePipe: DatePipe,
    private decimalPipe: DecimalPipe,
    private _excelService: ExcelExportService,
    private formBuilder: FormBuilder,
    private _route: ActivatedRoute,
    private modalService: NgbModal,
    private predictionService: PredictionControlService,
    private _messagesService: MessageService,
    private _forecastService: ForecastsService,
    private _predictionService: PredictionService,
    private _authenticationService: AuthenticationService,
    private ngChartjsService: NgChartjsService,
    private _recordChartService: RecordChartService,
    private _forecastCycleService: ForecastCycleService,
    private _optimizerService: OptimizerService) {
      this.predicciones = [];
      this.idservicio = this._route.snapshot.paramMap.get('idservicio');
      this.getForecasts('-1');
     }


  ngOnInit(): void {
    this.getServicio(this.idservicio);
    this.form = this.predictionService.toFormGroup(this.predictions as PredictionsBase<string>[]);
    this.changePlot = true;
    this.historialLoading = false;

    registerLocaleData(es);
    this.modal_historial = null;

    this.uploadForm = this.formBuilder.group({
      historial_produccion: [''],
      historial_mantenimiento: [''],
      planificacion: [''],
      nombre: ['']
    });
    this.progress = {
      historial_produccion: 0,
      historial_mantenimiento: 0,
      planificacion: 0
    };

    this.acceptFiles = [
      // "text/csv",
      // ".csv",
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-excel.sheet.binary.macroEnabled.12',
      // "application/vnd.ms-excel",//csv
      'application/vnd.ms-excel.sheet.macroEnabled.12'];


      this.usuarioActual = this._authenticationService.currentUserValue;
      this.rol = this._authenticationService.currentUserValue.rol;
      console.log('usuarioACtual: ', this.usuarioActual);
      console.log('rol: ', this.rol);
      /*switch(this.rol){
        case "ADMIN":
        case "ING-DATOS":
          this.cargarModelos();
          break;
        case "ADMIN-EMPRESA":
        case "ING-PLANTA":
          this.cargarModeloActivo();
      }*/
      this.modeloActivo = null;
      this.prediccionActual = null;
      this.cargarModeloActivo();
      this.getModelos('idmodelo', 'true');
      this.getCycles();
  }

  volverEnNavegacion() {
    this.location.back();
  }

  async getChartConfig() {

    try {
      console.log("HARE EL LLAMADO");
      const resp = await this._apiService.getChartConfig(this.idModeloActivo);
      console.log("RESP chartcnf: ", resp);
      this.chartDatos = resp.datos;
    } catch (err) {
      console.log("err", err);
    }
  }

  async getModelConfig() {

    const resp = await this._apiService.getModelConfig(this.idModeloActivo);
    console.log("mdcnf: ", resp);
    this.modelCnf = resp.dato;

    for(let file of this.modelCnf.model_files) {
      this.addFile(file.name);
    }
  }

  get mantFiles() {
    return this.mantForm.get("files") as FormArray;
  }

  get uploadedFile() {
    return this.mantForm.get("tmp") as FormArray;
  }

  fileUpload(file) {
    console.log("BLABLA: ", file.target.files);
  }

  addFile(name) {
    return this.mantFiles.push(this.formBuilder.control(name));
  }

  addUploadedFile(file) {
    return this.uploadedFile.push(file)
  }

  initMantForm() {

    const form = this.formBuilder.group({
      files: this.formBuilder.array([]),
      tmp: this.formBuilder.array([])
    })

    return form;
  }

  cambiar_pagina(nueva_pagina) {
    this._forecastService.setOffset(this.paginacion.limit * (nueva_pagina - 1));
    this.prediccionesSubscripcion.unsubscribe();
    this.prediccionesSubscripcion = this._forecastService.restart('-1', '-1').subscribe(this.dataArrived);
    this.paginacion.pagina = nueva_pagina;
  }
  updatePaginacion(total) {
    // this.paginacion.pagina = pagina;
    this.paginacion.paginas = Math.floor(total / this.paginacion.limit);
    this.paginacion.total = total;
  }

  async getForecasts(idmodelo) {
    this._forecastService.start(this.idservicio, idmodelo, this.selectedCycle);
    this.prediccionesSubscripcion = this._forecastService.getPredicciones().subscribe(this.dataArrived);
  }

  async getCycles() {
    const resp = await this._apiService.getForecastCycles(this.modeloActivo);
    if (resp.ok) {
      this.forecastCycles = resp.datos;
      console.log('Forecast cycles: ', this.forecastCycles);
    } else {
      this._messagesService.error('Error al obtener ciclos');
    }
  }

  selectedCycleChange(newValue) {
    if (!newValue) { newValue = -1; }
    this.prediccionesSubscripcion.unsubscribe();
    this.prediccionesSubscripcion = this._forecastService.continue(this.selectedModel , newValue).subscribe(this.dataArrived);
  }

  async  getModelos(param, descending) {
    const resp = await this._apiService.getModelosByServicio(this.idservicio, param, descending);
    if (resp.ok) {
      this.modelosServicio = resp.datos;
      console.log('Modelos del servicio: ', this.modelosServicio);
    }
  }

  changeModelo(value) {
    if (!value) { value = -1; }
    this.prediccionesSubscripcion.unsubscribe();
    this.prediccionesSubscripcion = this._forecastService.continue(value, this.selectedCycle).subscribe(this.dataArrived);
  }

  dataArrived = (response) => {
    this.updatePaginacion(response.datos.count);
    this.predicciones = response.datos.rows;
  }

  focoGanado() {
    this._forecastService.stop();
  }
  async focoPerdido(idforecast, comentario) {
    const resp = await this._apiService.editComentariosForecast(idforecast, comentario);
    if (resp.ok) {
      this._messagesService.success(resp.message);
    }
    this.prediccionesSubscripcion.unsubscribe();
    this.prediccionesSubscripcion = this._forecastService.continue('-1', '-1').subscribe(this.dataArrived);
  }

  prepareToExport(prediccion, sheetName) {
    // console.log("Prediccion a exportar: ", prediccion);
    if (prediccion && prediccion.forecast) {
      const datos = prediccion.forecast.datos;
      const cabeceras = prediccion.forecast.cabeceras;
      const fecha = this.datePipe.transform(prediccion.fecha, 'yyyy-MM-dd HH:mm');
      const creacion = this.datePipe.transform(new Date(), 'yyyy-MM-dd HH:mm');
      const fileName = 'Prediccion ' + ((prediccion.nombre != null) ? prediccion.nombre + ' ' + fecha : fecha);
      const hoja = {
        data : [],
        fileName : fileName,
        title : prediccion.nombre,
        date: fecha,
        creacion: creacion,
        comments: prediccion.comentarios,
        username: this.usuarioActual.nombres + ' ' + this.usuarioActual.apellidos,
        email: this.usuarioActual.email,
        sheetName: sheetName, // REEMPLAZAR
        header : cabeceras,
        archivos: prediccion.archivos
      };
      // notese el uso de OF
      for (const fila of datos) {
        const tmp = {};
        // notese el uso de IN
        for (const i_dato in fila) {
          tmp[cabeceras[i_dato]] = fila[i_dato];
        }
        hoja.data.push(tmp);
      }
      return hoja;
    }
    return null;
  }


  exportar(modal) {
    console.log('exportando ' + this.prediccionActual.nombre);
    this._excelService.exportAsExcel(this.prepareToExport(this.prediccionActual, this.prediccionActual.nombre));
    modal.close();
  }

  exportarHistorial(modal) {
    this._excelService.exportHistorial(this.prepareToExportHistorial());
    // console.log(this.prepareToExportHistorial());
    modal.close();
  }
  async exportarTodasPredicciones() {
    console.log('Exportando todas');
    const resp = await this._apiService.getForecastsByModel(this.idservicio, true, this.idModeloActivo);
    if (resp.ok) {
      const datos = resp.datos.rows;
      const date = this.datePipe.transform(new Date(), 'yyyy-MM-dd HH:mm');
      this._excelService.newWorkBook('Predicciones ' + date, new Date());
      for (const prediccion of datos) {
        const respFiles = await this._apiService.getFiles(prediccion.idforecast);
        prediccion.archivos = {};
        for (const archivo of respFiles.datos) {
          prediccion.archivos[archivo['tipo']] = archivo.nombre;
        }

        const pre = this.prepareToExport(prediccion, prediccion.idforecast + '-' + prediccion.nombre);
        if (pre != null) {
          this._excelService.createSheet(
            pre.sheetName,
            pre.data,
            pre.date,
            pre.creacion,
            pre.title,
            pre.comments,
            pre.username,
            pre.email,
            pre.header,
            pre.archivos);
        }
      }
      this._excelService.exportActualWorkBook();
    }
  }

  async exportarPrediccionesOptimizador() {
    console.log('Exportando todas optimizador');
    let resp;
    let sheetNumber = 1;
    resp = await this._apiService.getForecastCyclesByModel(this.idModeloActivo);
    console.log("RESP CICLOS: ", resp);
    //resp = await this._apiService.getForecastsByModel(this.idservicio, true, this.idModeloActivo);
    //console.log("Predicciones del modelo: ", resp);
    if(resp.ok) {
      const datos = resp.datos;
      const date = this.datePipe.transform(new Date(), 'yyyy-MM-dd HH:mm');
      this._excelService.newWorkBook('Predicciones ' + date, new Date());
      for (const ciclo of datos) {
        const sheetNameTmp = sheetNumber + ' - ' + ciclo.orden_produccion
        const pre = this.prepareToExportOptimizador(ciclo, sheetNameTmp);
        sheetNumber++;
        if(pre != null) {
          this._excelService.createSheetOptimizer(
            pre.sheetName,
            pre.data,
            pre.dates,
            pre.titles,
            pre.comments,
            pre.cabeceras,
            pre.limits,
            pre.config,
            pre.userMails,
            pre.usernames
          )
        }
      }
      this._excelService.exportActualWorkBook();
    }
  }

  prepareToExportOptimizador(ciclo, sheetName) {
    console.log("Ciclo: ", ciclo);
    let totalData = [];
    let dates = [];
    let comments = [];
    let usernames = [];
    let userMails = [];
    let limits = [];
    let config = [];
    let titles = [];
    let cabeceras;
    for(let prediccion of ciclo.forecast) {
      console.log("Entre al for");
      if (prediccion && prediccion.forecast && prediccion.parsedForecast) {
        try {
          const datos = prediccion.parsedForecast;
          totalData.push(datos);
          cabeceras = datos.data_names;
          const prediccionConfig = prediccion.forecast_configs;
          const fecha = this.datePipe.transform(prediccion.fecha, 'yyyy-MM-dd HH:mm');
          dates.push(fecha, ' ');
          comments.push(prediccion.comentarios, ' ');
          usernames.push(prediccion.userName, ' ');
          userMails.push(prediccion.user, ' ');
          let title = ciclo.orden_produccion + '-' + prediccion.numero_orden;
          titles.push(title, ' ');
          limits.push(prediccion.limites);
          //const fileName = 'Prediccion ' + ((prediccion.nombre != null) ? prediccion.nombre + ' ' + fecha : fecha);
          // const hoja = {
          //   data: datos.data,
          //   fileName: fileName,
          //   title: prediccion.ciclo_forecast?.orden_produccion + '- ' + prediccion.numero_orden,
          //   date: fecha,
          //   comments: prediccion.comentarios,
          //   username: prediccion.userName,
          //   email: prediccion.user,
          //   sheetName: sheetName,
          //   config: [],
          //   header: cabeceras,
          //   limites: prediccion.limites
          // }

          const resultArray = [];
          const configName = [];
          const values = [];
          for (const forConfig of prediccionConfig) {
            configName.push(forConfig.variable_prediccion.etiqueta);
            values.push(forConfig.value);
            //hoja.config.push(resultArray);
            //resultArray.push(configName);
            //resultArray.push(values);
          }

          const tmpLimits = {
            configName,
            values
          }
          config.push(tmpLimits);

          //return hoja;
        } catch (err) {
          console.log("Entre al error");
          return null;
        }
      }
    }

    const hoja = {
      data: totalData,
      dates: dates,
      titles,
      comments,
      cabeceras,
      sheetName,
      limits,
      config,
      userMails,
      usernames
    }

    console.log("HOJA: ", hoja)

    return hoja;
  }

  async exportarTodasPrediccionesCalidad() {
    console.log('Exportando todas calidad');
    const resp = await this._apiService.getForecastsByModel(this.idservicio, true, this.idModeloActivo);
    if (resp.ok) {
      const datos = resp.datos.rows;
      console.log('DATOS: ', datos);
      const date = this.datePipe.transform(new Date(), 'yyyy-MM-dd HH:mm');
      this._excelService.newWorkBook('Predicciones ' + date, new Date());
      for (const prediccion of datos) {
        const pre = this.prepareToExportCalidad(prediccion, prediccion.idforecast + '-' + prediccion.ciclo_forecast?.orden_produccion + '- ' + prediccion.numero_orden);
        if (pre != null) {
          this._excelService.createSheetQuality(
            pre.sheetName,
            pre.data,
            pre.date,
            pre.creacion,
            pre.title,
            pre.comments,
            pre.username,
            pre.email,
            pre.header,
            pre.config);
        }
      }
      this._excelService.exportActualWorkBook();
    }
  }

  prepareToExportCalidad(prediccion, sheetName) {
    // console.log("Prediccion a exportar: ", prediccion);
    console.log('PRED: ', prediccion);
    console.log('SHEETNAME: ', sheetName);
    if (prediccion && prediccion.forecast) {
      const datos = JSON.parse(prediccion.forecast.data);
      const cabeceras = prediccion.forecast.data_columns;
      // let prediccionConfig = prediccion.forecast_config.inputs;
      const prediccionConfig = prediccion.forecast_configs;
      // console.log("PREDCONF: ", prediccionConfig);
      const fecha = this.datePipe.transform(prediccion.fecha, 'yyyy-MM-dd HH:mm');
      const creacion = this.datePipe.transform(new Date(), 'yyyy-MM-dd HH:mm');
      const fileName = 'Prediccion ' + ((prediccion.nombre != null) ? prediccion.nombre + ' ' + fecha : fecha);
      const hoja = {
        data : [],
        fileName : fileName,
        title : prediccion.ciclo_forecast?.orden_produccion + '- ' + prediccion.numero_orden,
        date: fecha,
        creacion: creacion,
        comments: prediccion.comentarios,
        username: prediccion.userName,
        email: prediccion.user,
        sheetName: sheetName, // REEMPLAZAR
        header : cabeceras,
        archivos: prediccion.archivos,
        config: []
      };

      for (const forConfig of prediccionConfig) {
        const resultArray = [];
        resultArray.push(forConfig.variable_prediccion.etiqueta);
        resultArray.push(forConfig.value);
        hoja.config.push(resultArray);
      }

      // for (const input of Object.keys(prediccionConfig)) {
      //   const resultArray = [];
      //   resultArray.push(input);
      //   resultArray.push(prediccionConfig[input]);
      //   hoja.config.push(resultArray);
      // }
      // notese el uso de OF
      for (const fila of datos) {
        const tmp = {};
        // notese el uso de IN
        for (const i_dato in fila) {
          tmp[cabeceras[i_dato]] = fila[i_dato];
        }
        hoja.data.push(tmp);
      }
      return hoja;
    }
    return null;
  }

  prepareToExportHistorial() {

    const datos = [];
    const fechas = [];
    const nombres = [];

    const historial_mantenimiento = [];
    const historial_produccion = [];
    const planificacion = [];
    console.log(this.datosHistorial);
    for (const prediccion of this.datosHistorial) {
      fechas.push(this.datePipe.transform(prediccion.fecha, 'yyyy-MM-dd HH:mm'));
      nombres.push(prediccion.nombre);
      datos.push(prediccion.dato);
      for (const archivo of prediccion.archivos) {
        switch (archivo.tipo) {
          case 'historial_mantenimiento':
            historial_mantenimiento.push(String(archivo.nombre).trim());
            break;
          case 'historial_produccion':
            historial_produccion.push(String(archivo.nombre));
            break;
          case 'planificacion':
            planificacion.push(String(archivo.nombre));
            break;
        }
      }
    }

    const indexElemName = this.datosHistorial[0].variable.indexOf('abreviatura');
    const fileName = datos[0][indexElemName];
    const cabeceras = this.datosHistorial[0].cabeceras;
    const hoy = this.datePipe.transform(new Date(), 'yyyy-MM-dd HH:mm');
    console.log(fileName);
    const hoja = {
      data : datos,
      fileName : 'Historial ' + fileName + '- ' + hoy,
      title : 'Historial del rodillo ' + fileName,
      dateString: hoy,
      fechas : fechas,
      nombres: nombres,
      historial_mantenimiento: historial_mantenimiento,
      historial_produccion: historial_produccion,
      planificacion: planificacion,
      username: this.usuarioActual.nombres + ' ' + this.usuarioActual.apellidos,
      email: this.usuarioActual.email,
      sheetName: fileName,
      header : cabeceras
    };
    return hoja;
  }

  async verPrediccionCalidad(modal, forecast, tabSelected, modalError) {
    console.log('Forecast selected: ', forecast);
    if (!this.isOptimizer) {
      console.log('Entre al no es optimizador');
      this.activeIdString = tabSelected;
      this.inputsConfig = null;
      this.prediccionActual = forecast;
      let resp;
      try {
        resp = await this._apiService.getForecastResults(forecast.idforecast);
      } catch (err) {
        this.modalService.open(modalError);
      }

      console.log('resp:  ', resp);
      this.forecastResults = resp.datos;
      this.prediccionActual.forecast.data = JSON.parse(this.prediccionActual.forecast.data);
      this.prediccionActual['forecast']['data'] = this.prediccionActual.forecast.data[0];
    } else {
      console.log('Entre al es optimizador');
      console.log('modelo activo', this.servicio);
      this.activeIdString = tabSelected;
      this.inputsConfig = null;
      this.prediccionActual = forecast;
      let resp;
      try {
        resp = await this._apiService.getOptimizerResults(forecast.idforecast, this.servicio.idmodelo);
      } catch (err) {
        console.log("ERr:", err);
        this.modalService.open(modalError);
      }
      this.forecastResults = resp.datos;
    }

    this.modalService.open(modal);
  }

  async verPrediccion(modal_content, idforecast, modal_historial) {
    console.log('Entre al ver prediccion');
    const that = this;
    this.modal_historial = modal_historial;
    this.modalService.open(modal_content, {
      size: 'lg'
    }).result.then((result) => {
      this.prediccionActual = null;
    }, (reason) => {
      this.prediccionActual = null;
    });

    this.prediccionLoading = true;
    const resp = await this._apiService.getForecast(idforecast);
    const respFiles = await this._apiService.getFiles(idforecast);
    console.log('resp: ', resp);
    console.log('respFiles: ', respFiles);
    if (resp.ok && respFiles.ok) {
      this.prediccionActual = resp.dato;
      this.prediccionActual.archivos = {};
      for (const archivo of respFiles.datos) {
        this.prediccionActual.archivos[archivo['tipo']] = archivo.nombre;
      }

      console.log('prediccionActual: ', this.prediccionActual);



      const data = resp.dato.forecast;
      const porcentajes = [];
      const kilos = [];
      const nombres = [];
      const colores = [];
      let minimo = 0;

      const color_valido = 'green'; // "rgba(255, 99, 132, 0.2)";
      const color_invalido = 'red'; // "rgba(75, 192, 192, 0.2)";

      const porcentaje_index = data.variable.indexOf('porcentaje');
      const kilos_index = data.variable.indexOf('kilos_remanentes');
      const nombres_index = data.variable.indexOf('abreviatura');
      const valido_index = data.variable.indexOf('valido');
      const validos = [];

      for (const d of data.datos) {
        porcentajes.push(d[porcentaje_index]);
        minimo = (d[kilos_index] < minimo) ? d[kilos_index] : minimo;
        kilos.push(d[kilos_index]);
        nombres.push(d[nombres_index]);
        validos.push(d[valido_index]);
        const color = d[valido_index] ? color_valido : color_invalido;
        console.log(color);
        colores.push( color);
      }
      console.log('Nombres: ', nombres);
      // nombres[0] = "Rodillo 1 superior ESTRUJADOR DESENGRASE"
      console.log('Cabeceras: ', data.cabeceras);
      console.log('porcentajes: ', porcentajes);
      // console.log(colores);
      // console.log(validos);
      if (minimo < 0) {
        const modulo = Math.abs(minimo % 1000);
        console.log('Modulo : ' + modulo);
        minimo = minimo - (1000 - modulo);
      }
      console.log('Nuevo minimo :' + minimo);
      const parentThis = this;
      this.datosGrafico = {
        lineChartData: [
          {
            data: kilos,
            label: this.chartDatos?.yAxis ? this.chartDatos.yAxis : 'Kilos remanentes a la fallaa',
            type: 'bar',
            pointStyle: 'rect',
            yAxisID: 'first_y',
          },
          {
            data: porcentajes,
            label: this.chartDatos?.secondYAxis ? this.chartDatos.secondYAxis : 'Porcentaje de vida útil remanente',
            type: 'line',
            fill: false,
            pointStyle: 'circle',
            yAxisID: 'second_y'
          }
        ],
        lineChartLabels: nombres, // nombres abreviatura eje X
        lineChartOptions: {
          legend: {
            labels: {
              usePointStyle: true
            }
          },
          tooltips: {
            callbacks: {
              // funcion que permite ver el tooltip, kilos remanentes
              label: function(tooltipItem, data) {
                let etiqueta = data.datasets[tooltipItem.datasetIndex].label + ' : ' + that.formatearNumero(tooltipItem.yLabel);
                if (data.datasets[tooltipItem.datasetIndex].yAxisID == 'second_y') {
                  etiqueta = etiqueta + '%';
                }
                // console.log("Etiqueta: ", etiqueta)
                return etiqueta;
              }
            }
          },
          responsive: true,
          onClick: function name(event, array) {
            console.log('evt: ', event);
            if (array.length > 0) {
              console.log('ENTRE AL IF');
              // parentThis.clickedData();
              parentThis.barrasClick(array[0]._index, modal_content);
            }
          },
          onHover: (event, chartElement) => {
            event.target.style.cursor = chartElement[0] ? 'pointer' : 'default';
          },
          scales: {
            // Caracteristicas eje X
            xAxes: [{
              display: true,
              scaleLabel: {
                display: true,
                labelString: this.chartDatos?.xAxis ? this.chartDatos.xAxis : 'Rodillo'
              },
              ticks: {
                maxRotation: 90,
                minRotation: 90,
                // funcion para rodillos no validos
                // No es generico
                callback: function(label, index, labels) {
                  // console.log("Callback")
                  return (!validos[index] ? '###' : '') + label;
                }
              }
            }],
            // Caracteristicas eje y
            yAxes: [
              {
                id: 'first_y',
                position: 'left',
                display: true,
                scaleLabel: {
                  display: true,
                  labelString: this.chartDatos?.yAxis ? this.chartDatos.yAxis : 'Kilos remanentes a la falla'
                },
                gridLines: {
                  drawOnChartArea: false
                },
                ticks: {
                  min: minimo, // Se pide desde la bd?
                  // Generico
                  callback: function(label, index, labels) {
                    console.log('callback eje y');
                    return that.formatearNumero(label);
                  }
                  // max:100
                }
              },
              // Segundo y
              {
                id: 'second_y',
                position: 'right',
                display: true,
                scaleLabel: {
                  display: true,
                  labelString: this.chartDatos?.secondYAxis ? this.chartDatos.secondYAxis : 'Porcentaje de vida útil remanente'
                },
                // Porcentajes, desde la bd?
                ticks: {
                  min: 0,
                  max: 100,
                }
              }
            ]
          },
          annotation: {
            annotations: [
              {
                drawTime: 'afterDraw',
                type: 'line',
                mode: 'horizontal',
                scaleID: 'second_y',
                value: this.chartDatos?.precautionValue ? this.chartDatos?.precautionValue : 15,
                borderColor: 'yellow',
                borderWidth: 2,
              },
              {
                drawTime: 'afterDraw',
                type: 'line',
                mode: 'horizontal',
                scaleID: 'second_y',
                value: this.chartDatos?.dangerValue ? this.chartDatos?.dangerValue : 8,
                borderColor: 'red',
                borderWidth: 2,
              },
            ],
          },
        },
        lineChartLegend : true,
        lineChartType : 'bar',
      };
    }
    this.prediccionLoading = false;
  }

  formatearNumero(valor) {
    return this.decimalPipe.transform(valor, '1.0-1', 'es');
  }

  verError(ventana, prediccion) {
    this.prediccionActual = prediccion;
    this.modalService.open(ventana);
  }

  clickedData(evt, modal) {
    this.chartOneTest = this.ngChartjsService.getChart('chartOne');
    console.log('CHARTONE: ', this.chartOneTest);
    console.log('clickedData');
    console.log('evt: ', evt);
    if (evt.active.length > 0 ) {
      this.changePlot = false;
      this.historialLoading = true;
      console.log('histLod: ', this.historialLoading);
      this.barrasClick(evt.active[0]._index, modal);
      this.chartOneTest?.clear();
    }
  }

  async barrasClick(indexClickeado, prediccion_modal) {
    // this.prediccionLoading = tr ue;
    this.changePlot = false;
    console.log('BarrasClick');

    const that = this;
    const campo = 'abreviatura';
    console.log('prediccionActual', this.prediccionActual);
    console.log('modeloActivo', this.modeloActivo);
    const pos_idelemento = this.prediccionActual.forecast.variable.indexOf(campo);
    const idelemento = this.prediccionActual.forecast.datos[indexClickeado][pos_idelemento];
    const resp = await this._apiService.getHistorialElemento(idelemento, this.idModeloActivo, campo);
    // const resp = await this._apiService.getHistorialElemento(idelemento, this.idservicio, campo);
    console.log('resp: ', resp);
    if (resp.ok) {
      console.log('resp.datos: ', resp.datos);
      const historial = resp.datos;


      historial.sort(function compara(a, b) {
        return new Date(a.fecha).getTime() - new Date(b.fecha).getTime();
      });

      this.datosHistorial = historial;

      const name_index = historial[0].variable.indexOf('abreviatura');
      const first_index = historial[0].variable.indexOf('kilos_remanentes');
      const second_index = historial[0].variable.indexOf('porcentaje');
      const names = [];
      const first_array = [];
      const second_array = [];
      let minimo = 0;
      for (const prediccion of historial) {
        first_array.push( prediccion.dato[first_index] );
        minimo = (prediccion.dato[first_index] < minimo) ? prediccion.dato[first_index] : minimo;
        second_array.push(prediccion.dato[second_index]);
        names.push(
          this.datePipe.transform(prediccion.fecha, 'yyyy-MM-dd HH:mm')
        );

      }

      console.log('Minimo :' + minimo);
      if (minimo < 0) {
        const modulo = Math.abs(minimo % 1000);
        console.log('Modulo : ' + modulo);
        minimo = minimo - (1000 - modulo);
      }
      console.log('Nuevo minimo :' + minimo);

      this.graficoHistorial = {
        nombre: historial[0].dato[name_index],
        lineChartData: [
          {
            data: first_array,
            label: historial[0].cabeceras[first_index],
            type: 'bar',
            pointStyle: 'rect',
            yAxisID: 'first_y',
            maxBarThickness: this.MAX_BAR_THICKNESS
          },
          {
            data: second_array,
            label: historial[0].cabeceras[second_index],
            type: 'line',
            pointStyle: 'circle',
            fill: false,
            yAxisID: 'second_y'
          }
        ],
        lineChartLabels: names,
        lineChartOptions: {
          legend: {
            labels: {
              usePointStyle: true
            }
          },
          tooltips: {
            callbacks: {
              label: function(tooltipItem, data) {
                let etiqueta = data.datasets[tooltipItem.datasetIndex].label + ' : ' + that.formatearNumero(tooltipItem.yLabel);
                if (data.datasets[tooltipItem.datasetIndex].yAxisID == 'second_y') {
                  etiqueta = etiqueta + '%';
                }
                return etiqueta;
                // return data.datasets[tooltipItem.datasetIndex].label + " : " + that.formatearNumero(tooltipItem.yLabel);
              }
            }
          },
          responsive: true,
          scales: {
            xAxes: [{
              display: true,
              scaleLabel: {
                display: true,
                labelString: 'Fecha'
              },
              ticks: {
                maxRotation: 90,
                minRotation: 90
              }
            }],
            yAxes: [
              {
                id: 'first_y',
                position: 'left',
                type: 'linear',
                display: true,
                scaleLabel: {
                  display: true,
                  labelString: historial[0].cabeceras[first_index]
                },
                ticks: {
                  min: minimo,
                  callback: function(label, index, labels) {
                    return that.formatearNumero(label);
                  }
                  // max:100
                },
                gridLines: {
                  drawOnChartArea: false
                }
              },
              {
                id: 'second_y',
                position: 'right',
                type: 'linear',
                display: true,
                scaleLabel: {
                  display: true,
                  labelString: historial[0].cabeceras[second_index]
                },
                ticks: {
                  min: 0,
                  max: 100
                }
              }
            ]
          },
          annotation: {
            annotations: [
              {
                drawTime: 'afterDraw',
                type: 'line',
                mode: 'horizontal',
                scaleID: 'second_y',
                value: 15,
                borderColor: 'yellow',
                borderWidth: 2,
              },
              {
                drawTime: 'afterDraw',
                type: 'line',
                mode: 'horizontal',
                scaleID: 'second_y',
                value: 8,
                borderColor: 'red',
                borderWidth: 2,
              },
            ],
          },
        },
        lineChartLegend : true ,
        lineChartType : 'bar'
      };

    }

    this.historialLoading = false;
  }

  async closeModal(modal) {
    // this.modalService.open(verPrediccionModal);
    this.historialLoading = false;
    this.changePlot = !this.changePlot;
  }

  closeHistModal(modal) {
    console.log("closeHistModal");
    // this.modalService.open(verPrediccionModal);
    this.historialLoading = false;
    this.changePlot = true;
    modal.close();
  }

  // cargar el modelo entrenado activo segun el servicio actual
  async cargarModeloActivo() {
    console.log("SERVICIO CARAGARMODELO: ", this.servicio)
    this.modelos = null;
    const resp = await this._apiService.getModeloActivo(this.idservicio);
    console.log("RESP2.0: ", resp);
    if (resp.ok) {
      this.modeloActivo = resp.dato;
      console.log('Antes de obtener las variables: ', this.servicio);

      if (this.servicio?.esOptimizador) {
        await this._predictionService.getModelVariables(this.modeloActivo.idmodelo, true, 'true', 'true');
      } else {
        await this._predictionService.getModelVariables(this.modeloActivo.idmodelo, true, 'false', 'null');
      }
      this.predictions$ = this._predictionService.getPredictions();
      this.predictions = this._predictionService.getPredictions2();
      console.log('PREDICTIONSSSS', this.predictions);
      console.log('El modelo activo es: ', this.modeloActivo);
      this.idModeloActivo = this.modeloActivo.idmodelo;

      if(this.servicio.tipo === "MANTENIMIENTO") {
        this.getModelConfig();
        this.getChartConfig();
      }
    }


  }

  async mostrar_prediccion(content, optimizerModal) {
    console.log('isOptimizar: ', this.isOptimizer);
    if (!this.servicio?.esOptimizador) {
      this.modalReference = this.modalService.open(content);
      await this.getServicio(this.idservicio);
    } else {
      console.log('Entre al es optimizador');
      this.isOptimizer = true;
      this.modalReference = this.modalService.open(optimizerModal);
    }
  }



  async getServicio(idservicio) {
    const resp = await this._apiService.getServicio(idservicio);
    if (resp.ok) {
      console.log('El servicio es: ', resp.dato);
      this.servicio = resp.dato;
      if (this.servicio?.esOptimizador) {
        this.optimizer = await this._optimizerService.getOptimizerById(this.servicio.idoptimizador);
        this.isOptimizer = true;
      }
    }
  }

  async onFileSelect(event) {

    console.log(event);
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      console.log('Name: ' + file.name);
      console.log('Type: ' + file.type);
      console.log('Size: ' + file.size);
      if (!this.acceptFiles.includes(file.type)) {
        this._messagesService.error('Tipo de archivo no es válido');
        console.log(event.target.name);
        //this.uploadForm.get(event.target.name).reset();
        event.target.value = null;
        return;
      } else if (file.size >= MAX_FILE_SIZE) {
        this._messagesService.error('Tamaño de archivo no puede superar los ' + (MAX_FILE_SIZE / 1024 / 1024) + ' megas');
        console.log(event.target.name);
        //this.uploadForm.get(event.target.name).reset();
        event.target.value = null;
        return;
      } else {
        this.uploadForm.get(event.target.name).setValue(file);
        //this.uploadedFile.push(this.formBuilder.control(file));
      }
    }
  }

  receiveMessage($event) {
    console.log('receiveMessage');
    console.log($event);
    this.newCycle = false;
    this.idCycle = $event;
    this.getForecasts('-1');
    this.getCycles();
  }

  receiveSecondMessage($event) {
    console.log('secondMessage');
    this.defaultFormValues = $event;
    console.log($event);
  }

  deletedForecastMessage() {
    console.log('deletedForecastMessage');
    this.getForecasts('-1');
  }

  async openQualityRecord(modal) {
    this.forecastCycles = await this._forecastCycleService.getForecastsCycles(this.modeloActivo);
    this.datosGrafico = await this._recordChartService.getChartRecord(this.idModeloActivo, -1, true, '-1');
    if (!this.idCycle) { this.idCycle = undefined; }
    this.modalService.open(modal);
  }

  async submitMantTmp(modal) {
    const uploadingFiles = [];
    console.log("MANTFORM: ", this.mantForm);
    console.log("FILES: ", this.mantForm.value.tmp);
    console.log(this.modelCnf)
    for(let file of this.mantForm.value.tmp) {
      uploadingFiles.push(this.manageUploadTmp(file).pipe(catchError(error => of(error))));
    }

    forkJoin(uploadingFiles).subscribe(async (valores: any) => {
      console.log("Valores: ", valores);
      const newForecastConfig = {
        idmodelo: this.modeloActivo.idmodelo,
        nombre: "Nueva conf",
        inputs: { }
      };
      let that = this;
      let bodyForCore = {}
      valores?.forEach(function (value, i ) {
        if (value.body.ok) {
          bodyForCore[that.mantForm.value.files[i]] = value.body.dato.ruta;
          newForecastConfig.inputs[that.mantForm.value.files[i]] = value.body.dato.idcoleccion;
        } else {
          this._messageService.error(value.body.message);
        }
      });

      console.log("Nuevo for config: ", newForecastConfig);
      console.log("Body para el Core: ", bodyForCore);
      // this.resetFormulario

      const forecast_config = await this._apiService.postForecastConfig(newForecastConfig);
      console.log("For config: ", forecast_config);
      if(forecast_config.ok) {
        modal.close();
        try {
          const resp = await this._apiService.launchForecast(forecast_config.dato.idconfig, this.modeloActivo.ruta, bodyForCore, this.modelCnf.functionName);

          if (resp.ok) {
            this._messagesService.success(resp.message);
          } else {
            this._messagesService.error(resp.message);
          }
        }
        catch (err) {
          this._messagesService.error("Error al lanzar predicción, verificar la configuración");
        }
      } else {
        this._messagesService.error(forecast_config.message);
      }
    })

    // let resp = this.manageUploadTmp(this.mantForm.value.tmp[0]);
    // console.log("RESP: ", resp);

  }

  async submitMant(modal) {
    console.log("FORM: ", this.uploadForm.value);
    let resp = this.manageUpload("historial_produccion").pipe(catchError(error => of(error)))
    console.log("RESP: ", resp);
    forkJoin(resp).subscribe(async (valores: Array<uploadedFile>) => {
      console.log("valores: ", valores);
      const nuevoConfig = {
        idmodelo: this.modeloActivo.idmodelo,
        nombre: this.uploadForm.value.nombre,
        inputs: { }
      };

      for(const valor of valores) {
        if(valor.body.ok) {
          nuevoConfig.inputs[valor.field] = valor.body.dato.idcoleccion;
        } else {
          this._messagesService.error(valor.body.message);
        }
      }

      console.log(nuevoConfig);
      this.resetFormulario();

      const forecast_config = await this._apiService.postForecastConfig(nuevoConfig);
      console.log("Forcf: ", forecast_config);
      if(forecast_config.ok) {
        const resp = await this._apiService.launchForecast(forecast_config.dato.idconfig, this.modeloActivo.ruta, null, null);

        if(resp.ok) {
          this._messagesService.success(resp.message);
        } else {
          this._messagesService.error(resp.message);
        }
      } else {
        this._messagesService.error(forecast_config.message);
      }

      this.modalService.dismissAll();

      this.resetFormulario();
    }, (error) => {
      this.modalService.dismissAll();
    })
  }

  async submit(modal) {
    this.disable_predecir = true;

    // validar!!!
    const tmp = this.uploadForm.value;
    console.log("Formulario: ", tmp);

    const archivos = ['historial_mantenimiento', 'historial_produccion', 'planificacion'];
    const forks = [];

    let valido = true;
    /*let validaciones = [
      tmp.nombre.trim() == "",
      tmp.historial_mantenimiento == "",
      tmp.historial_produccion == ""
    ]*/


    for (const campo in tmp) {
      if (campo in this.invalid) {
        this.invalid[campo] = tmp[campo] == '';
        if (this.invalid[campo]) {
          valido = false;
        }
      }
      if (archivos.includes(campo) && tmp[campo] != '') {
        console.log('agregando' + campo);
        forks.push(
          this.manageUpload(campo).pipe(catchError(error => of(error)))
        );
      }
    }
    // if(validaciones.some((item)=>item)){
    if (!valido) {
      console.log('Es invalido!!!!!');
      // dar feedback sobre que falta;
      this.disable_predecir = false;
      return;
    }

    forkJoin(forks).subscribe(async (valores: Array<uploadedFile>) => {
      console.log(valores);
      const nuevoConfig = {
        idmodelo: this.modeloActivo.idmodelo,
        nombre: tmp.nombre,
        inputs: { }
      };
      for (const valor of valores) {
        if (valor.body.ok) {
          nuevoConfig.inputs[valor.field] = valor.body.dato.idcoleccion;
        } else {
          this._messagesService.error(valor.body.message);
        }
      }
      console.log(nuevoConfig);
      this.resetFormulario();

      const forecast_config = await this._apiService.postForecastConfig(nuevoConfig);
      console.log(forecast_config);
      if (forecast_config.ok) {
        const resp = await this._apiService.launchForecast(forecast_config.dato.idconfig, this.modeloActivo.ruta, null, null);
        console.log(resp);
        if (resp.ok) {
          this._messagesService.success(resp.message);
        } else {
          this._messagesService.error(resp.message);
        }
      } else {
        this._messagesService.error(forecast_config.message);
      }

      this.modalService.dismissAll();

      // resetear formulario
      this.resetFormulario();
    }, (error) => {
      this.modalService.dismissAll();
      console.log('ERROROORORORORORORORORRRRRRRRRRRRRRRRRRRRR');
    });


  }

  resetFormulario() {
    this.uploadForm.reset({
      historial_mantenimiento: '',
      historial_produccion: '',
      planificacion: '',
      nombre: ''
    });
    this.invalid = {
      nombre: false,
      historial_produccion: false,
      historial_mantenimiento: false
    };
    this.progress.historial_produccion = 0;
    this.progress.historial_mantenimiento = 0;
    this.progress.planificacion = 0;
    this.disable_predecir = false;
  }
  manageUpload(field: string): Observable<uploadedFile> {
    console.log("Estoy en el manageupload...")
    const tipos = ['historial_produccion',
    'historial_mantenimiento',
    'planificacion'];
    return new Observable((observer) => {
      const archivo = this.uploadForm.get(field).value;
      const moreData = {
        idempresa: 1,
        idtipo: 1,
        idanterior: -1,
        tipo : field,
        header: null};

      this._apiService.subirArchivo(archivo, moreData).pipe(catchError((error) => of({type: 'Mi Error', message: error}))).subscribe(resp => {
        if (resp.type === HttpEventType.Response) {
            console.log('Upload complete');
            const output: uploadedFile = {field: field, body: resp.body};
            observer.next(output);
            observer.complete();
        }
        if (resp.type === HttpEventType.UploadProgress) {
            const percentDone = Math.round(100 * resp.loaded / resp.total);
            console.log('Progress ' + percentDone + '%');
            this.progress[field] = percentDone;
        }
        if (resp.type == 'Mi Error') {
          console.log('Llego mi tipo de error');
          console.log(resp.message);
          this._messagesService.error('El archivo ' + resp.message.file + ' no tiene el formato correpondiente a ' + resp.message.tipo.replace('_', ' '));
        }
      });

    });

  }

  manageUploadTmp(file) {
    console.log("Entre al manageUploadTmp");
      const moreData = {
        idempresa: 1,
        idtipo: 1,
        idanterior: -1,
        tipo: "X",
        header: null
      }

      return new Observable((observer) => {
        this._apiService.uploadForecastCollecion(file, moreData).subscribe(resp => {
          if (resp.type === HttpEventType.Response) {
            console.log("RESP in manage: ", resp);
            console.log("Subido");
            const output = { file: file, body: resp.body };
            observer.next(output);
            observer.complete();
          }

          if (resp.type === HttpEventType.UploadProgress) {
            console.log("En progreso...");
          }
        }, error => {
          console.log("Error: ", error);
        });
      })

  }

  ngOnDestroy() {
    this.prediccionesSubscripcion.unsubscribe();
    this._forecastService.stop();
  }

  openDeleteModal(modal, prediccion) {
    this.prediccionAEliminar = prediccion;
    this.modalService.open(modal);
  }
}
