import {Component, Input, OnInit} from '@angular/core';
import {RecordChartService} from '../services/record-chart.service';
import {NgChartjsService} from 'ng-chartjs';
import {ForecastCycleService} from '../services/forecasts-cycles.service';


@Component({
  selector: 'app-record-chart',
  templateUrl: './forecasts-record-chart.component.html',
  styleUrls: ['./forecasts-record-chart.component.css']
})

export class ForecastsRecordChartComponent implements OnInit {
  @Input() service: any;
  @Input() activeModel: any;
  @Input() modal: any;
  @Input() chart: any;
  @Input() forecastCycles: any;
  @Input() activeCycle: any = '-1';
  recordChartValues: any;
  chartRecordObj: any;
  productionOrder: string;
  selectedCycle: String = '-1';
  isNormalize: String = 'true';
  variable: String = '-1';
  constructor(private recordChartService: RecordChartService,
              private ngChartjsService: NgChartjsService,
              private forecastCycleService: ForecastCycleService) {
  }

  ngOnInit() {
    this.getRecordChart();
    console.log('ACTIVE CYCLE: ', this.activeCycle);
    if (this.activeCycle) { this.selectedRecordCycle(this.activeCycle); }
  }

  getRecordChart() {
    this.chartRecordObj = this.recordChartService.getChartObj();
    this.recordChartValues = this.recordChartService.getChartData();
  }

  async selectedRecordCycle(selectedCycle) {
    this.selectedCycle = selectedCycle;
    if (parseInt(selectedCycle, 10) === 0) {
      selectedCycle = -1;
      this.productionOrder = 'Ciclo no seleccionado';
      this.selectedCycle = '-1';
    } else {
      const selectedCycleObj = this.forecastCycles.find(x => x.idciclo === parseInt(selectedCycle, 10));
      this.productionOrder = selectedCycleObj['orden_produccion'];
    }
    this.chart = await this.recordChartService.getChartRecord(this.activeModel.idmodelo, selectedCycle, this.isNormalize, this.variable);
    this.getRecordChart();
  }

  async variableChangeTmp(value) {
    const recordChart = this.ngChartjsService.getChart('finalRecordChart');
    console.log('variablechangetmp: ', value);
    if (value === 'Todos') {
      value = '-1';
    }
    this.variable = value;
    this.chart = await this.recordChartService.getChartRecord(this.activeModel.idmodelo, this.selectedCycle, this.isNormalize, value);
    this.getRecordChart();
    // recordChart.update();
    console.log('DONE: ', this.chart);
  }

  async dataChange(value) {
    console.log('Nueva visualización: ', value);
    this.isNormalize = value;
    this.chart = await this.recordChartService.getChartRecord(this.activeModel.idmodelo, this.selectedCycle, value, this.variable);
  }

  variableChange(value) {
    console.log('variablechange');
    let getChange;
    const parsedChartDataObj = JSON.parse(this.chartRecordObj.finalChartData);
    const recordChart = this.ngChartjsService.getChart('finalRecordChart');

    if (value === 'Todos') {
      recordChart.data.datasets.length = parsedChartDataObj.length;
      console.log('parsedChartDataObj: ', parsedChartDataObj);
      this.chart.lineChartData = parsedChartDataObj;
      recordChart.update();
    } else {
      parsedChartDataObj.forEach(function (chartObj, i) {
        const auxData = chartObj.auxData;
        const finalData = chartObj.data;

        parsedChartDataObj[i].auxData = finalData;
        parsedChartDataObj[i].data = auxData;

        if (value === chartObj.label) {
          getChange = chartObj;
        }
      });
      const newChartData = [];
      newChartData.push(getChange);
      newChartData.push(parsedChartDataObj.slice(-1).pop());
      recordChart.data.datasets.length = newChartData.length;
      console.log('newChartData: ', newChartData);
      this.chart.lineChartData = newChartData;
      recordChart.update();
    }
  }
}
