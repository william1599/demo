import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ApiRestService} from '../../../services/api-rest.service';
import {MessageService} from '../../../services/messages.service';
import {ForecastsService} from '../services/forecasts.service';

@Component({
  selector: 'app-forecasts-delete',
  templateUrl: './forecasts-delete-component.html'
})

export class ForecastsDeleteComponent implements OnInit {
  @Input() forecast: any;
  @Input() modal: any;
  @Input() activeCycle: any;
  @Input() activeModel: any;

  @Output() deletedForecastMessage = new EventEmitter<any>();
  constructor(private _apiRestService: ApiRestService,
              private _messageService: MessageService,
              private _forecastService: ForecastsService) {
  }
  ngOnInit() {
    console.log('Forecast a eliminar', this.forecast);
  }
  async onSubmit() {
    const resp = await this._apiRestService.editVerifiedForecast(this.forecast.idforecast, { habilitado: false });
    if (resp.ok) {
      this.deletedForecastMessage.emit();
      this.modal.close();
      //this._forecastService.restart(this.activeModel.idmodelo, this.activeCycle);
    } else {
      this._messageService.error('Error al eliminar predicción');
    }
  }
}
