import { Component, Input, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { PredictionsBase } from "src/app/models/predictions-models/prediction-form";


@Component({
  selector: 'prediction-form',
  templateUrl: './forecasts-create-form-prediction.component.html'
})

export class DynamicFormPredictionComponent implements OnInit {
  @Input() prediction!: PredictionsBase<string>;
  @Input() form!: FormGroup;
  constructor() {}

  ngOnInit() {
    //console.log("prediction 2 es: ", this.prediction);
  }
  get isValid() {
    return this.form.controls[this.prediction.key].valid;
  }
}
