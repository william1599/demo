import { Component } from "@angular/core";
import { Observable } from "rxjs";
import { PredictionsBase } from "src/app/models/predictions-models/prediction-form";
import { PredictionService } from "src/app/models/predictions-models/prediction.service";


@Component({
  selector: 'form-root',
  template: `
  <div>
    <app-dynamic-form [predictions]="predictions$ | async"></app-dynamic-form>
  </div>
  `
})

export class FormComponent {
  predictions$: Observable<PredictionsBase<any>[]>;

  constructor(service: PredictionService) {
    this.predictions$ = service.getPredictions();
  }
}
