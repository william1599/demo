import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {Form, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import { NgbActiveModal, NgbModal, NgbTabChangeEvent } from '@ng-bootstrap/ng-bootstrap';
import { PredictionControlService } from 'src/app/models/predictions-models/prediction-control.service';
import { PredictionsBase } from 'src/app/models/predictions-models/prediction-form';
import { ApiRestService } from 'src/app/services/api-rest.service';
import { MessageService } from 'src/app/services/messages.service';
import {PredictionService} from "../../../models/predictions-models/prediction.service";
import {group} from "@angular/animations";

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './forecasts-create-dynamic-form.component.html'
})

export class DynamicFormComponent implements OnInit {

  @Input() predictions: PredictionsBase<string>[] | null = [];
  @Input() modelId: Number;
  @Input() modal: any;
  @Input() serviceId: Number;
  @Input() newCycle: string;
  @Input() selectedCycleId: string;
  @Input() formValues: Object = null;
  @Input() isOptimizer: any;
  @Input() optimizer: any;

  form!: FormGroup;
  boundaryForm: FormGroup;
  cycleForm: FormGroup;
  payLoad = '';
  forecastName: string;
  forecastConfigId: Number;
  forecastId: Number;
  activeIdString: any;
  model: any;
  showInputCycleName: Boolean = false;
  showSelectCycle: Boolean = false;
  showVariableForm: Boolean = false;
  forecastCycles: any;
  idSelectedCycle: Number;
  variablesOptimizer: any;
  changesApplied: any = false;

  @Output() messageEvent = new EventEmitter<any>();
  @Output() secondMessageEvent = new EventEmitter<string>();

  constructor(
    private predictionService: PredictionControlService,
    private _apiRestService: ApiRestService,
    private _messageService: MessageService,
    private formBuilder: FormBuilder,
    private _predictionService: PredictionService,
    private _modalService: NgbModal
    ) {}

  //await this._predictionService.getModelVariables(this.modeloActivo.idmodelo, true, 'false', 'false');
  ngOnInit() {
    console.log('ModelId: ', this.modelId);
    console.log('PREDICTIONSS3: ', this.predictions);
    console.log('Es optimizador: ', this.isOptimizer);
    console.log('optimizador: ', this.optimizer);
    this.form = this.predictionService.toFormGroup(this.predictions as PredictionsBase<string>[]);
    console.log('formmmm', this.form);
    if (this.formValues) {
      this.form.patchValue(this.formValues);
    }
    this.getModel();
    this.getCycles();
    this.initCycleForm();
    if (this.isOptimizer) {
      this.getVariablesOptimizer();
    }
  }

  async getVariablesOptimizer() {
    this.variablesOptimizer = await this._predictionService.getModelVariables(this.modelId, true, 'false' , 'false');
    this.variablesOptimizer = this.variablesOptimizer.filter(function (el) {
      return !el.esConstante && !el.isOutput;
    });

    const group: any = {};
    console.log("variablesoptimizer: ", this.variablesOptimizer);
    this.variablesOptimizer.forEach(varTmp => {
      if(varTmp.optimizerMax != null && varTmp.optimizerMin != null) {
        console.log("ENTRE ACA 1");
        group[varTmp.idparametros] = new FormGroup({
          minimo: new FormControl(varTmp.optimizerMin),
          maximo: new FormControl(varTmp.optimizerMax)
        });
      } else {
        console.log("ENTRE ACA 2");
        group[varTmp.idparametros] = new FormGroup({
          minimo: new FormControl(varTmp.min),
          maximo: new FormControl(varTmp.max)
        });
      }
    });

    this.boundaryForm = new FormGroup(group);
    console.log("FORMGRUOU: ", this.boundaryForm);
    console.log("VARIABLESOPTIMIZER: ", this.variablesOptimizer);
  }

  async setBoundaryValues(modal) {
    this.changesApplied = true;
    console.log("FORMAMSM: ", this.boundaryForm.value);
    const resp = await this._predictionService.updateMinAndMaxOfPredictions(this.boundaryForm.value);

    if(resp) {
      this._messageService.success("Valores límites cambiados con éxito");
      //this.getVariablesOptimizer();
      const resp = await this._apiRestService.getOptimizerById(this.optimizer.idoptimizador);
      this.optimizer = resp.dato;
      console.log("THISOPT: ", this.optimizer);
    }

    this.activeIdString = 'objetivo'
    console.log("MODAL: ", modal);
    if(modal) {
      modal.close();
    }
  }

  initCycleForm() {

    this.cycleForm = this.formBuilder.group({

      orden_produccion: ['', Validators.required],
      predictionName: [''],
      id_cycle: ['', Validators.required],
      newCycle: [''],
      predictionComment: ['']
    });
    console.log('selectedCycleId: ', this.selectedCycleId);
    this.newCycleParse(this.newCycle);
    if (typeof this.selectedCycleId !== 'undefined') {
      this.cycleForm.get('orden_produccion').clearValidators();
      this.cycleForm.get('orden_produccion').updateValueAndValidity();
      this.cycleForm.patchValue({ id_cycle: this.selectedCycleId });
    }
    console.log('cycleForm: ', this.cycleForm.value);
  }

  async onSubmit() {
    console.log('FORMASASD: ', this.form.value);
    if (!this.form.valid || !this.cycleForm.valid) {
      this._messageService.error('Faltan campos por completar');
      console.log(this.cycleForm);
      this.form.markAllAsTouched();
      this.cycleForm.markAllAsTouched();
      return;
    }
    this.payLoad = JSON.stringify(this.form.getRawValue());
    const config = {
      inputs: this.form.value
    };


    if (!this.isOptimizer) {
      const forecast = await this.postForecast(false);
      const forecastConfig = await this.postForecastConfig(forecast.idforecast);
      this.launchForecast(forecast, config);
    } else {
      const forecast = await this.postForecast(true);
      const forecastConfig = await this.postForecastConfig(forecast.idforecast);
      this.launchOptimizer(forecast, forecastConfig);
    }
    this.sendMessage();
    this.modal.close();
  }

  async getModel() {
    const resp = await this._apiRestService.getModeloPorId(this.modelId);
    if (resp.ok) {
      this.model = resp.dato;
      console.log('Modelo en dynamic: ', this.model);
    } else {
      this._messageService.error('Error al obtener modelo');
    }
  }

  async getCycles() {
    console.log('getCycles');

    const resp = await this._apiRestService.getForecastCycles(this.modelId);
    if (resp.ok) {
      this.forecastCycles = resp.datos;
    } else {
      this._messageService.error('Error al obtener ciclos');
    }
  }

  cycleChange(value) {
    this.idSelectedCycle = value;
    this.cycleForm.patchValue({
      id_cycle: value
    });
  }

  async launchForecast(forecast, newForecastConfig) {
    // let layers = this.model.architecture.layers_architecure
    console.log('launchForecast');
    console.log(this.modelId);
    // let resp = await this._apiRestService.launchQualityForecast(this.forecastId, this.modelId, 45);
    const resp = await this._apiRestService.launchQualityForecastPy(this.forecastId, this.modelId, 45, this.model, forecast, newForecastConfig);
    if (resp.ok) {
      this._messageService.success(resp.message);
    } else {
      this._messageService.error('Error al lanzar la predicción');
    }
  }

  async launchOptimizer(forecast, forecastConfig) {
    console.log('launchoptimizer');
    console.log('form: ', this.form.value);
    console.log('boundary form: ', this.boundaryForm.value);
    const col_variables = [];
    const col_salidas_modelos = [];
    const col_constantes = [];
    const ponderador_entradas = [];
    const ponderador_accuracy = [];
    const valores_maximos = [];
    const valores_minimos = [];
    const options = {
        'c1': 0.5,
        'c2': 0.3,
        'w': 0.9
    };

    const obj = {
      'numero_de_particulas': this.optimizer.num_particulas,
      'numero_de_iteraciones': this.optimizer.num_iteraciones,
      'salida_del_modelo': this.optimizer.modelo?.architecture?.salida,
      'options': options
    };


    const variables = this.optimizer.modelo?.parametros_prediccion;
    console.log('Variables: ', variables);
    const valores_constantes = [];
    const valores_objetivos = [];

    for (const variable of variables) {
        if (variable.esConstante) {
            col_constantes.push(variable.dato_coleccion?.nombre);
            valores_constantes.push(parseFloat(this.form.value[variable.llave]));
        }
        if (variable.isOutput) {
            ponderador_accuracy.push(parseFloat(variable.ponderador));
            col_salidas_modelos.push(variable.llave);
            valores_objetivos.push(parseFloat(this.form.value[variable.llave]));
        }
        if (!variable.isOutput && !variable.esConstante) {
            col_variables.push(variable.dato_coleccion?.nombre);
            ponderador_entradas.push(parseFloat(variable.ponderador));
            valores_maximos.push(variable.maximo || 100);
            valores_minimos.push(variable.minimo || 0);
        }
    }


    obj['ponderador_accuracy'] = ponderador_accuracy;
    obj['ponderador_entradas'] = ponderador_entradas;
    obj['col_variables'] = col_variables;
    obj['col_constantes'] = col_constantes;
    obj['valores_maximos'] = valores_maximos;
    obj['valores_minimos'] = valores_minimos;
    obj['col_salidas_modelo'] = col_salidas_modelos;

    const objJSON = JSON.stringify(obj);

    console.log('obj', obj);

    const json_entrada = {
      'salida_objetivo': valores_objetivos,
      'constantes': valores_constantes
    };

    console.log("JSON ENTRADA: ", json_entrada);
    console.log("OPTIMZER.modelo: ", this.optimizer.modelo);
    // console.log("FORECAST: ", this.optimizer.modelo.architecture.layers_architecure[0].inputs[0].input_tensor);
    const etlResp = await this._apiRestService.getEtlById(this.optimizer.modelo.architecture.layers_architecure[0].inputs[0].input_tensor);
    console.log("etlREsp", etlResp.dato.coleccions.ruta);
    const resp = await this._apiRestService.launchOptimizerForecast(objJSON, this.optimizer.modelo, json_entrada, forecast, etlResp.dato.coleccions.ruta);
  }

  async postForecast(optimizer) {
    let forecast;
    console.log('Cycleform: ', this.cycleForm.value);
    console.log('selectedCycle on postForecast: ', this.idSelectedCycle);
    const orden_produccion = this.cycleForm.value.orden_produccion;

    if (orden_produccion) {
      console.log('Entre al if');
      forecast = {
        'fecha': new Date(),
        'forecast': null,
        // 'idforecast_config': this.forecastConfigId,
        'idservicio': this.serviceId,
        'nombre': this.forecastName,
        'estado': 'CREADO',
        'idmodelo': this.modelId,
        'orden_produccion': orden_produccion,
        'comentarios': this.cycleForm.get('predictionComment').value ? this.cycleForm.get('predictionComment').value : 'Sin comentarios',
        ... (optimizer && { 'limites': this.boundaryForm.value })
      };
    } else {
      console.log('Entre al else');
      forecast = {
        'fecha': new Date(),
        'forecast': null,
        // 'idforecast_config': this.forecastConfigId,
        'idservicio': this.serviceId,
        'nombre': this.forecastName,
        'estado': 'CREADO',
        'idmodelo': this.modelId,
        'idciclo': this.cycleForm.value.id_cycle,
        'comentarios': this.cycleForm.get('predictionComment').value ? this.cycleForm.get('predictionComment').value : 'Sin comentarios',
        ... (optimizer && { 'limites': this.boundaryForm.value })
      };
    }

    const resp = await this._apiRestService.postForecast(forecast);
    if (resp.ok) {
      this.forecastId = resp.dato.idforecast;
      this.cycleForm.patchValue({ id_cycle: resp.dato.idciclo });
      console.log('forecast: ', resp);
      return resp.dato;
    } else {
      this._messageService.error('Error al crear forecast');
    }
  }

  async postForecastConfig(idforecast) {

    const body = {};
    let idx = 0;
    for (const input in this.form.value) {
      console.log('input', input);
      body[this.predictions[idx]['idparametros']] = this.form.value[input];
      idx++;
    }

    console.log('body: ', body);

    const newForecastConfig = {
      inputs: this.form.value,
      idmodelo: this.modelId,
      nombre: this.forecastName
    };

    const resp = await this._apiRestService.postMultipleForecastConfig(body, this.forecastName, this.modelId, idforecast);
    if (resp.ok) {
      console.log('Forecast config: ', resp);
      // this.forecastConfigId = resp.dato.idconfig;
      // console.log('forecastConfigId: ', this.forecastConfigId);
      return resp.dato;
    } else {
      this._messageService.error('Error al guardar configuración');
    }
  }

  sendMessage() {
    this.messageEvent.emit(this.cycleForm.value.id_cycle);
    this.secondMessageEvent.emit(this.form.value);
  }

  closeModalMessage() {
    this.modal.close();
  }

  cycleConfigChange(newValue) {
    switch (newValue) {
      case 'Sí':
        this.newCycleParse(true);
        this.cycleForm.get('id_cycle').clearValidators();
        this.cycleForm.get('id_cycle').updateValueAndValidity();
        break;
      case 'No':
        this.newCycleParse(false);
        this.cycleForm.get('orden_produccion').clearValidators();
        this.cycleForm.get('orden_produccion').updateValueAndValidity();
        break;
    }
  }

  newCycleParse(value) {
    if (typeof value == 'undefined') {
      this.cycleForm.patchValue({
        newCycle: ''
      });
      return;
    }

    if (value) {
      this.showInputCycleName = true;
      this.showVariableForm = true;
      this.showSelectCycle = false;
      this.cycleForm.patchValue({
        newCycle: 'Sí'
      });
    } else {
      this.showInputCycleName = false;
      this.showVariableForm = true;
      this.showSelectCycle = true;
      this.cycleForm.patchValue({
        newCycle: 'No'
      });
    }
  }

  changeTab(modal) {
    if(this.boundaryForm.touched && !this.changesApplied) {
      this.openConfirmModal(modal);
    }
    this.activeIdString = 'objetivo';
  }

  beforeChange($event: NgbTabChangeEvent, modal) {
    console.log("befChange", this.boundaryForm);
    if(this.boundaryForm.touched && $event.nextId === 'objetivo') {
      this.activeIdString = $event.activeId;
      this.openConfirmModal(modal);
    }

    if($event.nextId === 'limites') {
      this.changesApplied = false;
      //this.boundaryForm.touched = false;
      this.boundaryForm.markAsUntouched();
    }

    this.activeIdString = $event.nextId;
  };

  openConfirmModal(modal) {
    this._modalService.open(modal);
  }

}
