import {Injectable} from "@angular/core";
import {ApiRestService} from "../../../services/api-rest.service";
import {Subject} from "rxjs";

@Injectable({ providedIn: 'root' })
export class ModelService {
  private models = [];
  private model: any;
  modelsChanged = new Subject();
  constructor(private _apiRestService: ApiRestService) {
  }
  async getModel(idmodelo) {
   const resp = await this._apiRestService.getModeloPorId(idmodelo);
   if (resp.ok) {
     this.model = resp.dato;
     return this.model;
   } else {
     console.log('Error al obtener modelo');
   }
  }
  getSingleModel() {
    return this.model;
  }

  async getModelsByService(idservicio) {
    const resp = await this._apiRestService.getModelosByServicio(idservicio, 'createdAt', 'true');
    if(resp.ok) {
      this.models = resp.datos;
      console.log("thismodels: ", this.models)
      return this.models;
    } else {
      console.log('Error al obtener modelos');
    }
  }

  getModels() {
    console.log("thismodels: ", this.models)
    return this.models;
  }
}
