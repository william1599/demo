import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

import { Modelo } from 'src/app/models/modelo';
import { ApiRestService } from '../../services/api-rest.service';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { Observable, Subscription, zip } from 'rxjs';
import { ModelosService } from 'src/app/services/modelos.service';
import { ResultadosService } from 'src/app/services/log-resultados.service';
import { RespuestaArray, RespuestaDato } from 'src/app/models/respuesta.model';
import { MessageService } from 'src/app/services/messages.service';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { DatePipe, Location } from '@angular/common';

import { NgChartjsDirective } from 'ng-chartjs';
import { Chart } from 'chart.js';
import { animate, style, transition, trigger, query, stagger, state } from '@angular/animations';
import { ExcelExportService } from 'src/app/services/excel-export.service';
import { PlainFileService } from 'src/app/services/plain-file.service';


const FILTER_PAG_REGEX = /[^0-9]/g;

export interface IHash {
  [details: number]: any;
}

@Component({
  selector: 'app-listamodelos',
  templateUrl: './listamodelos.component.html',
  styleUrls: ['./listamodelos.component.scss'],
  animations: [
    trigger('listAnimation', [
      transition('* => *', [
        // each time the binding value changes
        query(
          ':leave',
          [stagger(100, [animate('0.5s', style({ opacity: 0 }))])],
          { optional: true }
        ),
        query(
          ':enter',
          [
            style({ opacity: 0 }),
            stagger(100, [animate('0.5s', style({ opacity: 1 }))])
          ],
          { optional: true }
        )
      ])
    ]),
    trigger(
      'enterAnimation', [
        transition(':enter', [
          style({transform: 'translateX(-100px)', opacity: 0}),
          animate('300ms', style({transform: 'translateX(0)', opacity: 1, 'overflow-x': 'hidden'}))
        ]),
      ]
    ),
    trigger('slideIn', [
      state('*', style({ 'overflow-y': 'hidden' })),
      state('void', style({ 'overflow-y': 'hidden' })),
      transition('* => void', [
        style({ height: '*' }),
        animate(250, style({ height: 0 }))
      ]),
      transition('void => *', [
        style({ height: '0' }),
        animate(250, style({ height: '*' }))
      ])
    ])
  ]
})
export class ListaModelosComponent implements OnInit {
  constructor(private formBuilder: FormBuilder,
     private modalService: NgbModal ,
     private route: ActivatedRoute,
     private router: Router,
     private datePipe: DatePipe,
     private _excelService: ExcelExportService,
     public _apiRestService: ApiRestService,
     public _modelosService: ModelosService,
     public _resultadosService: ResultadosService,
     public _messagesService: MessageService,
     private _plainFileService: PlainFileService,
     private _authenticationService: AuthenticationService,
     private location: Location
  ) {

    this.idservicio = this.route.snapshot.paramMap.get('idservicio');
    this.usuario = _authenticationService.currentUserValue;
    this.getServicio(this.idservicio);
    this.resModelos$ = this._modelosService.getModelos('updatedAt', 'true', this.idservicio, null);
    // console.log('Modelos: ', this.resModelos$.subscribe(res => console.log('modelos', res)))
    this.configuraciones = {};
  }
  // public modelos: any[];
  public closeResult = '';
  public nombre_modulo = '';
  // private suscripcion;
  formModelo: FormGroup;
  resModelos$: Observable<RespuestaArray>;
  modeloActivo: any;
  configuraciones: IHash;
  configs: any;
  resResultados$: Observable<RespuestaDato>;
  mod: any;
  filtros: any;
  subscription: Subscription;
  subscriptionPlot: Subscription;
  filtroActivo: any;
  filtroDescending: any;
  idConfigSelec: any;
  usuario: User;
  selectLog = 1;
  batchesLog: any;
  selectPlots = ['Gráfico coste de prueba', 'Gráfico coste de entrenamiento'];
  costTrainLog: any;
  totalResults: any;
  formChangePlot: FormGroup;
  logHeader: any;
  costTestLog: any;
  idservicio: string;
  modeloAEntrenar: any;
  nombreModeloAEntrenar: any;
  modeloSeleccionado: any;
  idArchEntrenar: any;
  servicio;
  chartData: Array<any>;
  chartLabels: Array<any>;
  chartDataArray: Array<any>;
  chartDataTrain: Array<any>;
  chartLabelsTest: Array<any>;
  chartDataResumen: Array<any>;
  textoError: any;

  // public chartDatasets: Array<any> = [
  //   { data: this.costTestLog, label: 'My First dataset' },
  //   { data: [28, 48, 40, 19, 86, 27, 90], label: 'My Second dataset' }
  // ];

  public chartType = 'line';
  // public chartLabels: Array<any> = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  public chartColors: Array<any> = [
    {
      backgroundColor: 'rgba(105, 0, 132, .2)',
      borderColor: 'rgba(200, 99, 132, .7)',
      borderWidth: 2,
    },
    {
      backgroundColor: 'rgba(0, 137, 132, .2)',
      borderColor: 'rgba(0, 10, 130, .7)',
      borderWidth: 2,
    }
  ];
  public chartOptions: any = {
    responsive: true,
    title: {
      text: 'Gráfico coste',
      labels: {
        fontSize: 100
      },
      display: true,
    },
    scales: {
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Batch',
        }
      }],
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Coste'
        }
      }]
    }
  };

  paginacion = {
    pagina: 1,
    paginas: 9,
    limit: 10,
    total: 100
  };
  page = 1;
  pageSize = 7;

  public chartClicked(e: any): void { }
  public chartHovered(e: any): void { }

  ngOnInit(): void {
    this.iniciarFiltros();
    this.iniciarModelo();
    this.getConfiguraciones();
    
    this.subscription = this.formModelo.get('listaConf').valueChanges.subscribe(val => {
      this.confCambiada(val);
    });
    this.formChangePlot = this.formBuilder.group({
      changePlot: [-1, Validators.required],
      plotData: [[], Validators.required]
    });
    this.subscriptionPlot = this.formChangePlot.get('changePlot').valueChanges.subscribe(val => {
      console.log('chartDataRRay', this.chartDataArray);
      if (val == -2) {
        this.selectLog = -2;
      } else {
        this.chartDataTrain = this.chartDataArray[val];
        this.selectLog = 0;
      }

    });
    // this.selectLog.valueChanges.sus
  }

  volverEnNavegacion() {
    this.location.back();
  }

  getModelosFiltro(param, descending) {
    this.filtroActivo = param;
    this.filtroDescending = descending;
    this.resModelos$ = this._modelosService.getModelos(param, descending, this.idservicio, null);
  }

  range = (start, stop, step) => Array.from({ length: (stop - start) / step + 1}, (_, i) => start + (i * step));

  updatePaginacion(total) {
    this.paginacion.pagina = 1;
    this.paginacion.paginas = Math.floor(total / this.paginacion.limit) + 1;
    this.paginacion.total = total;
  }

  cambiar_pagina(nueva_pagina) {
    this._resultadosService.setOffset(this.paginacion.limit * (nueva_pagina - 1));
    this.resResultados$ = this._resultadosService.restart();
    this.paginacion.pagina = nueva_pagina;
  }

  async getConfiguraciones() {
    const resultados = await this._apiRestService.getTrainConfs(this.idservicio);
    let confs;
    if (resultados.status == 200) {
      confs = resultados.datos;
      this.configs = resultados.datos;
      console.log('Las confs son: ', confs);
    } else {
      console.log('error: ' + resultados.status);
      console.log(resultados);
      this.configuraciones = null;
    }

    for (const conf in confs) {
      console.log(confs[conf]);
      this.configuraciones[confs[conf].idconf] = confs[conf];
    }
    console.log('Configuraciones son: ', this.configuraciones);
  }

  async getModeloActivo() {
    console.log('El servicio activo es: ', this.servicio);
    const response = await this._apiRestService.getModeloPorId(this.servicio.idmodelo);
    console.log('El modelo activo es: ', response.dato);
    this.modeloActivo = response.dato;

    if (response.status === 200) {

    } else {
      console.log('error: ', response.error);
    }
  }

  /*agregaModelos(){
    let last = this.modelos.length
    this.modelos.push({idmodelo:last + 1, nombre:"modelo"+last})
  }*/

  open(content, mod) {
    this.mod = mod;
    this.modalService.open(content, {
      scrollable: true,
      size: 'lg',
      ariaLabelledBy: 'modal-basic-title'
    }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  cambiaFiltro(dato) {
    console.log('El dato es: ', dato);
    this.selectLog = dato;
  }

  async mostrar_log(content, modelo) {
    console.log('El modelo es: ', modelo);
    this.mod = modelo;
    this.logHeader = JSON.parse(modelo.log_header);
    console.log('El header del log es: ', this.logHeader);
    const tmpHeader = this.logHeader.slice();
    tmpHeader.shift();
    tmpHeader.shift();
    this.selectPlots = tmpHeader;
    const result = await this._apiRestService.getResultsMetadata(this.mod.idmodelo);

    if (modelo.estado === 'ENTRENADO') {
      this.batchesLog = [];
      const modelLogs = await this._apiRestService.getTotalResults(modelo.idmodelo);
      console.log('Los resultados totales son: ', modelLogs);
      const valuesArray = [];

      for (let i = 0; i < modelLogs.dato.datos[0].valor.length; i++) {
        valuesArray[i] = [];
      }

      modelLogs.dato.datos.forEach(element => {

        for (let i = 0; i < element.valor.length; i++) {
          valuesArray[i].push(element.valor[i]);
        }

        const batch = element.batch;
        this.batchesLog.push(batch);
      });

      const chartsArray = [];

      for (let i = 0; i < valuesArray.length; i++) {
        chartsArray.push([{
          data: valuesArray[i],
          label: this.logHeader[i]
        }]);
      }

      chartsArray.shift();
      chartsArray.shift();

      this.chartDataArray = chartsArray;

      this.formChangePlot.get('plotData').setValue(chartsArray[0]);
      this.formChangePlot.get('changePlot').setValue(0);

      // this.chartDataResumen = [
      //   { data: this.costTestLog, label: 'Coste de prueba' },
      //   { data: this.costTrainLog, label: 'Coste de entrenamiento' }
      // ]

      this.chartLabels = this.batchesLog;

    }
    if (result.ok) {
      this._resultadosService.start(this.mod.idmodelo);
      this.resResultados$ = this._resultadosService.getResultados();

      // this.paginacion.total = result.total;
      this.updatePaginacion(result.dato);
      // this.resResultados$.subscribe();
      // console.log(this.resResultados$);
      this.modalService.open(content, {
        size: 'lg',
        scrollable: true,
        ariaLabelledBy: 'modal-basic-title'
      }).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
        this._resultadosService.stop();
        this.mod = null;
      }, (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        this._resultadosService.stop();
        this.mod = null;
      });
    }
  }

  exportarLogs() {
    console.log('El usuario es: ', this.usuario);
    const date = this.datePipe.transform(new Date(), 'yyyy-MM-dd HH:mm');
    this._excelService.newWorkBook('Entrenamiento modelo ' + this.mod.nombre + ' ' + date, new Date());
    console.log('El modelo actual es: ', this.mod);
    const fecha = this.datePipe.transform(this.mod.updatedAt, 'yyyy-MM-dd HH:mm');
    const fileName = 'Entrenamiento ' + this.mod.nombre + ' ' + fecha;

    this._excelService.createSheetLogs(
      fileName,
      this.totalResults.datos,
      this.mod.architecture.nombre,
      this.mod.training_config.nombre,
      fecha,
      this.usuario.nombres,
      this.usuario.email,
      this.logHeader
    );
    this._excelService.exportActualWorkBook();
  }


  stopTrain(idmodelo) {
    this._messagesService.success('Cancelando entrenamiento');
    this._apiRestService.stopTraining(idmodelo);
  }
  deleteModel(idmodelo) {
    this._messagesService.alert('Eliminando modelo');
    this._apiRestService.stopTraining(idmodelo);
  }

  openTrain(modal, idmodelo, idarch, nombreModelo, idconf) {
    this.confCambiada(this.configs.findIndex(x => x.idconf === idconf));
    this.idConfigSelec = idconf;
    console.log('LA ID DE LA ARCH es:', idarch);
    console.log('Id del modelo a entrenar', idmodelo);
    this.nombreModeloAEntrenar = nombreModelo;
    this.modeloAEntrenar = idmodelo;
    this.idArchEntrenar = idarch;
    this.modalService.open(modal, {
      scrollable: true,
      // size: 'lg',
      ariaLabelledBy: 'modal-basic-title'
    }).result.then((result) => {
      console.log(result);
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  async exportarModelo(idmodelo, pos) {
    const respuesta = await this._apiRestService.exportarModelo(idmodelo, this.idservicio);
    if (respuesta.ok) {
      // enviar este mensaje al servicio de mensajes
      this.servicio = respuesta.dato;
      this._messagesService.success(respuesta.message);
      this.getModeloActivo();
      // hacer que this.resModelos$ se actualice
      // TODO: hacer una función en el servicio de modelos que
      // fuerce una llamada al backend
    }
  }

  async getServicio(idservicio) {
    const resp = await this._apiRestService.getServicio(idservicio);
    console.log("Servicio es: ", resp);
    if (resp.ok) {
      this.servicio = resp.dato;
      await this.getModeloActivo();
    }
  }

  ngOnDestroy() {
    /*if (this.suscripcion) {
      this.suscripcion.unsubscribe();
    }*/
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  confCambiada(conf) {
    // this.conf_actual = this.configuraciones[conf];
    console.log('La config que viene es: ', conf);
    console.log('configs es: ', this.configs);
    console.log(this.configs[conf]);
    this.formModelo.get('nombre').setValue(this.configs[conf].nombre);
    this.formModelo.get('n_epochs').setValue(this.configs[conf].n_epochs);
    this.formModelo.get('batch_size').setValue(this.configs[conf].batch_size);
    this.formModelo.get('learning_rate').setValue(this.configs[conf].learning_rate);
    this.formModelo.get('print_cost_every_n_batch').setValue(this.configs[conf].print_cost_every_n_batch);
    this.formModelo.get('early_stopping').setValue(this.configs[conf].early_stopping);
    this.formModelo.get('L1_lambda').setValue(this.configs[conf].L1_lambda);
    this.formModelo.get('L2_lambda').setValue(this.configs[conf].L2_lambda);
    this.formModelo.get('dropout').setValue(this.configs[conf].dropout);
    // this.formModelo.get('id_architecture').setValue(this.arquitecturas[this.imod].id_architecture);
    this.formModelo.get('lower_bound').setValue(this.configs[conf].lower_bound);
    this.formModelo.get('upper_bound').setValue(this.configs[conf].upper_bound);
    this.formModelo.get('trainset').setValue(this.configs[conf].trainset);
    this.formModelo.get('testset').setValue(this.configs[conf].testset);
  }

  iniciarModelo() {
    this.formModelo = this.formBuilder.group({
      nombre: ['', Validators.required],
      n_epochs: ['', Validators.required],
      batch_size: ['', Validators.required],
      learning_rate: ['', Validators.required],
      print_cost_every_n_batch: ['', Validators.required],
      early_stopping: ['', Validators.required],
      L1_lambda: ['', Validators.required],
      L2_lambda: ['', Validators.required],
      dropout: ['', Validators.required],
      id_architecture: [0],
      listaConf: [''],
      lower_bound: ['', Validators.required],
      upper_bound: ['', Validators.required],
      trainset: ['', Validators.required],
      testset: ['', Validators.required]
    });
  }

  async entrenarModelo(modal) {
    console.log('Entre al re entrenar modelo');
    console.log(this.modeloAEntrenar);

    if (this.validacionesForm()) {
      this._messagesService.error('Faltan campos a rellenar');
      return;
    }

    this.formModelo.get('id_architecture').setValue(this.idArchEntrenar);
    const conf_actual = await this.guardar(modal, true);
    console.log('LA CONFIG ES', this.configs[conf_actual.idconf]);
    // console.log()
    // let resp2 = await this._apiRestService.cambiarEstadoEntrenadoArchitectura(this.formModelo.get('id_architecture').value);
    const respModelo = await this._apiRestService.putModeloEntrenando(this.modeloAEntrenar, { 'entrenando': false, 'estado': 'PREPARANDO', 'trained_epochs': 0, 'stop': false });
    const respDeleleteRes = await this._apiRestService.deleteResults(this.modeloAEntrenar);
    this.resModelos$ = this._modelosService.getModelos('updatedAt', 'true', this.idservicio, null);
    modal.close();
    const resp = await this._apiRestService.launchTrain(conf_actual.idconf, this.modeloAEntrenar, this.modeloAEntrenar);
    // this.router.navigate(['/servicio/'+this.idservicio+'/entrenar']);
  }

  validacionesForm() {
    console.log('ENTRE AL VALIDACIONES FORM');
    if (this.formModelo.controls['n_epochs'].errors?.required ||
       this.formModelo.controls['nombre'].errors?.required ||
       this.formModelo.controls['batch_size'].errors?.required ||
       this.formModelo.controls['learning_rate'].errors?.required ||
       this.formModelo.controls['early_stopping'].errors?.required ||
       this.formModelo.controls['L1_lambda'].errors?.required ||
       this.formModelo.controls['L2_lambda'].errors?.required ||
       this.formModelo.controls['dropout'].errors?.required ||
       this.formModelo.controls['lower_bound'].errors?.required ||
       this.formModelo.controls['upper_bound'].errors?.required ||
       this.formModelo.controls['print_cost_every_n_batch'].errors?.required) {
      return true;
    } else {
      console.log('RETORNO FALSO');
      return false;
    }

  }

  async guardar(modal, retornar = false) {
    let nueva = this.formModelo.value;
    nueva = {...nueva, idservicio: this.idservicio};
    console.log(nueva);
    nueva['modelo'] = this.nombreModeloAEntrenar;

    const response = await this._apiRestService.postConfiguracion(nueva);
    if (response.ok) {
      console.log(response);
      // this.getConfiguraciones();
      this.configs.push(response.dato);
      if (retornar) {
        return response.dato;
      }
    } else {
      modal.close('Error');
      // this._messageService.error(response.message);
    }
  }


  iniciarFiltros() {
    this.filtros = {
      'idModeloDesc': false,
      'nombreDesc': false,
      'createdAtDesc': false,
      'updatedAtDesc': false,
      'estadoDesc': false,
      'architecturaDesc': false,
    };
  }

  abrirLogError(modal, modelo) {
    console.log('El modelo es: ', modelo);
    this.textoError = modelo.tipo_error;
    this.modalService.open(modal);
  }

  getPageSymbol(current: number) {
    return ['A', 'B', 'C', 'D', 'E', 'F', 'G'][current - 1];
  }

  selectPage(page: string) {
    this.page = parseInt(page, 10) || 1;
  }

  formatInput(input: HTMLInputElement) {
    input.value = input.value.replace(FILTER_PAG_REGEX, '');
  }

  irAEditarConfig(id_architecture) {
    // [routerLink]="'/servicio/'+idservicio+'/entrenar/configuracion/nueva'"
    this.router.navigateByUrl('/servicio/' + this.idservicio + '/entrenar/configuracion/nueva', {state: { id_architecture }});
  }

  abrirModalVerMas(modelo, modal) {
    this.modeloSeleccionado = modelo;
    console.log('Modelo seleccionado es: ', this.modeloSeleccionado);
    this.modalService.open(modal);
  }

  cambioFiltroEstado(value) {
    console.log(value);
    if (value == -1) {
      value = null;
      console.log('AA');
    }

    this.resModelos$ = this._modelosService.getModelos('updatedAt', 'true', this.idservicio, value);
  }

  downloadTxtFile() {
    const text = `ID modelo: ${this.modeloSeleccionado.idmodelo}\nNombre del modelo: ${this.modeloSeleccionado.nombre}\nArquitectura del modelo: ${this.modeloSeleccionado.architecture.nombre}\nEstado del modelo: ${this.modeloSeleccionado.estado}\nFecha de creación: ${this.modeloSeleccionado.createdAt}\nFecha última actualización: ${this.modeloSeleccionado.updatedAt}`;
    this._plainFileService.dyanmicDownloadByHtmlTag({
      fileName: `Información modelo ${this.modeloSeleccionado.idmodelo}`,
      text: text
    });
  }

}
