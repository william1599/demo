import {Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ApiRestService} from '../../../../services/api-rest.service';
import {MessageService} from '../../../../services/messages.service';
import {ModelService} from '../../services/model.service';

@Component({
  selector: 'app-prediction-config-options',
  templateUrl: './prediction-config-options.component.html'
})

export class PredictionConfigOptionsComponent implements OnInit {
  @Input() modelId: any;
  optionsForm: FormGroup;
  model: any;
  constructor(private formBuilder: FormBuilder,
              private _apiRestService: ApiRestService,
              private _messageService: MessageService,
              private _modelService: ModelService) {
  }
  async ngOnInit() {
    this.getModel();
    this.initOptionsForm();
  }

  getModel() {
    this.model = this._modelService.getSingleModel();
  }

  initOptionsForm() {
    this.optionsForm = this.formBuilder.group({
      forecastComment: [this.model?.comentario_habilitado, Validators.required],
      forecastTitle: [this.model?.titulo, Validators.required]
    });
  }

  async onSubmit() {
    const body = {
      titulo: this.optionsForm.get('forecastTitle').value,
      comentario_habilitado: this.optionsForm.get('forecastComment').value
    };
    try {
      const resp = await this._apiRestService.putModeloEntrenando(this.modelId, body);
      this._messageService.success('Cambios guardados correctamente');
    } catch (e) {
      this._messageService.error('Error al guardar los cambios');
    }
  }
}
