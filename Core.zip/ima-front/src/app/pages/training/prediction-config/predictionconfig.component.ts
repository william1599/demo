import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable, Subscription } from 'rxjs';
import { PredictionsBase } from 'src/app/models/predictions-models/prediction-form';
import { PredictionService } from 'src/app/models/predictions-models/prediction.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiRestService } from 'src/app/services/api-rest.service';
import { MessageService } from 'src/app/services/messages.service';
import { animate, style, transition, trigger, query, stagger, state } from '@angular/animations';
import {ModelService} from "../services/model.service";
import { UrlService } from 'src/app/services/url.service';
import { HttpEventType } from '@angular/common/http';

@Component({
  selector: 'app-config-prediction',
  templateUrl: './predictionconfig.component.html',
  styleUrls: ['./predictionconfig.component.css'],
  animations: [
    trigger('listAnimation', [
      transition('* => *', [
        // each time the binding value changes
        query(
          ':leave',
          [stagger(100, [animate('0.5s', style({ opacity: 0 }))])],
          { optional: true }
        ),
        query(
          ':enter',
          [
            style({ opacity: 0 }),
            stagger(100, [animate('0.5s', style({ opacity: 1 }))])
          ],
          { optional: true }
        )
      ])
    ]),
    trigger(
      'enterAnimation', [
        transition(':enter', [
          style({transform: 'translateX(-100px)', opacity: 0}),
          animate('300ms', style({transform: 'translateX(0)', opacity: 1, 'overflow-x': 'hidden'}))
        ]),
      ]
    ),
    trigger('slideIn', [
      state('*', style({ 'overflow-y': 'hidden' })),
      state('void', style({ 'overflow-y': 'hidden' })),
      transition('* => void', [
        style({ height: '*' }),
        animate(250, style({ height: 0 }))
      ]),
      transition('void => *', [
        style({ height: '0' }),
        animate(250, style({ height: '*' }))
      ])
    ])
  ]
})

export class PredictionConfigComponent implements OnInit {

  idservicio: string;
  idmodelo: string;
  parameterList$: Observable<PredictionsBase<any>[]>;
  drawNewParameter: any;
  drawEditVariable: any;
  showInputs: boolean;
  showInput: boolean;
  showEditInputs: boolean;
  showOptions: boolean;
  variables: Array<any>;
  inputTypes: Array<Object>;
  variableSelected: any;
  variableToDelete: Number;
  disabledVariables: any;
  servicio: any;
  subscription: Subscription;
  previousUrl: string = '';
  isOptimizerUrl: any;
  mainForm: FormGroup;
  chartConfigForm: FormGroup;
  chartConfig: any;

  constructor (
    private route: ActivatedRoute,
    private location: Location,
    private _predictionService: PredictionService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private _apiRestService: ApiRestService,
    private _messageService: MessageService,
    private _modelService: ModelService,
    private urlService: UrlService
  ) {
    this.idservicio = this.route.snapshot.paramMap.get('idservicio');
    this.idmodelo = this.route.snapshot.paramMap.get('idmodelo');
    this.parameterList$ = this._predictionService.getPredictions();
    this.drawEditVariable = {
      inputs: []
    };
  }

  ngOnInit(): void {
    this.mainForm = this.initMainForm();
    this.chartConfigForm = this.initChartConfigForm();
    this.urlService.previousUrl$.subscribe(( previousUrl: string ) => {
      console.log("PREVIOUS URL: ", previousUrl)
      if (previousUrl?.includes('optimizer')) {
        console.log("Vengo del optimizador")
        this.isOptimizerUrl = true;
      } else {
        this.isOptimizerUrl = false;
      }
      // this.previousUrl = previousUrl;
    })

    this._modelService.getModel(this.idmodelo);
    console.log('paramterList: ', this.parameterList$);
    console.log('ID MODELO: ', this.idmodelo);
    // this.getModelVariables(true);
    this.getModelVariables(true);
    this.getInputTypes();
    this._predictionService.getModelVariables(this.idmodelo, true, 'false', 'false');
    this.showInputs = false;
    this.showInput = false;
    this.showEditInputs = false;
    this.showOptions = false;
    this.getServicio();
    this.subscription = this._predictionService.predictionChanged.subscribe(
      (predictions: any) => {
        this.variables = predictions;
      }
    );
    //this.variables = this._predictionService.getPredictions2();
    this.getModelConfig();
    this.getChartConfig();
  }

  get files() {
    return this.mainForm.get('files') as FormArray;
  }

  addFile(name) {
    this.files.push(this.formBuilder.control(name));
  }

  removeFile(index) {
    this.files.removeAt(index);

  }

  initMainForm() {
    const form = this.formBuilder.group({
      functionName: ['', Validators.required],
      files: this.formBuilder.array([]),
      idmodelo: ['', Validators.required],
      archivo: ['']
    })

    // form.patchValue({ functionName: funName });

    return form;
  }

  initChartConfigForm() {
    const form = this.formBuilder.group({
      yAxis: ['', Validators.required],
      xAxis: ['', Validators.required],
      secondYAxis: [''],
      chartType: ['', Validators.required],
      title: [''],
      idmodelo: [''],
      precautionValue: [''],
      dangerValue: ['']
    });

    return form;
  }

  async postMainForm() {

    this.mainForm.patchValue({ idmodelo: this.idmodelo });
    console.log("MAINFORM: ", this.mainForm.value);
    // const resp = await this._apiRestService.postModelConfig(this.mainForm.value);
    let fileToUpload = this.mainForm.get('archivo').value;
    let moreData = {
      functionName: this.mainForm.value.functionName,
      files: this.mainForm.get('files').value,
      idmodelo: this.idmodelo
    }
    console.log('fileToUpload: ', fileToUpload);
    console.log('moreData: ', moreData);
    this._apiRestService.postModelConfig(fileToUpload, moreData).subscribe(resp => {
      if(resp.type === HttpEventType.Response) {
        console.log("UPLOAD COMPLETE")
        // this.getColecciones('idcoleccion', this.parametrosColecciones.idDesc)
        this._messageService.success("Archivo subido correctamente");
        // success = true;
      }

      if(resp.type === HttpEventType.UploadProgress) {
        const percentDone = Math.round(100 * resp.loaded / resp.total);
        console.log('Progress ' + percentDone + '%')
      }
    })

    // if (resp.ok) {
    //   this._messageService.success("Cambios guardados correctamente");
    // } else {
    //   this._messageService.error("Error al guardar los cambios");
    // }
  }

  onFileChange(evt: any) {
    /* wire up file reader */
    const file = evt.target.files[0];
    console.log('file is: ', file);
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    this.mainForm.get('archivo').setValue(file);
    // this.fileInForm = true;
  }

  async getModelConfig() {

    const resp = await this._apiRestService.getModelConfig(this.idmodelo);
    console.log("modelconf: ", resp);

    let filesCf = []

    for(let file of resp.dato.model_files) {
      this.addFile(file.name);
    }

    // console.log("FILESCF: ", filesCf);
    this.mainForm.patchValue({ functionName: resp.dato.functionName, files: filesCf })

    return resp.dato;
  }

  async getServicio() {
    console.log('Entre al get servicio');
    const response = await this._apiRestService.getServicio(this.idservicio);
    if (response.ok) {
      console.log('El servicio es: ', response.dato);
      this.servicio = response.dato;
    } else {
      console.log('Hubo un error', response.error);
    }
  }

  async getModelVariables(enabled) {
    // const resp = await this._apiRestService.getModelVariables(this.idmodelo, enabled);
    this.variables = await this._predictionService.getModelVarFromDB(this.idmodelo, enabled, null);
    console.log("Variables: ", this.variables);
  }

  async getInputTypes() {
    const resp = await this._apiRestService.getInputsType();
    if (resp.ok) {
      this.inputTypes = resp.datos;
      console.log('Tipo de entrada', this.inputTypes);
    } else {
      console.log('Ocurrió un error inesperado');
    }
  }

  backInNavigation() {
    this.location.back();
  }

  openModal(modal) {
    this.modalService.open(modal);
  }

  async openCreateModal(modal) {
    try {
      const resp = await this._apiRestService.getModelVariables(this.idmodelo, false, 'false', 'false');
      this.disabledVariables = resp.datos;
      this.modalService.open(modal);
    } catch (e) {
      console.error(e);
    }
  }

  openDeleteModal(modal, idvariable) {
    this.variableToDelete = idvariable;
    this.modalService.open(modal);
  }

  openEditModal(modal, selectedVar) {
    this.variableSelected = selectedVar;
    this.modalService.open(modal);
  }

  async deleteVariable(modal) {
    const body = { habilitado: false };
    const resp = await this._apiRestService.editModelVariable(this.variableToDelete, body);

    if (resp) {
      this._messageService.success('Variable eliminada correctamente');
      await this.getModelVariables(true);
    } else {
      this._messageService.error('Error al eliminar la variable');
    }

    modal.close();
  }

  async getChartConfig() {
    try {
      const resp = await this._apiRestService.getChartConfig(this.idmodelo);
      this.chartConfig = resp.datos;
      console.log("chartConfig: ", this.chartConfig);
      this.chartConfigForm.patchValue({ yAxis: this.chartConfig.yAxis,
                                        xAxis: this.chartConfig.xAxis,
                                        secondYAxis: this.chartConfig.secondYAxis,
                                        precautionValue: this.chartConfig.precautionValue,
                                        dangerValue: this.chartConfig.dangerValue })
      console.log(this.chartConfigForm.value);
    } catch (err) {
      console.error(err);
    }
  }

  async editChartConfig() {
    try {
      this.chartConfigForm.value.idmodelo = this.idmodelo;
      console.log("chartCfg: ", this.chartConfigForm.value);
      const resp = await this._apiRestService.editChartConfig(this.chartConfigForm.value);
      this._messageService.success('Configuración de gráfico editado correctamente');
    } catch (err) {
      this._messageService.error('Error al editar la configuración del gráfico');
      console.error(err);
    }
  }

  async postChartConfig(modal) {
    console.log("chartConfig: ", this.chartConfigForm.value);
    this.chartConfigForm.value.idmodelo = this.idmodelo;
    const resp = await this._apiRestService.postChartConfig(this.chartConfigForm.value);

    if(resp) {
      this._messageService.success('Configuración guardada con éxito');
    } else {
      this._messageService.error('Error la guardar configuración');
    }

    modal.close();
    this.getChartConfig();
  }

}
