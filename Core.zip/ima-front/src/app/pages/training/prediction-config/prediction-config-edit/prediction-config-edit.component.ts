import {Component, Input, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ApiRestService} from '../../../../services/api-rest.service';
import {Subscription} from 'rxjs';
import {PredictionService} from '../../../../models/predictions-models/prediction.service';

@Component({
  selector: 'app-prediction-config-edit',
  templateUrl: './prediction-config-edit.component.html'
})

export class PredictionConfigEditComponent implements OnInit {
  @Input() modal: any;
  @Input() inputTypes: any;
  @Input() idmodelo: any;
  @Input() variableSelected: any;
  @Input() variables: any;
  showOptions: any;
  showEditInputs: any;
  selectedType: any;
  drawEditVariable: any;
  editFormVariable: FormGroup;
  subscriptionParameter: Subscription;
  maxRows: any;
  selectedVariableOrder: any;
  maxColumns: any = ['1', '2', '3'];
  constructor(private formBuilder: FormBuilder,
              private _apiRestService: ApiRestService,
              private _predictionService: PredictionService) {
  }
  ngOnInit() {
    console.log("Variables: ", this.variables);
    this.maxRows = this.variables.length;
    this.maxRows = Array(this.variables.length).fill(null).map((x, i) => i);
    console.log(this.maxRows);
    this.editFormVariable = this.initForm();
    this.editVariableTypeChanged(this.variableSelected['tipos_entradas'] ? this.variableSelected['tipos_entradas']['nombre'] : 'Texto');
    console.log('variable selected: ', this.variableSelected);
    this.selectedVariableOrder = this.variableSelected.orden;
  }
  get inputsEdit(): FormArray {
    return this.editFormVariable.get('inputs') as FormArray;
  }

  get optionsEdit(): FormArray {
    return this.editFormVariable.get('options') as FormArray;
  }
  addEditOption() {
    this.optionsEdit.push(this.formBuilder.control(''));
  }
  initForm() {
    const varia = this.formBuilder.group({
      type: [this.variableSelected['tipos_entradas'] ? this.variableSelected['tipos_entradas']['nombre'] : 'Texto', Validators.required],
      name: [this.variableSelected['etiqueta'], Validators.required],
      value: [this.variableSelected['valor'], Validators.required],
      min: [this.variableSelected['minimo'], Validators.required],
      esConstante: [this.variableSelected['esConstante']],
      max: [this.variableSelected['maximo'], Validators.required],
      key: [this.variableSelected['llave'], Validators.required],
      order: [this.variableSelected['orden'], Validators.required],
      parameterForm: [this.variableSelected['tipos_entradas'] ? this.variableSelected['tipos_entradas']['nombre'] : 'Texto', Validators.required],
      inputs: this.formBuilder.array([]),
      options: this.formBuilder.array([])
    });

    this.subscriptionParameter = varia.get('parameterForm').valueChanges.subscribe(val => {
      this.editVariableTypeChanged(val);
    });

    return varia;
  }
  async editVariable(modal) {

    console.log('Valores: ', this.editFormVariable.value);
    console.log('Select type: ', this.selectedType);
    console.log('Draw edit variable: ', this.drawEditVariable);
    console.log('Input edit: ', this.inputsEdit);

    const variable = {};

    variable['idmodelo'] = this.idmodelo;
    variable['tipo'] = this.selectedType.tipo;
    variable['idtipoentrada'] = this.selectedType.idtipoentrada;
    variable['controlType'] = 'input';
    variable['orden'] = this.editFormVariable.value.order;
    variable['previousOrder'] = this.selectedVariableOrder;
    variable['esConstante'] = this.editFormVariable.value.esConstante;

    if (this.selectedType.tipo === 'select') {
      variable['controlType'] = 'select';
      variable['options'] = JSON.stringify(this.editFormVariable.value.options);
    }

    for (let i = 0; i < this.selectedType['entradas'].length; i++) {
      const input = this.selectedType['entradas'][i];
      console.log("INPUT: ", input);
      // variable[input['clave']] = this.editFormVariable.value.inputs[i];
      variable[input['clave']] = this.inputsEdit.value[i];
    }

    console.log('VARIABLE: ', variable);

    const resp = await this._apiRestService.editModelVariable(this.variableSelected['idparametros'], variable);
    await this._predictionService.getModelVarFromDB(this.idmodelo, true, null);
    // this._predictionService.getModelVariables(this.idmodelo, true);

    modal.close();
  }
  editVariableTypeChanged(value) {
    console.log('ENtre al edit en edit component');
    this.inputsEdit.clear();
    this.showEditInputs = false;
    this.clearFormArray(this.editFormVariable.get('options'));
    const selectedType = this.inputTypes.find(x => x['nombre'] === value);
    if (!selectedType) { return; }
    this.selectedType = selectedType;
    console.log('Tipo seleccionado', selectedType);
    const inputs = selectedType['entradas'];
    this.drawEditVariable = {
      inputs: []
    };
    for (let i = 0; i < inputs.length; i++) {
      const valueForm = this.variableSelected[inputs[i].clave];
      inputs[i].valor = valueForm;
      if (valueForm) {
        inputs[i].valor = valueForm;
      } else {
        inputs[i].valor = '';
      }
      console.log("INPUT[I]: ", inputs[i]);
      this.drawEditVariable.inputs.push(inputs[i]);
      this.inputsEdit.push(this.formBuilder.control(valueForm));
    }
    console.log('inputsEdit', this.inputsEdit.value);
    console.log('drawEditVariable', this.drawEditVariable);
    console.log('editFormVariable', this.editFormVariable.value);

    this.showEditInputs = true;

    if (selectedType['tipo'] === 'select') {
      this.showOptions = true;
    } else {
      this.showOptions = false;
    }
  }
  clearFormArray = (formArray) => {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }
}

