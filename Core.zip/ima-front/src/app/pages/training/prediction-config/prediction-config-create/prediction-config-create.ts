import {Component, Input, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Subscription} from 'rxjs';
import {PredictionService} from '../../../../models/predictions-models/prediction.service';
import {ApiRestService} from '../../../../services/api-rest.service';
import {MessageService} from "../../../../services/messages.service";

@Component({
  selector: 'app-prediction-config-create',
  templateUrl: './prediction-config-create.html'
})

export class PredictionConfigCreateComponent implements OnInit {
  @Input() modal: any;
  @Input() inputTypes: any;
  @Input() showInputs: any;
  @Input() showInput: any;
  @Input() drawNewParameter: any;
  @Input() showOptions: any;
  @Input() idmodelo: any;
  @Input() disabledVariables: any;
  selectedType: any;
  formParameter: FormGroup;
  subscriptionParameter: Subscription;
  variableChanged: Boolean = false;
  constructor(private formBuilder: FormBuilder,
              private _predictionService: PredictionService,
              private _apiRestService: ApiRestService,
              private _messageService: MessageService) {
  }
  ngOnInit() {
    this.formParameter = this.initForm();
  }
  get inputs(): FormArray {
    return this.formParameter.get('inputs') as FormArray;
  }
  get options() {
    return this.formParameter.get('options') as FormArray;
  }
  addOption() {
    this.options.push(this.formBuilder.control(''));
  }

  initForm() {
    const form = this.formBuilder.group({
      type: ['', Validators.required],
      variableId: ['', Validators.required],
      value: ['', Validators.required],
      min: ['', Validators.required],
      max: ['', Validators.required],
      key: ['', Validators.required],
      parameterForm: ['', Validators.required],
      inputs: this.formBuilder.array([]),
      options: this.formBuilder.array([])
    });

    this.subscriptionParameter = form.get('parameterForm').valueChanges.subscribe(val => {
      this.parameterTypeChanged(val);
    });
    return form;
  }

  variableChange(value) {
    console.log(value);
    this.variableChanged = true;
  }

  parameterTypeChanged(value) {
    console.log('value', value);
    console.log('ESTOY EN EL NEW');
    this.clearFormArray(this.formParameter.get('options'));

    const selectedType = this.inputTypes.find(x => x['nombre'] === value);
    this.selectedType = selectedType;
    console.log('ASDAD', selectedType);
    const inputs = selectedType['entradas'];

    // var finalOptions = this.getOptions();
    this.drawNewParameter = {
      inputs: []
    };

    for (let i = 0; i < inputs.length; i++) {

      this.drawNewParameter.inputs.push(inputs[i]);
      this.inputs.push(this.formBuilder.control(''));
    }

    this.showInput = true;

    if (selectedType['tipo'] === 'select') {
      this.showOptions = true;
    } else {
      this.showOptions = false;
    }
  }

  clearFormArray = (formArray) => {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }

  async saveParameter(modal) {
    console.log(this.formParameter.get('variableId').value);

    const variable = {};

    variable['idmodelo'] = this.idmodelo;
    variable['tipo'] = this.selectedType.tipo;
    variable['idtipoentrada'] = this.selectedType.idtipoentrada;
    variable['controlType'] = 'input';
    variable['habilitado'] = true;


    if (this.selectedType.tipo === 'select') {
      variable['controlType'] = 'select';
      variable['options'] = JSON.stringify(this.formParameter.value.options);
    }

    for (let i = 0; i < this.selectedType['entradas'].length; i++) {
      const input = this.selectedType['entradas'][i];
      variable[input['clave']] = this.formParameter.value.inputs[i];
    }

    console.log('VARIABLE: ', variable);
    try {
      const resp = await this._apiRestService.editModelVariable(this.formParameter.get('variableId').value, variable);
    } catch (e) {
      console.error(e);
      this._messageService.error('Error al guardar variable');
    }
    await this._predictionService.updatePrediction(this.idmodelo);
    // this._predictionService.getModelVariables(this.idmodelo);
    // this.getModelVariables();
    modal.close();
  }
}
