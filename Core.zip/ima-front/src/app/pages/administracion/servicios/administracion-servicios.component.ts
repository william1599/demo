import { Location } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { User } from "src/app/models/user";
import { ApiRestService } from "src/app/services/api-rest.service";
import { AuthenticationService } from "src/app/services/authentication.service";


@Component({
  selector: 'app-administracion-servicios',
  templateUrl: './administracion-servicios.component.html',
  styleUrls: ['./administracion-servicios.component.css']
})

export class AdministracionServiciosComponent implements OnInit {


  usuario: User;
  servicios: Array<any>;
  formCrearServicio: FormGroup;
  formEditarServicio: FormGroup;
  empresas: Array<any>;
  servicioCambiaEstado: any;
  idServicioAEditar: Number;
  idEmpresa: any;
  idServicioDesc: boolean;
  nombreServicioDesc: boolean;
  tipoServicioDesc: boolean;
  descripcionServicioDesc: boolean;
  empresaServicioDesc: boolean;
  creacionServicioDesc: boolean;
  estadoServicioDesc: boolean;
  plantaServicioDesc: boolean;
  lineasProduccion: any;
  page = 1;
  pageSize = 5;
  idempresaFiltro: any;
  selectIdLinea = -1;


  constructor(
    private _route: ActivatedRoute,
    private _apiRestService: ApiRestService,
    private _authenticationService: AuthenticationService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private router: Router,
    private location: Location
    ) {

  }

  ngOnInit(): void {
    this.idServicioDesc = false;
    this.nombreServicioDesc = false;
    this.tipoServicioDesc = false;
    this.descripcionServicioDesc = false;
    this.empresaServicioDesc = false;
    this.creacionServicioDesc = false;
    this.estadoServicioDesc = false;
    this.plantaServicioDesc = false;
    this.idEmpresa = this._route.snapshot.paramMap.get('idempresa');
    console.log('Id empresa: ', this.idEmpresa)
    this.usuario = this._authenticationService.currentUserValue;
    this.formCrearServicio = this.formCreaServicio();
    this.formEditarServicio = this.formEditaServicio();
    this.getEmpresas();
    this.getLineasProduccion();
    if(this.idEmpresa != 'todos') {
      console.log('Entre aqui caserito')
      this.getServiciosPorEmpresa('idservicio', 'true');
    } else {
      this.getServicios('idservicio', 'true');
    }
  }


  previusNavigate() {
    this.location.back();
  }

  async getServicios(param, descending) {
    try {
      let response;
      if(this.usuario.rol === 'ADMIN-EMPRESA') {
        response = await this._apiRestService.getServicios(this.usuario.idempresa, param, descending);
      } else if(this.idempresaFiltro) {
        response = await this._apiRestService.getServicios(this.idempresaFiltro, param, descending);
      } else {
        response = await this._apiRestService.getServicios(null, param, descending);
      }

      this.servicios = response.datos
      for(let servicio of this.servicios) {
        if(servicio.idmodelo) {
          let respuestaModelo = await this._apiRestService.getModeloPorId(servicio.idmodelo);
          servicio['modelo'] = respuestaModelo.dato.nombre;
        } else {
          servicio['modelo'] = "No habilitado";
        }
      }
      console.log('Los servicios son: ', this.servicios)
    } catch(e) {
      console.log("Error al obtener servicios", e)
    }
  }

  async getServiciosPorEmpresa(param, descending) {
    try {
      let response = await this._apiRestService.getServicios(this.idEmpresa, param, descending)
      this.servicios = response.datos
      for(let servicio of this.servicios) {
        if(servicio.idmodelo) {
          let respuestaModelo = await this._apiRestService.getModeloPorId(servicio.idmodelo);
          servicio['modelo'] = respuestaModelo.dato.nombre;
        } else {
          servicio['modelo'] = "No habilitado";
        }
      }
      console.log("los servicios son: ", this.servicios)
    } catch(e) {
      console.log('Error al obtener servicios', e)
    }
  }

  formCreaServicio() {
    return this.formBuilder.group({
      nombre: ['', Validators.required],
      tipo: ['', Validators.required],
      descripcion: ['', Validators.required],
      idempresa: ['', Validators.required],
      idlineaproduccion: ['', Validators.required],
      planta: ['', Validators.required]
    })
  }

  formEditaServicio() {
    return this.formBuilder.group({
      nombre: ['', Validators.required],
      tipo: ['', Validators.required],
      descripcion: ['', Validators.required],
      idempresa: ['', Validators.required],
      idlineaproduccion: ['', Validators.required],
    })
  }

  async getEmpresas() {
    try {
      let response = await this._apiRestService.getEmpresas('idempresa', true);
      console.log(response.datos)
      this.empresas = response.datos;
      console.log(this.empresas)
    } catch(e) {
      console.log('Hubo un error al obtener las empresas', e)
    }
  }

  async getLineasProduccion() {
    if(this.usuario.rol === 'ADMIN-EMPRESA') {
      try {
        let response = await this._apiRestService.getLineasPorEmpresa('nombre', 'true', this.usuario.idempresa);
        console.log(response.datos)
        this.lineasProduccion = response.datos;
        console.log('Las lineas de produccion son: ', this.lineasProduccion)
      } catch(e) {
        console.log('Error al obtener lineas de producción', e)
      }
    } else {
      try {
        let response = await this._apiRestService.getLineasProduccion('nombre', 'true', null);
        console.log(response.datos)
        this.lineasProduccion = response.datos;
        console.log('Las lineas de produccion son: ', this.lineasProduccion)
      } catch(e) {
        console.log('Error al obtener lineas de producción', e)
      }
    }


  }

  cambioFiltroEmpresa(nuevoValor) {
    if(nuevoValor != -3) {
      this.idempresaFiltro = nuevoValor;
      this.getServicios('idservicio', 'true')
    } else {
      this.idempresaFiltro = null;
      this.getServicios('idservicio', 'true')
    }
  }

  abrirModalNuevoServicio(modal) {
    this.modalService.open(modal)
  }

  abrirModalEditarServicio(modal, nombre, tipo, descripcion, idempresa, idservicio, idlineaproduccion) {
    this.formEditarServicio.setValue({ nombre, tipo, descripcion, idempresa, idlineaproduccion });
    this.idServicioAEditar = idservicio;
    this.modalService.open(modal)
  }

  async guardarServicio(modal) {
    if(this.usuario.rol === 'ADMIN-EMPRESA') {
      this.formCrearServicio.controls['idempresa'].setValue(this.usuario.idempresa)
    }
    try {
      console.log('Servicio a mandar: ', this.formCrearServicio.value)
      let response = await this._apiRestService.postServicio(this.formCrearServicio.value)
      if(response.ok) {
        this.formCrearServicio.reset();
        this.getServiciosPorRolUsuario('idservicio', 'true');
        modal.close("Exito");
      } else {
        modal.close();
      }
    } catch(e) {
      console.log("Error al guardar servicio")
    }
  }

  async editarServicio(modal) {
    try {
      let response = await this._apiRestService.editarServicio(this.idServicioAEditar, this.formEditarServicio.value)
      if(response.ok) {
        this.getServiciosPorRolUsuario('idservicio', 'true');
        modal.close('Exito')
      } else {
        modal.close()
      }
    } catch(e) {
      modal.close()
      console.log('Error al editar servicio', e)
    }
  }

  async cambiarEstadoServicio(modal) {
    try {
      let response = await this._apiRestService.cambiarEstadoServicio(this.servicioCambiaEstado.idservicio)
      if(response.ok) {
        this.getServiciosPorRolUsuario('idservicio', 'true');
        modal.close('Exito')
      } else {
        modal.close()
      }
    } catch(e) {
      modal.close()
    }
  }

  async onChange(valor) {
    console.log('Valor es: ', valor)
    this.selectIdLinea = -1;
    this.formCrearServicio.controls['idlineaproduccion'].setValue(-1)
    //this.formCrearServicio.controls['idlineaproduccion'].setValue(valor)
    try {
      let response = await this._apiRestService.getLineasPorEmpresa('nombre', 'true', valor);
      this.lineasProduccion = response.datos;
      console.log('Las lineas de esta empresa son: ', this.lineasProduccion)
    } catch(e) {
      console.log('Error al obtener lineas', e)
    }

    //this.formCrearServicio['idlineaproduccion'].setValue(null)
  }

  onChangeLinea(valor) {
    console.log('Entre al changelinea',valor)
    this.formCrearServicio.controls['idlineaproduccion'].setValue(valor)
    //this.formCrearServicio.setValue({ idlineaproduccion: valor });
  }

  getServiciosPorRolUsuario(param, descending) {
    if(this.usuario.rol === 'ADMIN') {
      this.getServicios(param, descending);
    } else {
      this.getServiciosPorEmpresa(param, descending);
    }
  }

  abrirModalConfirmacion(modal, nombre, tipo, idservicio, habilitado) {
    this.servicioCambiaEstado = {
      idservicio,
      nombre,
      tipo,
      habilitado
    }
    this.modalService.open(modal)
  }


}
