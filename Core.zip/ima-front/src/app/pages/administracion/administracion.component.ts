import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";


import { User } from 'src/app/models/user';
import { AuthenticationService } from "src/app/services/authentication.service";

@Component({
  selector: 'app-administracion',
  templateUrl: './administracion.component.html',
  styleUrls: ['./administracion.component.css']
})

export class AdministracionComponent implements OnInit {

  usuario: User;

  constructor(
    private router: Router,
    private _autehticationService: AuthenticationService)
    {}

  ngOnInit(): void {

    this.usuario = this._autehticationService.currentUserValue;
  }

  verEmpresas() {
    this.router.navigate(['adminempresas'])
    //this.router.navigateByUrl('/adminempresas', { state: { id:10 } })
  }

}
