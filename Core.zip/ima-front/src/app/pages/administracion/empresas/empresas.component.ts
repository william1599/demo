import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';



import { ApiRestService } from 'src/app/services/api-rest.service';

import { User } from 'src/app/models/user';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-administracion-empresas',
  templateUrl: './empresas.component.html',
  styleUrls: ['./empresas.component.scss']
})

export class EmpresasComponent implements OnInit {

  user: User;
  companies: Array<any>;
  companyForm: FormGroup;
  editCompanyForm: FormGroup;
  companyIdToEdit: Number;
  companyToDisable: any;
  userCompanyAdminCompany: any;
  companyIdDesc: boolean;
  nameDesc: boolean;
  descriptionDesc: boolean;
  createDesc: boolean;
  statusDesc: boolean;
  page = 1;
  pageSize = 5;

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private _apiRestService: ApiRestService,
    private modalService: NgbModal,
    private secondModalService: NgbModal,
    private formBuilder: FormBuilder) {}

  ngOnInit(): void {

    this.companyIdDesc = false;
    this.nameDesc = false;
    this.descriptionDesc = false;
    this.createDesc = false;
    this.statusDesc = false;
    this.user = this.authenticationService.currentUserValue;
    console.log('El usuario es: ', this.user);
    if (this.user.rol === 'ADMIN-EMPRESA') {
      this.getEmpresaPorIdUsuario();
    }
    this.companyForm = this.creaEmpresa();
    this.editCompanyForm = this.editarEmpresa();
    this.getTotalEmpresas('habilitado', 'true');
  }

  async getTotalEmpresas(param, descending) {
    console.log(descending);
    try {
      const response = await this._apiRestService.getEmpresas(param, descending);
      console.log('Empresas totales', response.datos);
      this.companies = response.datos;
    } catch (e) {
      console.log('Hubo un error al obtener las empresas', e);
    }
  }

  async getEmpresaPorIdUsuario() {
    try {
      const response = await this._apiRestService.getEmpresa(this.user.idempresa);
      console.log('Empresas por usuario', response);
      this.userCompanyAdminCompany = response.dato;
      // this.empresas = response.datos;
    } catch (e) {
      console.log('Hubo un error al obtener las empresas', e);
    }
  }

  creaEmpresa() {
    return this.formBuilder.group({
      nombre: ['', Validators.required],
      descripcion: ['', Validators.required]
    });
  }

  editarEmpresa() {
    return this.formBuilder.group({
      nombre: ['', Validators.required],
      descripcion: ['', Validators.required]
    });
  }

  goBackButton() {
    this.router.navigate(['administracion']);
  }

  filtro(param, descending) {

  }


  guardarEmpresa(modal) {

    this.companyForm.value['habilitado'] = true;
    console.log(this.companyForm.value);
    this._apiRestService.nuevaEmpresa(this.companyForm.value).then((response) => {
      if (response.ok) {
        this.companyForm.reset();
        this.getTotalEmpresas('idempresa', 'true');
        modal.close('Exito');
      } else {
        modal.close();
      }
    }, (error) => {
      modal.close('Error');
    });
  }

  guardarEdicionEmpresa(modal) {
    const empresa = {
      nombre: this.editCompanyForm.get('nombre').value,
      descripcion: this.editCompanyForm.get('descripcion').value
    };
    console.log('las empresa es: ', empresa);
    console.log('las id de la empresa es: ', this.companyIdToEdit);

    this._apiRestService.editarEmpresa(this.companyIdToEdit, empresa).then((response) => {
      if (response.ok) {
        this.getTotalEmpresas('updatedAt', 'true');
        modal.close('Exito');
      } else {
        modal.close();
      }
    }, (error) => {
      modal.close('Error');
    });
  }

  abrirModal(modal) {
    console.log(modal);
    this.modalService.open(modal)
      .result.then((result) => {
        console.log('Cerrada con exito');
      }, (reason) => {
        console.log('Cerrada por ' + reason);
      });
  }

  async abrirModalEditarEmpresa(modal, id, nombre, descripcion) {
    console.log('Id de la empresa: ', id);
    this.editCompanyForm.setValue({ nombre: nombre, descripcion: descripcion});
    this.companyIdToEdit = id;
    this.secondModalService.open(modal)
      .result.then((result) => {
        console.log('Cerrada con exito');
      }, (reason) => {
        console.log('Cerrada por ' + reason);
      });
  }

  irAusuarios(idempresa) {
    this.router.navigateByUrl('/adminusuarios', {state: {idempresa: idempresa}});
  }

  abrirModalDeshabilitar(idempresa, nombre, habilitado, modal) {
    this.companyToDisable = {
      idempresa,
      nombre,
      habilitado
    };
    this.modalService.open(modal);
  }

  async cambiarEstadoEmpresa(modal) {
    try {
      const response = await this._apiRestService.cambiarEstadoEmpresa(this.companyToDisable.idempresa);
      if (response.ok) {
        this.getTotalEmpresas('habilitado', 'true');
        modal.close();
      }
  } catch (e) {
    console.log('Error al cambiar de estado', e);
    modal.close();
    }
  }
}
