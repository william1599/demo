import { Location } from "@angular/common";
import { HttpEventType } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { Form, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { Observable } from "rxjs";
import { catchError } from "rxjs/operators";
import { User } from "src/app/models/user";
import { ApiRestService } from "src/app/services/api-rest.service";
import { AuthenticationService } from "src/app/services/authentication.service";
import { MessageService } from "src/app/services/messages.service";
import * as XLSX from 'xlsx';

const MAX_FILE_SIZE = 10*1024*1024;

@Component({
  selector: 'app-administracion-equipos',
  templateUrl: './administracion-equipos.component.html',
  styleUrls: ['./administracion-equipos.component.css']
})

export class AdministracionEquiposComponent implements OnInit {

  Object = Object;
  usuario: User;
  equipos: Array<any>;
  formCrearEquipo: FormGroup;
  formEditaEquipo: FormGroup;
  uploadForm: FormGroup;
  parametrosForm: FormGroup;
  acceptFiles:Array<string>;
  parametrosInForm = null;
  data: any;
  page = 1;
  pageSize = 8;
  equipoAEditar: Number;
  equipoCambiaEstado: any;
  equipoEditado: Number;
  mostrarDatos: Boolean;
  fileInForm: Boolean;
  textoEnBotonPreVisualizar: any;
  lineasDeProduccion: any;
  idLineaDeProduccion: string;
  idFiltroLineaProduccion: any;
  idFiltroEmpresa: any;
  filtros: any;
  empresas: any;
  showUploadEquipment: any = false;
  showText: any = false;

  constructor(
    private _route: ActivatedRoute,
    private _apiRestService: ApiRestService,
    private _authenticationService: AuthenticationService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private _messagesService: MessageService,
    private router: Router,
    private location: Location
  ) {}


  ngOnInit(): void {
    this.filtros = {
      'idEquipoDesc': false,
      'idPropioDesc': false,
      'nombreDesc': false,
      'descripcionDesc': false,
      'tipoDesc': false,
      'empresaDesc': false,
      'lineaProduccionDesc': false,
      'creacionDesc': false,
      'estadoDesc': false
    }
    this.idLineaDeProduccion = this._route.snapshot.paramMap.get('idequipo')
    this.uploadForm = this.formBuilder.group({
      idlineaproduccion: ['', Validators.required],
      archivo_equipos: ['']
    });

    this.acceptFiles = [
      //"text/csv",
      //".csv",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/vnd.ms-excel.sheet.binary.macroEnabled.12",
      //"application/vnd.ms-excel",//csv
      "application/vnd.ms-excel.sheet.macroEnabled.12"];

    this.usuario = this._authenticationService.currentUserValue;
    this.mostrarDatos = false;
    this.fileInForm = false;
    this.textoEnBotonPreVisualizar = 'Previsualizar datos';
    this.getLineasProduccion();
    this.getEmpresas('idempresa', 'true');
    //this.formCrearEquipo = this.formCreaEquipo();
    this.formEditaEquipo = this.formEditarEquipo();
    if(this.idLineaDeProduccion != 'todos') {
      this.getEquiposPorLineaDeProduccion(this.idLineaDeProduccion);
    } else {
      this.getEquipos('idequipo', 'true');
    }
  }

  previusNavigate() {
    this.location.back();
  }

  abrirModalNuevoEquipo(modal) {
    this.modalService.open(modal)
    if(this.equipos[0]) {
      console.log(this.equipos[0])
      let p2 = this.Object.assign({}, this.equipos[0].parametros)
      let parametrosVacios = this.setAll(p2, '');
      this.parametrosInForm = parametrosVacios;
      console.log("parametorsinForm: ", this.parametrosInForm);
      this.formCrearEquipo = this.formBuilder.group(parametrosVacios);
      this.formCrearEquipo.addControl('nombre', new FormControl('', Validators.required));
      this.formCrearEquipo.addControl('descripcion', new FormControl('', Validators.required));
      this.formCrearEquipo.addControl('tipo', new FormControl('', Validators.required));
      this.formCrearEquipo.addControl('idlineaproduccion', new FormControl('', Validators.required));
    }
  }

  formCreaEquipo(parametros) {
    return this.formBuilder.group({
      nombre: ['', Validators.required],
      tipo: ['', Validators.required],
      descripcion: ['', Validators.required],
      parametros
    })
  }

  formEditarEquipo() {
    return this.formBuilder.group({
      nombre: ['', Validators.required],
      tipo: ['', Validators.required],
      descripcion: ['', Validators.required]
    })
  }

  async getEquipos(param, descending) {
    try {
      let response = await this._apiRestService.getEquipos(param, descending);
      this.equipos = response.datos;
      console.log("Equipos: ", this.equipos)
    } catch(e) {
      console.log("Error al obtener lineas de produccion", e)
    }
  }

  async getEmpresas(param, descending) {
    try {
      let response = await this._apiRestService.getEmpresas(param, descending);
      this.empresas = response.datos;
    } catch(e) {
      console.log("Error al obtener empresas", e)
    }
  }

  async getEquiposPorLineaDeProduccion(idlineaproduccion) {
    try {
      let response = await this._apiRestService.getEquiposPorLineaProduccion(idlineaproduccion, 'idequipo', 'true');
      this.equipos = response.datos;
      console.log("EQUIPOS: ", this.equipos)
    } catch(e) {
      console.log("Error al obtener equipos", e)
    }
  }

  async getEquipmentByLine(idlineaproduccion) {
    try {
      let response = await this._apiRestService.getEquiposPorLineaProduccion(idlineaproduccion, 'idequipo', 'true');
      return response.datos; 
    } catch (err) {
      console.log("Error al obtener equipos");
    }
  }

  async getEquiposPorEmpresa(param, descending) {
    try {
      let response = await this._apiRestService.getEquiposPorEmpresa(this.idFiltroEmpresa, param, descending)
      this.equipos = response.datos;
    } catch(e) {
      console.log("Error al obtener equipos", e)
    }
  }

  async getLineasProduccion() {
    try {
      let response = await this._apiRestService.getLineasProduccion('nombre', 'true', null);
      this.lineasDeProduccion = response.datos;
      console.log(this.lineasDeProduccion);
    } catch(e) {
      console.log("Error al obtener lineas de produccion", e);
    }
  }

  async onFileSelect(event) {

    console.log(event);
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      console.log("Name: "+file.name);
      console.log("Type: "+file.type);
      console.log("Size: "+file.size);
      if(!this.acceptFiles.includes(file.type)){
        this._messagesService.error("Tipo de archivo no es válido");
        console.log(event.target.name);
        //this.uploadForm.get(event.target.name).reset();
        event.target.value = null;
        return;
      }
      else if(file.size >= MAX_FILE_SIZE){
        this._messagesService.error("Tamaño de archivo no puede superar los "+(MAX_FILE_SIZE/1024/1024)+" megas");
        console.log(event.target.name);
        //this.uploadForm.get(event.target.name).reset();
        event.target.value = null;
        return;
      }
      else{
        this.uploadForm.get(event.target.name).setValue(file);
      }
    }
  }

  async submitArchivo(modal) {

    let tmp = this.uploadForm.get('archivo_equipos').value;
    let lineaDeProduccion = this.uploadForm.get('idlineaproduccion').value;
    console.log("El archivo es: ", tmp)

    for(let campo in tmp) {
      console.log(campo)
    }

    console.log("Voy a ejecutar el llamado")
    this._apiRestService.subirArchivoEquipos(tmp, lineaDeProduccion).subscribe(resp => {
      console.log("La respuesta es: ", resp);
      this.getEquipos('idequipo', 'true');
      modal.close();
      this._messagesService.success('Carga realizada correctamente');
    }, error => {
      console.log("Error: ", error)
      this._messagesService.error('Hubo un error al subir equipos')
    });

  }

  onFileChange(evt: any) {
    /* wire up file reader */
    const file = evt.target.files[0];
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      this.data = <XLSX.AOA2SheetOpts>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
      console.log(this.data);
    };
    reader.readAsBinaryString(target.files[0]);
    this.uploadForm.get(evt.target.name).setValue(file)
    this.fileInForm = true;
  }

  botonPreVisualizar() {
    this.mostrarDatos = !this.mostrarDatos;
    this.mostrarDatos ? this.textoEnBotonPreVisualizar = 'Cerrar previsualización' : this.textoEnBotonPreVisualizar = 'Previsualizar datos'


  }

  cambioFiltroLineaProduccion(nuevoValor) {
    if(nuevoValor != -3) {
      this.idLineaDeProduccion = nuevoValor;
      this.getEquiposPorLineaDeProduccion(nuevoValor);
    } else {
      this.getEquipos('idequipo', 'true');
    }
  }

  cambioFiltroEmpresa(nuevoValor) {
    if(nuevoValor != -3) {
      this.idFiltroEmpresa = nuevoValor;
      this.getEquiposPorEmpresa('idequipo', true);
    } else {
      this.getEquipos('idequipo', 'true');
    }
  }

  async abrirModalParametros(modal, parametros, idequipo) {
    //console.log(parametros)
    this.equipoAEditar = idequipo;
    this.parametrosInForm = parametros;
    let p2 = this.Object.assign({}, parametros)
    console.log("Ignorado en 3")
    console.log(this.parametrosInForm)

    for(let key of Object.keys(this.parametrosInForm)) {
      console.log("La llave es: ", key)
    }

    this.parametrosForm = this.formBuilder.group(parametros);
    let parametrosVacios = this.setAll(p2, '');
    this.formCrearEquipo = this.formBuilder.group(parametrosVacios);
    this.formCrearEquipo.addControl('nombre', new FormControl('', Validators.required));
    this.formCrearEquipo.addControl('descripcion', new FormControl('', Validators.required));
    this.formCrearEquipo.addControl('tipo', new FormControl('', Validators.required));
    this.modalService.open(modal)
    console.log(this.parametrosForm.value)


  }

  setAll(obj, val) {
    Object.keys(obj).forEach(function(index) {
        obj[index] = val
    });

    return obj;
}

  abrirModalConfirmacion(modal, nombre, idequipo, habilitado) {
    this.equipoCambiaEstado = {
      idequipo,
      nombre,
      habilitado
    }

    this.modalService.open(modal)
  }

  abrirModalEditarEquipo(modal, nombre, tipo, descripcion, idequipo) {
    this.equipoEditado = idequipo;
    this.formEditaEquipo.setValue({ nombre, tipo, descripcion })
    this.modalService.open(modal);
  }

  async cambiarEstadoEquipo(modal, idequipo) {
    try {
       let response = await this._apiRestService.cambiarEstadoEquipo(idequipo);
       if(response.ok) {
         this.getEquipos('idequipo', 'true');
         this._messagesService.success(response.message)
         modal.close('Exito')
       }
       console.log(response)
    } catch(e) {
      this._messagesService.alert(e);
      modal.close();
    }
  }


  async submitEdicionParametros(modal) {
    console.log("El ID del equipo es: ", this.equipoAEditar);
    console.log("Los parametros son: ", this.parametrosForm.value);
    try {
      let response = await this._apiRestService.editarParametrosEquipo(this.equipoAEditar, this.parametrosForm.value);
      if(response.ok) {
        this.getEquipos('idequipo', 'true');
        modal.close('Exito');
        this._messagesService.success(`Parametros del equipo con ID ${this.equipoAEditar} editados correctamente`);
        console.log("Respuesta: ", response)
      } else {
        modal.close();
      }
    } catch(e) {
      console.log("Hubo un error", e);
      modal.close();
    }
  }

  async guardarEquipo(modal) {
    console.log(this.formCrearEquipo.value)
    console.log(this.parametrosInForm);
    // const formCrearEquipoTmp = this.formCrearEquipo.value;
    let formCrearEquipoTmp = { ...this.formCrearEquipo.value };
    delete formCrearEquipoTmp.nombre;
    delete formCrearEquipoTmp.descripcion;
    delete formCrearEquipoTmp.tipo;
    delete formCrearEquipoTmp.idlineaproduccion;
    const finalBody = {};
    finalBody['nombreQm'] = this.formCrearEquipo.value.nombre;
    finalBody['descripcionQm'] = this.formCrearEquipo.value.descripcion;
    finalBody['tipoQm'] = this.formCrearEquipo.value.tipo;
    finalBody['idlineaproduccion'] = this.formCrearEquipo.value.idlineaproduccion;
    finalBody['parameters'] = formCrearEquipoTmp;

    console.log('finalBODY: ', finalBody);
    try {
      const response = await this._apiRestService.crearEquipo(finalBody);
      this._messagesService.success('Equipo guardado correctamente');
    } catch (err) {
      this._messagesService.error("Error al guardar equipo");
    }
    modal.close();
    this.getEquipos('idequipo', 'true');
  } 

  async editarEquipo(modal) {
    let response = await this._apiRestService.editarEquipo(this.equipoEditado, this.formEditaEquipo.value);
    if(response.ok) {
      this.getEquipos('idequipo', 'true');
      modal.close();
      this._messagesService.success(`Equipo con ID ${this.equipoEditado} editado correctamente`);
    } else {
      modal.close();
    }
  }

  async lineChanged(value) {
    console.log("Value: ", value);
    this.parametrosInForm = null;
    const resp = await this.getEquipmentByLine(value);
    console.log("resp: ", resp);
    if(resp.length != 0) {
      let p2 = this.Object.assign({}, resp[0].parametros);
      let parametrosVacios = this.setAll(p2, '');
      this.parametrosInForm = parametrosVacios;
      console.log("parametorsinForm: ", this.parametrosInForm);
      this.formCrearEquipo = this.formBuilder.group(parametrosVacios);
      this.formCrearEquipo.addControl('nombre', new FormControl('', Validators.required));
      this.formCrearEquipo.addControl('descripcion', new FormControl('', Validators.required));
      this.formCrearEquipo.addControl('tipo', new FormControl('', Validators.required));
      this.formCrearEquipo.addControl('idlineaproduccion', new FormControl(value, Validators.required));
      this.showUploadEquipment = true;
      this.showText =  false;
    } else {
      console.log("Salte al else");
      this.showUploadEquipment = false;
      this.showText = true;
    }
  }

}
