import { Location } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { User } from "src/app/models/user";
import { ApiRestService } from "src/app/services/api-rest.service";
import { AuthenticationService } from "src/app/services/authentication.service";
import { RouterExtService } from "src/app/services/router-ext-service";

@Component({
  selector: 'app-administracion-lineas-produccion',
  templateUrl: './administracion-lineas-produccion.component.html',
  styleUrls: ['./administracion-lineas-produccion.component.css']
})

export class AdministracionLineasProduccionComponent implements OnInit {

  usuario: User;
  lineasDeProduccion: Array<any>;
  formCrearLineaProduccion: FormGroup;
  formEditaLineaProduccion: FormGroup;
  idLineaProduccion: Number;
  page = 1;
  pageSize = 5;
  empresas: any;
  lineaDeProduccionCambiaEstado: any;
  idNavegacion: any;
  idEmpresa: any;
  descFilter = {
    idDescending: false,
    nameDescending: false,
    codeDesc: false,
    descriptionDesc: false,
    typeDesc: false,
    companyDesc: false,
    createdAtDesc: false,
    enabledDesc: false
  }


  constructor(
    private _route: ActivatedRoute,
    private _apiRestService: ApiRestService,
    private _authenticationService: AuthenticationService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private location: Location,
    private routerExtService: RouterExtService
  ) {}

    ngOnInit(): void {
      console.log(this.routerExtService.getPreviousUrl());
      this.idNavegacion = this._route.snapshot.paramMap.get('idlineaproduccion')
      this.usuario = this._authenticationService.currentUserValue;
      this.idEmpresa = this._route.snapshot.paramMap.get('idlineaproduccion');
      this.formCrearLineaProduccion = this.formCreaLineaProduccion();
      this.formEditaLineaProduccion = this.formEditarLineaProduccion();
      this.getEmpresas();
      if(this.idEmpresa != 'todos') {
        console.log(this.idEmpresa)
        this.getLineasPorEmpresa('idlineaproduccion', 'true');
      }
      else if(this.idNavegacion != 'todos') {
        this.getLineaProduccionPorId()
      } else {
        this.getLineasProduccion('idlineaproduccion', 'true');
      }
    }

    previusNavigate() {
      this.location.back();
    }

    async getLineasProduccion(param, descending, companyId = null) {
      try {
        let response = await this._apiRestService.getLineasProduccion(param, descending, companyId);
        this.lineasDeProduccion = response.datos
        console.log("Las lineas de produccion son: ", this.lineasDeProduccion)
      } catch(e) {
        console.log("Error al obtener lineas de produccion", e)
      }
    }

    async getLineaProduccionPorId() {
      try {
        let response = await this._apiRestService.getLineaPorId(this.idNavegacion);
        this.lineasDeProduccion = [response.dato];
        console.log(response)
        console.log("Linea de produccion es: ", this.lineasDeProduccion)
      } catch(e) {
        console.log("Error al obtener linea de produccion", e)
      }
    }

    async getLineasPorEmpresa(param, descending) {
      try {
        let response = await this._apiRestService.getLineasPorEmpresa(param, descending, this.idEmpresa);
        this.lineasDeProduccion = response.datos;
        console.log(response)
        console.log("Linea de produccion es: ", this.lineasDeProduccion)
      } catch(e) {
        console.log("Error al obtener linea de produccion", e)
      }
    }

    formCreaLineaProduccion() {
      return this.formBuilder.group({
        nombre: ['', Validators.required],
        tipo: ['', Validators.required],
        descripcion: ['', Validators.required],
        idempresa: ['', Validators.required],
        codigo: ['', Validators.required]
      })
    }

    formEditarLineaProduccion() {
      return this.formBuilder.group({
        nombre: ['', Validators.required],
        tipo: ['', Validators.required],
        descripcion: ['', Validators.required],
        codigo: ['', Validators.required]
      })
    }

    abrirModalNuevaLineaProduccion(modal) {
      this.modalService.open(modal)
    }

    async guardarLineaProduccion(modal) {
      console.log("guardarLineaProduccion: ", this.formCrearLineaProduccion.value)
      try {
        let response = await this._apiRestService.crearLineaProduccion(this.formCrearLineaProduccion.value);
        if(response.ok) {
          this.formCrearLineaProduccion.reset();
          this.getLineasProduccion('idlineaproduccion', 'true');
          modal.close("Exito")
        } else {
          modal.close();
        }
      } catch(e) {
        console.log("Error al guardar linea de produccion", e)
      }
    }

    async getEmpresas() {
      try {
        let response = await this._apiRestService.getEmpresasHabilitadas('idempresa', true, null);
        console.log("Empresas: ", response.datos)
        this.empresas = response.datos;
        console.log(this.empresas)
      } catch(e) {
        console.log('Hubo un error al obtener las empresas', e)
      }
    }

    abrirModalEditarLineaProduccion(modal, nombre, descripcion, tipo, idlineaproduccion, codigo) {
      console.log("AAAAAAAAAAAAAA")
      console.log("id es: ", idlineaproduccion)
      this.modalService.open(modal)
      this.formEditaLineaProduccion.setValue({ nombre, tipo, descripcion, codigo })
      this.idLineaProduccion = idlineaproduccion;
    }

    async editarLineaProduccion(modal) {
      try {
        console.log(this.idLineaProduccion)
        console.log(this.formEditaLineaProduccion.value)
        let response = await this._apiRestService.editarLineaProduccion(this.idLineaProduccion, this.formEditaLineaProduccion.value);
        if(response.ok) {
          this.getLineasProduccion('idlineaproduccion', 'true');
          modal.close("Exito")
        } else {
          modal.close();
        }
      } catch(e) {
        modal.close()
        console.log("Error al editar linea de produccion", e)
      }
    }

    abrirModalCambioEstado(modal, nombre, idlineaproduccion, habilitado) {
      this.lineaDeProduccionCambiaEstado = {
        idlineaproduccion,
        nombre,
        habilitado
      };

      this.modalService.open(modal);
    }

    async cambiarEstadoLineaProduccion(modal) {
      let response = await this._apiRestService.cambiarEstadoLineaProduccion(this.lineaDeProduccionCambiaEstado.idlineaproduccion);
      if(response.ok) {
        this.getLineasProduccion('idlineaproduccion', 'true');
        modal.close();
      } else {
        modal.close();
      }
    }

    cambioFiltroEmpresa(value) {
      if(value == -3) {
        this.getLineasProduccion('idlineaproduccion', true)
      } else {
        this.getLineasProduccion('idlineaproduccion', true, value)
      }
      console.log(value)
    }

}

