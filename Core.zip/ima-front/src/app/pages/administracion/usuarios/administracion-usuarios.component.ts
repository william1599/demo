import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { User } from "src/app/models/user";
import { ApiRestService } from "src/app/services/api-rest.service";
import { AuthenticationService } from "src/app/services/authentication.service";


@Component({
  selector: 'app-administracion-usuarios',
  templateUrl: './administracion-usuarios.component.html',
  styleUrls: ['./administracion-usuarios.component.css']
})

export class AdministracionUsuariosComponent implements OnInit {

  users: Array<any>;
  empresas: Array<any>;
  usuario: User;
  formNuevoUsuario: FormGroup;
  formEditarUsuario: FormGroup;
  idusuario: Number;
  idempresaFiltro: any;
  link: any;
  usuarioADeshabilitar: any;
  idusuarioDesc: boolean;
  emailDesc: boolean;
  nombresDesc: boolean;
  apellidosDesc: boolean;
  empresaDesc: boolean;
  rolDesc: boolean;
  estadoDesc: boolean;
  page = 1;
  pageSize = 5;
  rolesOptions: any;
  fieldTextType: Boolean;
  tipoTexto: Boolean;
  todasLasEmpresas: any;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private modalService: NgbModal,
    private _apiRestService: ApiRestService,
    private _authenticationService: AuthenticationService
  ) {
    console.log(this.router.getCurrentNavigation().extras.state)
    if(this.router.getCurrentNavigation().extras.state) {
      this.idempresaFiltro = this.router.getCurrentNavigation().extras.state.idempresa
      this.link = ['/adminempresas']
    } else {
      this.idempresaFiltro = null;
      this.link = ['/administracion']
    }
  }

  ngOnInit(): void {
    this.fieldTextType = false;
    this.tipoTexto = false;
    this.idusuarioDesc = false;
    this.emailDesc = false;
    this.apellidosDesc = false;
    this.empresaDesc = false;
    this.rolDesc = false;
    this.estadoDesc = false;
    //this.idempresaFiltro = null;
    this.usuario = this._authenticationService.currentUserValue;
    this.colocarOpcionesRoles();
    this.formNuevoUsuario = this.creaUsuario();
    this.formEditarUsuario = this.editaUsuario();
    this.getUsuarios(this.idempresaFiltro, 'idusuario', 'true');
    this.getTodasLasEmpresas();
    this.getEmpresas();
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  toggleVerPass() {
    this.tipoTexto = !this.tipoTexto;
  }

  colocarOpcionesRoles() {
    if (this.usuario.rol === 'ADMIN') {
      this.rolesOptions = [
        { value: 'ADMIN', label: 'Administrador del sistema' },
        { value: 'ADMIN-EMPRESA', label: 'Administrador de empresa' },
        { value: 'ING-PLANTA', label: 'Ingeniero de planta' },
        { value: 'ING-DATOS', label: 'Ingeniero de datos' }
      ];
    } else {
      this.rolesOptions = [
        { value: 'ADMIN-EMPRESA', label: 'Administrador de empresa' },
        { value: 'ING-PLANTA', label: 'Ingeniero de planta' },
        { value: 'ING-DATOS', label: 'Ingeniero de datos' }
      ];
    }
  }

  creaUsuario() {
    return this.formBuilder.group({
      nombres: ['', Validators.required],
      apellidos: ['', Validators.required],
      email: ['', Validators.required],
      rol: ['', Validators.required],
      idempresa: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  editaUsuario() {
    return this.formBuilder.group({
      nombres: ['', Validators.required],
      apellidos: ['', Validators.required],
      email: ['', Validators.required],
      rol: ['', Validators.required],
      idempresa: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  async getUsuarios(idempresa, param, descending) {
    try {
      if (this.usuario.rol === 'ADMIN-EMPRESA') {
        const response = await this._apiRestService.getUsuarios(this.usuario.idempresa, param, descending);
        this.users = response.datos;
        console.log(this.users);
      } else if (idempresa) {
        const response = await this._apiRestService.getUsuarios(idempresa, param, descending);
        this.users = response.datos;
        console.log(this.users);
      } else {
        const response = await this._apiRestService.getUsuarios(null, param, descending);
        this.users = response.datos;
        console.log(this.users);
      }
    } catch(e) {
      console.log('Hubo un error al obtener usuarios', e)
    }
  }

  async getEmpresas() {
    try {
      const response = await this._apiRestService.getEmpresasHabilitadas('idempresa', true, false);
      console.log(response.datos);
      this.empresas = response.datos;
      console.log(this.empresas);
    } catch (e) {
      console.log('Hubo un error al obtener las empresas', e);
    }
  }

  async getTodasLasEmpresas() {
    try {
      const response = await this._apiRestService.getEmpresas('idempresa', 'true');
      this.todasLasEmpresas = response.datos;
      console.log('Todas las empresas', this.todasLasEmpresas);
    } catch(e) {
      console.log('Error al obtener empresas habilitadas', e);
    }
  }

  abrirModalNuevoUsuario(modal) {
    this.modalService.open(modal);
  }

  abrirModalEditarUsuario(modal, nombres, apellidos, idempresa, rol, email, idusuario) {
    this.formEditarUsuario.setValue({ nombres, apellidos, idempresa, rol, email, password: null });
    console.log(this.formEditarUsuario.value);
    this.idusuario = idusuario;
    this.modalService.open(modal);
  }

  async guardarUsuario(modal) {
    if (this.usuario.rol === 'ADMIN-EMPRESA') {
      this.formNuevoUsuario.controls['idempresa'].setValue(this.usuario.idempresa);
    }
    console.log(this.formNuevoUsuario.value)
    try {
      const response = await this._apiRestService.nuevoUsuario(this.formNuevoUsuario.value)
      if (response.ok) {
        this.formNuevoUsuario.reset();
        await this.getUsuarios(this.idempresaFiltro, 'idusuario', 'true');
        modal.close("Exito");
      } else {
        modal.close();
      }
    } catch(e) {
      console.log("Error al guardar usuario")
    }

  }

  cambioFiltroEmpresa(nuevoValor) {
    if (nuevoValor != -3) {
      this.idempresaFiltro = nuevoValor;
      this.getUsuarios(this.idempresaFiltro, 'idusuario', 'true');
    } else {
      this.idempresaFiltro = null;
      this.getUsuarios(this.idempresaFiltro, 'idusuario', 'true');
    }
  }

  async guardarEdicionUsuario(modal) {
    console.log('Id del usuario', this.idusuario);
    console.log(this.formEditarUsuario.value);

    try {
      const response = await this._apiRestService.editarUsuario(this.idusuario, this.formEditarUsuario.value);
      if (response.ok) {
        this.getUsuarios(this.idempresaFiltro, 'idusuario', 'true');
        modal.close('Exito');
      } else {
        modal.close();
      }
    } catch (e) {
      modal.close();
      console.log('Error al editar usuario', e);
    }
  }

  async deshabilitarUsuario(modal) {
    try {
      const response = await this._apiRestService.cambiarEstadoUsuario(this.usuarioADeshabilitar.id);
      console.log('Entre');
      if (response.ok) {
        this.getUsuarios(this.idempresaFiltro, 'idusuario', 'true');
        modal.close('Exito');
      } else {
        modal.close();
      }
    } catch (e) {
      console.log('Error al cambiar estado del usuario', e);
      modal.close();
    }

  }

  abrirModalConfirmacion(modal, id, usuarioNombre, usuarioEmail, habilitado) {
    this.usuarioADeshabilitar = {
      id: '',
      nombres: '',
      email: '',
      habilitado
    };
    this.usuarioADeshabilitar.id = id;
    this.usuarioADeshabilitar.nombres = usuarioNombre;
    this.usuarioADeshabilitar.email = usuarioEmail;
    this.modalService.open(modal);
  }
}
