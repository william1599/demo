import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { MiddlebarComponent } from 'src/app/components/middlebar/middlebar.component';
import { MainLayoutRoutes } from './main-layout.routing';
import { ListaModelosComponent } from '../../pages/training/listamodelos.component';
import { ListaConfiguracionesComponent } from '../../pages/architectures/architecture-list/listaconfig.component';
import { NuevaArquitecturaComponent } from '../../pages/architectures/new-architecture/nuevaarquitectura.component';
import { ModelosService } from 'src/app/services/modelos.service';
import { ResultadosService } from 'src/app/services/log-resultados.service';
import { ForecastsService } from 'src/app/pages/forecasts/services/forecasts.service';
import { ListaColeccionesComponent } from 'src/app/pages/colecciones/lista-colecciones.component';
import { ListaServiciosComponent } from 'src/app/pages/configuracion/lista-servicios.component';
import { NuevaEmpresaComponent } from 'src/app/pages/configuracion/nueva-empresa.component';
import { NuevoModuloComponent } from 'src/app/pages/configuracion/nuevo-modulo.component';
import { NuevoRodilloComponent } from 'src/app/pages/configuracion/nuevo-rodillo.component';
import { ConfiguracionComponent } from 'src/app/pages/configuracion/configuracion.component';
import { ListaEmpresaComponent } from 'src/app/pages/empresas/lista-empresas.component';
import { ListaForecastsComponent } from 'src/app/pages/forecasts/forecasts-list/forecasts-list.component';
import { EmpresasComponent } from 'src/app/pages/administracion/empresas/empresas.component';
import { AdministracionUsuariosComponent } from 'src/app/pages/administracion/usuarios/administracion-usuarios.component';
import { AdministracionComponent } from 'src/app/pages/administracion/administracion.component';
import { PaginaBaseAdminComponent } from 'src/app/pages/base/pagina-base-admin.component';
import { PaginaBaseOPeracionComponent } from 'src/app/pages/base/pagina-base-operacion.component';
import { AdministracionServiciosComponent } from 'src/app/pages/administracion/servicios/administracion-servicios.component';
import { AdministracionLineasProduccionComponent } from 'src/app/pages/administracion/lineas-produccion/administracion-lineas-produccion.component';
import { AdministracionEquiposComponent } from 'src/app/pages/administracion/equipos/administracion-equipos.component';
import { DynamicFormPredictionComponent } from 'src/app/pages/forecasts/forecasts-quality-create/forecasts-create-form-prediction.component';
import { DynamicFormComponent } from 'src/app/pages/forecasts/forecasts-quality-create/forecasts-create-dynamic-form.component';
import { FormComponent } from 'src/app/pages/forecasts/forecasts-quality-create/forecasts-create-display-form.component';
import { PredictionConfigComponent } from 'src/app/pages/training/prediction-config/predictionconfig.component';
import { LoaderComponent } from 'src/app/pages/forecasts/forecasts-list/loader.component';
import { NgChartjsModule } from 'ng-chartjs';
import { ForecastResultsComponent } from '../../pages/forecasts/forecasts-list/forecast-results/forecast-results.component';
import { OptimizerComponent } from "../../pages/optimizer/optimizer.component";
import { OptimizerCreateComponent } from "../../pages/optimizer/optimizer-create/optimizer-create.component";
//import { NgChartjsModule } from 'ng2-charts';
import { DatePipe, DecimalPipe } from '@angular/common';
import { KeysPipe } from 'src/app/pages/colecciones/keys.pipe';
import { ETLComponent } from 'src/app/pages/colecciones/etls/etl-colecciones.component';
import { ForecastsRecordChartComponent } from '../../pages/forecasts/forecasts-record-chart/forecasts-record-chart.component';
import {RecordChartService} from "../../pages/forecasts/services/record-chart.service";
import {ForecastCycleService} from "../../pages/forecasts/services/forecasts-cycles.service";
import { ForecastsErrorComponent } from '../../pages/forecasts/forecasts-list/forecasts-error/forecasts-error.component';
import {PredictionConfigCreateComponent} from "../../pages/training/prediction-config/prediction-config-create/prediction-config-create";
import {PredictionConfigEditComponent} from "../../pages/training/prediction-config/prediction-config-edit/prediction-config-edit.component";
import {PredictionConfigOptionsComponent} from "../../pages/training/prediction-config/prediction-config-options/prediction-config-options.component";
import {ForecastsDeleteComponent} from "../../pages/forecasts/forecasts-delete/forecasts-delete.component";
import {OptimizerListComponent} from "../../pages/optimizer/optimizer-list/optimizer-list.component";
import { ForecastOptimizerComponent } from 'src/app/pages/forecasts/forecasts-optimizer/forecasts-optimizer.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(MainLayoutRoutes),
    ReactiveFormsModule,
    NgbModule,
    NgChartjsModule,
    FormsModule
  ],
  declarations: [
    MiddlebarComponent,
    ListaModelosComponent,
    ListaConfiguracionesComponent,
    NuevaArquitecturaComponent,
    ListaColeccionesComponent,
    ListaServiciosComponent,
    NuevaEmpresaComponent,
    ConfiguracionComponent,
    ListaEmpresaComponent,
    ListaForecastsComponent,
    NuevoModuloComponent,
    NuevoRodilloComponent,
    EmpresasComponent,
    AdministracionUsuariosComponent,
    AdministracionComponent,
    AdministracionServiciosComponent,
    PaginaBaseAdminComponent,
    AdministracionLineasProduccionComponent,
    PredictionConfigComponent,
    AdministracionEquiposComponent,
    PaginaBaseOPeracionComponent,
    DynamicFormPredictionComponent,
    DynamicFormComponent,
    ForecastsRecordChartComponent,
    PredictionConfigCreateComponent,
    PredictionConfigEditComponent,
    PredictionConfigOptionsComponent,
    ForecastResultsComponent,
    ForecastsErrorComponent,
    ForecastsDeleteComponent,
    FormComponent,
    ETLComponent,
    LoaderComponent,
    OptimizerComponent,
    OptimizerCreateComponent,
    OptimizerListComponent,
    ForecastOptimizerComponent,
    KeysPipe,
  ],
  providers : [ForecastsService, ResultadosService, ModelosService, DatePipe, DecimalPipe, RecordChartService, ForecastCycleService]
})

export class MainLayoutModule {}
