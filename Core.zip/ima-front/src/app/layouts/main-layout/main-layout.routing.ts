import { Routes } from '@angular/router';

import { ListaModelosComponent } from '../../pages/training/listamodelos.component';
import { NuevaArquitecturaComponent } from '../../pages/architectures/new-architecture/nuevaarquitectura.component';
import { ListaConfiguracionesComponent } from '../../pages/architectures/architecture-list/listaconfig.component';
import { ListaColeccionesComponent } from 'src/app/pages/colecciones/lista-colecciones.component';
import { ListaServiciosComponent } from 'src/app/pages/configuracion/lista-servicios.component';
import { ConfiguracionComponent } from 'src/app/pages/configuracion/configuracion.component';
import { ListaEmpresaComponent } from 'src/app/pages/empresas/lista-empresas.component';
import { ListaForecastsComponent } from 'src/app/pages/forecasts/forecasts-list/forecasts-list.component';
import { AdministracionComponent } from 'src/app/pages/administracion/administracion.component';
import { EmpresasComponent } from 'src/app/pages/administracion/empresas/empresas.component';
import { AdministracionUsuariosComponent } from 'src/app/pages/administracion/usuarios/administracion-usuarios.component';
import { PaginaBaseAdminComponent } from 'src/app/pages/base/pagina-base-admin.component';
import { AdministracionServiciosComponent } from 'src/app/pages/administracion/servicios/administracion-servicios.component';
import { AdministracionLineasProduccionComponent } from 'src/app/pages/administracion/lineas-produccion/administracion-lineas-produccion.component';
import { AdministracionEquiposComponent } from 'src/app/pages/administracion/equipos/administracion-equipos.component';
import { PaginaBaseOPeracionComponent } from 'src/app/pages/base/pagina-base-operacion.component';
import { PredictionConfigComponent } from 'src/app/pages/training/prediction-config/predictionconfig.component';
import { ETLComponent } from 'src/app/pages/colecciones/etls/etl-colecciones.component';
import { OptimizerComponent } from 'src/app/pages/optimizer/optimizer.component';
import { OptimizerCreateComponent } from "../../pages/optimizer/optimizer-create/optimizer-create.component";

export const MainLayoutRoutes: Routes = [
    { path: 'servicios', component: ListaServiciosComponent },
    { path: 'servicio/:idservicio/entrenar', component: ListaModelosComponent },
    { path: 'servicio/:idservicio/entrenar/configuracion', component: ListaConfiguracionesComponent },
    { path: 'servicio/:idservicio/entrenar/configuracion/nueva', component: NuevaArquitecturaComponent },
    { path: 'servicio/:idservicio/importar', component: ListaColeccionesComponent },
    { path: 'servicio/:idservicio/predecir', component: ListaForecastsComponent },
    { path: 'empresas', component: ListaEmpresaComponent },
    { path: 'empresas/configuracion', component: ConfiguracionComponent },
    { path: 'administracion',  component: AdministracionComponent},
    { path: 'adminempresas', component: EmpresasComponent },
    { path: 'adminusuarios', component: AdministracionUsuariosComponent },
    { path: 'paginabaseadmin', component: PaginaBaseAdminComponent },
    { path: 'paginabaseoperacion/:idservicio', component: PaginaBaseOPeracionComponent },
    { path: 'adminempresas/:idempresa', component: AdministracionServiciosComponent },
    { path: 'adminlineasproduccion/:idlineaproduccion', component:  AdministracionLineasProduccionComponent },
    { path: 'adminequipos/:idequipo', component: AdministracionEquiposComponent },
    { path: 'servicio/:idservicio/importar/:idcoleccion', component: ETLComponent },
    { path: 'servicio/:idservicio/entrenar/:idmodelo', component: PredictionConfigComponent},
    { path: 'servicio/:idservicio/optimizer', component: OptimizerComponent }
];
