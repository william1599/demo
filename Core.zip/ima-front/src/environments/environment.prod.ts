export const environment = {
  production: "production"
};

